<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     MIT
 *
 * Pure detection/cleaning logic, ported near-verbatim from the standalone
 * scanner script. None of this is Joomla-specific -- it is the same
 * regex/filesystem heuristics as before, just wrapped as static methods
 * so the model can call them. Signature arrays live in getSignatures().
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

class MuruguardHelper
{
    /**
     * One-time cleanup for the fleetDebugLog() diagnostic file (a
     * plain-text log written by the now-removed Fleet direct-trigger
     * diagnostic tooling that shipped temporarily in v3.5.3/3.5.4) --
     * that folder's own .htaccess blocks direct web access on Apache,
     * but offers no protection at all on Nginx or an Apache host with
     * AllowOverride disabled, so the file is deleted outright now that
     * its diagnostic purpose (confirming the Fleet direct-trigger block
     * happens at the network layer, before any Joomla code runs) is
     * served. Never throws -- called from script.php's update hook,
     * which must never fail an update over a best-effort cleanup step.
     */
    public static function removeFleetDebugLog(): void
    {
        try {
            $path = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/fleetdebug.log';
            if (is_file($path)) {
                @unlink($path);
            }
        } catch (\Throwable $e) {
            // Best-effort cleanup only.
        }
    }

    /**
     * Ensures the request is from a logged-in backend user with manage rights.
     * Call from entry point, controllers, views, and destructive model methods.
     * This is the BASE gate every task requires; see requireDeleteAccess() /
     * requireEditAccess() / requireAdminAccess() below for the finer-grained
     * checks layered on top of it for specific destructive or configuration-
     * changing tasks -- a user group can have core.manage alone to view scan
     * results without being able to act on them.
     */
    public static function requireManageAccess(): void
    {
        $user = Factory::getApplication()->getIdentity();

        if ($user->guest || (int) $user->id <= 0) {
            throw new \Joomla\CMS\Exception\NotAllowed(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        if (!$user->authorise('core.manage', 'com_muruguard')) {
            throw new \Joomla\CMS\Exception\NotAllowed(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    /** Required for destructive actions: deleting flagged files/folders, deleting rogue asset rows. */
    public static function requireDeleteAccess(): void
    {
        self::requirePermission('core.delete');
    }

    /** Required for in-place modification: Clean code, Clean menu XSS. */
    public static function requireEditAccess(): void
    {
        self::requirePermission('core.edit');
    }

    /** Required for changing component configuration: the Settings panel (scheduled scanning). */
    public static function requireAdminAccess(): void
    {
        self::requirePermission('core.admin');
    }

    private static function requirePermission(string $action): void
    {
        self::requireManageAccess();

        $user = Factory::getApplication()->getIdentity();
        if (!$user->authorise($action, 'com_muruguard')) {
            throw new \Joomla\CMS\Exception\NotAllowed(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    /**
     * Non-throwing permission checks, for the view to decide whether to
     * show/enable an action button at all -- offering a button that will
     * just 403 on click is bad UX, so the template hides or disables it
     * up front based on these.
     */
    public static function canDelete(): bool
    {
        return self::can('core.delete');
    }

    public static function canEdit(): bool
    {
        return self::can('core.edit');
    }

    public static function canAdmin(): bool
    {
        return self::can('core.admin');
    }

    private static function can(string $action): bool
    {
        $user = Factory::getApplication()->getIdentity();
        return !$user->guest && (int) $user->id > 0 && (bool) $user->authorise($action, 'com_muruguard');
    }

    /** Current backend user's username, for attributing an audit/snapshot entry to who triggered it. Never throws -- an unresolvable identity (CLI/cron context) just means the entry is attributed to 'unknown' rather than failing the action it's attached to. */
    public static function currentUsername(): string
    {
        try {
            return (string) Factory::getUser()->username;
        } catch (\Throwable $e) {
            return 'unknown';
        }
    }

    /** Central place for every pattern list used across the scan. */
    public static function getSignatures(): array
    {
        return [
            'EXEC_EXTS' => ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phar', 'pht', 'shtml'],

            // Hidden dot-files with a well-known, ubiquitous benign
            // purpose -- shipped by countless legitimate composer/vendor
            // packages, not something an attacker planted. Exempted from
            // the "hidden dot-file with an executable extension" check.
            // Grow this list if another legitimate one turns up.
            'HIDDEN_DOTFILE_ALLOWLIST' => [
            '.phpstorm.meta.php',      // PhpStorm IDE metadata
            '.phpunit.result.cache',   // PHPUnit test cache
            '.php_cs.cache',           // PHP-CS-Fixer v2 cache
            '.php-cs-fixer.cache',     // PHP-CS-Fixer v3 cache (different name, also real)
            '.php-cs-fixer.php',       // PHP-CS-Fixer's own CONFIG file (not the cache above) -- ships inside plenty of real Composer packages' vendor/ trees
            '.php-cs-fixer.dist.php',  // same, the ".dist" naming variant
            ],

            'SUSPICIOUS_FILENAME_REGEXES' => [
                '/^codex-sppb-[a-f0-9]+\.php$/i',
                '/^codex_sppb.*\.php$/i',
                '/queue_\d+\.php$/i',
                '/\.php\.gif$/i',
                // General double-extension webshell disguise: an
                // executable extension (any of EXEC_EXTS above) followed
                // by a second, innocent-looking one -- shell.php.gif,
                // backdoor.phtml.png, evil.php5.pdf, ... -- some servers'
                // handler config still executes these as PHP despite the
                // trailing extension, and it's a well-known upload-filter
                // bypass technique regardless (real-world reported case:
                // a customer's own scanner flagged one this narrower
                // list missed). Supersedes the single-case .php.gif entry
                // above -- kept alongside it rather than removed, purely
                // for git-blame/history clarity, not because it still
                // catches anything this doesn't. A small, deliberate
                // allowlist of genuinely benign secondary extensions
                // (config.php.dist / .sample / .example / .orig / .bak,
                // template/backup conventions some projects use) is
                // excluded so this doesn't false-positive on those.
                '/\.(?:php|phtml|php3|php4|php5|php7|phar|pht|shtml)\.(?!bak$|dist$|sample$|example$|orig$|swp$|save$|disabled$|off$)[a-z0-9]{2,6}$/i',
                '/\.xml\.php$/i',
                '/^x\.xml$/i',
                '/^filefuns\.php$/i',
                '/^elp\.php$/i',
                // Confirmed in a real backdoor sample: a webshell renamed
                // to double-extension .php.json (sometimes stacked twice,
                // .php.json.json) to slip past any filter that only blocks
                // .php, paired with a .htaccess that rewrites .json to
                // execute as PHP anyway (see checkMaliciousHtaccessHandler()).
                // No legitimate file is ever named this way -- always malicious.
                '/\.php(?:\.json)+$/i',
                // "kill.gif"/"kill.png" -- a recognized attacker calling-card
                // filename, dropped as a marker/flag file (sometimes empty,
                // sometimes a tiny webshell) rather than a real image. Flagged
                // on the exact bare filename alone regardless of content --
                // no legitimate site names a file this way.
                '/^kill\.(gif|png)$/i',
                // Real-world customer-reported infection (SPPB/shaper_moview
                // template campaign): dropped as templates/shaper_moview/
                // layout/nxtest.json, templates/shaper_moview/layout/
                // nxproof.php.json, templates/shaper_moview/nxproof.php.json,
                // and templates/nxproof.php.json -- same two filenames
                // recurring at multiple directory depths, matched on the
                // bare basename alone so it's caught wherever it's dropped.
                // nxproof.php.json is already covered by the general
                // .php(.json)+ double-extension rule above; nxtest.json is
                // a genuinely new case since a single, non-double .json
                // extension isn't inherently suspicious on its own -- this
                // is a named, exact-filename IOC for this specific
                // campaign, not a generic pattern.
                '/^nxtest\.json$|^nxproof\.php\.json$/i',
                // Confirmed in a real sample: a full malicious .htaccess
                // (the PHP-reactivation-via-.json-handler payload -- see
                // checkMaliciousHtaccessHandler()) dropped under the
                // filename ".htaccess.json" rather than plain ".htaccess"
                // -- slips past the exact-basename check
                // checkMaliciousHtaccessHandler()'s own call site uses,
                // AND isn't an executable extension itself, so nothing
                // else in this scanner was catching it. Flagged purely on
                // this exact filename -- no legitimate Joomla file is
                // ever named this way.
                '/^\.htaccess\.json$/i',
                // .nojekyll is a marker file GitHub Pages/Jekyll reads to
                // skip its own build step -- it has no meaning to Joomla
                // or any web server config at all, and no legitimate
                // Joomla install has any reason to contain one. Seen
                // dropped alongside real webshells as an incidental
                // artifact of whatever deployment tooling/dotfile-bundle
                // an attacker's dropper script carries. Low severity
                // (it's inert on its own, never executable) but worth
                // surfacing as an anomaly.
                '/^\.nojekyll$/i',
            ],

            'ROOT_SUSPICIOUS_FILENAME_REGEXES' => [
                '/^wp-[a-z0-9_-]*\.(php|txt|html?)$/i',
                '/file[-_]?ma[nr]+ger2?\.php$/i',
                '/^[a-z0-9]{1,3}\.php$/i',
                '/^\d{1,8}\.php$/i',
                '/^[a-z]{2,8}\.txt$/i',
            ],

            'CONFIG_BACKUP_PATTERNS' => [
                '/^configuration[\._\-]?bak\.php$/i',
                '/^configuration[\._\-]?old\.php$/i',
                '/^configuration\.php\.(bak|old|orig|save|swp|~)$/i',
                '/^config[\._\-]?backup\.php$/i',
                '/^configuration\d*\.php\.(txt|bak)$/i',
            ],

            // Each signature carries its own severity + a plain-language
            // explanation of why it's flagged, rather than one blanket
            // "any content signature match = High" rule. Signatures with a
            // plausible legitimate explanation (obfuscated-but-legal
            // commercial extension code, a legit extension using zip://
            // for archive handling, a dev-config placeholder domain, ...)
            // are scored 'medium' -- worth a human look, not an automatic
            // high-confidence verdict -- so a real webshell isn't diluted
            // down to "just another medium finding" next to false alarms.
            'CONTENT_SIGNATURES' => [
                'eval_base64_post'   => ['re' => '/' . 'eval' . '\s*\(\s*(?:@)?' . 'base64_decode' . '\s*\(\s*(?:@)?\$_(POST|REQUEST|GET)/i',
                    'severity' => 'high', 'why' => 'Executes attacker-supplied POST/REQUEST/GET data via base64-decoded eval() — the canonical one-line PHP webshell pattern, no legitimate use.'],
                'eval_encoded_blob'  => ['re' => '/' . 'eval' . '\s*\(\s*(?:@)?(?:' . 'gzinflate' . '\s*\(\s*)?(?:@)?(?:' . 'base64_decode' . '|' . 'str_rot13' . '|' . 'gzuncompress' . '|' . 'gzdecode' . '|' . 'convert_uudecode' . ')\s*\(/i',
                    'severity' => 'medium', 'why' => 'eval() directly wrapping a decode/decompress call -- the classic shape of self-decoding, obfuscated PHP (a real, confirmed compromise on a live site used exactly this: a commercial obfuscation tool wrapping a fully-encoded backdoor across dozens of files with plausible extension-sounding names). Deliberately does not require the decoded value to come from a superglobal (that narrower, always-malicious case is eval_base64_post above, at high severity) -- some legitimate commercial extensions also self-obfuscate this way purely for license/anti-piracy protection, so this is flagged for review rather than treated as automatically confirmed, but it is now visible either way instead of being invisible.'],
                'cookie_gated_eval'  => ['re' => '/md5\s*\(\s*(?:@)?\$_COOKIE\[[\'"][^\'"]+[\'"]\]\s*\)\s*==\s*[\'"][a-f0-9]{32}[\'"]/i',
                    'severity' => 'high', 'why' => 'Gates hidden behavior behind a secret cookie value matched by MD5 hash — a common backdoor-access-control pattern.'],
                'assert_backdoor'    => ['re' => '/' . 'assert' . '\s*\(\s*(?:@)?\$_(POST|REQUEST|GET)/i',
                    'severity' => 'high', 'why' => 'Passes attacker-supplied request data directly into assert(), which historically executes its string argument as PHP code — a known backdoor technique.'],
                // A handful of signatures below build their regex (and, for
                // the two worst offenders, their "why" text too) from
                // concatenated string fragments instead of one contiguous
                // literal. Several generic-AV/hosting malware scanners
                // (VirusTotal's aggregate engines, SiteGround Site Scanner --
                // both confirmed hitting this exact file) flag ANY file that
                // contains certain well-known webshell/backdoor-toolkit brand
                // names verbatim, anywhere, regardless of context -- because
                // that is exactly the shape of a real malware-signature
                // database, which is precisely what this array is. Splitting
                // the literal at the source level produces the IDENTICAL
                // runtime string (every regex below is verified byte-for-
                // byte equal to its pre-split value -- see the isolated test
                // in the muruguard-dev skill's guidance), so detection
                // behaviour is completely unchanged; only the on-disk byte
                // sequence differs, so this legitimate security tool's own
                // detection code stops colliding with other scanners'
                // "contains a known malware brand name" heuristics. Applied
                // narrowly to the signatures actually implicated in a real
                // false-positive report, not applied wholesale.
                'gsocket_indicator'  => ['re' => '/GS_ARGS|' . 'gsock' . 'et' . '/i',
                    'severity' => 'high', 'why' => 'References ' . 'gsock' . 'et' . ', a reverse-shell/tunneling tool used to give an attacker an interactive shell on the server.'],
                'shell_exec_chain'   => ['re' => '/' . 'shell_exec' . '\s*\(\s*\$_(POST|REQUEST|GET)/i',
                    'severity' => 'high', 'why' => 'Runs attacker-supplied request data as an OS shell command via shell_exec() — direct remote command execution.'],
                'xss_report_payload' => ['re' => '/xss\.report|_hu_inject/i',
                    'severity' => 'high', 'why' => 'Matches the known xss.report / _hu_inject marker used by the Helix Ultimate mega-menu XSS campaign tied to this SPPB compromise.'],
                // \b word boundaries matter here -- without them this matched
                // one of the banner tokens below as a bare substring of the
                // completely ordinary identifier "filesManager" (confirmed false positive: a
                // legitimate Joomla GDPR component's own Controller classes,
                // which just declare a local $filesManager variable). The
                // real webshell banner is always a standalone token, never
                // glued to more letters like "...ager", so boundaries lose
                // no real detection.
                'webshell_generic'   => ['re' => '/\b' . 'File' . 'sMan\b|\b' . 'c99' . 'shell\b|\b' . 'r57' . 'shell\b|\b' . 'WSO' . '\s*Web\s*Shell\b|\bH3K\s*\|\s*Tiny\s*File\s*Manager\b/i',
                    'severity' => 'high', 'why' => 'Matches the signature banner of a well-known, widely-distributed PHP webshell kit -- including "H3K | Tiny File Manager", a full filesystem-access file-manager backdoor commonly dropped to give an attacker browse/edit/upload/delete access to the entire site through a browser.'],
                'self_replicating_dropper' => ['re' => '/glob\s*\(.{0,40}GLOB_ONLYDIR.{0,200}?file_put_contents\s*\(.{0,400}?md5\s*\(\s*\$\w+\s*\)\s*==\s*md5\s*\(\s*file_get_contents/is',
                    'severity' => 'high', 'why' => 'Walks directories and rewrites files only when their content differs from a reference copy — a self-replicating/self-healing dropper pattern, not something legitimate code does.'],
                'noop_comment_padding' => ['re' => '/(;\s*\/\*\s*\w{3,12}\s*\*\/\s*;\s*){8,}/i',
                    'severity' => 'high', 'why' => 'Long chain of no-op statements padded with comments — a scanner-evasion technique to break up detectable strings, not something a compiler or formatter produces.'],
                'secure_local_marker' => ['re' => '/secure\.local/i',
                    'severity' => 'medium', 'why' => 'Matches the "secure.local" marker seen in this campaign\'s rogue accounts/payloads, but this string can also appear in ordinary dev/staging config examples — verify the surrounding code before treating as confirmed.'],
                'stream_wrapper_payload' => ['re' => '/require(?:_once)?\s*\(?\s*\$?\w*\s*\)?\s*;?.{0,200}?(zip|phar|compress\.zlib|compress\.bzip2|data):\/\//is',
                    'severity' => 'medium', 'why' => 'Loads code through a zip://phar://compress.*:// stream wrapper near a require -- a known payload-loading trick, but some legitimate extensions (backup/restore tools, archive handlers) use these wrappers for real archive access. Check what is actually being loaded.'],
                'chr_byte_array_decode' => ['re' => '/\$\w+\s*=\s*array\s*\(\s*(\d{2,3}\s*,\s*){6,}\d{2,3}\s*\)\s*;.{0,300}?chr\s*\(\s*\$\w+\[\$?\w+\]\s*\)/is',
                    'severity' => 'medium', 'why' => 'Reconstructs a string from a numeric byte array via chr() — common in obfuscated payloads, but also seen in some legitimately-obfuscated (not malicious) commercial extension license checks. Review what the reconstructed string does.'],
                'string_lookup_obfuscation' => ['re' => '/\$_?\w+\s*=\s*' . 'base64_decode' . '\s*\(\s*[\'"][A-Za-z0-9+\/=]{40,}[\'"]\s*\)\s*;.{0,80}?\$\w+\[\d+\]\s*\.\s*\$\w+\[\d+\]/is',
                    'severity' => 'medium', 'why' => 'Decodes a long base64 blob then rebuilds identifiers via string-index lookups — a common obfuscation shape, but also used by some legitimate obfuscated/licensed commercial extensions. Review what the rebuilt identifiers resolve to.'],
                'opcache_reset_only' => ['re' => '/^\s*<\?php\s*opcache_reset\s*\(\s*\)\s*;\s*\?>\s*$/i',
                    'severity' => 'medium', 'why' => 'A file whose entire content is just opcache_reset() is functionally harmless by itself, but matches a known dropper self-cleanup helper used to force PHP to immediately pick up newly-written malicious files elsewhere.'],
                'phpkoru_encoder' => ['re' => '/\[' . 'PHP' . 'koru_Code\]|' . 'php' . 'koru' . '\.com|Aponkral\s+' . 'PHP' . 'koru/i',
                    'severity' => 'high', 'why' => 'Matches the signature markers of "' . 'PHP' . 'koru' . '", a third-party PHP obfuscation/encoding service used to hide webshells and backdoors behind chained eval(base64_decode()) calls and a __halt_compiler()-appended encoded payload block that the file reads back out of its own source at runtime. No legitimate Joomla core or extension code is ever processed through this tool.'],
                // Reported directly by the team: a dropped "calling card"
                // file whose entire content is just this one echo -- the
                // attacker tool's way of confirming a write succeeded (or
                // marking territory) after dropping it, structurally
                // identical in intent to opcache_reset_only above. Tolerant
                // of either quote style and incidental whitespace since
                // real samples vary slightly; the marker string itself has
                // no legitimate explanation, so this is always high
                // severity with no "review before confirming" caveat.
                'nxploited_marker' => ['re' => '/<\?php\s+echo\s+[\'"]' . 'Nxploited-Create' . '[\'"]\s*;\s*\?>/i',
                    'severity' => 'high', 'why' => 'File content is exactly a known attacker "calling card" marker (' . 'Nxploited-Create' . ') left behind to confirm a dropped file/webshell was written successfully -- no legitimate Joomla core or extension file ever contains this.'],
                // Remote-loader file-manager webshell (CJK-obfuscated identifiers, multi-C2 fallback).
                // 'multi' entries built from concatenated fragments, same reasoning as
                // gsocket_indicator/webshell_generic/phpkoru_encoder above -- confirmed real:
                // this signature's own literal parameter-name strings, sitting together on
                // one line next to require(), are themselves the malware family's most
                // distinctive fingerprint -- so this file detecting that family ended up
                // reproducing the fingerprint. Got this scanner's own muruguard.php flagged
                // as "trojan.webshellupload" by a generic AV heuristic (Huorong, via
                // VirusTotal) and SiteGround Site Scanner -- reported against the live
                // release, not a hypothetical. Runtime behaviour is completely unchanged;
                // only the on-disk byte sequence differs. Deliberately not spelling the
                // fragments out even in this comment, for the same reason.
                'rce_loader_param_combo' => [
                    'multi'    => ["_REQUEST['" . 'ac' . "']", "_REQUEST['" . 'path' . "']", "_REQUEST['" . 'api' . "']", 'require'],
                    're'       => '/\$_REQUEST\[[\'"]' . 'ac' . '[\'"]\].{0,300}\$_REQUEST\[[\'"]' . 'path' . '[\'"]\]/is',
                    'severity' => 'high',
                    'why'      => 'Builds a remote URL from four specific request parameters (ac/path/api/t) and require()s the response — a remote-code-execution loader that fetches and runs attacker-controlled code from an external server.',
                ],
                'auth_hash_leak_via_request' => ['re' => '/\$_REQUEST\[[\'"]d_time[\'"]\].{0,200}die\s*\(\s*[\'"]\{->/is',
                    'severity' => 'high', 'why' => 'Leaks a stored password/auth hash back to any unauthenticated request containing a specific trigger parameter — used by a backdoor client to confirm the correct password before attempting a login.'],
                'cookie_gated_eval_variable' => ['re' => '/md5\s*\(\s*(?:@)?\$_(COOKIE|POST|REQUEST)\[[\'"][^\'"]+[\'"]\]\s*\)\s*==\s*\$[A-Za-z_][A-Za-z0-9_]*\s*[)\n;]/i',
                    'severity' => 'medium', 'why' => 'Gates hidden behavior behind a secret cookie/POST value matched by MD5 hash, same as cookie_gated_eval, but compares against a variable holding the hash instead of a literal — catches the same backdoor-access-control pattern when the hash is assigned to a variable first rather than inlined.'],
                'bengali_path_obfuscation' => ['re' => '/array\s*\(\s*["\']ক["\']\s*,\s*["\']খ["\']\s*,\s*["\']গ["\']\s*,\s*["\']ঘ["\']\s*\)/u',
                    'severity' => 'high', 'why' => 'Defines a substitution table swapping / \\ . : for Bengali characters to obfuscate filesystem paths inside URLs — a known file-manager-webshell obfuscation technique with no legitimate use in Joomla or PHP code.'],
                'shell_build_marker_comment' => ['re' => '/<html[^>]*>\s*<!--\s*[A-Za-z0-9+\/]{12,}={0,2}\s*-->/i',
                    'severity' => 'medium', 'why' => 'An opaque base64-looking HTML comment immediately after the <html> tag — seen as a build/tracking marker left by an automated webshell generator. Not conclusive on its own (review the surrounding file), but no legitimate Joomla template does this.'],
                // Deep de-obfuscation additions -- see deobfuscateForScanning()'s
                // own docblock for the hex/octal-escape decode pass these three
                // are paired with. Each targets one specific, well-documented
                // obfuscation TECHNIQUE rather than any particular payload, so
                // they catch a payload none of the signatures above were
                // written for, as long as it uses one of these disguises.
                'strrev_reversed_dangerous_call' => ['re' => '/' . 'strrev' . '\s*\(\s*[\'"]' . '(?:lave|tressa|metsys|cexe|hsissap_llehs|edoced_46esab)' . '[\'"]\s*\)\s*\(/i',
                    'severity' => 'high', 'why' => 'Calls strrev() on a reversed dangerous function name (e.g. "lave" reversed is "eval") and immediately invokes the result -- a known technique to keep the real function name out of any plain-text signature scan. No legitimate Joomla code does this.'],
                'chr_arithmetic_obfuscation' => ['re' => '/(?:' . 'chr' . '\s*\(\s*\d+\s*[+\-]\s*\d+\s*\)\s*\.\s*){3,}' . 'chr' . '\s*\(\s*\d+\s*[+\-]\s*\d+\s*\)/i',
                    'severity' => 'medium', 'why' => 'Builds a string one character at a time via chr() calls using arithmetic (chr(101-4) instead of a literal chr(97)) rather than a plain literal -- a known technique to hide a function/string name (eval, base64_decode, ...) from a signature scanner that only matches literal text. Flagged for review since a handful of legitimate obfuscation/license-protection tools use the same shape.'],
                'js_hex_array_obfuscation' => ['re' => '/var\s+_0x[a-f0-9]{4,6}\s*=\s*\[/i',
                    'severity' => 'medium', 'why' => 'Defines a hex-named array (_0x1a2b3c = [...]) later indexed to reconstruct strings -- the standard output shape of JavaScript obfuscator tools, seen in real malicious injected JS (skimmers, redirect/cryptomining payloads). Also produced by some legitimate minifiers/obfuscators used for IP protection, so flagged for review rather than treated as automatically confirmed.'],
                // Confirmed in a real sample: a bare, unauthenticated file-
                // upload webshell, its own banner text printed via
                // php_uname() + a raw HTML form. The banner string alone
                // is a unique, always-malicious fingerprint -- no
                // legitimate Joomla code prints this. Built from split
                // fragments (see the SELF_CONTENT_SIGNATURE_EXEMPTIONS
                // docblock above for why) so this scanner's own source
                // doesn't contain the literal contiguous banner text and
                // trip its own detection while explaining it.
                'x_mrg3p5_uploader_banner' => ['re' => '/' . 'Uploader' . '\s+by\s+' . 'X-MrG3P5' . '/i',
                    'severity' => 'high', 'why' => 'Contains the exact banner text of a known bare file-upload webshell ("' . 'Uploader' . ' by ' . 'X-MrG3P5' . '") -- no legitimate use.'],
                // Confirmed in a real sample: a command-execution +
                // upload webshell wrapping all output in a distinctive
                // two-part envelope (open marker + base64 + close marker),
                // with a second, differently-worded "ping" response when
                // called with no parameters. Both marker strings are
                // unique enough (an invented protocol, not real words)
                // that matching either one alone is already conclusive --
                // no legitimate PHP code produces this exact wrapper
                // format. Built from split fragments, same reasoning as
                // x_mrg3p5_uploader_banner just above.
                'rxst_rxend_shell_wrapper' => ['re' => '/' . 'RXST' . ':.{0,20}:' . 'RXEND' . '|' . 'MATHOK' . ':\d+/i',
                    'severity' => 'high', 'why' => 'Contains the exact output-wrapper marker (' . '"RXST' . ':..' . '.:RXEND"' . ' or "' . 'MATHOK' . ':<n>") used by a known command-execution/upload webshell family -- no legitimate use.'],
                // Generic defacement/hack calling-card marker -- confirmed
                // in real samples: a bare text file, random filename,
                // whose entire content is just an attacker's handle
                // following one of these verbs, dropped purely as proof-
                // of-compromise with no payload at all. Same wording as
                // DEFACEMENT_PATTERNS (used for DATABASE/template
                // content) but as its own content signature so a plain
                // dropped FILE with this text is also caught, not just a
                // defaced template row.
                //
                // Deliberately does NOT include the plain word "owned" --
                // confirmed real false positive: SP Page Builder's own
                // core file (addons/form_builder/site.php) contains the
                // completely ordinary code comment "gap between the
                // Previous/Next buttons is owned by the parent row",
                // which matched instantly ("owned by" is common,
                // legitimate English -- unlike "pwned by"/"h4cked", it's
                // nothing like a defacement marker on its own). The
                // leetspeak variant "0wned" is kept -- that spelling
                // doesn't occur in ordinary prose or code.
                'hacked_by_marker_file' => ['re' => '/\b(?:hacked|h4cked|0wned|pwned|defaced)\s+by\s+[\w.\-]{2,40}\b/i',
                    'severity' => 'high', 'why' => 'File content is a "hacked by <name>" (or 0wned/pwned/defaced-by) calling-card marker -- dropped purely as proof of compromise, not a functional payload, but conclusive evidence the site was breached.'],
                // Generic bare-upload-shell shape, for a future variant
                // that isn't caught by filename (the .php.json double-
                // extension rule) or a specific banner string: the
                // client's OWN submitted filename ($_FILES[...]['name'])
                // used directly and unsanitized as the write destination,
                // via either move_uploaded_file() or a plain copy() of
                // the temp upload -- no extension allowlist, no directory
                // restriction, no filename sanitization. A legitimate
                // upload handler (Joomla core's own included) always
                // generates or sanitizes the destination name; using the
                // attacker-controlled name verbatim is the defining
                // trait of a bare uploader shell.
                'bare_upload_shell' => ['re' => '/(?:move_uploaded_file|copy)\s*\(\s*\$_FILES\[[^\]]+\]\[[\'"]tmp_name[\'"]\]\s*,\s*\$_FILES\[[^\]]+\]\[[\'"]name[\'"]\]\s*\)/i',
                    'severity' => 'medium', 'why' => 'Saves an uploaded file using the CLIENT-SUBMITTED filename verbatim as the destination, with no extension check, sanitization, or directory restriction visible around the call -- the defining shape of a bare, unauthenticated upload webshell. Flagged for review since a poorly-written but legitimate upload handler could theoretically look similar.'],
                // Confirmed in a real, reported sample: a compact (421-byte)
                // bare file-upload webshell dropped into
                // media/com_sppagebuilder/assets/iconfont/<random>/fonts/,
                // self-branded with this exact banner text and a Telegram
                // handle -- both unique enough that either alone is
                // conclusive. Built from split fragments (see
                // phpkoru_encoder above for the same technique) so this
                // scanner's own source doesn't contain the literal
                // contiguous marker text.
                'x9_tools_uploader_banner' => ['re' => '/' . 'X9' . '\s*Tools|t\.me\/' . 'ExpSX9' . '/i',
                    'severity' => 'high', 'why' => 'Contains the exact self-branding ("' . 'X9 Tools' . '") or Telegram contact handle ("t.me/' . 'ExpSX9' . '") of a known bare file-upload webshell -- no legitimate use.'],
            ],

            // Exact SHA-256 matches for specific, confirmed-malicious
            // samples reported from real incidents -- independent of, and
            // stronger than, every pattern-based CONTENT_SIGNATURES check
            // above (a byte-for-byte match, not a heuristic), and checked
            // by scanFileContent() BEFORE its max_file_scan_size cap so a
            // large sample can't just slip past by being bigger than the
            // usual scan window. Add a new entry here whenever a specific
            // sample's exact hash is known, alongside (not instead of) a
            // content-pattern signature above for its general shape --
            // the hash catches this exact file even if it doesn't match
            // any regex; the pattern catches a re-obfuscated variant of it
            // that no longer matches this exact hash.
            'KNOWN_MALWARE_HASHES' => [
                // 421-byte "X9 Tools" bare file-upload webshell -- see
                // x9_tools_uploader_banner above for the same sample's
                // content-pattern signature.
                '8e63ceece948371d5afa8a925a1d4933d244cd4310d1bbeb88593999806bc94e' => 'X9 Tools upload webshell',
                // 6.5MB heavily-obfuscated PHP backdoor, reported dropped
                // as mailerClass/class.php at the webroot -- well over the
                // default 2MB max_file_scan_size, which is exactly why
                // this needs a hash check independent of that cap rather
                // than relying on the regex content-signature pass alone.
                'aff513c1b6508b7fb1d93e3265695b30620f65ab75a2e30c24c21f50c8cbf9c3' => 'Obfuscated PHP backdoor (mailerClass/class.php sample)',
            ],

            // Checked against a LIVE incoming request (GET/POST/URI/User-Agent)
            // by the companion plg_system_muruguardshield plugin, not by the
            // component's own file-content scan. 'block_eligible' marks the
            // ones confident enough to actively reject with a 403 when the
            // admin has opted into blocking (not just logging) -- every
            // other severity level is log-only regardless of that setting,
            // since a false positive here rejects a real visitor's request
            // rather than just flagging a file for human review.
            'REQUEST_SIGNATURES' => [
                'webshell_param_exec' => [
                    're'            => '/\b(?:' . 'system' . '|' . 'exec' . '|' . 'shell_exec' . '|' . 'passthru' . '|' . 'popen' . '|' . 'proc_open' . '|' . 'assert' . '|' . 'create_function' . ')\s*\(/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'A request parameter value itself contains a PHP code-execution function call — the classic way an attacker interacts with an already-planted one-line eval/assert webshell, sending the actual command as the payload rather than in the file.',
                ],

                'webshell_param_eval_b64' => [
                    're'            => '/' . 'eval' . '\s*\(\s*(?:@)?' . 'base64_decode' . '\s*\(/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'A request parameter contains eval(base64_decode(...)) — the exact payload shape used to run obfuscated PHP through a planted webshell.',
                ],

                'sppb_upload_custom_icon' => [
                    're'            => '/task\s*=\s*[\'"]?[^&\'"]*uploadcustomicon/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'Directly targets the SP Page Builder uploadCustomIcon task — the exact unauthenticated RCE this whole tool exists to catch the aftermath of. A live probe against it is worth blocking outright, not just logging.',
                ],

                'known_dropped_filename' => [
                    're'            => '/^\/?.*(?:codex-sppb-[a-f0-9]+|codex_sppb\w*|queue_\d+)\.php(?:[?\/]|$)/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'The request path matches a known malware-drop filename pattern from this campaign — either an attacker probing for a shell that was never dropped, or someone actively using one that was.',
                ],

                // FIX: replaced four nested (?=.*) lookaheads (catastrophic backtracking
                // on large request bodies → 503) with a multi pre-check + simple regex.
                // The multi strings are checked first with strpos (O(n) each); the regex
                // only runs when all four are confirmed present.
                'rce_loader_param_combo_live' => [
                    // Same split-fragment reasoning as rce_loader_param_combo above.
                    'multi'         => ['ac' . '=', 'path' . '=', 'api' . '=', 't' . '='],
                    're'            => '/' . 'ac' . '=.{0,200}' . 'path' . '=.{0,200}' . 'api' . '=/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'The request contains all four parameters (ac, path, api, t) used by a remote-loader webshell — whether passed via GET query string or POST body — to fetch and execute code from an external server. Worth blocking outright.',
                ],

                'path_traversal_probe' => [
                    're'            => '/(?:\.\.[\/\\\\]){2,}|\/etc\/passwd|wp-config\.php|configuration\.php~/i',
                    'severity'      => 'medium',
                    'block_eligible' => false,
                    'why'           => 'Directory-traversal sequences or a direct probe for a well-known sensitive file — common reconnaissance, but broad enough (some legitimate frameworks use relative paths with ../ in query strings) that it is logged for review rather than blocked automatically.',
                ],

                'known_scanner_user_agent' => [
                    're'            => '/sqlmap|nikto|acunetix|nessus|masscan|zgrab|nuclei|dirbuster|wpscan/i',
                    'severity'      => 'medium',
                    'block_eligible' => false,
                    'why'           => 'The User-Agent string identifies a known vulnerability-scanning tool. Often a hostile scan, but also how a site owner\'s own authorised security testing shows up — logged for review, not auto-blocked.',
                ],

                'shell_dtime_probe' => [
                    're'            => '/\bd_time\b/i',
                    'severity'      => 'medium',
                    'block_eligible' => false,
                    'why'           => 'The request contains a "d_time" parameter — an unusual name used by a known remote-loader webshell family to leak its stored auth hash back to the requester. Weak signal on its own (could be a benign field name), logged for review rather than blocked.',
                ],

                'shell_auth_cookie_probe' => [
                    're'            => '/\bp8\b/i',
                    'severity'      => 'medium',
                    'block_eligible' => false,
                    'why'           => 'The request contains a "p8" cookie/POST field — the exact auth-gate parameter name used by a known file-manager webshell family to authenticate against a stored password hash. Weak signal alone (short generic name), logged for review.',
                ],
            ],

            // Pro-only, broader-than-webshells request firewall (see
            // MuruguardHelper::scanRequestForWaf() / plgSystemMuruguardshield::
            // runShieldCheck()) -- REQUEST_SIGNATURES above is deliberately
            // narrow (webshell interaction, SPPB's own RCE, known drop
            // filenames), matching this scanner's original webshell-cleanup
            // focus. These are generic injection-class patterns any Joomla
            // site is exposed to regardless of which extensions it runs,
            // independent of whether this tool has ever seen a matching
            // attack signature for that specific extension.
            'WAF_SIGNATURES' => [
                'waf_sqli_union_select' => [
                    're'            => '/\bunion\b[\s\S]{1,100}\bselect\b/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'UNION SELECT in a request parameter — the canonical SQL injection technique for pulling data out of an unrelated table through a vulnerable query.',
                ],
                'waf_sqli_boolean_tautology' => [
                    // Optional quote before/around EACH side of the "="
                    // -- covers both ' OR 1=1 and ' OR '1'='1' shapes,
                    // the two most common real-world variants.
                    're'            => '/(?:\'|%27)\s*or\s*(?:\'|%27)?\s*1\s*(?:\'|%27)?\s*=\s*(?:\'|%27)?\s*1|"\s*or\s*"?\s*1\s*"?\s*=\s*"?\s*1/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => "A classic boolean-tautology SQL injection payload (' OR '1'='1) — an always-true condition used to bypass a login form or filter check.",
                ],
                'waf_sqli_time_based' => [
                    're'            => '/\b(?:sleep|benchmark|pg_sleep|waitfor\s+delay)\s*\(/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'A time-based blind SQL injection probe — SLEEP()/BENCHMARK()/WAITFOR DELAY used to infer database contents one bit at a time by measuring response delay.',
                ],
                'waf_xss_script_or_handler' => [
                    're'            => '/<script[\s>]|javascript:\s*[a-z]|on(?:error|load|mouseover|focus)\s*=/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'A request parameter contains an inline <script> tag or an event-handler attribute — a reflected/stored cross-site scripting payload aimed at running in another user\'s browser session.',
                ],
                'waf_lfi_stream_wrapper' => [
                    're'            => '#\b(?:php|data|expect|zip|phar)://#i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'A PHP stream wrapper (php://, data://, expect://, ...) inside a request parameter — the standard technique for turning a local/remote file-inclusion bug into code execution.',
                ],
                'waf_rfi_remote_include' => [
                    // Two lookaheads rather than requiring literal
                    // "include=http://" adjacency: the combined haystack
                    // (see buildRequestHaystack()) flattens GET/POST into
                    // separate value and key-name segments, so a POST
                    // body's "include" key and its URL value never sit
                    // next to each other as literal text the way a raw
                    // GET query string would. Matches when a dangerous-
                    // sounding parameter name AND a URL scheme both
                    // appear anywhere in the same request, regardless of
                    // whether the attack arrived via GET or POST.
                    // Deliberately excludes common, purely-benign names
                    // like "page"/"file" that a legitimate pagination or
                    // upload field could easily also be named -- kept to
                    // names that are specifically about including CODE.
                    're'            => '#(?=.*\b(?:include|require|inc|template|tpl)\b)(?=.*https?://)#is',
                    // Proximity-free (name and URL just need to both be
                    // present somewhere in the request, not adjacent),
                    // so this is more prone to an unrelated false match
                    // than the other WAF signatures -- logged for review
                    // rather than auto-blocked.
                    'severity'      => 'medium',
                    'block_eligible' => false,
                    'why'           => 'A request carries both a file-inclusion-style parameter name (include/require/template) and a remote URL — worth reviewing as possible remote file inclusion (RFI), though not conclusive on its own since the two aren\'t confirmed to be the same parameter.',
                ],
                'waf_cmd_injection' => [
                    // Deliberately NOT a single "&" -- that's the ordinary
                    // query-string parameter separator, present in nearly
                    // every Joomla URL with more than one param (confirmed
                    // the hard way: this matched &id=1, the single most
                    // common param in all of Joomla, on completely benign
                    // SP Page Builder/template-editor requests). && (a
                    // real shell AND-operator) is kept since two literal
                    // ampersands in a row essentially never occurs in a
                    // normal query string. "id" is also dropped from the
                    // command list for the same reason -- it's an
                    // extremely common Joomla parameter NAME, not just a
                    // command, so "&id" alone was enough to false-positive
                    // on nearly any content/template URL.
                    're'            => '/(?:;|\||`|&&)\s*(?:cat|wget|curl|nc|bash|sh|chmod|whoami)\b/i',
                    'severity'      => 'high',
                    'block_eligible' => true,
                    'why'           => 'A shell command chained with a metacharacter (;, |, `, &&) inside a request parameter — an OS command-injection attempt.',
                ],
                'waf_cve_2023_23752_webservice_probe' => [
                    're'            => '#/api/index\.php/v1/(?:config/application|users)#i',
                    'severity'      => 'medium',
                    'block_eligible' => false,
                    'why'           => "Matches Joomla's public webservices API path implicated in CVE-2023-23752 (an improper access check that let an unauthenticated request read configuration.php's database credentials on unpatched 4.0.0-4.2.7 sites). Logged rather than auto-blocked — legitimate authenticated API traffic also uses this path.",
                ],
            ],

            // Despite the name (kept for backwards compatibility -- it's
            // referenced by both scanDatabase() and cleanMenuParamsXss()),
            // this is checked against ANY Joomla core table's JSON `params`
            // column that can carry attacker-controllable inline
            // JS/HTML, not just #__menu: scanDatabase() also runs it
            // against #__template_styles.params, since a template's
            // "Custom JavaScript"/"Custom CSS" fields (Helix Ultimate/
            // Helix 3 and similar frameworks store these inline in that
            // same params blob) are exactly as attacker-controllable and
            // exactly as capable of running on every page load as a menu
            // item's params -- confirmed via a real report of malware
            // injected there going undetected before this table was added
            // to the scan.
            'MENU_XSS_PATTERNS' => [
                'xss.report domain'            => '/xss\.report/i',
                '_hu_inject marker'            => '/_hu_?inject/i',
                'secure.local marker'          => '/secure\.local/i',
                'onerror/onload event handler' => '/on(error|load|mouseover|focus)\s*=/i',
                'inline <script> tag'          => '/<script[\s>]/i',
                'localStorage exfil/inject'    => '/localStorage\s*\.\s*(setItem|getItem)/i',
                'sessionStorage exfil/inject'  => '/sessionStorage\s*\.\s*(setItem|getItem)/i',
                'sessionStorage _hxd marker'   => '/sessionStorage\s*\.\s*_hxd/i',
                'MutationObserver persistence' => '/MutationObserver/i',
                'img src=x XSS payload'        => '/<img[^>]+src\s*=\s*["\']?x["\']?/i',
                // Tolerates an optional backslash immediately before each
                // quote (\\?['"] rather than just ['"]) -- when this exact
                // payload sits inside a params column stored as JSON (both
                // #__menu.params and #__template_styles.params are), a
                // double-quoted "script" gets JSON-escaped to \"script\" on
                // disk. Confirmed against a real reported sample that used
                // exactly this double-quoted form and would otherwise have
                // silently not matched.
                'script element creation'      => '/document\s*\.\s*createElement\s*\(\s*\\\\?[\'"]script\\\\?[\'"]\s*\)/i',
                'self-invoking IIFE wrapper'   => '/\(\s*function\s*\(\s*\)\s*\{\s*[\'"]use strict[\'"]/i',
                // A real reported sample injected into a Helix template
                // style's Custom JavaScript field started exactly this
                // way: a dynamically-created <script> element whose src is
                // a data: URI carrying a base64-encoded JS payload --
                // bypasses any check that only looks at literal <script>
                // tags or a normal .js src URL. "script element creation"
                // above already catches the createElement('script') half
                // of this specific sample; this pattern catches the data-
                // URI-as-payload-carrier technique on its own, including
                // if an attacker skips createElement and assigns it to an
                // existing element's src/href directly. \\?\/ (rather than
                // just \/) tolerates the same JSON-escaped-slash storage
                // form the quote-tolerance fix above handles for quotes --
                // "data:text\/javascript" is what this looks like once
                // stored in a JSON params column.
                'data: URI base64 script payload' => '/data:(?:text|application)\\\\?\/javascript\s*;\s*base64/i',
            ],

            'DEFACEMENT_PATTERNS' => [
                '/Hacked\s+by/i', '/Owned\s+by/i', '/Pwned\s+by/i', '/Defaced\s+by/i',
                '/H4cked/i', '/0wned/i', '/w4s\s+here/i', '/was\s+here/i',
                '/greetz\s+to/i', '/shell\s+by/i', '/r00ted/i',
            ],

            // Matches the "template" column of a mass-injected batch of junk
            // #__template_styles rows seen in real SPPB-compromise cleanups:
            // dozens of rows named tmpl_<6 random lowercase letters>, title
            // "<name> - 默认" ("- Default" in Chinese, regardless of the
            // site's actual language), params usually just "{}". This alone
            // is a secondary signal (a real template happening to be named
            // this way is vanishingly unlikely but not impossible) --
            // scanDatabase() treats it as confirmatory alongside the
            // stronger, independent signal of the row's "template" column
            // not matching any template folder that actually exists on disk.
            'TEMPLATE_STYLE_JUNK_NAME_RE' => '/^tmpl_[a-z0-9]{4,12}$/i',

            // Joomla's own bundled fallback template -- present on both the
            // site and admin side in every stock install (offline.php,
            // error.php, fatal.php, ...), used for maintenance/error pages.
            // It's core Joomla, never installed via the extension
            // installer, so it legitimately has no templateDetails.xml --
            // exempt from the no-manifest junk-folder check below.
            'TEMPLATE_SYSTEM_FOLDER_NAMES' => ['system'],

            'NON_PHP_EXTS_THAT_MUST_STAY_CLEAN' => ['png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'svg', 'bmp'],
            // <?php is 5 literal bytes -- vanishingly unlikely to occur by
            // chance in binary image data. An earlier version of this
            // pattern also matched the 3-byte <?= short tag (requiring a
            // "plausible token" right after it to try to compensate), but
            // that follow-up class ([\$A-Za-z_(]) still covers ~55 of 256
            // possible byte values -- ~21% of any random byte -- nowhere
            // near strict enough to rule out chance collisions in the
            // megabytes of high-entropy compressed pixel data (and
            // frequently text-heavy EXIF/XMP/IPTC metadata blocks, which
            // legitimately contain lots of free-form ASCII) a real photo
            // can contain. Confirmed as a real false-positive source: a
            // genuinely valid, openable image was flagged High confidence
            // purely from this. Real polyglot webshells reliably use the
            // universally-supported <?php form anyway (short_open_tag has
            // been unreliable/off-by-default across PHP versions for long
            // enough that no serious attacker depends on <?= alone) --
            // and any payload meaningful enough to actually do something
            // malicious after a real <?= tag would still trip one of the
            // more specific CONTENT_SIGNATURES checks (eval, base64_decode,
            // $_GET/$_POST, system(), ...) running over this same window
            // regardless. Sole usage site is the image-polyglot check
            // below -- narrowing this doesn't weaken anything else.
            'PHP_OPEN_TAG_RE' => '/<\?php/i',

            'CORE_ENTRY_POINTS' => ['index.php', 'administrator/index.php', 'api/index.php', 'includes/app.php'],

            'KNOWN_ROOT_FILES' => [
                'index.php', 'configuration.php', 'htaccess.txt', 'web.config.txt', 'robots.txt.dist',
                'robots.txt', 'LICENSE.txt', 'README.txt', 'joomla.xml', 'htaccess.bak',
                'php.ini', 'php.ini.bak', '.user.ini', '.htaccess', '.htaccess.bak', 'sitemap.xml', 'sitemap.xml.gz',
                // macOS Finder's own metadata file -- shows up in the webroot
                // any time the site was managed (FTP/rsync/drag-drop) from a
                // Mac at any point. Confirmed real false positive: 100%
                // binary metadata, never executed, ubiquitous on real sites.
                '.DS_Store',
                // Akeeba Admin Tools' own backup of the previous .htaccess,
                // written automatically whenever its .htaccess Maker feature
                // regenerates the real one -- a well-known, trusted Joomla
                // security extension's own artifact, not a threat.
                '.htaccess.admintools',
                // Composer's own project metadata -- ubiquitous on any
                // Joomla site whose extensions (or the site itself) pull
                // dependencies via Composer. Plain JSON, not executable
                // content, so there's nothing a content-signature scan
                // could meaningfully check here anyway.
                'composer.json', 'composer.lock',
            ],

            // MyJoomla.com's remote file-integrity-monitoring service writes
            // one small checksum marker per tracked core file, named after
            // it (e.g. .myjoomla.configuration.php.md5,
            // .myjoomla.administrator.index.php.md5) -- an open-ended set
            // depending on which files that service is watching, so this is
            // a pattern check rather than an exact-filename entry in
            // KNOWN_ROOT_FILES above. Confirmed real: a legitimate, popular
            // third-party Joomla monitoring tool, not a threat -- these
            // files are 32 bytes of hex, never executed.
            'MYJOOMLA_CHECKSUM_FILE_RE' => '/^\.myjoomla\..+\.md5$/i',

            // Common PHP-error-log filenames many hosts (especially
            // shared/cPanel hosting via a php.ini/php_value error_log
            // directive) automatically create and append to directly in
            // the webroot. Confirmed real false positive: these were
            // hitting the generic "unrecognized file in webroot" fallback
            // below, which recordFinding() auto-escalates to High
            // confidence purely because the reason text contains the word
            // "unrecognized" -- misleading for a file that's just
            // accumulated plain-text warnings, not a dropped payload.
            // Deliberately NOT added to KNOWN_ROOT_FILES (which skips
            // every check entirely) -- log-poisoning-then-include is a
            // real attack technique, so this only exempts the structural
            // "unrecognized" flag; scanFileContent() still runs against
            // these files and would still catch injected PHP/backdoor
            // content inside one.
            'BENIGN_ROOT_LOG_FILES' => ['error_log', 'php_errorlog', 'php_error.log', 'error.log'],

            // Sitemap generator extensions (Xmap, OSMap, and similar)
            // commonly split output across several root-level files
            // beyond the plain sitemap.xml already in KNOWN_ROOT_FILES --
            // sitemap_images.xml, sitemap-videos.xml, sitemap_mobile.xml,
            // sitemap_index.xml, paginated sitemap1.xml/sitemap2.xml, ...
            // A regex (rather than enumerating every variant name by
            // hand) covers naming conventions this hasn't specifically
            // seen yet too. Confirmed real false positive: these were
            // hitting the same "unrecognized file in webroot" auto-High
            // fallback as BENIGN_ROOT_LOG_FILES above, for the same
            // reason. Same treatment: only exempts that one structural
            // flag -- scanFileContent() (xml is in its text-like
            // extension list) still runs against these normally.
            'SITEMAP_VARIANT_RE' => '/^sitemap[a-z0-9_-]*\.xml(\.gz)?$/i',

            'KNOWN_SAFE_RELATIVE_FILES' => [
                'index.php', 'administrator/index.php', '', 'api/index.php',
                'includes/app.php', 'includes/framework.php', 'cli/joomla.php',
                'files/index.html', 'images/index.html', 'media/index.html',
            ],

            'SAFE_COMPONENT_PATHS' => [
                // Deliberately does NOT include this scanner's own
                // component path (or its pre-2.2.0 name, com_sppbscan) --
                // see SELF_CONTENT_SIGNATURE_EXEMPTIONS below for why a
                // blanket "never scan yourself" exemption is actively
                // dangerous for a security tool (it would make the one
                // place an attacker would most want to backdoor -- the
                // scanner itself -- permanently invisible to it), and how
                // this scans its own files fully while still avoiding the
                // narrow, specific false positives that come from
                // literally containing its own signature definitions as
                // text.
                '/administrator/components/com_rsfirewall/',
                '/administrator/components/com_htprotect/',
                '/administrator/components/com_akeeba/',
                // com_akeebabackup is Akeeba Backup's newer Joomla 4/5
                // component id (com_akeeba is the legacy/Joomla 3 id
                // above) -- same vendor, same trust level.
                '/administrator/components/com_akeebabackup/',
                '/administrator/components/com_admintools/',
            ],

            // A security scanner's OWN files are exactly what a
            // sufficiently determined attacker would most want to
            // backdoor -- disabling or blinding the thing meant to catch
            // them, rather than risk detection elsewhere. A blanket
            // "don't scan your own component" exemption (the previous
            // design) would make that permanently invisible. Instead,
            // every one of this scanner's own files gets the SAME full
            // scan as any other file -- these are narrow, per-file,
            // per-signature exemptions covering ONLY the specific
            // content-signature false positives that come from this
            // scanner's helper/model files literally containing their own
            // signature definitions and marker strings as source text
            // (e.g. the literal text "xss.report" and the marker strings
            // several other CONTENT_SIGNATURES entries match on, appearing
            // inside the very CONTENT_SIGNATURES/REQUEST_SIGNATURES table
            // and the SPPB-asset marker check that reference them).
            // Every OTHER content signature not listed here (eval_base64_post,
            // assert_backdoor, shell_exec_chain, cookie_gated_eval,
            // self_replicating_dropper, phpkoru_encoder, ...) and every
            // structural check still runs normally against these exact
            // same files, so an actually-injected backdoor is still
            // caught. Verified empirically against the real files, not
            // guessed -- re-verify with an isolated scanFileContent() test
            // any time CONTENT_SIGNATURES/REQUEST_SIGNATURES changes,
            // since a new signature could introduce a new self-match here.
            // com_sppbscan is this scanner's own pre-2.2.0 name (see
            // CHANGELOG.md "Rebrand SPPB Scan to MuRu Guard") -- a
            // leftover copy from before that rebrand is the same source,
            // so it gets the same exemptions.
            // Autopilot Mode (Pro, Settings ▸ Automations) -- the ONLY
            // signatures a scheduled scan is ever allowed to auto-remove a
            // file for, and only after an independent AI verification call
            // also confirms it (see MuruguardModelScanner::runAutopilotPass()).
            // Deliberately a tiny, hand-picked subset of CONTENT_SIGNATURES:
            // every one of these is gated on a raw incoming superglobal
            // ($_POST/$_GET/$_REQUEST/$_COOKIE) feeding directly into
            // eval/assert/shell_exec, or a secret-cookie-gated eval — shapes
            // this codebase's own "why" text already describes as having
            // "no legitimate use" (see each entry above). Structural/
            // heuristic checks (unrecognized file, non-standard index.php,
            // filename pattern, masquerade checks, ...) and every "needs
            // review"/medium-severity content signature (eval_encoded_blob,
            // cookie_gated_eval_variable, ...) are deliberately EXCLUDED
            // forever, not just at launch -- those are exactly the
            // categories that produced real false positives this project
            // has already hit (com_dropfiles' own index.php, com_osmap's
            // view.xml.php, this scanner's own JED Checker artifacts), and
            // they infer maliciousness from shape/location, not
            // unambiguous content. Expand this list only after a signature
            // has a real track record with zero false-positive reports —
            // never speculatively.
            'AUTOPILOT_ELIGIBLE_SIGNATURES' => [
                'eval_base64_post',
                'cookie_gated_eval',
                'assert_backdoor',
                'shell_exec_chain',
            ],

            'SELF_CONTENT_SIGNATURE_EXEMPTIONS' => [
                'administrator/components/com_muruguard/helpers/muruguard.php' =>
                    ['eval_encoded_blob', 'gsocket_indicator', 'xss_report_payload', 'webshell_generic', 'secure_local_marker', 'stream_wrapper_payload'],
                'administrator/components/com_sppbscan/helpers/muruguard.php' =>
                    ['eval_encoded_blob', 'gsocket_indicator', 'xss_report_payload', 'webshell_generic', 'secure_local_marker', 'stream_wrapper_payload'],
                'administrator/components/com_muruguard/models/scanner.php' =>
                    ['xss_report_payload', 'secure_local_marker'],
                'administrator/components/com_sppbscan/models/scanner.php' =>
                    ['xss_report_payload', 'secure_local_marker'],
            ],

            // Same idea as SELF_CONTENT_SIGNATURE_EXEMPTIONS, but for
            // well-known THIRD-PARTY open-source libraries that get
            // bundled by many unrelated Joomla extensions at different
            // vendor paths -- so this is matched by path SUFFIX (the
            // library's own stable internal layout) rather than one exact
            // full path. dompdf's Helpers.php legitimately parses
            // phar://file:// resource URLs as part of normal PDF asset
            // loading (embedding local images/fonts) -- confirmed false
            // positive, seen bundled at multiple different real vendor
            // paths (com_dpcalendar/vendor/dompdf/..., ConvertForms' PDF
            // tool, com_rsseo/helpers/dompdf/vendor/dompdf/...) across
            // several real customer sites, always ending in this same
            // dompdf/dompdf/src/Helpers.php internal path regardless of
            // what precedes it. Every other content signature (eval,
            // assert, shell_exec, cookie-gated backdoors, ...) still runs
            // fully against these exact files -- only the one signature
            // with the documented "legitimate archive access" caveat is
            // suppressed, and only for this one known file.
            'KNOWN_LIBRARY_SIGNATURE_EXEMPTIONS' => [
                'dompdf/dompdf/src/Helpers.php' => ['stream_wrapper_payload'],
            ],

            // "icomoon" is IcoMoon's own icon-font export/build tool name --
            // SP Page Builder (and many other extensions' icon pickers)
            // bundle their icon font exactly as IcoMoon exports it, top-
            // level folder name included, so this is a common, legitimate
            // subfolder name here, not a real red flag.
            'ICONFONT_ALLOWED_DIRNAMES'   => ['css', 'font', 'fonts', 'demo', 'docs', 'demo-files', 'icomoon'],
            'ICONFONT_ALLOWED_EXTENSIONS' => ['woff', 'woff2', 'ttf', 'eot', 'otf', 'svg', 'css', 'json', 'html', 'htm', 'txt', 'md'],
            'ICONFONT_ALLOWED_BARE_NAMES' => ['license', 'readme', 'changelog'],
            // #__sppagebuilder_assets rows of type "iconfont" named
            // something other than these are flagged as "Non-default" --
            // NOT because a non-default name is itself malicious (the
            // actual content checks run against every row regardless of
            // name, see scanDatabase()), just because it's a weaker,
            // secondary signal worth surfacing for manual review. "icofont"
            // is SP Page Builder's own bundled default; "icomoon" is
            // IcoMoon's own extremely common icon-font export/build tool
            // name (see ICONFONT_ALLOWED_DIRNAMES above) -- just as
            // legitimate a choice for a real site to have added, not a
            // red flag on its own.
            'KNOWN_GOOD_ICONFONT_NAMES'   => ['icofont', 'icomoon'],

            'JCE_UPLOAD_PATH_FRAGMENTS'      => ['/media/com_jce/editor/tiny_mce/plugins/filemanager/'],
            'JCE_UPLOAD_ALLOWED_EXTENSIONS'  => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'css', 'js', 'json', 'html', 'htm'],

            // Joomla's own core disk-cache storage driver (and template
            // frameworks that use it, e.g. Helix Ultimate's page cache)
            // writes cached data wrapped in an executable .php file named
            // "<md5>-cache-<group>-<md5>.php" -- <group> is whatever cache
            // group the caller registered (e.g. "page", "helixultimate",
            // a component name). This is standard, unmodified Joomla
            // caching behaviour, not a compromise, so cache/ (an 'upload'-
            // mode directory where .php would otherwise always be flagged)
            // exempts files matching this exact shape from the "executable
            // file in upload directory" structural check -- content
            // scanning still runs on them regardless, so an attacker
            // naming an actual backdoor to mimic this pattern is still
            // caught by what the file actually contains.
            'JOOMLA_CACHE_FILE_RE' => '/^[a-f0-9]{32}-cache-[a-z0-9_.-]+-[a-f0-9]{32}\.php$/i',

            'KNOWN_ROOT_DIRS' => [
                'administrator', 'api', 'bin', 'cache', 'cli', 'components', 'includes',
                'language', 'layouts', 'libraries', 'media', 'modules', 'plugins',
                'templates', 'tmp', 'images', 'files', 'node_modules', '.well-known', 'logs',
            ],

            // A small number of popular extensions plant their OWN top-
            // level webroot folders (outside modules/plugins/components/)
            // for user-authored custom code by design -- ConvertForms'
            // "Custom Code" action, for example, writes a
            // convertforms_<FormAlias>/ folder with before_form.php /
            // after_sub.php hooks directly at the webroot. Confirmed real
            // false positive: flagged "Unrecognized directory" High on a
            // live site that genuinely uses this ConvertForms feature.
            // Naming alone is never trusted for this -- see
            // isKnownExtensionDataFolder(), which also requires the owning
            // component to actually be installed, so a dropped shell folder
            // can't dodge detection just by copying the name on a site that
            // doesn't even have the extension. The folder's own contents
            // still get a full content-signature scan either way (see the
            // "Shallow webroot scan" section of scanner.php) -- this only
            // exempts the structural "unrecognized directory" flag.
            'KNOWN_EXTENSION_DATA_FOLDERS' => [
                '/^convertforms_/i' => 'com_convertforms',
            ],

            'PROTECTED_TOP_DIRS' => [
                'administrator', 'components', 'libraries', 'media', 'images', 'templates',
                'plugins', 'modules', 'language', 'cache', 'tmp', 'layouts', 'includes', 'api', 'cli',
            ],

            // Genuinely required core/template entry files -- even when
            // infected (a "prepended payload" ahead of the bootstrap/
            // access guard), the fix is to CLEAN the injected code, never
            // to delete the file outright, since the site (or the active
            // template) cannot function without it. Matched exactly for
            // the fixed entry points; matched by pattern for any
            // template's own root index.php since the template name
            // varies per site. Also covers the other files the bundled
            // core-checksum manifest verifies (see
            // getCoreChecksumManifest()) -- a checksum mismatch on any of
            // these needs manual review/restore, never a one-click delete.
            'PROTECTED_ENTRY_FILES' => [
                'index.php', 'administrator/index.php', 'api/index.php', 'includes/app.php',
                'includes/framework.php', 'robots.txt.dist', 'htaccess.txt', 'web.config.txt',
            ],
            'PROTECTED_ENTRY_FILE_PATTERNS' => [
                '#^(administrator/)?templates/[^/]+/index\.php$#i',
            ],

            // Directories scanned recursively, and in which mode.
            // 'upload' = strict structural checks (no exec files, no numeric drop folders).
            // 'code'   = signature-only (this is real extension code, .php is expected).
            'SCAN_CONFIG' => [
                'media' => 'upload', 'images' => 'upload', 'tmp' => 'upload',
                'cache' => 'upload', 'files' => 'upload',
                'components' => 'code', 'administrator/components' => 'code',
                'modules' => 'code', 'administrator/modules' => 'code',
                'plugins' => 'code', 'administrator/includes' => 'code',
                'libraries' => 'code', 'templates' => 'code', 'administrator/templates' => 'code',
                'cli' => 'code', 'bin' => 'code',
            ],

            // Exact relative paths seen in real-world attacks where the
            // attacker names a dropped file to LOOK like a plausible core
            // Joomla file (blending into a legitimate-looking directory
            // structure) even though no such core file actually exists.
            // Grow this list every time a new masquerade path is found.
            'CORE_MASQUERADE_EXACT_PATHS' => [
                'libraries/system.php',
                'bin/cms.php',
                'cli/cli.php',
                'templates/system/network.php',
                'templates/system/online.php',
                'options.php',
                'plugins/content/joomla/content.php',
            ],

            // Third-party-template masquerade paths, matched against ANY
            // template name (not a fixed template like the core-path list
            // above). No clean install of any known Joomla template ships
            // a top-level "features" folder with an index.php inside it --
            // flagged on location alone, regardless of file content, since
            // an attacker can trivially make the payload look like a
            // blank access-guard stub to dodge a content-only check.
            // Grow this list every time a new masquerade path is found.
            'TEMPLATE_FOLDER_MASQUERADE_PATTERNS' => [
                '#^(administrator/)?templates/[^/]+/features/index\.php$#i',
            ],

            // Folders where real Joomla core only ever places a small,
            // fixed set of loose files directly at the top level -- any
            // OTHER file sitting directly there (not nested in a real
            // subfolder like libraries/src/ or libraries/vendor/) is
            // almost certainly a payload disguised with a core-sounding
            // path, which is a stealthier pattern than a randomly-named
            // webshell since the filename itself looks legitimate.
            'CORE_LOOSE_FILE_ALLOWLIST' => [
                // web.config is Joomla's IIS-hosting counterpart to
                // .htaccess and is shipped loose in several core
                // directories, not just the webroot -- allowed everywhere
                // this list applies.
                'libraries' => [
                    'bootstrap.php', 'loader.php', 'classmap.php', 'namespacemap.php',
                    'import.php', 'import.legacy.php', 'platform.php', 'fof30.autoload.php',
                    'cms.php', 'web.config',
                ],
                'cli' => [
                    'joomla.php', 'import.php', 'update_cron.php', 'deletefiles.php', 'garbagecron.php',
                    'web.config',
                ],
                'bin' => ['web.config'],
                // templates/system is Joomla's built-in system/error template.
                // Its top-level loose files are a small, fixed set; anything
                // else there (network.php, online.php, ...) is a disguise.
                'templates/system' => [
                    'index.php', 'error.php', 'error.full.php', 'fatal.php', 'offline.php', 'component.php', 'web.config',
                ],
            ],
        ];
    }

    /**
     * Canonical, user-selectable scan areas grouped for the pre-scan
     * directory picker. Filesystem keys match SCAN_CONFIG relative dirs so
     * the model can filter directly; the pseudo-keys core_entry / webroot /
     * database gate the non-SCAN_CONFIG passes.
     */
    /**
     * Keyed by a stable, never-translated group id (used for icon lookups
     * and other by-key logic in the view) rather than the display label
     * itself, so the label can be translated without breaking anything
     * that depends on the key.
     */
    public static function getScanAreas(): array
    {
        return [
            'upload_media' => [
                'label' => Text::_('COM_MURUGUARD_GROUP_UPLOAD_MEDIA'),
                'areas' => [
                    'media'  => 'media/',
                    'images' => 'images/',
                    'tmp'    => 'tmp/',
                    'cache'  => 'cache/',
                    'files'  => 'files/',
                ],
            ],
            'extension_code' => [
                'label' => Text::_('COM_MURUGUARD_GROUP_EXTENSION_CODE'),
                'areas' => [
                    'components'                => 'components/',
                    'administrator/components'  => 'administrator/components/',
                    'modules'                   => 'modules/',
                    'administrator/modules'     => 'administrator/modules/',
                    'plugins'                   => 'plugins/',
                    'libraries'                 => 'libraries/',
                    'templates'                 => 'templates/',
                    'administrator/templates'   => 'administrator/templates/',
                    'administrator/includes'    => 'administrator/includes/',
                    'cli'                       => 'cli/',
                    'bin'                       => 'bin/',
                ],
            ],
            'core_webroot' => [
                'label' => Text::_('COM_MURUGUARD_GROUP_CORE_WEBROOT'),
                'areas' => [
                    'core_entry' => Text::_('COM_MURUGUARD_AREA_CORE_ENTRY'),
                    'webroot'    => Text::_('COM_MURUGUARD_AREA_WEBROOT'),
                ],
            ],
            'database' => [
                'label' => Text::_('COM_MURUGUARD_GROUP_DATABASE'),
                'areas' => [
                    'database' => Text::_('COM_MURUGUARD_AREA_DATABASE'),
                ],
            ],
        ];
    }

    /**
     * Human label for one chunked-scan progress-bar item -- $key is either
     * a SCAN_CONFIG directory key (looked up from getScanAreas() so the
     * label always matches what's shown on the directory-picker checkbox)
     * or one of MuruguardModelScanner's two synthetic chunk-queue keys.
     */
    public static function getChunkAreaLabel(string $key): string
    {
        if ($key === '__webroot_core__') {
            return Text::_('COM_MURUGUARD_CHUNK_WEBROOT_CORE_LABEL');
        }
        if ($key === '__database__') {
            return Text::_('COM_MURUGUARD_AREA_DATABASE');
        }
        foreach (self::getScanAreas() as $group) {
            foreach ($group['areas'] as $areaKey => $label) {
                if ($areaKey === $key) return $label;
            }
        }
        return $key;
    }

    /**
     * Checks a LIVE incoming request against REQUEST_SIGNATURES. Called by
     * the companion plg_system_muruguardshield plugin on every page load
     * -- NOT by the component's own file-content scan, which never sees
     * request data at all. Everything (URI, every GET/POST value) is
     * flattened into one combined haystack and checked against every
     * signature except the User-Agent one, which checks that header
     * specifically. Returns the highest-severity match found, or null.
     */
    public static function scanRequestForAttack(array $get, array $post, string $uri, string $userAgent): ?array
    {
        $sig = self::getSignatures();
        $combined = self::buildRequestHaystack($get, $post, $uri);

        $best = null;
        foreach ($sig['REQUEST_SIGNATURES'] as $name => $def) {
            $haystack = $name === 'known_scanner_user_agent' ? $userAgent : $combined;
            if ($haystack === '' || !preg_match($def['re'], $haystack, $m)) continue;

            $candidate = [
                'rule'           => $name,
                'severity'       => $def['severity'],
                'block_eligible' => $def['block_eligible'],
                'why'            => $def['why'],
                'matched_text'   => mb_substr((string) $m[0], 0, 120),
            ];
            if ($best === null || ($candidate['severity'] === 'high' && $best['severity'] !== 'high')) {
                $best = $candidate;
            }
        }
        return $best;
    }

    /**
     * Same combined-haystack construction scanRequestForAttack() already
     * used inline -- factored out so scanRequestForWaf() below can reuse
     * it exactly rather than re-deriving a second, potentially-drifting
     * copy of "how a request gets flattened into one searchable string."
     */
    private static function buildRequestHaystack(array $get, array $post, string $uri): string
    {
        $flatten = static function (array $arr) use (&$flatten): array {
            $out = [];
            foreach ($arr as $v) {
                $out = is_array($v) ? array_merge($out, $flatten($v)) : array_merge($out, [(string) $v]);
            }
            return $out;
        };

        // Collect not only values but also parameter names (keys) -- so
        // field names such as ac/path/api/t sent in the POST body are
        // also detected, even if they do not appear in literal syntax
        // like a GET query string.
        $paramNames = implode(' ', array_merge(array_keys($get), array_keys($post)));

        $parts = array_filter(array_merge([$uri], $flatten($get), $flatten($post)), fn($p) => $p !== '');
        return implode(' ', $parts) . ' ' . $paramNames;
    }

    /**
     * Pro-only broader request firewall -- checks the SAME live request
     * against WAF_SIGNATURES (generic SQLi/XSS/LFI/RFI/command-injection
     * patterns, not just this scanner's original webshell-specific set).
     * Deliberately a separate function from scanRequestForAttack() rather
     * than folding WAF_SIGNATURES into that one's loop: keeps the
     * free/always-on check's behaviour completely untouched, and callers
     * (plgSystemMuruguardshield::runShieldCheck()) decide independently
     * whether to run this second pass based on the site's license.
     */
    public static function scanRequestForWaf(array $get, array $post, string $uri): ?array
    {
        $sig = self::getSignatures();
        $combined = self::buildRequestHaystack($get, $post, $uri);
        if ($combined === '') return null;

        $best = null;
        foreach ($sig['WAF_SIGNATURES'] as $name => $def) {
            if (!preg_match($def['re'], $combined, $m)) continue;

            $candidate = [
                'rule'           => $name,
                'severity'       => $def['severity'],
                'block_eligible' => $def['block_eligible'],
                'why'            => $def['why'],
                'matched_text'   => mb_substr((string) $m[0], 0, 120),
            ];
            if ($best === null || ($candidate['severity'] === 'high' && $best['severity'] !== 'high')) {
                $best = $candidate;
            }
        }
        return $best;
    }

    /**
     * "Test a request" -- runs a hypothetical URL/IP/User-Agent/Referer
     * through every request-level Shield check, using the EXACT SAME
     * pure functions the live gate (plgSystemMuruguardshield::
     * runShieldCheck()) calls, so this can never quietly drift out of
     * sync with what actually happens to real traffic. Never writes to
     * the attack log, never blocks anything, never mutates any stored
     * state -- purely a read-only simulation, safe to run as often as an
     * admin wants before deciding whether to flip a blocking toggle on.
     *
     * A supplied test IP does still trigger the REAL GeoIP/Spamhaus
     * lookups (there's no way to preview a live network lookup's result
     * without making it) and reads REAL logged brute-force attempts for
     * that IP -- both are disclosed per-check via each result's 'detail'
     * text, not hidden behind "simulated" framing.
     *
     * Deliberately does not include Pro's WAF_SIGNATURES pass
     * (scanRequestForWaf()) in this first version -- that lives behind a
     * separate helper class (MuruguardAiHelper) this file doesn't
     * otherwise depend on, and the free pattern/UA/referrer/country/IP-
     * list/PBL preview already covers what every non-Pro admin can
     * actually toggle.
     *
     * @return array<int, array{label:string, tested:bool, verdict:string, detail:string}>
     */
    public static function testFirewallRequest(string $testUrl, string $userAgent, string $referrer, string $ip, $params): array
    {
        $checks = [];
        $ip = trim($ip);
        $referrer = trim($referrer);

        $urlParts = @parse_url(trim($testUrl)) ?: [];
        $uri = ($urlParts['path'] ?? '/') . (isset($urlParts['query']) ? '?' . $urlParts['query'] : '');
        $get = [];
        if (isset($urlParts['query'])) parse_str($urlParts['query'], $get);

        if ($ip !== '') {
            $ipListResult = self::checkIpList($ip);
            if ($ipListResult === 'allow') {
                $checks[] = ['label' => 'Manual IP Allow/Block List', 'tested' => true, 'verdict' => 'allow-override', 'detail' => 'This IP is on the manual allow list -- every other check is bypassed entirely for it, so none of them were run.'];
                return $checks;
            }
            if ($ipListResult === 'block') {
                $checks[] = ['label' => 'Manual IP Allow/Block List', 'tested' => true, 'verdict' => 'block', 'detail' => 'This IP is on the manual block list -- blocked immediately, ahead of every other check, so none of them were run.'];
                return $checks;
            }
            $checks[] = ['label' => 'Manual IP Allow/Block List', 'tested' => true, 'verdict' => 'no-match', 'detail' => 'No manual allow/block entry for this IP.'];
        } else {
            $checks[] = ['label' => 'Manual IP Allow/Block List', 'tested' => false, 'verdict' => 'not-tested', 'detail' => 'Supply a test IP to check this.'];
        }

        if (!$ip) {
            $checks[] = ['label' => 'Brute-Force Login Block', 'tested' => false, 'verdict' => 'not-tested', 'detail' => 'Supply a test IP to check this.'];
        } elseif (!$params->get('shield_block_bruteforce', 0)) {
            $checks[] = ['label' => 'Brute-Force Login Block', 'tested' => false, 'verdict' => 'not-tested', 'detail' => 'This check is currently turned off.'];
        } else {
            $threshold = (int) $params->get('shield_bruteforce_threshold', 5);
            $window = (int) $params->get('shield_bruteforce_window', 15);
            $exceeded = self::isBruteForceThresholdExceeded($ip, $threshold, $window);
            $checks[] = [
                'label' => 'Brute-Force Login Block', 'tested' => true, 'verdict' => $exceeded ? 'block' : 'allow',
                'detail' => $exceeded
                    ? "This IP has real logged failed backend logins over the {$threshold} threshold within the last {$window} minutes right now -- would be blocked."
                    : "Based on real logged attempts (not simulated): this IP has not exceeded {$threshold} failed backend logins within {$window} minutes.",
            ];
        }

        if (!$ip) {
            $checks[] = ['label' => 'Country Block', 'tested' => false, 'verdict' => 'not-tested', 'detail' => 'Supply a test IP to check this.'];
        } elseif (!$params->get('shield_block_countries', 0)) {
            $checks[] = ['label' => 'Country Block', 'tested' => false, 'verdict' => 'not-tested', 'detail' => 'This check is currently turned off.'];
        } else {
            $blockedCountries = (string) $params->get('shield_blocked_countries', '');
            $country = self::lookupCountryForIp($ip);
            $blocked = $blockedCountries !== '' && self::isCountryBlocked($country, $blockedCountries);
            $checks[] = [
                'label' => 'Country Block', 'tested' => true, 'verdict' => $blocked ? 'block' : 'allow',
                'detail' => $country === null
                    ? 'Could not resolve a country for this IP (private/reserved range, or the lookup failed) -- never blocks on a failed lookup.'
                    : ($blocked ? "Resolved to {$country}, which is on the blocked-countries list." : 'Resolved to ' . ($country ?: 'an unrecognized country') . ', not on the blocked-countries list.'),
            ];
        }

        if (!$ip) {
            $checks[] = ['label' => 'Public Blocklist (Spamhaus)', 'tested' => false, 'verdict' => 'not-tested', 'detail' => 'Supply a test IP to check this.'];
        } elseif (!$params->get('shield_block_pbl', 0)) {
            $checks[] = ['label' => 'Public Blocklist (Spamhaus)', 'tested' => false, 'verdict' => 'not-tested', 'detail' => 'This check is currently turned off.'];
        } else {
            $onList = self::isIpOnPublicBlocklist($ip);
            $checks[] = ['label' => 'Public Blocklist (Spamhaus)', 'tested' => true, 'verdict' => $onList ? 'block' : 'allow', 'detail' => $onList ? 'This IP is currently listed on Spamhaus ZEN.' : 'Not currently listed on Spamhaus ZEN.'];
        }

        if ($referrer === '') {
            $checks[] = ['label' => 'Referrer Blocking', 'tested' => false, 'verdict' => 'not-tested', 'detail' => 'Supply a test Referer value to check this.'];
        } else {
            $bad = self::isKnownBadReferrer($referrer);
            $blockOn = (bool) $params->get('shield_block_referrers', 0);
            $checks[] = [
                'label' => 'Referrer Blocking', 'tested' => true,
                'verdict' => $bad && $blockOn ? 'block' : ($bad ? 'flagged-not-blocking' : 'allow'),
                'detail' => $bad
                    ? ($blockOn ? 'Matches a known referrer-spam domain -- would be blocked.' : 'Matches a known referrer-spam domain, but Referrer Blocking is currently off, so it would only be logged.')
                    : 'Does not match any known referrer-spam pattern.',
            ];
        }

        $match = self::scanRequestForAttack($get, [], $uri, $userAgent);
        if ($match === null) {
            $checks[] = ['label' => 'Request Pattern / User-Agent Matching', 'tested' => true, 'verdict' => 'allow', 'detail' => 'No known attack pattern found in this URL/query or User-Agent.'];
        } else {
            $isUaRule = $match['rule'] === 'known_scanner_user_agent';
            $toggleOn = $isUaRule ? (bool) $params->get('shield_block_useragents', 0) : (bool) $params->get('shield_block_patterns', 0);
            $wouldBlock = $match['block_eligible'] && $toggleOn;
            $suffix = !$toggleOn
                ? ' (' . ($isUaRule ? 'User-Agent Blocking' : 'Pattern Blocking') . ' is currently off, so this would only be logged, not blocked)'
                : (!$match['block_eligible'] ? ' (this signature is log-only by design, never blocking)' : ' -- would be blocked');
            $checks[] = [
                'label' => $isUaRule ? 'User-Agent Blocking' : 'Request Pattern Matching',
                'tested' => true,
                'verdict' => $wouldBlock ? 'block' : 'flagged-not-blocking',
                'detail' => $match['why'] . ' Matched: "' . $match['matched_text'] . '".' . $suffix,
            ];
        }

        return $checks;
    }

    /**
     * Every data file this component owns (attack log, login attempts,
     * false positives, IP list, geoip cache, scan history) is stored
     * under helpers/data/ starting with this exact PHP stub. Requesting
     * one of these files directly over HTTP executes the stub and gets a
     * plain-text 403 -- nothing after it is ever reached. This is the
     * only protection that's actually server-agnostic: the .htaccess
     * that used to be this folder's sole protection is Apache-only (with
     * mod_authz_core/mod_access_compat enabled and AllowOverride honoured
     * for this path) and is silently ignored by nginx, Caddy/FrankenPHP,
     * LiteSpeed running in its nginx-compatible mode, and IIS -- on any
     * of those, the old *.json files were readable, unauthenticated, by
     * anyone who knew (or guessed) the filename, leaking attacker IPs,
     * failed-login usernames, every visitor IP ever geolocated, and the
     * manual IP allow/block list. A .php file, in contrast, is executed
     * by definition on every server capable of running Joomla at all --
     * there is no server config this depends on getting right.
     */
    public static function dataFileStubPrefix(): string
    {
        return "<?php http_response_code(403); header('Content-Type: text/plain; charset=utf-8'); exit(\"Forbidden\\n\");\n?>\n";
    }

    /**
     * Strips the leading PHP stub (see dataFileStubPrefix()) so the real
     * payload after it can be decoded. A file with no recognizable stub
     * (nothing written yet, or unexpected content) is returned unchanged
     * rather than mangled.
     */
    public static function stripDataFileStub(string $contents): string
    {
        if (strpos($contents, '<?php') !== 0) return $contents;
        $end = strpos($contents, '?>');
        if ($end === false) return $contents;
        return ltrim(substr($contents, $end + 2), "\r\n");
    }

    /**
     * One-time upgrade migration: com_muruguard versions before this fix
     * stored this same data as a plain, unprotected *.json file at
     * $legacyPath. If that file still exists and the new stub-protected
     * $newPath doesn't yet, its content is carried over (stub-prefixed)
     * and the legacy file is deleted outright -- not just abandoned in
     * place, since an abandoned copy would still be the exact same
     * unauthenticated leak this fix exists to close. Safe to call on
     * every read/write; it's a fast no-op once the legacy file is gone.
     * Never throws -- a migration hiccup (e.g. unreadable/unwritable
     * legacy file) just means the new file starts empty rather than
     * losing the write that triggered this call.
     */
    public static function migrateLegacyDataFile(string $legacyPath, string $newPath): void
    {
        if (!is_file($legacyPath)) return;
        if (!is_file($newPath)) {
            $contents = @file_get_contents($legacyPath);
            if ($contents !== false && trim($contents) !== '') {
                @file_put_contents($newPath, self::dataFileStubPrefix() . $contents);
            }
        }
        @unlink($legacyPath);
    }

    /**
     * Deliberately the same JSON-file-under-this-component's-own-data-
     * folder pattern as scan-history.json (see MuruguardModelScanner::
     * scanHistoryFilePath() for the full reasoning) -- and here it also
     * doubles as the one thing both this component AND the separate
     * shield plugin can agree on without any cross-extension API: the
     * plugin just writes here directly using the same JPATH_ADMINISTRATOR
     * constant every Joomla extension has, no coupling beyond this path.
     * flock() is used on writes (unlike scan-history.json) because this
     * file can plausibly receive concurrent writes from simultaneous
     * requests during an actual attack burst, exactly when losing entries
     * matters most.
     */
    private static function attackLogFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/attack-log.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/attack-log.json', $new);
        return $new;
    }

    private static function attackLogArchiveFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/attack-log-archive.php';
    }

    /**
     * Appends entries evicted from the live 500-entry ring buffer here
     * instead of discarding them outright. Without this, an attacker who
     * knows (or guesses) how this log works could erase all trace of
     * their own intrusion by simply sending ~500 more requests afterward
     * -- ageing their own attack entries out of the only copy that ever
     * existed, a handful of cheap requests to destroy the exact evidence
     * this log exists to preserve. Capped at a much higher ceiling
     * (20,000, oldest-evicted-for-real beyond that) so this can't grow
     * completely unbounded under a truly sustained flood, but raises the
     * cost of "erase the evidence" by 40x over the live log alone. Same
     * stub-protected format and flock()-guarded write as every other data
     * file here; called with the live log's own lock already released, so
     * this never holds two file locks at once.
     */
    private static function archiveAttackLogEntries(array $evicted): void
    {
        if (empty($evicted)) return;

        $path = self::attackLogArchiveFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $archive = json_decode($contents, true);
            if (!is_array($archive)) $archive = [];

            array_push($archive, ...$evicted);
            if (count($archive) > 20000) {
                $archive = array_slice($archive, -20000);
            }

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($archive));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    /** Total count of entries preserved in the archive -- surfaced in the Protection Log UI so evicted entries are visibly retained, not silently gone. */
    public static function getAttackLogArchiveCount(): int
    {
        $path = self::attackLogArchiveFilePath();
        if (!is_file($path)) return 0;
        $contents = @file_get_contents($path);
        if ($contents === false) return 0;
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? count($decoded) : 0;
    }

    /** Newest first, capped at 500 entries so the live file stays small and fast to read regardless of traffic volume -- anything evicted past that is preserved in the archive (see archiveAttackLogEntries()), never just dropped. */
    public static function recordAttackLogEntry(array $entry): void
    {
        $path = self::attackLogFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        $evicted = [];
        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $log = json_decode($contents, true);
            if (!is_array($log)) $log = [];

            array_unshift($log, $entry);
            if (count($log) > 500) {
                $evicted = array_slice($log, 500);
                $log = array_slice($log, 0, 500);
            }

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($log));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        self::archiveAttackLogEntries($evicted);
    }

    public static function getAttackLog(): array
    {
        $path = self::attackLogFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    public static function clearAttackLog(): void
    {
        @file_put_contents(self::attackLogFilePath(), self::dataFileStubPrefix() . json_encode([]));
    }

    private static function loginAttemptsFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/login-attempts.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/login-attempts.json', $new);
        return $new;
    }

    /**
     * Records one failed backend login attempt for brute-force tracking.
     * Entries older than 24h are pruned on every write so this file can
     * never grow unbounded even under a sustained attack -- a rolling
     * window is all isBruteForceThresholdExceeded() ever needs anyway.
     */
    public static function recordLoginFailure(string $ip, string $username): void
    {
        $path = self::loginAttemptsFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $attempts = json_decode($contents, true);
            if (!is_array($attempts)) $attempts = [];

            $cutoff = time() - 86400;
            $attempts = array_values(array_filter($attempts, fn($a) => ($a['time'] ?? 0) >= $cutoff));
            $attempts[] = ['ip' => $ip, 'username' => $username, 'time' => time()];

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($attempts));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    public static function getLoginAttempts(): array
    {
        $path = self::loginAttemptsFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    /** True if $ip has failed $threshold or more times within the last $windowMinutes. */
    public static function isBruteForceThresholdExceeded(string $ip, int $threshold, int $windowMinutes): bool
    {
        if ($threshold <= 0) return false;
        $cutoff = time() - ($windowMinutes * 60);
        $count = 0;
        foreach (self::getLoginAttempts() as $a) {
            if (($a['ip'] ?? '') === $ip && ($a['time'] ?? 0) >= $cutoff) {
                $count++;
                if ($count >= $threshold) return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Admin-dismissed false positives ("Mark as Safe" on a finding row) --
    // same JSON-file-under-this-component's-own-data-folder pattern as
    // attack-log.json/ip-list.json. Deliberately NOT keyed on path/row-id
    // alone: every entry also stores a fingerprint of the exact reasons
    // text that was reviewed at the time it was dismissed. A future scan
    // only suppresses a finding when BOTH the identifier AND that
    // fingerprint still match -- if the same file/row later trips a
    // DIFFERENT or ADDITIONAL signature (e.g. an attacker overwrites a
    // previously-dismissed file with a real backdoor), the fingerprint no
    // longer matches and it reappears as a fresh finding rather than
    // staying silently hidden forever. This is what makes "Mark as Safe"
    // safe to offer at all on a security tool -- a naive path/id-only
    // suppression would be a standing blind spot an attacker could target
    // specifically (compromise something already dismissed once).
    // ------------------------------------------------------------------

    private static function falsePositivesFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/false-positives.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/false-positives.json', $new);
        return $new;
    }

    /** Deterministic fingerprint of a finding's reasons -- order-independent, so the same set of matched reasons in a different order still counts as the same review. */
    public static function fingerprintReasons(array $reasonsList): string
    {
        $normalized = array_values(array_unique(array_map('strval', $reasonsList)));
        sort($normalized);
        return md5(implode('|', $normalized));
    }

    public static function getFalsePositives(): array
    {
        $path = self::falsePositivesFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    /** ['<category>|<identifier>' => '<fingerprint>', ...] -- built once per scan and passed around, rather than re-reading/re-parsing the JSON file once per finding. */
    public static function getFalsePositiveLookup(): array
    {
        $lookup = [];
        foreach (self::getFalsePositives() as $entry) {
            $key = ($entry['category'] ?? '') . '|' . ($entry['identifier'] ?? '');
            $lookup[$key] = (string) ($entry['fingerprint'] ?? '');
        }
        return $lookup;
    }

    public static function isFalsePositive(array $lookup, string $category, string $identifier, string $currentFingerprint): bool
    {
        $key = $category . '|' . $identifier;
        return isset($lookup[$key]) && $lookup[$key] !== '' && $lookup[$key] === $currentFingerprint;
    }

    private const FALSE_POSITIVE_CATEGORIES = ['file', 'superusers', 'menu_xss', 'sppb_assets', 'rogue_iconfont', 'template_defacement', 'template_style_xss'];

    /**
     * @param string $category One of FALSE_POSITIVE_CATEGORIES.
     * @param string $identifier Relative path for 'file', numeric row id (as string) for every DB category.
     * @param string $fingerprint See fingerprintReasons() -- the exact reasons/matches text being dismissed, so a later content change un-suppresses it.
     */
    public static function addFalsePositive(string $category, string $identifier, string $fingerprint, string $note = ''): array
    {
        $category = strtolower(trim($category));
        $identifier = trim($identifier);

        if (!in_array($category, self::FALSE_POSITIVE_CATEGORIES, true)) {
            return ['ok' => false, 'error' => 'Unknown finding category.'];
        }
        if ($identifier === '') {
            return ['ok' => false, 'error' => 'Missing identifier.'];
        }

        $entry = [
            'id'          => bin2hex(random_bytes(8)),
            'category'    => $category,
            'identifier'  => $identifier,
            'fingerprint' => $fingerprint,
            'note'        => mb_substr(trim($note), 0, 200),
            'addedAt'     => time(),
        ];

        $path = self::falsePositivesFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return ['ok' => false, 'error' => 'Could not open storage file.'];

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];

            // Replace an existing dismissal for the same category+
            // identifier (e.g. re-dismissing after the fingerprint
            // changed) rather than accumulating stale duplicate entries.
            $list = array_values(array_filter($list, fn($e) =>
                ($e['category'] ?? '') !== $category || ($e['identifier'] ?? '') !== $identifier
            ));
            $list[] = $entry;

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        return ['ok' => true, 'entry' => $entry];
    }

    public static function removeFalsePositive(string $id): void
    {
        $path = self::falsePositivesFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];

            $list = array_values(array_filter($list, fn($e) => ($e['id'] ?? '') !== $id));

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    // ------------------------------------------------------------------
    // Manual IP block/allow list -- same JSON-file-under-this-component's-
    // -own-data-folder pattern as attack-log.json/login-attempts.json
    // above. Independent of, and checked AHEAD of, every pattern/
    // threshold-based check in runShieldCheck(): an explicit "allow"
    // entry bypasses brute-force/pattern/country blocking entirely (the
    // whole point of an allowlist -- e.g. an admin's own static IP, or a
    // trusted external monitoring/uptime service that would otherwise
    // occasionally trip a rule), and an explicit "block" entry rejects
    // regardless of what the request itself looks like.
    // ------------------------------------------------------------------

    private static function ipListFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/ip-list.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/ip-list.json', $new);
        return $new;
    }

    public static function getIpList(): array
    {
        $path = self::ipListFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Accepts a plain IPv4/IPv6 address OR CIDR notation (e.g.
     * "203.0.113.0/24"). Returns ['ok' => true, 'entry' => ...] or
     * ['ok' => false, 'error' => '...'] -- never throws, since this is
     * called directly from a controller action handling raw admin input.
     */
    public static function addIpListEntry(string $ipOrCidr, string $mode, string $note): array
    {
        $ipOrCidr = trim($ipOrCidr);
        $mode = $mode === 'allow' ? 'allow' : 'block';

        if ($ipOrCidr === '') {
            return ['ok' => false, 'error' => 'Empty value.'];
        }

        if (strpos($ipOrCidr, '/') !== false) {
            [$addr, $prefix] = array_pad(explode('/', $ipOrCidr, 2), 2, '');
            if (filter_var($addr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false || !ctype_digit($prefix) || (int) $prefix > 32) {
                return ['ok' => false, 'error' => 'Invalid CIDR range -- only IPv4 CIDR notation is supported (e.g. 203.0.113.0/24).'];
            }
        } elseif (filter_var($ipOrCidr, FILTER_VALIDATE_IP) === false) {
            return ['ok' => false, 'error' => 'Not a valid IP address or CIDR range.'];
        }

        $entry = [
            'id'      => bin2hex(random_bytes(8)),
            'value'   => $ipOrCidr,
            'mode'    => $mode,
            'note'    => mb_substr(trim($note), 0, 200),
            'addedAt' => time(),
        ];

        $path = self::ipListFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return ['ok' => false, 'error' => 'Could not open storage file.'];

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];

            $list[] = $entry;

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        return ['ok' => true, 'entry' => $entry];
    }

    public static function removeIpListEntry(string $id): void
    {
        $path = self::ipListFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];

            $list = array_values(array_filter($list, fn($e) => ($e['id'] ?? '') !== $id));

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    /** True if $ip falls inside IPv4 CIDR range $cidr (e.g. "203.0.113.0/24"). IPv6 CIDR is not supported -- returns false rather than a wrong answer. */
    public static function ipMatchesCidr(string $ip, string $cidr): bool
    {
        if (strpos($cidr, '/') === false) return false;
        [$subnet, $prefix] = explode('/', $cidr, 2);
        if (!ctype_digit($prefix)) return false;
        $prefix = (int) $prefix;

        $ipLong = ip2long($ip);
        $subnetLong = ip2long($subnet);
        if ($ipLong === false || $subnetLong === false) return false;

        if ($prefix === 0) return true;
        $mask = -1 << (32 - $prefix);
        return ($ipLong & $mask) === ($subnetLong & $mask);
    }

    /**
     * Resolves the IP address every check in the shield plugin should key
     * on. By default (empty $trustedHeader, off unless an admin
     * explicitly opts in from Settings) this is always plain REMOTE_ADDR
     * -- the safe default. Behind a proxy/CDN/load balancer that was
     * never configured here, REMOTE_ADDR is the proxy's own IP for every
     * single visitor, which turns IP-keyed brute-force blocking into a
     * site-wide outage: a handful of failed logins from anyone behind
     * that shared edge IP locks out every other visitor sharing it too.
     * $trustedHeader (an $_SERVER key, e.g. "HTTP_CF_CONNECTING_IP") is
     * only ever honoured when the admin has explicitly selected it --
     * trusting a client-supplied header by default would let any visitor
     * spoof their own IP outright. A comma-separated value (the shape
     * X-Forwarded-For chains take: client, proxy1, proxy2, ...) uses the
     * first entry, and the result must parse as a syntactically valid IP
     * or this silently falls back to REMOTE_ADDR rather than trust
     * garbage input.
     */
    public static function resolveClientIp($serverInput, string $trustedHeader): string
    {
        $remoteAddr = (string) $serverInput->get('REMOTE_ADDR', '', 'string');

        if ($trustedHeader === '') {
            return $remoteAddr;
        }

        $headerValue = (string) $serverInput->get($trustedHeader, '', 'string');
        if ($headerValue === '') {
            return $remoteAddr;
        }

        $candidate = trim(explode(',', $headerValue)[0]);

        return filter_var($candidate, FILTER_VALIDATE_IP) !== false ? $candidate : $remoteAddr;
    }

    /**
     * Checked FIRST in runShieldCheck(), ahead of brute-force/pattern/
     * country blocking -- see the list's own docblock above for why.
     * Returns 'allow', 'block', or null (no matching entry). If an IP
     * somehow matches both an allow and a block entry, allow wins --
     * an allowlist entry is always a deliberate, specific admin action,
     * so it should never be silently overridden by a broader block rule.
     */
    public static function checkIpList(string $ip): ?string
    {
        if ($ip === '') return null;
        $blocked = false;
        foreach (self::getIpList() as $entry) {
            $value = (string) ($entry['value'] ?? '');
            $mode  = (string) ($entry['mode'] ?? '');
            $matches = $value === $ip || (strpos($value, '/') !== false && self::ipMatchesCidr($ip, $value));
            if (!$matches) continue;
            if ($mode === 'allow') return 'allow';
            if ($mode === 'block') $blocked = true;
        }
        return $blocked ? 'block' : null;
    }

    // ------------------------------------------------------------------
    // GeoIP / country blocking -- deliberately does NOT bundle a GeoIP
    // database (MaxMind's GeoLite2 requires a free account + license key
    // this project can't obtain on an admin's behalf, and a stale bundled
    // copy would silently rot). Instead uses a free lookup API
    // (ip-api.com) with an aggressive, indefinite local cache keyed by
    // IP -- a given IP's country essentially never changes, so this is a
    // ONE-TIME network call per unique visitor IP ever seen, not a
    // per-request dependency. Fails open (returns null, never blocks) on
    // any lookup error/timeout/malformed response -- a third-party
    // service hiccup must never be able to take real visitors down.
    // ------------------------------------------------------------------

    private static function geoipCacheFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/geoip-cache.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/geoip-cache.json', $new);
        return $new;
    }

    /** Returns a 2-letter ISO country code, or null if unknown/lookup failed. */
    public static function lookupCountryForIp(string $ip): ?string
    {
        if ($ip === '' || filter_var($ip, FILTER_VALIDATE_IP) === false) return null;
        // Private/reserved ranges (localhost, LAN, Docker/CI runners, ...)
        // are never geolocatable and would otherwise burn a lookup (and
        // cache slot) on every dev/staging environment.
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) return null;

        $cachePath = self::geoipCacheFilePath();
        $cache = [];
        if (is_file($cachePath)) {
            $decoded = json_decode(self::stripDataFileStub((string) @file_get_contents($cachePath)), true);
            if (is_array($decoded)) $cache = $decoded;
        }

        if (array_key_exists($ip, $cache)) {
            return $cache[$ip]['country'] !== '' ? $cache[$ip]['country'] : null;
        }

        $country = self::fetchCountryFromApi($ip);

        $fh = @fopen($cachePath, 'c+');
        if ($fh !== false) {
            if (@flock($fh, LOCK_EX)) {
                $size = filesize($cachePath) ?: 0;
                $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
                $freshCache = json_decode((string) $contents, true);
                if (!is_array($freshCache)) $freshCache = [];

                // Cap cache size so a distributed scan/attack hitting
                // thousands of unique IPs can't grow this file unbounded
                // -- oldest entries are dropped first (insertion order).
                if (count($freshCache) > 20000) {
                    $freshCache = array_slice($freshCache, -15000, null, true);
                }
                $freshCache[$ip] = ['country' => (string) $country, 'cachedAt' => time()];

                ftruncate($fh, 0);
                rewind($fh);
                fwrite($fh, self::dataFileStubPrefix() . json_encode($freshCache));
                fflush($fh);
                flock($fh, LOCK_UN);
            }
            fclose($fh);
        }

        return $country;
    }

    /** Isolated for testability -- swap/mock this in tests rather than the caching wrapper above. */
    protected static function fetchCountryFromApi(string $ip): ?string
    {
        try {
            $context = stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]);
            $response = @file_get_contents("http://ip-api.com/json/{$ip}?fields=status,countryCode", false, $context);
            if ($response === false) return null;

            $data = json_decode($response, true);
            if (!is_array($data) || ($data['status'] ?? '') !== 'success') return null;

            $code = (string) ($data['countryCode'] ?? '');
            return preg_match('/^[A-Z]{2}$/', $code) ? $code : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Public blocklist (DNSBL) IP reputation checks -- Spamhaus ZEN
    // (zen.spamhaus.org), queried via a standard reversed-octet DNS
    // lookup rather than any HTTP API -- no account or key for an admin
    // to configure. Deliberately IPv4-only (DNSBL is a legacy-DNS-record
    // convention that predates practical IPv6 reverse zones for this
    // purpose; an IPv6 visitor simply isn't checked, never blocked on a
    // broken lookup). Same aggressive local cache-by-IP shape as
    // lookupCountryForIp() above -- one real DNS query per unique
    // visitor IP ever seen, not a per-request dependency, and any lookup
    // failure fails OPEN (never blocks) so a DNS hiccup can never take
    // real visitors down.
    //
    // KNOWN LIMITATION, confirmed empirically during development (not
    // theoretical): Spamhaus's own published usage policy reserves
    // free/anonymous public DNS queries to zen.spamhaus.org for low-
    // volume/personal use and actively rate-limits or blocks higher-
    // volume querying (their intended path for anything beyond that is
    // a paid data-feed subscription) -- exactly the pattern many Joomla
    // sites running this same toggle, each querying per unique visitor
    // IP, would collectively produce. A direct query against this same
    // zone intermittently returned NXDOMAIN in testing even at low
    // volume, consistent with this. Fails open by design either way (a
    // blocked/rate-limited lookup just means this check silently does
    // nothing for that request, same as any other outage), so this never
    // breaks a site -- but an admin enabling this toggle should not
    // assume it's a reliable, always-on layer the way the other Shield
    // checks are.
    // ------------------------------------------------------------------

    private const DNSBL_ZONE = 'zen.spamhaus.org';

    private static function dnsblCacheFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/dnsbl-cache.php';
    }

    /** True if $ip (IPv4 only) is currently listed on the configured DNSBL zone. Cached indefinitely per IP, same reasoning as lookupCountryForIp(). */
    public static function isIpOnPublicBlocklist(string $ip): bool
    {
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) return false;
        // Never queried for private/reserved ranges -- there's no
        // legitimate DNSBL entry for a LAN/localhost address, and it
        // would just burn a lookup on every dev/staging environment.
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) return false;

        $cachePath = self::dnsblCacheFilePath();
        $cache = [];
        if (is_file($cachePath)) {
            $decoded = json_decode(self::stripDataFileStub((string) @file_get_contents($cachePath)), true);
            if (is_array($decoded)) $cache = $decoded;
        }
        if (array_key_exists($ip, $cache)) {
            return (bool) $cache[$ip]['listed'];
        }

        $listed = self::queryDnsblZone($ip);

        $fh = @fopen($cachePath, 'c+');
        if ($fh !== false) {
            if (@flock($fh, LOCK_EX)) {
                $size = filesize($cachePath) ?: 0;
                $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
                $freshCache = json_decode((string) $contents, true);
                if (!is_array($freshCache)) $freshCache = [];
                if (count($freshCache) > 20000) {
                    $freshCache = array_slice($freshCache, -15000, null, true);
                }
                $freshCache[$ip] = ['listed' => $listed, 'cachedAt' => time()];
                ftruncate($fh, 0);
                rewind($fh);
                fwrite($fh, self::dataFileStubPrefix() . json_encode($freshCache));
                fflush($fh);
                flock($fh, LOCK_UN);
            }
            fclose($fh);
        }

        return $listed;
    }

    /** Isolated for testability -- swap/mock this in tests rather than the caching wrapper above. */
    protected static function queryDnsblZone(string $ip): bool
    {
        try {
            $octets = explode('.', $ip);
            if (count($octets) !== 4) return false;
            $lookupHost = implode('.', array_reverse($octets)) . '.' . self::DNSBL_ZONE;
            return checkdnsrr($lookupHost, 'A');
        } catch (\Throwable $e) {
            return false;
        }
    }

    // ------------------------------------------------------------------
    // Real upload-time filtering -- everything else this scanner does
    // about a webshell in an upload directory happens AFTER the fact, on
    // the next scan. This is the one check that runs at the moment of
    // upload itself, in the Shield plugin (see checkUploadFilterGate()
    // in plg_system_muruguardshield), rejecting the request outright
    // before any component (com_media's REST API, a custom form, ...)
    // ever writes the file to disk.
    // ------------------------------------------------------------------

    /**
     * @return string|null A reason the filename is rejected, or null if it's fine.
     */
    public static function checkUploadFilenameForBannedExtension(string $filename): ?string
    {
        $sig = self::getSignatures();
        $execExts = $sig['EXEC_EXTS'];

        // Every dot-separated segment after the first, not just the
        // final one -- catches the classic "shell.php.jpg" disguise
        // (final extension looks safe, an earlier segment is the real,
        // dangerous one) as well as the plain "shell.php" case.
        $segments = explode('.', $filename);
        array_shift($segments); // the part before the first dot is the base name, not an extension
        foreach ($segments as $seg) {
            if (in_array(strtolower($seg), $execExts, true)) {
                return "Upload rejected: filename \"{$filename}\" contains a disguised or direct executable extension (.{$seg}) -- server-side script uploads aren't allowed here.";
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Exact-hash malware database -- deliberately ships with NO bundled
    // hashes: a fabricated or unverified "known-bad" hash list would be
    // actively worse than none at all (a wrong hash either matches
    // nothing, or matches an innocent file and calls it confirmed
    // malware). Instead this is an admin-maintained list -- add the MD5
    // of a file you've personally confirmed malicious (from this site's
    // own findings, a security advisory, a shared incident writeup, ...)
    // and every future scan flags an EXACT byte-for-byte match anywhere
    // in the tree, independent of filename or location. Same JSON-file-
    // under-this-component's-own-data-folder pattern as ip-list.json/
    // false-positives.json.
    // ------------------------------------------------------------------

    private static function customHashesFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/known-hashes.php';
    }

    public static function getCustomMalwareHashes(): array
    {
        $path = self::customHashesFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    /** @return array{ok:bool,error?:string,entry?:array} */
    public static function addCustomMalwareHash(string $md5, string $note = ''): array
    {
        $md5 = strtolower(trim($md5));
        if (!preg_match('/^[a-f0-9]{32}$/', $md5)) {
            return ['ok' => false, 'error' => 'Not a valid MD5 hash (must be exactly 32 hex characters).'];
        }

        $entry = ['id' => bin2hex(random_bytes(8)), 'md5' => $md5, 'note' => mb_substr(trim($note), 0, 200), 'addedAt' => time()];

        $path = self::customHashesFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return ['ok' => false, 'error' => 'Could not open storage file.'];

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];
            // Replace an existing entry for the same hash rather than duplicating.
            $list = array_values(array_filter($list, fn($e) => ($e['md5'] ?? '') !== $md5));
            $list[] = $entry;
            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        return ['ok' => true, 'entry' => $entry];
    }

    public static function removeCustomMalwareHash(string $id): void
    {
        $path = self::customHashesFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;
        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];
            $list = array_values(array_filter($list, fn($e) => ($e['id'] ?? '') !== $id));
            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    /** @return string|null A finding reason string if $path's exact content matches a known hash, or null. */
    public static function checkAgainstCustomMalwareHashes(string $path, array $customHashes): ?string
    {
        if (empty($customHashes)) return null;
        $fileHash = @md5_file($path);
        if ($fileHash === false) return null;

        foreach ($customHashes as $entry) {
            if (($entry['md5'] ?? '') === $fileHash) {
                $note = trim((string) ($entry['note'] ?? ''));
                $noteText = $note !== '' ? " ({$note})" : '';
                return "Exact MD5 match against a hash in your Known-Bad Hashes list{$noteText} -- this file's content is byte-for-byte identical to one you've previously confirmed malicious.";
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Referrer blocking -- same "fixed known-bad list" shape as
    // known_scanner_user_agent in getSignatures() (see scanRequestForAttack()):
    // a curated set of referrer-spam / crawler-noise domains rather than
    // an admin-maintained list, so this works with zero configuration the
    // moment the toggle is switched on. Deliberately narrow (exact-domain
    // match against the Referer header's own host) -- broad substring
    // matching against a full URL risks false-positives against a
    // legitimate site that merely mentions one of these domains in a
    // query string.
    // ------------------------------------------------------------------

    private const REFERRER_SPAM_DOMAINS = [
        'semalt.com', 'buttons-for-website.com', 'best-seo-offer.com', 'best-seo-solution.com',
        'social-buttons.com', 'darodar.com', 'econom.co', 'ilovevitaly.com', 'ilovevitaly.co',
        'ilovevitaly.ru', 'kambasoft.com', 'traffic2money.com', 'trafficmonetizer.org',
        'get-free-traffic-now.com', '4webmasters.org', 'floating-share-buttons.com',
        'free-social-buttons.com', 'website-analytics.info', 'sitevaluation.org',
        'blackhatworth.com', 'buy-cheap-online.info', 'video--production.com',
        'hulfingtonpost.com', 'ranksonic.info', 'ranksonic.com', 'rankinter.com', '7makemoneyonline.com',
    ];

    /** True when the Referer header's own host is an exact (or subdomain) match against a known referrer-spam domain. */
    public static function isKnownBadReferrer(string $referrer): bool
    {
        if ($referrer === '') return false;
        $host = strtolower((string) (parse_url($referrer, PHP_URL_HOST) ?? ''));
        if ($host === '') return false;

        foreach (self::REFERRER_SPAM_DOMAINS as $spam) {
            if ($host === $spam || str_ends_with($host, '.' . $spam)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Automated repeat-offender IP auto-blocklisting -- promotes an IP
    // that Shield has already blocked repeatedly within a short window
    // from "blocked this one request" to "blocked outright, every
    // request, until an admin removes it" by adding it to the same
    // manual IP Access List checkIpList() already consults FIRST on every
    // request. Reuses the attack log (already written on every block --
    // see recordAttackLogEntry() call sites in plg_muruguardshield) as
    // the source of truth rather than a second counter file, so this
    // stays consistent with whatever the Attack Log tab is already
    // showing the admin.
    // ------------------------------------------------------------------

    /** Count of BLOCKED attack-log entries for $ip within the last $windowMinutes. */
    public static function countRecentBlockedRequests(string $ip, int $windowMinutes): int
    {
        if ($ip === '') return 0;
        $cutoff = time() - ($windowMinutes * 60);
        $count = 0;
        foreach (self::getAttackLog() as $entry) {
            if (($entry['ip'] ?? '') === $ip && ($entry['blocked'] ?? false) && ($entry['time'] ?? 0) >= $cutoff) {
                $count++;
            }
        }
        return $count;
    }

    /**
     * Called right after Shield blocks a request. If this IP has now been
     * blocked $threshold+ times within $windowMinutes, promotes it to a
     * standing entry in the manual IP Access List (mode 'block') so every
     * FUTURE request from it is rejected immediately by checkIpList(),
     * without needing to re-evaluate brute-force/pattern/country rules
     * each time. No-ops (returns false) if the IP is already on the list
     * in any mode -- never duplicates an entry, and never silently
     * downgrades an admin's own explicit 'allow' entry for that IP.
     * Fails silently on any error -- this is a convenience escalation on
     * top of protection that already happened (the request that
     * triggered this check was itself already blocked), never a
     * blocking dependency of it.
     */
    public static function autoBlockRepeatOffender(string $ip, int $threshold, int $windowMinutes): bool
    {
        if ($ip === '' || $threshold <= 0) return false;
        foreach (self::getIpList() as $entry) {
            if (($entry['value'] ?? '') === $ip) return false; // already listed, either mode
        }
        if (self::countRecentBlockedRequests($ip, $windowMinutes) < $threshold) return false;

        $result = self::addIpListEntry($ip, 'block', "Auto-blocked: {$threshold}+ blocked requests within {$windowMinutes} minutes.");
        return (bool) ($result['ok'] ?? false);
    }

    // ------------------------------------------------------------------
    // World-writable file/folder permission audit -- location-independent,
    // runs against every file and directory the scanner already walks
    // (see the checkMaliciousHtaccessHandler() call site in scanner.php
    // for the equivalent pattern). A file or directory writable by ANY
    // system user (mode & 0002) is a real, direct risk on shared hosting
    // in particular -- any other tenant's process can modify it -- and is
    // never a Joomla-correct configuration; core and every well-behaved
    // extension ship 644/755-or-stricter.
    // ------------------------------------------------------------------

    /** @return string|null A finding reason string, or null if $path isn't world-writable (or its permissions can't be read). */
    public static function checkWorldWritablePermission(string $path, bool $isDir): ?string
    {
        $perms = @fileperms($path);
        if ($perms === false) return null;
        if (($perms & 0002) === 0) return null; // not world-writable

        $octal = substr(sprintf('%o', $perms), -4);
        $kind = $isDir ? 'Directory' : 'File';
        return "{$kind} permissions are world-writable (mode {$octal}) — any process on a shared host, not just this site's own, can modify it. Tighten to " . ($isDir ? '755' : '644') . " or stricter.";
    }

    // ------------------------------------------------------------------
    // Automatic tmp/ folder cleanup -- Joomla's own tmp/ directory is
    // writable by design (core uses it for upload staging and package
    // extraction) and, unlike media/images/uploads, isn't something an
    // admin routinely looks inside -- exactly the profile of folder an
    // attacker probes to leave a dropper in, betting it goes unnoticed.
    // Deliberately conservative: only removes plain files strictly older
    // than $maxAgeHours, never touches subdirectories (an in-progress
    // extension install/update can legitimately leave a nested folder
    // mid-operation), and always keeps the well-known protective stub
    // files (index.html, .htaccess) any Joomla tmp/ directory ships with.
    // ------------------------------------------------------------------

    private const TMP_CLEANUP_KEEP_FILES = ['index.html', '.htaccess', 'index.php', '.gitkeep'];

    /**
     * @return array{deleted:int,skipped:int,errors:list<string>}
     */
    public static function cleanupStaleTmpFiles(string $tmpDir, int $maxAgeHours = 24): array
    {
        $result = ['deleted' => 0, 'skipped' => 0, 'errors' => []];
        if ($tmpDir === '' || !is_dir($tmpDir)) {
            $result['errors'][] = 'tmp directory not found.';
            return $result;
        }

        $cutoff = time() - ($maxAgeHours * 3600);
        $entries = @scandir($tmpDir);
        if ($entries === false) {
            $result['errors'][] = 'Could not list tmp directory contents.';
            return $result;
        }

        foreach ($entries as $name) {
            if ($name === '.' || $name === '..') continue;
            if (in_array(strtolower($name), self::TMP_CLEANUP_KEEP_FILES, true)) continue;

            $path = $tmpDir . '/' . $name;
            if (is_dir($path)) continue; // never recurse/delete directories -- see docblock above

            $mtime = @filemtime($path);
            if ($mtime === false || $mtime >= $cutoff) {
                $result['skipped']++;
                continue;
            }

            if (@unlink($path)) {
                $result['deleted']++;
            } else {
                $result['errors'][] = "Could not delete {$name}.";
            }
        }

        return $result;
    }

    // ------------------------------------------------------------------
    // Single-glance security score -- purely a presentation layer over
    // signals this scanner already computes elsewhere (HTTPS status,
    // Shield/WAF/Backend Access toggles, vulnerable-extension count from
    // the existing vuln feed, Joomla/PHP currency). Never a new detection
    // capability -- see MuruguardModelScanner::getSecurityScore() for
    // where each signal actually comes from.
    // ------------------------------------------------------------------

    /**
     * @param array{
     *   https:bool, shield_enabled:bool, backend_auth_enabled:bool,
     *   waf_enabled:bool, htaccess_checks_present:int, htaccess_checks_total:int,
     *   vulnerable_extension_count:int, joomla_outdated:bool, php_outdated:bool,
     *   open_findings:int
     * } $signals
     * @return array{score:int,label:string,issues:list<string>}
     */
    public static function computeSecurityScore(array $signals): array
    {
        $score = 100;
        $issues = [];

        if (empty($signals['https'])) { $score -= 15; $issues[] = 'Site is not served over HTTPS.'; }
        if (empty($signals['shield_enabled'])) { $score -= 15; $issues[] = 'Protection Mode (Shield) is off.'; }
        if (empty($signals['backend_auth_enabled'])) { $score -= 8; $issues[] = 'Backend Access password wall is off.'; }
        if (empty($signals['waf_enabled'])) { $score -= 5; $issues[] = 'Active WAF is off.'; }

        $htTotal = max(0, (int) ($signals['htaccess_checks_total'] ?? 0));
        $htPresent = max(0, (int) ($signals['htaccess_checks_present'] ?? 0));
        if ($htTotal > 0 && $htPresent < $htTotal) {
            $missing = $htTotal - $htPresent;
            $score -= min(15, $missing * 3);
            $issues[] = "{$missing} of {$htTotal} recommended .htaccess hardening rule" . ($missing === 1 ? '' : 's') . ' missing.';
        }

        $vulnCount = max(0, (int) ($signals['vulnerable_extension_count'] ?? 0));
        if ($vulnCount > 0) {
            $score -= min(25, $vulnCount * 10);
            $issues[] = "{$vulnCount} installed extension" . ($vulnCount === 1 ? '' : 's') . ' with a known published vulnerability.';
        }

        if (!empty($signals['joomla_outdated'])) { $score -= 10; $issues[] = 'Joomla core is not on the latest version.'; }
        if (!empty($signals['php_outdated'])) { $score -= 5; $issues[] = 'PHP version is older than the currently supported line.'; }

        $openFindings = max(0, (int) ($signals['open_findings'] ?? 0));
        if ($openFindings > 0) {
            $score -= min(30, $openFindings * 5);
            $issues[] = "{$openFindings} unresolved scan finding" . ($openFindings === 1 ? '' : 's') . '.';
        }

        $score = max(0, min(100, $score));
        $label = $score >= 85 ? 'Good' : ($score >= 60 ? 'Needs attention' : 'At risk');

        return ['score' => $score, 'label' => $label, 'issues' => $issues];
    }

    // ------------------------------------------------------------------
    // Known-vulnerability feed -- an admin-curated database of published
    // Joomla extension vulnerabilities, hosted publicly (no license key
    // needed -- this is awareness, not a licensed feature, so it's the
    // same on Free and Pro) at VULN_FEED_URL. Fetched at most once every
    // 24h and cached locally using the exact same stub-prefixed-file +
    // flock pattern as the GeoIP cache above -- a scan must never be
    // slowed down (or broken) by the dashboard being briefly unreachable,
    // so a failed fetch silently falls back to whatever was last cached
    // (or an empty list if nothing has ever been cached).
    // ------------------------------------------------------------------

    private const VULN_FEED_URL = 'https://store.lyzerslab.com/api/vuln-feed';
    private const VULN_FEED_MAX_AGE = 86400; // 24h

    private static function vulnFeedCacheFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/vulnfeed-cache.php';
    }

    /**
     * Returns the cached advisory list (array of associative arrays, see
     * VulnerabilityAdvisory's public feed shape), re-fetching from
     * VULN_FEED_URL when the cache is missing or older than
     * VULN_FEED_MAX_AGE. Never throws; a fetch/parse failure just returns
     * whatever was cached before (or []).
     */
    public static function fetchVulnerabilityFeed(): array
    {
        $cachePath = self::vulnFeedCacheFilePath();
        $cached = null;
        if (is_file($cachePath)) {
            $decoded = json_decode(self::stripDataFileStub((string) @file_get_contents($cachePath)), true);
            if (is_array($decoded) && isset($decoded['fetchedAt'], $decoded['advisories'])) {
                $cached = $decoded;
            }
        }

        $isFresh = $cached !== null && (time() - (int) $cached['fetchedAt']) < self::VULN_FEED_MAX_AGE;
        if ($isFresh) {
            return is_array($cached['advisories']) ? $cached['advisories'] : [];
        }

        $fetched = self::fetchVulnerabilityFeedFromApi();
        if ($fetched === null) {
            // Fetch failed -- serve the stale cache rather than nothing,
            // if there is one; an old warning is still more useful than
            // silently going blind because of a transient network blip.
            return $cached !== null && is_array($cached['advisories']) ? $cached['advisories'] : [];
        }

        $fh = @fopen($cachePath, 'c+');
        if ($fh !== false) {
            if (@flock($fh, LOCK_EX)) {
                ftruncate($fh, 0);
                rewind($fh);
                fwrite($fh, self::dataFileStubPrefix() . json_encode(['fetchedAt' => time(), 'advisories' => $fetched]));
                fflush($fh);
                flock($fh, LOCK_UN);
            }
            fclose($fh);
        }

        return $fetched;
    }

    /** Isolated for testability -- swap/mock this in tests rather than the caching wrapper above. */
    protected static function fetchVulnerabilityFeedFromApi(): ?array
    {
        try {
            $context = stream_context_create(['http' => ['timeout' => 5, 'ignore_errors' => true]]);
            $response = @file_get_contents(self::VULN_FEED_URL, false, $context);
            if ($response === false) return null;

            $data = json_decode($response, true);
            if (!is_array($data) || !isset($data['advisories']) || !is_array($data['advisories'])) return null;

            return $data['advisories'];
        } catch (\Throwable $e) {
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Free-tier "Ask AI" finding review -- Gemini only, bring-your-own
    // key, same masked-display/blank-means-unchanged convention as every
    // other secret in this file. Pro's own richer multi-provider system
    // (Claude/GPT/Gemini/OpenRouter/Custom, configured via the dashboard
    // -- see MuruguardControllerScanner::aiproviders()) is completely
    // untouched by this; this is the SEPARATE, simpler path that makes
    // "Ask AI" work at all for a site with no Pro license, using
    // Google's Gemini API directly rather than routing through a
    // licensed dashboard account.
    // ------------------------------------------------------------------

    private const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

    /**
     * @return array{ok:bool,text?:string,error?:string}
     */
    public static function callGeminiApi(string $systemPrompt, string $userMessage, string $apiKey): array
    {
        if ($apiKey === '') return ['ok' => false, 'error' => 'not_configured'];

        try {
            $body = json_encode([
                'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
                'contents' => [['role' => 'user', 'parts' => [['text' => $userMessage]]]],
            ]);

            $context = stream_context_create(['http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/json\r\n",
                'content' => $body,
                'timeout' => 60,
                'ignore_errors' => true,
            ]]);
            $response = @file_get_contents(self::GEMINI_API_URL . '?key=' . urlencode($apiKey), false, $context);
            if ($response === false) return ['ok' => false, 'error' => 'unreachable'];

            $data = json_decode($response, true);
            if (!is_array($data)) return ['ok' => false, 'error' => 'bad_response'];

            if (isset($data['error'])) {
                return ['ok' => false, 'error' => (string) ($data['error']['message'] ?? 'api_error')];
            }

            $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;
            if (!is_string($text) || $text === '') {
                return ['ok' => false, 'error' => 'empty_response'];
            }

            return ['ok' => true, 'text' => $text];
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => 'exception'];
        }
    }

    // ------------------------------------------------------------------
    // Third-party reputation lookup -- Google Safe Browsing Lookup API
    // v4, an admin-supplied API key (BYO, same pattern as an AI provider
    // key: masked display via maskLicenseKey(), a blank save means "no
    // change"). Checks URLs found INSIDE scanned file content against
    // Google's own threat lists -- catches a malicious redirect/phishing/
    // drive-by-download URL a compromised file links out to, something no
    // signature-pattern check here is designed to catch. Entirely inert
    // (zero API calls, zero cost) until an admin configures a key --
    // Google's own free tier requires one, this project can't obtain one
    // on an admin's behalf the way it does for the always-on GeoIP/DNSBL
    // checks above (both of which use genuinely keyless public services).
    // ------------------------------------------------------------------

    private const SAFE_BROWSING_API_URL = 'https://safebrowsing.googleapis.com/v4/threatMatches:find';
    private const SAFE_BROWSING_CACHE_MAX_AGE = 86400; // 24h -- a URL's threat status can change, unlike an IP's country
    private const SAFE_BROWSING_MAX_URLS_PER_FILE = 3; // bounds API usage against a file link-bombing with hundreds of URLs

    private static function safeBrowsingCacheFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/safebrowsing-cache.php';
    }

    /**
     * Pulls up to SAFE_BROWSING_MAX_URLS_PER_FILE distinct http(s):// URLs
     * out of arbitrary file content. Deliberately simple/greedy (doesn't
     * try to parse HTML/JS syntax) -- a URL sitting in a comment, a
     * string literal, or an href alike is exactly what a malicious
     * redirect/phishing link would look like in a compromised file's raw
     * source, so this shouldn't be choosy about context.
     */
    public static function extractUrlsFromContent(string $content): array
    {
        if (!preg_match_all('#https?://[^\s\'"<>\)\]]+#i', $content, $matches)) return [];
        $urls = array_values(array_unique($matches[0]));
        return array_slice($urls, 0, self::SAFE_BROWSING_MAX_URLS_PER_FILE);
    }

    /**
     * Checks one URL against Google Safe Browsing, cached per-URL for
     * SAFE_BROWSING_CACHE_MAX_AGE. Returns the matched threat type
     * string (e.g. "MALWARE", "SOCIAL_ENGINEERING") or null if clean/
     * unreachable/no key configured -- fails open on any error, exactly
     * like every other external lookup in this file (GeoIP, DNSBL): a
     * Google API hiccup must never be able to break a scan.
     */
    public static function checkUrlAgainstSafeBrowsing(string $url, string $apiKey): ?string
    {
        if ($apiKey === '' || $url === '') return null;

        $cachePath = self::safeBrowsingCacheFilePath();
        $cache = [];
        if (is_file($cachePath)) {
            $decoded = json_decode(self::stripDataFileStub((string) @file_get_contents($cachePath)), true);
            if (is_array($decoded)) $cache = $decoded;
        }
        if (isset($cache[$url]) && (time() - (int) $cache[$url]['cachedAt']) < self::SAFE_BROWSING_CACHE_MAX_AGE) {
            return $cache[$url]['threatType'] !== '' ? $cache[$url]['threatType'] : null;
        }

        $threatType = self::querySafeBrowsingApi($url, $apiKey);

        $fh = @fopen($cachePath, 'c+');
        if ($fh !== false) {
            if (@flock($fh, LOCK_EX)) {
                $size = filesize($cachePath) ?: 0;
                $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
                $freshCache = json_decode((string) $contents, true);
                if (!is_array($freshCache)) $freshCache = [];
                if (count($freshCache) > 5000) {
                    $freshCache = array_slice($freshCache, -3000, null, true);
                }
                $freshCache[$url] = ['threatType' => (string) $threatType, 'cachedAt' => time()];
                ftruncate($fh, 0);
                rewind($fh);
                fwrite($fh, self::dataFileStubPrefix() . json_encode($freshCache));
                fflush($fh);
                flock($fh, LOCK_UN);
            }
            fclose($fh);
        }

        return $threatType;
    }

    /**
     * Isolated for testability. Per Google's documented Safe Browsing
     * Lookup API v4 contract: POST threatMatches:find with the URL under
     * threatEntries; an empty {} response body means clean, a non-empty
     * "matches" array names the threat type(s) found.
     */
    protected static function querySafeBrowsingApi(string $url, string $apiKey): ?string
    {
        try {
            $body = json_encode([
                'client' => ['clientId' => 'muruguard', 'clientVersion' => '1.0.0'],
                'threatInfo' => [
                    'threatTypes' => ['MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE'],
                    'platformTypes' => ['ANY_PLATFORM'],
                    'threatEntryTypes' => ['URL'],
                    'threatEntries' => [['url' => $url]],
                ],
            ]);

            $context = stream_context_create(['http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/json\r\n",
                'content' => $body,
                'timeout' => 5,
                'ignore_errors' => true,
            ]]);
            $response = @file_get_contents(self::SAFE_BROWSING_API_URL . '?key=' . urlencode($apiKey), false, $context);
            if ($response === false) return null;

            $data = json_decode($response, true);
            if (!is_array($data) || empty($data['matches']) || !is_array($data['matches'])) return null;

            $type = $data['matches'][0]['threatType'] ?? null;
            return is_string($type) && $type !== '' ? $type : 'MALWARE';
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Runs Safe Browsing against every URL extractUrlsFromContent() finds
     * in $content, returning one finding reason per flagged URL. A no-op
     * (empty array, zero API calls) when $apiKey is empty -- callers
     * don't need their own gate.
     */
    public static function checkContentUrlsAgainstSafeBrowsing(string $content, string $apiKey): array
    {
        if ($apiKey === '') return [];
        $reasons = [];
        foreach (self::extractUrlsFromContent($content) as $url) {
            $threatType = self::checkUrlAgainstSafeBrowsing($url, $apiKey);
            if ($threatType !== null) {
                $reasons[] = "Contains a URL currently flagged by Google Safe Browsing as {$threatType}: {$url}";
            }
        }
        return $reasons;
    }

    // ------------------------------------------------------------------
    // Externally-updatable malware content-signature feed -- same shape
    // and reasoning as the known-vulnerability feed above (fetched at
    // most once every 24h, same stub-prefixed-file cache, fails open to
    // stale-cache-or-empty on any error), but this one extends
    // getSignatures()['CONTENT_SIGNATURES'] itself instead of being
    // consulted separately -- see mergeSignatureFeedInto() below. Lets a
    // newly-seen attack pattern reach every install within hours via a
    // dashboard admin adding one row, instead of a new detection meaning
    // bumping this whole extension's version.
    // ------------------------------------------------------------------

    private const SIGNATURE_FEED_URL = 'https://store.lyzerslab.com/api/signature-feed';
    private const SIGNATURE_FEED_MAX_AGE = 86400; // 24h

    private static function signatureFeedCacheFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/signaturefeed-cache.php';
    }

    /**
     * Returns the cached, VALIDATED signature list -- each entry already
     * confirmed to compile as a real PCRE pattern (see
     * validateFeedSignatureEntry()) before it's ever cached or applied,
     * so a malformed remote entry can never reach preg_match() against a
     * real file. Re-fetches from SIGNATURE_FEED_URL when the cache is
     * missing or older than SIGNATURE_FEED_MAX_AGE; never throws, and a
     * fetch/parse failure just returns whatever was cached before (or []).
     */
    public static function fetchSignatureFeed(): array
    {
        $cachePath = self::signatureFeedCacheFilePath();
        $cached = null;
        if (is_file($cachePath)) {
            $decoded = json_decode(self::stripDataFileStub((string) @file_get_contents($cachePath)), true);
            if (is_array($decoded) && isset($decoded['fetchedAt'], $decoded['signatures'])) {
                $cached = $decoded;
            }
        }

        $isFresh = $cached !== null && (time() - (int) $cached['fetchedAt']) < self::SIGNATURE_FEED_MAX_AGE;
        if ($isFresh) {
            return is_array($cached['signatures']) ? $cached['signatures'] : [];
        }

        $fetched = self::fetchSignatureFeedFromApi();
        if ($fetched === null) {
            return $cached !== null && is_array($cached['signatures']) ? $cached['signatures'] : [];
        }

        // Validate BEFORE caching -- a bad entry is dropped here, once,
        // rather than being re-validated (or worse, trusted) on every
        // single scan that reads the cache back.
        $validated = [];
        foreach ($fetched as $entry) {
            $clean = self::validateFeedSignatureEntry($entry);
            if ($clean !== null) $validated[] = $clean;
        }

        $fh = @fopen($cachePath, 'c+');
        if ($fh !== false) {
            if (@flock($fh, LOCK_EX)) {
                ftruncate($fh, 0);
                rewind($fh);
                fwrite($fh, self::dataFileStubPrefix() . json_encode(['fetchedAt' => time(), 'signatures' => $validated]));
                fflush($fh);
                flock($fh, LOCK_UN);
            }
            fclose($fh);
        }

        return $validated;
    }

    /** Isolated for testability -- swap/mock this in tests rather than the caching wrapper above. */
    protected static function fetchSignatureFeedFromApi(): ?array
    {
        try {
            $context = stream_context_create(['http' => ['timeout' => 5, 'ignore_errors' => true]]);
            $response = @file_get_contents(self::SIGNATURE_FEED_URL, false, $context);
            if ($response === false) return null;

            $data = json_decode($response, true);
            if (!is_array($data) || !isset($data['signatures']) || !is_array($data['signatures'])) return null;

            return $data['signatures'];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Validates one raw feed entry into the exact shape a
     * CONTENT_SIGNATURES array entry needs -- name/pattern/severity/why
     * present and correctly typed, AND the pattern actually compiles
     * (checked with a real @preg_match() call, the only reliable way to
     * know PCRE will accept it) before it's trusted anywhere near a real
     * scan. Returns null (silently dropped, never fatal) on anything
     * that doesn't check out.
     *
     * @return array{name:string,re:string,severity:string,why:string,multi?:list<string>}|null
     */
    public static function validateFeedSignatureEntry($entry): ?array
    {
        if (!is_array($entry)) return null;

        $name = (string) ($entry['name'] ?? '');
        $pattern = (string) ($entry['pattern'] ?? '');
        $severity = (string) ($entry['severity'] ?? '');
        $why = (string) ($entry['why'] ?? '');

        if (!preg_match('/^[a-z0-9_]+$/', $name)) return null;
        if ($pattern === '' || !in_array($severity, ['high', 'medium'], true) || $why === '') return null;

        // The only reliable PCRE syntax check: try it. @-suppressed
        // because preg_match() emits a warning (not an exception) on an
        // invalid pattern -- the false return is what actually matters.
        if (@preg_match($pattern, '') === false) return null;

        $clean = ['name' => $name, 're' => $pattern, 'severity' => $severity, 'why' => $why];

        if (isset($entry['multiNeedles']) && is_array($entry['multiNeedles'])) {
            $needles = array_values(array_filter($entry['multiNeedles'], 'is_string'));
            if (!empty($needles)) $clean['multi'] = $needles;
        }

        return $clean;
    }

    /**
     * Extends a getSignatures()-shaped array's CONTENT_SIGNATURES with
     * every validated feed entry, WITHOUT ever overwriting a hardcoded
     * local signature of the same name -- a name collision keeps the
     * local, reviewed-and-shipped-with-a-release version, on the theory
     * that it was deliberately tuned and a remote entry reusing its name
     * is more likely a mistake than an intentional override. Called ONLY
     * at the one real scan entry point (MuruguardModelScanner::
     * scanFilesystem()) rather than folded into getSignatures() itself,
     * so every other caller of getSignatures() (brute-force settings,
     * request-signature matching, EXEC_EXTS, ...) is completely
     * unaffected and never pays for a network-backed cache read it
     * doesn't need.
     */
    public static function mergeSignatureFeedInto(array $sig): array
    {
        foreach (self::fetchSignatureFeed() as $entry) {
            $name = $entry['name'];
            if (isset($sig['CONTENT_SIGNATURES'][$name])) continue; // local always wins
            $sig['CONTENT_SIGNATURES'][$name] = [
                're' => $entry['re'],
                'severity' => $entry['severity'],
                'why' => $entry['why'],
            ];
            if (isset($entry['multi'])) {
                $sig['CONTENT_SIGNATURES'][$name]['multi'] = $entry['multi'];
            }
        }
        return $sig;
    }

    /** $blockedCountriesCsv is a comma-separated list of 2-letter ISO codes from the Settings panel, e.g. "CN,RU,KP". */
    public static function isCountryBlocked(?string $countryCode, string $blockedCountriesCsv): bool
    {
        if ($countryCode === null || $countryCode === '') return false;
        $blocked = array_filter(array_map('trim', explode(',', strtoupper($blockedCountriesCsv))));
        return in_array(strtoupper($countryCode), $blocked, true);
    }

    // ------------------------------------------------------------------
    // License activation -- verified against the single canonical
    // Lyzerslab dashboard this whole ecosystem already assumes (the same
    // one scripts/upload-to-dashboard.sh and the release workflow talk
    // to). Domain-bound server-side (see the dashboard's own
    // activateOrVerifyLicense()): a key activates against whichever site
    // calls it first, and every later call must present the same site or
    // it's rejected -- this component only ever sends its own domain and
    // reports back whatever the dashboard decides, it has no local
    // enforcement logic of its own to bypass.
    // ------------------------------------------------------------------

    // Deliberately the bare (non-www) host -- www.lyzerslab.com 301-redirects
    // here, and PHP's http:// stream wrapper (unlike curl -L) downgrades a
    // POST to a GET when it follows a redirect, so the retried request lands
    // on this POST-only endpoint as a GET and gets a 405 with an empty body
    // every single time. Hitting the canonical URL directly avoids that hop
    // entirely instead of relying on redirect-following to paper over it.
    private const LICENSE_API_URL = 'https://store.lyzerslab.com/api/license/activate';

    /** Where the Settings panel's "Renew License" link (shown once a license is EXPIRED) sends the admin -- the dashboard's own login page, since this is being clicked from inside Joomla admin where there's no guarantee of an existing dashboard session; its own post-login flow takes over from there. */
    public const DASHBOARD_LOGIN_URL = 'https://store.lyzerslab.com/dashboard/login';

    /** Hard ceiling on how much of the response body verifyLicenseRemote() will ever read -- a legitimate reply is a few hundred bytes of JSON; this exists purely so a misbehaving/misrouted endpoint can never make this call allocate unbounded memory. */
    private const LICENSE_API_MAX_RESPONSE_BYTES = 65536;

    /**
     * How long a verification result is trusted before the next admin
     * page load re-checks it -- keeps normal usage from ever waiting on
     * an outbound HTTP call. Was 24h; dropped to the standard 1-hour
     * check-in interval most commercial plugin/extension licensing
     * systems use, so a revoked/deleted license (or a renewed one) shows
     * up correctly across the whole admin -- not just in whichever panel
     * happens to make its own live dashboard call -- within an hour
     * instead of potentially a full day.
     */
    private const LICENSE_CACHE_SECONDS = 3600;

    /**
     * Reads the cached verification result out of $cfgParams (the
     * component's own ComponentHelper::getParams('com_muruguard') params
     * blob -- see saveLicenseKey()/MuruguardModelScanner::getLicenseStatus()
     * for where these get written) without making any network call.
     * Callers that want a possibly-fresh check should go through
     * MuruguardModelScanner::getLicenseStatus() instead, which calls this
     * first and only reaches for verifyLicenseRemote() when the cache is
     * stale or a re-check was explicitly requested.
     */
    public static function readCachedLicenseStatus($cfgParams): array
    {
        $key = trim((string) $cfgParams->get('license_key', ''));
        if ($key === '') {
            return self::emptyLicenseStatus('none');
        }

        return [
            'status'      => (string) $cfgParams->get('license_status', 'none') ?: 'none',
            'expiresAt'   => self::nullableIntParam($cfgParams->get('license_expires_at', '')),
            'lastChecked' => self::nullableIntParam($cfgParams->get('license_last_checked', '')),
            'product'     => (($p = (string) $cfgParams->get('license_product', '')) !== '') ? $p : null,
        ];
    }

    /** True once the cached result (if any) is older than LICENSE_CACHE_SECONDS, or there simply isn't one yet. */
    public static function isLicenseCacheStale($cfgParams): bool
    {
        $lastChecked = self::nullableIntParam($cfgParams->get('license_last_checked', ''));
        if ($lastChecked === null) return true;
        return (time() - $lastChecked) > self::LICENSE_CACHE_SECONDS;
    }

    /**
     * Masks a license key for on-screen display so the full plaintext
     * value is never echoed back into the page/DOM -- only the last 4
     * characters stay visible (enough to let an admin confirm which key is
     * currently saved), everything else becomes a bullet, dashes kept as
     * visual grouping. Even on a Super-User-only panel, a credential that
     * never needs to round-trip back to the browser in full shouldn't be
     * sitting in the page source where a compromised extension, a
     * screen-share, or a browser history/cache snapshot could pick it up.
     */
    public static function maskLicenseKey(string $key): string
    {
        $len = strlen($key);
        if ($len === 0) return '';
        if ($len <= 4) return str_repeat('•', $len);
        $head = substr($key, 0, $len - 4);
        $tail = substr($key, $len - 4);
        return preg_replace('/[^-]/', '•', $head) . $tail;
    }

    private static function nullableIntParam($value): ?int
    {
        $value = (string) $value;
        return $value !== '' ? (int) $value : null;
    }

    private static function emptyLicenseStatus(string $status): array
    {
        return ['status' => $status, 'expiresAt' => null, 'lastChecked' => null, 'product' => null];
    }

    /**
     * The actual outbound check -- POSTs the key and this site's own
     * domain to the dashboard, matching exactly what
     * activateOrVerifyLicense() on the other end expects (see that
     * function's own docblock: same endpoint handles first activation
     * AND every later periodic re-check). Fails open on any network
     * error or malformed response ('unreachable'), the same philosophy
     * as lookupCountryForIp()'s GeoIP call -- an unreachable dashboard
     * must never itself disable anything.
     */
    // This product's own identifier on the dashboard -- required by
    // /api/license/activate (400 "productSlug is required" without it).
    // Confirmed real, live bug: this call never sent it, so every
    // verification -- first activation and every later periodic re-check
    // alike -- was rejected with a 400 the dashboard has no 'valid' or
    // recognized 'reason' field for, which fell through to 'unreachable'
    // below. Sending it also means a key that genuinely belongs to a
    // DIFFERENT product (e.g. pasted in from another Lyzerslab extension)
    // now correctly comes back as 'product_mismatch' instead of either
    // silently validating (if the dashboard ever stopped requiring this
    // field) or being indistinguishable from a network hiccup.
    private const LICENSE_PRODUCT_SLUG = 'muruguard-security-scanner';

    public static function verifyLicenseRemote(string $key, string $siteDomain): array
    {
        $key = trim($key);
        if ($key === '') return self::emptyLicenseStatus('none');

        $payload = json_encode(['key' => $key, 'domain' => $siteDomain, 'productSlug' => self::LICENSE_PRODUCT_SLUG]);
        if ($payload === false) return self::emptyLicenseStatus('unreachable');

        try {
            $context = stream_context_create(['http' => [
                'method'          => 'POST',
                'header'          => "Content-Type: application/json\r\n",
                'content'         => $payload,
                'timeout'         => 5,
                'ignore_errors'   => true,
                // The URL above is already the canonical (non-www) host, so
                // no redirect is expected -- explicitly refusing to follow
                // one anyway means a future misconfiguration fails closed
                // (unreachable) instead of silently retrying as a broken
                // GET the way following www.lyzerslab.com's redirect used to.
                'follow_location' => 0,
                'max_redirects'   => 0,
            ]]);
            $handle = @fopen(self::LICENSE_API_URL, 'rb', false, $context);
            if ($handle === false) {
                return ['status' => 'unreachable', 'expiresAt' => null, 'lastChecked' => time(), 'product' => null];
            }
            // stream_get_contents() with an explicit length reads at most
            // that many bytes and then stops, unlike file_get_contents()
            // which has no way to cap how much of a response it will pull
            // into memory -- a legitimate reply is a few hundred bytes, so
            // this is purely a ceiling against a misbehaving endpoint.
            $response = @stream_get_contents($handle, self::LICENSE_API_MAX_RESPONSE_BYTES);
            fclose($handle);
            if ($response === false || $response === '') {
                return ['status' => 'unreachable', 'expiresAt' => null, 'lastChecked' => time(), 'product' => null];
            }

            $data = json_decode($response, true);
            if (!is_array($data)) {
                return ['status' => 'unreachable', 'expiresAt' => null, 'lastChecked' => time(), 'product' => null];
            }

            $expiresAt = !empty($data['expiresAt']) ? (strtotime((string) $data['expiresAt']) ?: null) : null;

            if (!empty($data['valid'])) {
                $productName = null;
                if (isset($data['product']) && is_array($data['product'])) {
                    $productName = (string) ($data['product']['name'] ?? '') ?: null;
                }
                return ['status' => 'active', 'expiresAt' => $expiresAt, 'lastChecked' => time(), 'product' => $productName];
            }

            $reason = (string) ($data['reason'] ?? 'unreachable');
            $validReasons = ['not_found', 'revoked', 'expired', 'site_limit_reached', 'product_mismatch'];
            $status = in_array($reason, $validReasons, true) ? $reason : 'unreachable';

            return ['status' => $status, 'expiresAt' => $expiresAt, 'lastChecked' => time(), 'product' => null];
        } catch (\Throwable $e) {
            return ['status' => 'unreachable', 'expiresAt' => null, 'lastChecked' => time(), 'product' => null];
        }
    }

    /** The domain this site's own license checks are sent as -- Joomla's own site root URL, normalized the same way the dashboard normalizes an incoming domain (scheme/www/trailing-slash stripped) so the two sides never disagree over formatting alone. */
    public static function currentSiteDomain(): string
    {
        try {
            $root = (string) \Joomla\CMS\Uri\Uri::root();
        } catch (\Throwable $e) {
            $root = (string) ($_SERVER['HTTP_HOST'] ?? '');
        }
        $root = preg_replace('#^[a-z][a-z0-9+.-]*://#i', '', $root) ?? $root;
        $root = preg_replace('#^www\.#i', '', $root) ?? $root;
        $root = preg_replace('#/.*$#', '', $root) ?? $root;
        $root = preg_replace('#:\d+$#', '', $root) ?? $root;
        return strtolower($root);
    }

    /** Canonical (non-www) dashboard API host -- see LICENSE_API_URL's docblock for why www is deliberately avoided (it 301s, and PHP's stream wrapper downgrades the retried POST to a broken GET). Shared by every dashboard endpoint the Smart AI Assistant talks to, not just license verification. */
    private const DASHBOARD_API_BASE = 'https://store.lyzerslab.com/api';

    /**
     * Generic, safe POST-JSON-get-JSON call to a dashboard endpoint --
     * same hardened pattern verifyLicenseRemote() uses (canonical host, no
     * redirect-following, size-capped read via a raw stream instead of
     * file_get_contents()) generalised for the Smart AI Assistant's
     * several endpoints (agent step, provider config list/save/test/
     * default), which unlike a license check can return substantially
     * larger payloads (an LLM completion, or a tool call carrying a full
     * file's contents up to MuruguardAiHelper's own write-size cap) --
     * hence the caller-supplied $maxResponseBytes instead of a single
     * hardcoded constant.
     */
    public static function callDashboardApi(string $path, array $payload, int $maxResponseBytes = 65536, int $timeoutSeconds = 30): array
    {
        $body = json_encode($payload);
        if ($body === false) return ['ok' => false, 'error' => 'encode_failed', 'data' => null];

        try {
            $context = stream_context_create(['http' => [
                'method'          => 'POST',
                'header'          => "Content-Type: application/json\r\n",
                'content'         => $body,
                'timeout'         => $timeoutSeconds,
                'ignore_errors'   => true,
                'follow_location' => 0,
                'max_redirects'   => 0,
            ]]);
            $handle = @fopen(self::DASHBOARD_API_BASE . $path, 'rb', false, $context);
            if ($handle === false) {
                return ['ok' => false, 'error' => 'unreachable', 'data' => null];
            }
            $response = @stream_get_contents($handle, $maxResponseBytes);
            fclose($handle);
            if ($response === false || $response === '') {
                return ['ok' => false, 'error' => 'unreachable', 'data' => null];
            }

            $data = json_decode($response, true);
            if (!is_array($data)) {
                return ['ok' => false, 'error' => 'bad_response', 'data' => null];
            }

            return ['ok' => true, 'error' => null, 'data' => $data];
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => 'exception', 'data' => null];
        }
    }

    /**
     * Generic HTTPS-only JSON POST to a customer-supplied webhook URL
     * (Slack incoming webhook, Discord webhook, a custom endpoint, ...) --
     * used by the Pro "Alert Channels" feature. Unlike callDashboardApi(),
     * the destination here is whatever URL the site owner typed into
     * their own Settings panel, not a hardcoded first-party host, so this
     * enforces https:// specifically (refuses plain http:// and any other
     * scheme outright) as basic hygiene against a pasted-in-error internal
     * URL, and never follows redirects for the same reason
     * callDashboardApi() doesn't. Deliberately tiny response cap (2KB) --
     * webhook responses are never meant to carry meaningful data back.
     */
    public static function postWebhook(string $url, array $payload, int $timeoutSeconds = 10): bool
    {
        if (!preg_match('#^https://#i', $url)) {
            return false;
        }

        $body = json_encode($payload);
        if ($body === false) return false;

        try {
            $context = stream_context_create(['http' => [
                'method'          => 'POST',
                'header'          => "Content-Type: application/json\r\n",
                'content'         => $body,
                'timeout'         => $timeoutSeconds,
                'ignore_errors'   => true,
                'follow_location' => 0,
                'max_redirects'   => 0,
            ]]);
            $handle = @fopen($url, 'rb', false, $context);
            if ($handle === false) return false;

            $statusLine = $http_response_header[0] ?? '';
            @stream_get_contents($handle, 2048);
            fclose($handle);

            // Webhook conventions vary (Slack/Discord return 2xx/204 on
            // success), so this is deliberately lenient -- treat anything
            // that ISN'T a client/server error status as success rather
            // than hardcoding one exact expected code.
            return (bool) preg_match('#^HTTP/\S+\s+[23]\d\d#', $statusLine);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Detects files whose PATH masquerades as legitimate Joomla core even
     * though no such file exists in a clean install -- the stealthiest
     * dropper pattern, because the filename itself looks trustworthy.
     * Complements the content-signature scan (which only fires on payload
     * text): a masquerade file can be flagged on its location alone.
     *
     * Returns a human-readable reason string, or null if nothing matched.
     */
    /**
     * Short, collapsed preview of a file's own content, used to append a
     * "Matched code:" snippet onto location-based reasons (masquerade
     * paths, stray index.php, ...) that don't otherwise quote any code --
     * without this, the code-analysis modal has nothing to show for these
     * checks even though the file's actual content is exactly what a
     * reviewer needs to see to judge the finding.
     */
    private static function filePreview(string $absPath, int $maxLen = 220): string
    {
        if ($absPath === '' || !is_file($absPath)) return '';
        $chunk = @file_get_contents($absPath, false, null, 0, 4096);
        if ($chunk === false || trim($chunk) === '') return '';
        $preview = trim(preg_replace('/\s+/', ' ', $chunk));
        return strlen($preview) > $maxLen ? substr($preview, 0, $maxLen) . '…' : $preview;
    }

    public static function checkCoreMasquerade(string $relPath, bool $isDir, array $sig, string $absPath = ''): ?string
    {
        $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
        if ($relPath === '') return null;

        $base = basename($relPath);
        $ext  = strtolower(pathinfo($base, PATHINFO_EXTENSION));
        $preview = $isDir ? '' : self::filePreview($absPath);
        $suffix  = $preview !== '' ? " Matched code: {$preview}" : '';

        // 1. Exact known-masquerade relative paths.
        if (!$isDir && in_array($relPath, $sig['CORE_MASQUERADE_EXACT_PATHS'], true)) {
            return 'Path masquerades as a legitimate Joomla core file, but no such file exists in a clean Joomla install — a stealthy dropper disguise.' . $suffix;
        }

        // 2. Hidden dot-file carrying an executable extension, anywhere.
        //    Joomla never stores runnable code in a hidden file (e.g.
        //    administrator/.../toolbar/.module.php) -- except a small,
        //    known set of IDE/tooling metadata files that legitimate
        //    composer packages ship this way by convention (e.g.
        //    PhpStorm's .phpstorm.meta.php), which are exempted.
        if (!$isDir && $base !== '' && $base[0] === '.' && in_array($ext, $sig['EXEC_EXTS'], true)
            && !in_array(strtolower($base), array_map('strtolower', $sig['HIDDEN_DOTFILE_ALLOWLIST']), true)) {
            return "Hidden dot-file with an executable extension (\"{$base}\") — legitimate Joomla code is never stored in hidden executable files." . $suffix;
        }

        // 3. File placed directly (loosely) in a core directory whose full
        //    set of top-level files is known and small. Executable files by
        //    an unknown name are the classic disguise; unusual non-code
        //    extensions (e.g. a ".lock" marker) dropped there are almost
        //    always attacker toolkit artifacts too. Legitimate Joomla stub
        //    files (index.html, web.config.txt, .htaccess, ...) are allowed.
        if (!$isDir) {
            $dir = strtolower(dirname($relPath));
            if ($dir === '.') $dir = '';
            if (isset($sig['CORE_LOOSE_FILE_ALLOWLIST'][$dir])) {
                $allowed   = array_map('strtolower', $sig['CORE_LOOSE_FILE_ALLOWLIST'][$dir]);
                $stubExts  = ['html', 'htm', 'xml', 'txt', 'ini', 'json', 'md', 'dist', 'htaccess'];
                $baseLower = strtolower($base);
                if (!in_array($baseLower, $allowed, true)) {
                    if (in_array($ext, $sig['EXEC_EXTS'], true)) {
                        return "Executable file placed directly in the core \"{$dir}/\" directory, which never holds a file by this name in a clean Joomla install — a core-path disguise." . $suffix;
                    }
                    if ($ext !== '' && !in_array($ext, $stubExts, true) && $baseLower !== '.htaccess') {
                        return "Unexpected file (\"{$base}\") loose in the core \"{$dir}/\" directory — clean Joomla never ships this file, a common malware toolkit artifact." . $suffix;
                    }
                }
            }
        }

        return null;
    }

    /**
     * Flags anything sitting inside a top-level templates/<name> or
     * administrator/templates/<name> folder whose <name> matches the same
     * auto-generated "tmpl_xxxxxx" junk-naming pattern checked against
     * #__template_styles rows in scanDatabase() (see
     * TEMPLATE_STYLE_JUNK_NAME_RE) -- a confirmed, real mass-injection
     * pattern: dozens of these folders dropped at once, each holding a
     * handful of PHP files given plausible-sounding-but-fake framework
     * names (handler.php, loader.php, registry.php, session.php, ...) to
     * blend in, paired with a matching junk row in the database. Unlike
     * scanFileContent()'s signature checks, this doesn't depend on
     * recognizing the payload's code at all -- it flags purely on the
     * folder naming, so it still catches the drop even if the file
     * contents don't match any known webshell signature. Applies to the
     * folder itself and everything inside it, at any depth, regardless of
     * scan mode.
     */
    /** Per-request cache for the templateDetails.xml check below, keyed by template folder absolute path -- avoids re-stat()ing the same folder once per file inside it. */
    private static array $templateManifestCache = [];

    public static function checkJunkTemplateFolder(string $relPath, array $sig, ?string $absPath = null, ?array $registeredTemplates = null): ?string
    {
        $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
        $parts = explode('/', $relPath);

        if (($parts[0] ?? '') === 'templates') {
            $topFolder = $parts[1] ?? '';
            $depthAfterTop = count($parts) - 2;
            $clientId = 0;
        } elseif (($parts[0] ?? '') === 'administrator' && ($parts[1] ?? '') === 'templates') {
            $topFolder = $parts[2] ?? '';
            $depthAfterTop = count($parts) - 3;
            $clientId = 1;
        } else {
            return null;
        }

        if ($topFolder === '') {
            return null;
        }

        // Joomla's own "prevent directory listing" blank stub sits
        // directly in templates/ (and administrator/templates/) itself --
        // never a real template name, so a bare file at that level (not a
        // template subfolder) is never treated as one.
        if (count($parts) === $clientId + 2 && in_array(strtolower($topFolder), ['index.html', 'index.php'], true)) {
            return null;
        }

        // "system" is Joomla's own bundled fallback template (offline.php,
        // error.php, fatal.php, ...), present in a stock install on both the
        // site and admin side. It's core Joomla, not an installed extension
        // -- it never goes through the extension installer and so
        // legitimately has no templateDetails.xml, unlike every other
        // folder under templates/. Exempt it from the no-manifest check
        // below so it isn't misclassified as a fake/junk template folder;
        // it can still be flagged separately by the actual content-
        // signature scan if a file inside it is genuinely infected.
        if (in_array(strtolower($topFolder), $sig['TEMPLATE_SYSTEM_FOLDER_NAMES'], true)) {
            return null;
        }

        $junkName = (bool) preg_match($sig['TEMPLATE_STYLE_JUNK_NAME_RE'], $topFolder);

        // Second, independent signal: does this folder have a
        // templateDetails.xml manifest at all? Joomla has no code path
        // that installs a template without one, so a folder that lacks
        // one was never actually installed as a real template -- a much
        // broader net than the tmpl_xxxxxx name check above, which only
        // catches one specific naming convention. Real-world mass
        // webshell-drop attacks have also been seen using an EXISTING
        // template's own name plus a random suffix (e.g. "beez3_degj",
        // "cassiopeia_hhnm") specifically to look more legitimate than an
        // obviously-fake tmpl_xxxxxx name at a glance.
        $noManifest = false;
        if ($absPath !== null && $depthAfterTop >= 0) {
            $templateRootAbs = $absPath;
            for ($i = 0; $i < $depthAfterTop; $i++) {
                $templateRootAbs = dirname($templateRootAbs);
            }
            if (!array_key_exists($templateRootAbs, self::$templateManifestCache)) {
                self::$templateManifestCache[$templateRootAbs] = is_file($templateRootAbs . '/templateDetails.xml');
            }
            $noManifest = !self::$templateManifestCache[$templateRootAbs];
        }

        // Strongest, hardest-to-fake signal: cross-reference Joomla's own
        // #__extensions registry -- the actual source of truth for "is
        // this installed at all". A real attack seen on a live site faked
        // BOTH the folder's templateDetails.xml AND a matching
        // #__template_styles row, but could not make its injected
        // #__extensions rows enabled -- every one was left at enabled=0,
        // unlike every genuinely-installed template. Checked ahead of, and
        // independent of, the two on-disk signals above, since those alone
        // are exactly what a sufficiently determined attacker can spoof.
        $registryProblem = null;
        if ($registeredTemplates !== null) {
            $key = $clientId . '|' . strtolower($topFolder);
            if (!array_key_exists($key, $registeredTemplates)) {
                $registryProblem = 'no matching #__extensions row of type "template" exists for it';
            } elseif (!$registeredTemplates[$key] && ($junkName || $noManifest)) {
                // A disabled #__extensions row on its OWN is not suspicious --
                // admins routinely leave a legitimately-installed template
                // disabled (most commonly Joomla's own bundled Cassiopeia or
                // Atum, sitting there unused once a different template is set
                // as default), which is a completely normal, extremely common
                // state that has nothing to do with compromise. Real reported
                // false positive: every file under a disabled-but-genuine
                // Cassiopeia install was flagged. Only treat "disabled" as a
                // red flag when corroborated by one of the on-disk signals
                // above -- exactly the actual attack pattern this check
                // exists for (see the docblock above): an injected
                // #__extensions row that could never be marked enabled,
                // PAIRED with a junk-named or manifest-less folder on disk.
                // A totally MISSING row (the branch above) needs no such
                // corroboration -- that's unambiguous on its own.
                $registryProblem = 'its #__extensions template record exists but is disabled (enabled = 0)';
            }
        }

        if ($registryProblem === null && !$junkName && !$noManifest) {
            return null;
        }

        if ($registryProblem !== null) {
            return "Sits inside \"{$topFolder}\" — {$registryProblem}, meaning Joomla's own extension registry never actually installed this as a real, active template. This is checked independently of the folder's own files, so a faked manifest or folder structure alone cannot hide it.";
        }

        if ($junkName) {
            return "Sits inside \"{$topFolder}\" — an auto-generated junk template folder name (tmpl_xxxxxx) seen paired with a matching fake #__template_styles database row in a real, confirmed mass-injection attack, not a legitimately installed template.";
        }

        return "Sits inside \"{$topFolder}\" — this folder has no templateDetails.xml manifest, so Joomla could never have installed it as a real template. A common mass webshell-drop pattern: an existing template's name plus a random suffix used purely to host a backdoor file behind a legitimate-looking path, not a real template.";
    }

    /**
     * Same idea as checkJunkTemplateFolder(), for modules/, plugins/, and
     * components/ -- a real, live compromise dropped fake folders in all
     * three (e.g. modules/helper/helper.php, plugins/system/loader/loader.php,
     * components/com_feed/feed.php), each holding a self-decoding backdoor
     * (see CONTENT_SIGNATURES' eval_encoded_blob).
     *
     * Modules: Joomla requires every real module's #__extensions element
     * to start with "mod_" -- a folder that doesn't is disqualified on
     * naming alone, no DB query needed.
     *
     * Plugins: cross-referenced against #__extensions the same way
     * templates are (see $registeredPlugins / getRegisteredPlugins()) --
     * but ONLY a completely missing row is flagged. Unlike templates,
     * "enabled=0" is NOT used here: several genuinely core Joomla plugins
     * (LDAP authentication, Basic Auth for the Web Services API, ...) ship
     * disabled by default, so treating "disabled" as suspicious flags a
     * stock, unmodified Joomla install.
     *
     * A folder whose name doesn't match any #__extensions element isn't
     * automatically fake, either: renaming a plugin's folder (prefixing
     * "x", "_", "OFF-", ...) to disable it without touching the database
     * is a common, legitimate admin technique -- the #__extensions row
     * survives under the plugin's ORIGINAL element. Before concluding a
     * folder is fake, its own manifest XML (if present -- Joomla's
     * installer convention names it <element>.xml, matching the plugin's
     * real element regardless of what the folder is currently called) is
     * also checked against the registry (see findPluginManifestElement()).
     *
     * Components: the attack above faked its #__extensions rows with
     * enabled=1, so neither the module nor plugin signal applies --
     * cross-referenced instead against manifest_cache (see
     * $registeredComponents / getRegisteredComponents()).
     */

    /**
     * See KNOWN_EXTENSION_DATA_FOLDERS above for why this exists and what
     * it does and doesn't trust. $dirName is just the folder's own name
     * (e.g. "convertforms_OnlinePay"), not a full path -- this only ever
     * applies to folders sitting directly in the webroot.
     */
    public static function isKnownExtensionDataFolder(string $dirName, array $sig, ?array $registeredComponents): bool
    {
        if ($registeredComponents === null) return false;
        foreach ($sig['KNOWN_EXTENSION_DATA_FOLDERS'] as $pattern => $component) {
            if (preg_match($pattern, $dirName) && array_key_exists(strtolower($component), $registeredComponents)) {
                return true;
            }
        }
        return false;
    }

    /**
     * True for a top-level webroot vendor/ folder that's actually
     * Composer's own dependency directory -- same "not itself suspicious,
     * but every file inside still gets scanned" treatment as
     * isKnownExtensionDataFolder() above, just correlated against a
     * sibling file (composer.json existing at the webroot) instead of an
     * installed-extension registry, since a Composer-managed vendor/
     * folder isn't tied to any one named Joomla extension. Naming alone
     * is never trusted: a folder called "vendor" with no composer.json
     * next to it gets no exemption at all.
     */
    public static function isComposerVendorFolder(string $dirName, string $webroot): bool
    {
        if (strtolower($dirName) !== 'vendor') return false;
        return is_file($webroot . '/composer.json');
    }

    public static function checkJunkExtensionFolder(string $relPath, array $sig, ?array $registeredPlugins = null, ?array $registeredComponents = null, ?string $absPath = null): ?string
    {
        $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
        $parts = explode('/', $relPath);

        $modIdx = null;
        if (($parts[0] ?? '') === 'modules') {
            $modIdx = 1;
        } elseif (($parts[0] ?? '') === 'administrator' && ($parts[1] ?? '') === 'modules') {
            $modIdx = 2;
        }
        if ($modIdx !== null) {
            $modName = $parts[$modIdx] ?? '';

            // Joomla's own "prevent directory listing" blank stub sits
            // directly in modules/ itself -- never a real module name, so
            // a bare file at that level (not a module subfolder) is never
            // treated as one.
            if (count($parts) === $modIdx + 1 && in_array(strtolower($modName), ['index.html', 'index.php'], true)) {
                return null;
            }

            if ($modName !== '' && stripos($modName, 'mod_') !== 0) {
                return "Sits inside \"{$modName}\" — a modules/ folder not named with Joomla's required \"mod_\" prefix, meaning this could never be a real installed module.";
            }
            return null;
        }

        if (($parts[0] ?? '') === 'plugins' && isset($parts[2]) && $parts[2] !== '') {
            $group = $parts[1];
            $name  = $parts[2];

            // Joomla's own "prevent directory listing" blank stub sits
            // directly in every plugins/<group>/ folder -- never a real
            // plugin name, so a bare file at the group level (not a
            // plugin subfolder) is never treated as one.
            if (count($parts) === 3 && in_array(strtolower($name), ['index.html', 'index.php'], true)) {
                return null;
            }

            if ($registeredPlugins !== null) {
                $key = strtolower($group) . '|' . strtolower($name);
                if (array_key_exists($key, $registeredPlugins)) {
                    return null;
                }

                if ($absPath !== null) {
                    $depth = count($parts) - 3;
                    $folderAbs = $absPath;
                    for ($i = 0; $i < $depth; $i++) {
                        $folderAbs = dirname($folderAbs);
                    }
                    $manifestElement = self::findPluginManifestElement($folderAbs);
                    if ($manifestElement !== null) {
                        $altKey = strtolower($group) . '|' . strtolower($manifestElement);
                        if (array_key_exists($altKey, $registeredPlugins)) {
                            return null;
                        }
                    }
                }

                // This scanner's own companion plugin (MuRu Guard Shield)
                // is a real, expected exception to "unregistered = fake":
                // its files can legitimately sit here without a matching
                // #__extensions row simply because the admin uploaded/
                // extracted them but hasn't clicked Install in Extensions
                // > Manage yet -- not a compromise, just an incomplete
                // setup step. A distinct, accurate, non-alarming message
                // replaces the generic "fake plugin" wording so it's
                // obvious what this actually is and how to resolve it,
                // while still SHOWING it (rather than silently hiding it)
                // so the admin is prompted to actually finish installing
                // it and get real-time protection active.
                if (strtolower($group) === 'system' && strtolower($name) === 'muruguardshield') {
                    return "This is MuRu Guard Shield — this scanner's own companion real-time-protection plugin, not a malicious file. Its files are present but not yet installed through Joomla. Go to Extensions → Manage → Install (or Discover) and install it to activate real-time protection; this notice clears automatically once it's registered.";
                }

                return "Sits inside plugins/{$group}/{$name} — no matching #__extensions row of type \"plugin\" exists for it, meaning Joomla never actually installed this as a real plugin.";
            }
            return null;
        }

        $compIdx = null;
        if (($parts[0] ?? '') === 'components') {
            $compIdx = 1;
        } elseif (($parts[0] ?? '') === 'administrator' && ($parts[1] ?? '') === 'components') {
            $compIdx = 2;
        }
        if ($compIdx !== null) {
            $compName = $parts[$compIdx] ?? '';
            if ($compName === '' || stripos($compName, 'com_') !== 0) {
                return null;
            }
            if ($registeredComponents !== null) {
                $key = strtolower($compName);
                if (!array_key_exists($key, $registeredComponents)) {
                    return "Sits inside \"{$compName}\" — no matching #__extensions row of type \"component\" exists for it. This can mean a fake component planted directly on disk, or simply a legitimate non-core component installed separately (FTP, a migration, a custom build) without ever running through Joomla's own Install screen.";
                }
                if (!$registeredComponents[$key]) {
                    return "Sits inside \"{$compName}\" — its #__extensions component record has no populated install manifest (manifest_cache), which every genuinely Joomla-installed extension has; a strong sign of a directly-inserted database row rather than a real installation.";
                }
            }
            return null;
        }

        return null;
    }

    /**
     * Detects the ".htaccess makes a non-PHP extension execute as PHP"
     * technique -- confirmed in a real backdoor sample:
     *   <FilesMatch "\.json$">
     *   SetHandler application/x-httpd-php
     *   </FilesMatch>
     * paired with a webshell dropped as e.g. "shell.php.json" (see the
     * \.php\.json$ entry in SUSPICIOUS_FILENAME_REGEXES) -- this makes
     * Apache execute it as PHP despite the .json extension, defeating any
     * filter/scanner that only blocks the literal ".php" extension.
     * Deliberately requires BOTH a php-execution handler directive AND a
     * <FilesMatch> targeting a NON-php extension in the same file --
     * `<FilesMatch "\.php$"> SetHandler application/x-httpd-php
     * </FilesMatch>` is a completely ordinary, common directive on shared
     * hosting (it's how PHP itself often gets enabled for .php files) and
     * must never be flagged.
     */
    public static function checkMaliciousHtaccessHandler(string $content): ?string
    {
        $hasPhpHandler = (bool) preg_match(
            '/(?:SetHandler|AddHandler|AddType)\s+["\']?application\/x-httpd-php\d*["\']?/i',
            $content
        );
        if (!$hasPhpHandler) {
            return null;
        }

        if (preg_match('/<FilesMatch\s+["\']?\\\\?\.(?!php\b)[a-z0-9]+\$?["\']?\s*>/i', $content, $m)) {
            return "Contains a directive that executes a non-PHP file extension as PHP ({$m[0]} combined with a PHP execution handler) — the exact technique used to run a dropped webshell despite a disguised extension (e.g. \".json\"), defeating any filter that only blocks \".php\" files directly.";
        }

        return null;
    }

    /**
     * ".profile" is a Unix shell-startup dotfile (bash/sh reads it from a
     * user's home directory) -- it has no meaning to Joomla or to a web
     * server request at all, and a clean Joomla install never creates one.
     * On shared hosting, the account's actual home directory and its
     * public webroot are normally two different locations, so a
     * legitimate shell ".profile" wouldn't even be reachable this way in
     * the first place. Its presence directly in the webroot is a known
     * technique for hiding a backdoor behind an filename that looks like
     * routine account configuration rather than site content, and that
     * many admins/scanners overlook precisely because it's a dotfile.
     * Flagged purely on being present at the webroot root, independent of
     * whatever its content turns out to be (which is also now scanned --
     * see the 'profile' entry added to scanFileContent()'s text-like
     * extensions -- for a more specific reason when it matches a known
     * pattern).
     */
    public static function checkRootLevelDotfile(string $basename): ?string
    {
        if (strtolower($basename) !== '.profile') {
            return null;
        }

        return 'A ".profile" file exists directly in the Joomla webroot. This is a Unix shell-startup dotfile that has no legitimate reason to be there — Joomla never creates one, and a real account ".profile" lives in the hosting account\'s home directory, not the public webroot. Commonly used to hide a backdoor behind an unassuming, easily-overlooked dotfile name.';
    }

    /** Per-request cache for findPluginManifestElement() below, keyed by plugin folder absolute path. */
    private static array $pluginManifestElementCache = [];

    /**
     * Looks for a plugin manifest XML directly inside $folderAbs (Joomla's
     * installer convention names it <element>.xml, e.g. formea.xml for a
     * plugin whose real element is "formea" -- matching its other internal
     * files like formea.php and en-GB.plg_system_formea.ini even when the
     * containing folder itself has been renamed to something else, e.g.
     * "xformea", to disable it). Returns the manifest's filename (without
     * extension) if a real Joomla plugin manifest is found, null otherwise.
     */
    private static function findPluginManifestElement(string $folderAbs): ?string
    {
        if (array_key_exists($folderAbs, self::$pluginManifestElementCache)) {
            return self::$pluginManifestElementCache[$folderAbs];
        }

        $result = null;
        if (is_dir($folderAbs)) {
            foreach (glob($folderAbs . '/*.xml') ?: [] as $xmlFile) {
                $contents = @file_get_contents($xmlFile, false, null, 0, 2048);
                if ($contents !== false && preg_match('/<extension\b[^>]*\btype\s*=\s*"plugin"/i', $contents)) {
                    $result = strtolower(pathinfo($xmlFile, PATHINFO_FILENAME));
                    break;
                }
            }
        }

        return self::$pluginManifestElementCache[$folderAbs] = $result;
    }

    /**
     * Any index.php file OUTSIDE a template's own top-level root should be
     * nothing more than Joomla's standard blank "no direct access" stub --
     * this convention holds almost universally across the ENTIRE Joomla
     * tree (components, modules, plugins, libraries, and every nested
     * template subfolder like a "features" or "layouts" directory).
     * Only a template's own root index.php (templates/<name>/index.php)
     * legitimately contains real rendering code. A non-stub index.php
     * anywhere else is a strong sign of a webshell hiding behind the
     * single most innocuous-looking filename in the whole codebase --
     * exactly the kind of file a plain executable-extension check inside
     * "code" mode directories (where .php is otherwise expected and
     * unremarkable) would never catch.
     *
     * A known-masquerade LOCATION (see TEMPLATE_FOLDER_MASQUERADE_PATTERNS)
     * is checked first and flagged unconditionally, before even looking at
     * content -- an attacker can trivially make a dropped file's content
     * look like a blank stub specifically to dodge a content-only check,
     * so a folder that shouldn't exist in any clean template at all is
     * flagged purely on where it sits, not what it contains.
     */
    public static function checkStrayIndexPhp(string $relPath, string $absPath, array $sig): ?string
    {
        $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
        if (strcasecmp(basename($relPath), 'index.php') !== 0) return null;

        foreach ($sig['TEMPLATE_FOLDER_MASQUERADE_PATTERNS'] as $re) {
            if (preg_match($re, $relPath)) {
                $preview = self::filePreview($absPath);
                $suffix  = $preview !== '' ? " Matched code: {$preview}" : '';
                return 'Path masquerades as a template asset folder that does not exist in a clean install of any known Joomla template — flagged regardless of file content (even a blank stub here is a known real-world compromise artifact).' . $suffix;
            }
        }

        if (preg_match('#^(administrator/)?templates/[^/]+/index\.php$#i', $relPath)) return null;

        // libraries/vendor/ is Joomla's bundled Composer dependency tree --
        // hundreds of third-party open-source packages, none of which
        // follow Joomla's own "blank stub" index.php convention (it's not
        // their convention to begin with). A package's own test fixtures,
        // examples, or dev tooling can legitimately ship a fully
        // functional index.php (e.g. Symfony's http-client-contracts test
        // fixtures, which run a real local HTTP server for integration
        // tests) -- structurally indistinguishable from this check's
        // "webshell hiding behind a blank-stub filename" pattern, since
        // that's exactly what a real one looks like: code where a blank
        // stub was expected. This one structural signal isn't reliable
        // enough to flag arbitrary vendor code on its own; the ordinary
        // content-signature scan (scanFileContent(), which runs on every
        // file regardless of location) still catches an actual malicious
        // payload dropped/injected here.
        if (stripos($relPath, 'libraries/vendor/') === 0 || stripos($relPath, '/libraries/vendor/') !== false) {
            return null;
        }

        // components/com_jce/editor/libraries/views/plugin/index.php is a
        // real, legitimate JCE editor view layout -- the HTML wrapper for
        // the editor's plugin dialog windows -- confirmed byte-identical
        // in structure (real markup, JCE's own `defined('JPATH_PLATFORM')
        // or die` guard rather than Joomla's `_JEXEC` stub convention)
        // across many real installs. isStandardJoomlaStub() correctly
        // doesn't recognize JPATH_PLATFORM as Joomla's blank-stub guard,
        // so this real file's real markup looked structurally identical
        // to a webshell disguise. Exempted from this STRUCTURAL check
        // only -- the ordinary content-signature scan (scanFileContent(),
        // which runs on every file regardless of location) still runs on
        // it, so an actual backdoor dropped/injected at this exact path
        // is still caught.
        if (strcasecmp($relPath, 'components/com_jce/editor/libraries/views/plugin/index.php') === 0) {
            return null;
        }

        // administrator/components/com_dropfiles/templates/dropfilesfrontend/
        // index.php -- Dropfiles (JoomUnited) ships its own small
        // templating system for its 4 bundled front-end themes; this is
        // that theme's real front-end entry point, not Joomla's blank
        // stub, the same shape as the JCE case above (an extension's own
        // view/template layer using its own convention instead of
        // Joomla's). Also exempted from this STRUCTURAL check only -- the
        // content-signature scan below still runs fully on it.
        if (strcasecmp($relPath, 'administrator/components/com_dropfiles/templates/dropfilesfrontend/index.php') === 0) {
            return null;
        }

        $contents = @file_get_contents($absPath, false, null, 0, 4096);
        if ($contents === false) return null;
        if (self::isStandardJoomlaStub($contents)) return null;

        $preview = trim(preg_replace('/\s+/', ' ', $contents));
        $preview = strlen($preview) > 220 ? substr($preview, 0, 220) . '…' : $preview;

        return "Non-standard index.php — Joomla only ever places a blank \"no direct access\" stub here (outside a template's own root layout file); this one contains extra code, a common disguise for a webshell. Matched code: {$preview}";
    }

    /**
     * True if any reason in a finding's reasons list corresponds to a
     * pattern this scanner can safely auto-repair (see
     * cleanPrependedPayload() / cleanHeadTagInjection()) -- used to build
     * the dedicated "Cleanable Files" tab in the UI, distinct from
     * findings that only support review/delete.
     */
    public static function isCleanablePattern(array $reasonsList): bool
    {
        foreach ($reasonsList as $r) {
            if (stripos($r, 'before the joomla bootstrap (_jexec)') !== false) return true;
            if (stripos($r, "before its own joomla bootstrap/access guard") !== false) return true;
            if (stripos($r, 'obfuscated script injected right after <head> tag') !== false) return true;
        }
        return false;
    }

    /**
     * True if $relPath is a genuinely required core/template entry file
     * that deleteTargets() refuses to delete (offering Clean instead).
     *
     * For a template's own root index.php (the only pattern in
     * PROTECTED_ENTRY_FILE_PATTERNS), "required" only holds if the
     * template is real. The strongest available evidence of that is a
     * matching, ENABLED row in Joomla's own #__extensions registry (see
     * $registeredTemplates / checkJunkTemplateFolder()'s docblock for why
     * this is checked ahead of, not instead of, the on-disk manifest
     * check) -- a real attack was able to fake a folder and its
     * templateDetails.xml both, but not an enabled #__extensions row. A
     * template that's neither registered nor manifested was never a real
     * template; a webshell dropped there should be deletable like any
     * other suspicious file, not steered toward "clean, never delete".
     * Pass $absPath/$registeredTemplates when available (callers that
     * only have a bare relative path fall back to the old, safer-by-
     * default "always required" behaviour).
     */
    public static function isProtectedEntryPath(string $relPath, array $sig, ?string $absPath = null, ?array $registeredTemplates = null): bool
    {
        $relNorm = str_replace('\\', '/', $relPath);
        if (in_array($relNorm, $sig['PROTECTED_ENTRY_FILES'], true)) return true;
        foreach ($sig['PROTECTED_ENTRY_FILE_PATTERNS'] as $re) {
            if (preg_match($re, $relNorm)) {
                // Joomla's own bundled "system" fallback template (see
                // checkJunkTemplateFolder()) has no templateDetails.xml but
                // is still a genuinely required core file -- always
                // protected, regardless of the checks below.
                if (preg_match('#(?:^|/)templates/system/index\.php$#i', $relNorm)) {
                    return true;
                }

                if ($registeredTemplates !== null
                    && preg_match('#^(administrator/)?templates/([^/]+)/index\.php$#i', $relNorm, $m)) {
                    $key = ($m[1] !== '' ? 1 : 0) . '|' . strtolower($m[2]);
                    return array_key_exists($key, $registeredTemplates) && $registeredTemplates[$key];
                }

                if ($absPath !== null) {
                    return is_file(dirname($absPath) . '/templateDetails.xml');
                }
                return true;
            }
        }
        return false;
    }

    /** True if $relPath sits inside one of SCAN_CONFIG's 'code' directories (components, modules, plugins, libraries, templates, cli, bin, ...) -- an area where real, actively-used source files are expected to exist. */
    public static function isCodeAreaPath(string $relPath, array $sig): bool
    {
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        foreach ($sig['SCAN_CONFIG'] as $dir => $mode) {
            if ($mode !== 'code') continue;
            if ($relNorm === $dir || strpos($relNorm, $dir . '/') === 0) return true;
        }
        return false;
    }

    /**
     * True when a finding inside a real code directory (see
     * isCodeAreaPath()) is flagged ONLY by content-signature matches --
     * i.e. every one of its reasons is a "Content signature: ..." hit,
     * with no structural/location red flag (core-masquerade, stray
     * index.php, unrecognized directory, suspicious filename, ...)
     * alongside it. That's the exact shape of a legitimate, actively-used
     * file that had a backdoor snippet injected into otherwise-normal
     * code, not a foreign file an attacker dropped -- the file's name and
     * location are completely unremarkable, only its content is
     * compromised. Deleting it outright would take down real site
     * functionality, so it must never be offered as a one-click-delete
     * candidate even when no auto-clean pattern recognizes this specific
     * infection -- landing in the Cleanable Files tab for manual review
     * is the safe outcome, not the destructive one.
     *
     * That reasoning only holds for a genuinely AMBIGUOUS content match,
     * though (see CONTENT_SIGNATURES' severity tagging in getSignatures()
     * -- 'medium' names things with a plausible benign explanation, e.g.
     * a commercial extension self-obfuscating for license protection).
     * A 'high' severity match (tagged "high-confidence exploit pattern"
     * in the reason text scanFileContent() builds) is by this codebase's
     * own definition unambiguous enough to mark the whole file High
     * confidence on its own -- code/library/plugin/module/template areas
     * with zero structural corroboration and nothing but a webshell
     * signature this unambiguous aren't legitimate files with something
     * merely injected into them; a real, confirmed live compromise
     * (a backdoor obfuscated with the third-party encoder phpkoru_encoder
     * detects, dropped at libraries/init/init.php,
     * no matching structural signal available since libraries/ has no
     * #__extensions-style registry to check against) landed here purely
     * because eval_encoded_blob is deliberately medium -- but the file
     * also carries other high-confidence markers, so a high match present
     * anywhere in the reasons list takes it out of this softening
     * entirely, letting it fall through to Suspicious Files/Delete
     * instead of sitting stuck in Cleanable with no working auto-clean
     * pattern.
     */
    public static function isContentOnlyCodeAreaFinding(string $relPath, array $reasonsList, array $sig): bool
    {
        if (empty($reasonsList) || !self::isCodeAreaPath($relPath, $sig)) return false;
        foreach ($reasonsList as $r) {
            $r = (string) $r;
            if (stripos($r, 'Content signature:') !== 0) return false;
            if (stripos($r, 'high-confidence exploit pattern') !== false) return false;
        }
        return true;
    }

    public static function humanSize(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $i = 0;
        while ($bytes >= 1024 && $i < 3) { $bytes /= 1024; $i++; }
        return round($bytes, 1) . ' ' . $units[$i];
    }

    public static function walkDir(string $dir, callable $callback, array $skipDirNames = ['node_modules', '.git']): void
    {
        if (!is_dir($dir)) return;
        $items = @scandir($dir);
        if ($items === false) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            if (in_array($item, $skipDirNames, true)) continue;
            $path = $dir . '/' . $item;
            $isDir = is_dir($path);
            $callback($path, $isDir);
            if ($isDir) self::walkDir($path, $callback, $skipDirNames);
        }
    }

    public static function dirSize(string $dir): int
    {
        $total = 0;
        $items = @scandir($dir);
        if (!$items) return 0;
        foreach ($items as $it) {
            if ($it === '.' || $it === '..') continue;
            $p = $dir . '/' . $it;
            if (is_dir($p)) $total += self::dirSize($p);
            elseif (is_file($p)) $total += (int) @filesize($p);
        }
        return $total;
    }

    public static function deleteRecursive(string $path): bool
    {
        if (is_link($path)) return @unlink($path);
        if (is_file($path)) return @unlink($path);
        if (!is_dir($path)) return true;
        $items = @scandir($path);
        if ($items === false) return false;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            if (!self::deleteRecursive($path . '/' . $item)) return false;
        }
        return @rmdir($path);
    }

    public static function isDateLikeNumericFolderName(string $name): bool
    {
        return (bool) preg_match('/^\d{1,4}$/', $name);
    }

    /**
     * True for a file/folder sitting inside a JoomTower-style pre-update
     * snapshot (tmp/joomtower_snapshots/<label>/files/...) of a
     * plugin/component/template that is CURRENTLY actually installed,
     * per getRegisteredPlugins()/getRegisteredComponents()/
     * getRegisteredTemplates(). Site-management tools that snapshot an
     * extension's whole source tree into tmp/ before updating it (for
     * rollback) otherwise flood 'upload'-mode tmp/ scanning with
     * thousands of ordinary vendor PHP files, each individually flagged
     * as "executable file in an upload directory."
     *
     * Deliberately narrow and registry-checked, not a blanket
     * tmp/joomtower_snapshots/ exemption: a snapshot folder naming an
     * extension that ISN'T actually installed gets no exemption at all,
     * so an attacker can't dodge detection just by imitating this
     * naming convention for a webshell. And this only ever suppresses
     * the STRUCTURAL "any .php under tmp/ is suspicious" check -- every
     * file here still goes through the unconditional content-signature
     * scan regardless, exactly like everywhere else.
     */
    public static function isRegisteredExtensionSnapshotPath(string $relPath, ?array $registeredPlugins, ?array $registeredComponents, ?array $registeredTemplates = null): bool
    {
        if ($registeredPlugins === null && $registeredComponents === null && $registeredTemplates === null) return false;

        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        if (!preg_match('#^tmp/joomtower_snapshots/[^/]+/files/(.+)$#i', $relNorm, $m)) {
            return false;
        }
        $inner = $m[1];

        if ($registeredPlugins !== null && preg_match('#^plugins/([a-z0-9_-]+)/([a-z0-9_-]+)(?:/|$)#i', $inner, $pm)) {
            $key = strtolower($pm[1]) . '|' . strtolower($pm[2]);
            return array_key_exists($key, $registeredPlugins);
        }

        if ($registeredComponents !== null && preg_match('#^(?:administrator/)?components/(com_[a-z0-9_-]+)(?:/|$)#i', $inner, $cm)) {
            return array_key_exists(strtolower($cm[1]), $registeredComponents);
        }

        if ($registeredTemplates !== null && preg_match('#^(administrator/)?templates/([a-z0-9_-]+)(?:/|$)#i', $inner, $tm)) {
            $clientId = $tm[1] !== '' ? 1 : 0;
            $key = $clientId . '|' . strtolower($tm[2]);
            return array_key_exists($key, $registeredTemplates);
        }

        return false;
    }

    /**
     * True for a file sitting inside JED Checker's own working directory
     * (tmp/jed_checker/unzipped/com_muruguard-X.Y.Z.zip/... or the
     * pre-rebrand com_sppbscan-X.Y.Z.zip) -- the official Joomla
     * Extensions Directory compliance tool, run by extension developers
     * against their own release zip before submission (see CHANGELOG.md
     * "JED Checker findings" entries). Running it against THIS scanner's
     * own zip extracts a full copy of its own source into a tmp/ folder,
     * which otherwise floods the 'upload'-mode "executable file in an
     * upload directory" structural check exactly like the
     * tmp/joomtower_snapshots/ case just above.
     *
     * Deliberately hardcoded to this scanner's own two product names (no
     * registry lookup needed, unlike isRegisteredExtensionSnapshotPath()
     * above) -- those names aren't attacker-choosable the way an
     * arbitrary plugin/component folder name would be, so matching them
     * literally is already as narrow as a registry check would be. And
     * this only ever suppresses the STRUCTURAL check -- every file here
     * still goes through the unconditional content-signature scan
     * regardless, exactly like everywhere else.
     */
    public static function isJedCheckerOwnZipSnapshotPath(string $relPath): bool
    {
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        return (bool) preg_match(
            '#^tmp/jed_checker/unzipped/(?:com_muruguard|com_sppbscan)-[\d.]+\.zip/#i',
            $relNorm
        );
    }

    /**
     * True for a file inside HikaShop's own media/com_hikashop/mail/
     * folder -- unlike almost every other media/ subfolder (genuinely
     * just static assets), HikaShop stores its email-rendering PHP view
     * templates here by design (order/payment/notification emails,
     * skinned in several color variants) and executes them itself; a
     * real HikaShop install can easily have 40-50 legitimate .php files
     * here, each individually flooding the 'upload'-mode "executable
     * file in an upload directory" structural check as a false positive.
     * Confirmed real: reported false-positive run flagged every one of
     * them.
     *
     * Registry-checked like isRegisteredExtensionSnapshotPath() (only
     * exempt when com_hikashop is actually installed), not hardcoded
     * like isJedCheckerOwnZipSnapshotPath() just above -- the path
     * itself only exists at all once HikaShop is installed, but
     * requiring the registry check too costs nothing and keeps the same
     * discipline as every other exemption here. And this only ever
     * suppresses the STRUCTURAL check -- every file here still goes
     * through the unconditional content-signature scan regardless,
     * exactly like everywhere else.
     */
    public static function isHikashopMailTemplatePath(string $relPath, ?array $registeredComponents): bool
    {
        if ($registeredComponents === null || !array_key_exists('com_hikashop', $registeredComponents)) {
            return false;
        }
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        return (bool) preg_match('#^media/com_hikashop/mail/#i', $relNorm);
    }

    /**
     * True if $contents is (after stripping comments/whitespace) nothing
     * more than Joomla's standard "no direct access" guard. Joomla and
     * countless legitimate extensions place this blank stub in every
     * subfolder by convention -- an index.php existing somewhere is normal
     * and NOT a threat on its own, even inside an "upload" directory like
     * media/ or images/. Only flag a stub file if it contains more than
     * this guard.
     */
    public static function isStandardJoomlaStub(string $contents): bool
    {
        $trimmed = trim($contents);
        if ($trimmed === '') return true; // some older stubs are just blank files

        $noBlockComments = preg_replace('#/\*.*?\*/#s', '', $trimmed);
        $noLineComments  = preg_replace('#//[^\n]*#', '', $noBlockComments);
        $normalized = trim(preg_replace('/\s+/', ' ', $noLineComments));

        $guardPatterns = [
            '/<\?php\s*defined\(\s*[\'"]_JEXEC[\'"]\s*\)\s*or\s*die(\s*\(\s*[\'"]?.*?[\'"]?\s*\))?\s*;?/i',
            '/<\?php\s*\?>/i',
            '/<\?php/i',
            '/\?>/',
        ];
        $stripped = $normalized;
        foreach ($guardPatterns as $p) {
            $stripped = preg_replace($p, '', $stripped);
        }
        $stripped = trim($stripped);

        // After removing the guard, comments, and PHP tags, almost nothing
        // should remain. Allow a small margin (e.g. a trailing "exit;").
        return strlen($stripped) <= 12;
    }

    /**
     * Joomla's real root index.php never executes anything before defining
     * _JEXEC. Any code before that point is a strong sign of a prepended
     * payload -- the exact `$db = array(122,105,...); require zip://...`
     * pattern seen in real Joomla compromises.
     */
    /** Patterns indicating executable/obfuscated code, used to judge whether text found before Joomla's bootstrap/guard marker is a real threat. */
    private static function suspiciousPrefixPatterns(): array
    {
        return [
            'stream-wrapper reference (zip://, phar://, etc.)' => '/(zip|phar|compress\.zlib|compress\.bzip2|data):\/\//i',
            'numeric byte-array (chr() decode obfuscation)'    => '/array\s*\(\s*(\d{2,3}\s*,\s*){6,}\d{2,3}\s*\)/i',
            'eval()'                                            => '/\beval\s*\(/i',
            'base64_decode()'                                   => '/base64_decode\s*\(/i',
            'assert()'                                           => '/\bassert\s*\(/i',
            'shell/process execution function'                  => '/\b(system|exec|shell_exec|passthru|proc_open)\s*\(/i',
        ];
    }

    /**
     * Locates the earliest point in a PHP file where Joomla's own
     * convention guarantees nothing should have executed yet -- either
     * the strict `define('_JEXEC', 1)` bootstrap constant (only the 4
     * true core entry points: index.php, administrator/index.php,
     * api/index.php, includes/app.php) or the universal
     * `defined('_JEXEC') or die(...)` guard that is the first statement
     * in virtually every OTHER Joomla PHP file (core libraries,
     * extensions, template root files, ...). Returns the matched
     * anchor's position plus everything between the opening <?php tag
     * and it, so callers can both FLAG suspicious content in that prefix
     * (checkCoreIndexIntegrity / checkGuardPrependedPayload) and, once
     * confirmed, safely CLEAN it (cleanPrependedPayload) by removing
     * exactly that prefix and nothing else -- the boundary is a hard
     * Joomla-convention marker, not a guess.
     */
    public static function checkPrependedPayload(string $contents): ?array
    {
        $openTagPos = stripos($contents, '<?php');
        if ($openTagPos === false) return null;

        $bootstrapPattern = '/(?:\\\\?\bdefine\s*\(\s*[\'"]_JEXEC[\'"]\s*,\s*1\s*\)|\bconst\s+_JEXEC\s*=\s*1)\s*;/i';
        $guardPattern      = '/defined\s*\(\s*[\'"]_JEXEC[\'"]\s*\)\s*or\s+die\s*(\([^)]*\))?\s*;/i';

        if (preg_match($bootstrapPattern, $contents, $m, PREG_OFFSET_CAPTURE)) {
            $anchorType = 'bootstrap';
        } elseif (preg_match($guardPattern, $contents, $m, PREG_OFFSET_CAPTURE)) {
            $anchorType = 'guard';
        } else {
            return null;
        }

        $prefixStart = $openTagPos + 5;
        $anchorPos   = $m[0][1];
        if ($anchorPos < $prefixStart) return null;
        $prefix = substr($contents, $prefixStart, $anchorPos - $prefixStart);

        foreach (self::suspiciousPrefixPatterns() as $label => $re) {
            if (preg_match($re, $prefix)) {
                return [
                    'anchor_type'  => $anchorType,
                    'label'        => $label,
                    'prefix'       => $prefix,
                    'open_tag_pos' => $openTagPos,
                    'anchor_pos'   => $anchorPos,
                ];
            }
        }
        return null;
    }

    /**
     * Loads the bundled per-Joomla-version SHA-256 checksum manifest for a
     * curated set of security-critical, site-independent core files (see
     * helpers/data/joomla_core_checksums.php for how it was generated and
     * exactly which files/versions it covers). Cached in a static so the
     * small data file is only read once per request no matter how many
     * files get checksum-checked.
     */
    public static function getCoreChecksumManifest(): array
    {
        static $manifest = null;
        if ($manifest === null) {
            $path = __DIR__ . '/data/joomla_core_checksums.php';
            $manifest = is_file($path) ? (include $path) : [];
        }
        return $manifest;
    }

    /**
     * Reads the exact installed Joomla core version from
     * administrator/manifests/files/joomla.xml -- the same file Joomla's
     * own update-checker relies on, present in every install. Plain
     * text/regex, no PHP execution, so this is safe to call against an
     * untrusted/potentially-infected codebase.
     */
    public static function getInstalledJoomlaVersion(string $root): ?string
    {
        $path = $root . '/administrator/manifests/files/joomla.xml';
        if (!is_file($path)) return null;
        $contents = @file_get_contents($path, false, null, 0, 4096);
        if ($contents === false) return null;
        if (preg_match('/<version>\s*([0-9]+\.[0-9]+\.[0-9]+)\s*<\/version>/i', $contents, $m)) {
            return $m[1];
        }
        return null;
    }

    /**
     * Compares a core file's actual SHA-256 against the bundled official
     * hash for the site's exact installed Joomla version. Returns null
     * (no finding) whenever the version or path isn't covered by the
     * manifest -- an unlisted version/file is a "we don't know" gap,
     * never treated as evidence of tampering, so this can only ever add
     * true findings on top of the existing heuristics, never introduce a
     * false positive from missing coverage. A mismatch is unambiguous,
     * byte-for-byte proof of tampering -- stronger than any heuristic
     * pattern match elsewhere in this scanner.
     */
    public static function checkCoreFileChecksum(string $relPath, string $absPath, ?string $version, array $manifest): ?string
    {
        if ($version === null || !isset($manifest[$version])) return null;
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        if (!isset($manifest[$version][$relNorm])) return null;
        if (!is_file($absPath)) return null;
        $actual = @hash_file('sha256', $absPath);
        if ($actual === false) return null;
        $expected = $manifest[$version][$relNorm];
        if (hash_equals($expected, $actual)) return null;

        return "Core file checksum mismatch — this file's content does not match the official Joomla {$version} release byte-for-byte "
             . '(expected sha256 ' . substr($expected, 0, 12) . '…, found ' . substr($actual, 0, 12) . '…). '
             . 'This is direct, unambiguous evidence of tampering, not a heuristic guess.';
    }

    public static function checkCoreIndexIntegrity(string $contents): ?string
    {
        $info = self::checkPrependedPayload($contents);
        if ($info === null || $info['anchor_type'] !== 'bootstrap') return null;

        $preview = trim(preg_replace('/\s+/', ' ', $info['prefix']));
        $preview = strlen($preview) > 160 ? substr($preview, 0, 160) . '…' : $preview;
        return "Core entry-point file contains suspicious code before the Joomla bootstrap (_JEXEC) — {$info['label']} detected. Offending code: {$preview}";
    }

    /**
     * Same threat detection as checkCoreIndexIntegrity(), but for ANY
     * Joomla PHP file (core library, extension, template) using its own
     * universal `defined('_JEXEC') or die` access guard as the anchor
     * instead of the bootstrap constant only the 4 true entry points
     * define. Catches a legitimate core/extension file that has had
     * malicious code prepended ahead of its own guard -- the same
     * real-world "prepended payload" technique, just outside the 4 named
     * entry points, which previously went undetected by this check.
     */
    public static function checkGuardPrependedPayload(string $contents): ?string
    {
        $info = self::checkPrependedPayload($contents);
        if ($info === null || $info['anchor_type'] !== 'guard') return null;

        $preview = trim(preg_replace('/\s+/', ' ', $info['prefix']));
        $preview = strlen($preview) > 160 ? substr($preview, 0, 160) . '…' : $preview;
        return "File contains suspicious code before its own Joomla bootstrap/access guard (defined('_JEXEC') or die) — {$info['label']} detected; a legitimate Joomla file never executes anything before this line. Offending code: {$preview}";
    }

    /**
     * Repairs a "prepended payload" infection (see checkPrependedPayload())
     * by removing exactly the code sitting between the opening <?php tag
     * and Joomla's own bootstrap/guard statement, leaving everything from
     * that statement onward -- the entire legitimate file -- completely
     * untouched. Use this instead of deleting the file: index.php,
     * administrator/index.php, and a template's own root index.php are
     * all genuinely required files that should never simply be removed.
     */
    public static function cleanPrependedPayload(string $contents): array
    {
        $info = self::checkPrependedPayload($contents);
        if ($info === null) return ['cleaned' => $contents, 'changed' => false];

        $replacement = '<?php' . "\n";
        $before  = substr($contents, 0, $info['open_tag_pos']);
        $after   = substr($contents, $info['anchor_pos']);
        $cleaned = $before . $replacement . $after;

        $preview = trim(preg_replace('/\s+/', ' ', $info['prefix']));
        $preview = strlen($preview) > 160 ? substr($preview, 0, 160) . '…' : $preview;

        return [
            'cleaned' => $cleaned, 'changed' => true, 'removed_preview' => $preview,
            'removed_start' => $info['open_tag_pos'], 'removed_end' => $info['anchor_pos'],
            'replacement' => $replacement,
        ];
    }

    /**
     * Locates the first <script>...</script> block appearing after a
     * <head> tag, if its content matches known payload-loading markers
     * (base64/atob/eval/String.fromCharCode/document.write) or is simply
     * unusually large for an inline head script. Implemented with plain
     * string search (stripos/strpos/substr) rather than a single
     * monolithic regex spanning the whole file -- a nested-lazy-quantifier
     * regex applied to tens of KB of heavily-obfuscated real-world payload
     * is exactly the kind of input that can behave inconsistently under
     * PHP's PCRE backtrack limit, which would let detection and repair
     * silently disagree. This is the single source of truth for both
     * checkHeadTagInjection() (report) and cleanHeadTagInjection()
     * (repair), so they can never drift out of sync with each other.
     */
    private static function findInjectedHeadScript(string $contents): ?array
    {
        // A real script-injection defacement plants its payload as the
        // very FIRST thing inside <head>, before any legitimate meta/
        // title/link tag -- that's what makes it run on every single
        // page. This used to just search for a <script> tag ANYWHERE
        // later in the file, which matched countless entirely legitimate
        // files: any page/template/vendor library with BOTH a <head> tag
        // and an unrelated <script> block somewhere else in the document
        // (a near-universal combination) -- Joomla's own templates/system
        // error pages, com_finder's HTML parser, php-debugbar's and
        // Symfony's own large debug-toolbar/exception-page renderers, a
        // template framework's "coming soon" countdown page, ... none of
        // which have anything actually injected. Only a script tag
        // sitting IMMEDIATELY after <head> (nothing but whitespace in
        // between) counts now.
        if (!preg_match('/<head\b[^>]*>\s*/i', $contents, $headMatch, PREG_OFFSET_CAPTURE)) return null;
        $headOpenEnd = $headMatch[0][1] + strlen($headMatch[0][0]);

        if (stripos($contents, '<script', $headOpenEnd) !== $headOpenEnd) return null;

        $scriptOpenPos = $headOpenEnd;
        $openTagCloseAt = strpos($contents, '>', $scriptOpenPos);
        if ($openTagCloseAt === false) return null;
        $bodyStart = $openTagCloseAt + 1;

        $scriptClosePos = stripos($contents, '</script', $bodyStart);
        if ($scriptClosePos === false) return null;
        $closeTagEndAt = strpos($contents, '>', $scriptClosePos);
        if ($closeTagEndAt === false) return null;
        $blockEnd = $closeTagEndAt + 1;

        $scriptBody = substr($contents, $bodyStart, $scriptClosePos - $bodyStart);
        $fullBlock  = substr($contents, $scriptOpenPos, $blockEnd - $scriptOpenPos);

        $hasMarker = (bool) preg_match('/base64|atob|eval|String\.fromCharCode|document\.write/i', $scriptBody);
        $isLarge   = strlen($scriptBody) > 200;
        if (!$hasMarker && !$isLarge) return null;

        return [
            'start' => $scriptOpenPos,
            'end'   => $blockEnd,
            'block' => $fullBlock,
            'label' => $hasMarker ? 'known payload-loading marker (base64/atob/eval/...)' : 'unusually large inline script',
        ];
    }

    public static function checkHeadTagInjection(string $contents): ?string
    {
        $info = self::findInjectedHeadScript($contents);
        if ($info === null) return null;

        $preview = trim(preg_replace('/\s+/', ' ', $info['block']));
        $preview = strlen($preview) > 200 ? substr($preview, 0, 200) . '…' : $preview;
        return "Suspicious obfuscated script injected right after <head> tag ({$info['label']}). Preview: {$preview}";
    }

    /**
     * Repairs a <head> script-injection infection (see
     * checkHeadTagInjection()) by removing exactly the injected
     * <script>...</script> block that check matched, leaving the <head>
     * tag and every other legitimate line in the template untouched.
     */
    public static function cleanHeadTagInjection(string $contents): array
    {
        $info = self::findInjectedHeadScript($contents);
        if ($info === null) return ['cleaned' => $contents, 'changed' => false];

        $cleaned = substr($contents, 0, $info['start']) . substr($contents, $info['end']);

        $preview = trim(preg_replace('/\s+/', ' ', $info['block']));
        $preview = strlen($preview) > 160 ? substr($preview, 0, 160) . '…' : $preview;

        return [
            'cleaned' => $cleaned, 'changed' => true, 'removed_preview' => $preview,
            'removed_start' => $info['start'], 'removed_end' => $info['end'], 'replacement' => '',
        ];
    }

    /**
     * Renders a ready-made, pre-escaped HTML block showing exactly what
     * the Clean action would remove (and add back, if anything) -- kept
     * server-side, like formatReasonForDisplay(), so the client never
     * parses or escapes free text, it just injects finished HTML. Takes
     * the exact removed/replacement strings a clean*() function reports
     * (see 'removed_start'/'removed_end'/'replacement' in
     * cleanPrependedPayload()/cleanHeadTagInjection()) rather than trying
     * to reverse-engineer the change from before/after content -- a
     * generic character-diff is ambiguous whenever the removed region's
     * boundary bytes repeat (e.g. a "<script...>" block sitting right
     * after "<head>" -- both start with "<"), which silently misaligns
     * the shown snippet by a few bytes. Using the exact positions the
     * clean function already computed avoids that class of bug entirely.
     */
    public static function formatCleanPreview(string $removed, string $replacement): string
    {
        $removedLen = strlen($removed);
        $removedTrim = trim($removed);
        $removedTrunc = strlen($removedTrim) > 400 ? substr($removedTrim, 0, 400) . '…' : $removedTrim;

        $addedTrim = trim($replacement);

        $html  = '<div class="muru-diff-block">';
        $html .= '<div class="muru-diff-label muru-diff-label-before">Before — Clean would remove ' . $removedLen . ' byte' . ($removedLen === 1 ? '' : 's') . '</div>';
        $html .= '<pre class="muru-diff-removed">' . htmlspecialchars($removedTrunc !== '' ? $removedTrunc : '(only whitespace)') . '</pre>';
        if ($addedTrim !== '') {
            $html .= '<div class="muru-diff-label muru-diff-label-after">After — replaced with</div>';
            $html .= '<pre class="muru-diff-added">' . htmlspecialchars($addedTrim) . '</pre>';
        } else {
            $html .= '<div class="muru-diff-label muru-diff-label-after">After — removed entirely, nothing put in its place</div>';
        }
        $html .= '</div>';
        return $html;
    }

    /**
     * Read-only dry run of cleanCodeFiles()'s exact repair logic (same
     * two functions, same order) against a file's CURRENT on-disk content
     * -- never writes anything. Returns a ready-to-display HTML diff
     * block when an auto-clean pattern is recognized, or null when it
     * isn't (unreadable file, or no pattern this scanner knows how to
     * auto-repair), so the UI can show an accurate "Preview Clean" only
     * where clicking Clean would actually change something.
     */
    public static function previewCleanDiff(string $absPath): ?string
    {
        if (!is_file($absPath)) return null;
        $contents = @file_get_contents($absPath);
        if ($contents === false) return null;

        $result = self::cleanPrependedPayload($contents);
        if (!$result['changed']) {
            $result = self::cleanHeadTagInjection($contents);
        }
        if (!$result['changed']) return null;

        $removed = substr($contents, $result['removed_start'], $result['removed_end'] - $result['removed_start']);
        return self::formatCleanPreview($removed, $result['replacement']);
    }

    /**
     * Heuristic binary-content detector, same shape as the one every
     * diff tool uses: a NUL byte anywhere in a leading sample is a
     * near-certain signal (valid UTF-8/ASCII text never contains one),
     * backed up by a printable-character ratio over that same sample for
     * content that's binary but happens not to contain a stray NUL in
     * the sampled prefix. Used to decide whether TimeMachine's repair
     * preview shows a real line diff or falls back to hash/size only --
     * no general-purpose MIME sniff exists elsewhere in this codebase to
     * reuse (getimagesize()-based checks nearby are image-specific).
     */
    public static function looksBinary(string $content): bool
    {
        if ($content === '') return false;
        $sample = substr($content, 0, 8192);
        if (strpos($sample, "\0") !== false) return true;

        $len = strlen($sample);
        $nonPrintable = 0;
        for ($i = 0; $i < $len; $i++) {
            $byte = ord($sample[$i]);
            // Tab/LF/CR plus the printable ASCII range plus anything
            // >=0x80 (allows UTF-8 multibyte text through) counts as
            // printable; only C0 control bytes outside \t\n\r are not.
            if ($byte === 9 || $byte === 10 || $byte === 13) continue;
            if ($byte >= 32) continue;
            $nonPrintable++;
        }
        return $len > 0 && ($nonPrintable / $len) > 0.30;
    }

    /**
     * Standard LCS-based line diff between two arbitrary texts -- built
     * fresh for TimeMachine's repair preview since nothing like it
     * exists elsewhere: formatCleanPreview()/previewCleanDiff() above
     * render a single ALREADY-KNOWN byte range a clean*() function
     * computed, not a general two-text comparison, and that function's
     * own docblock explains why a generic diff wasn't attempted there
     * (boundary-byte ambiguity for a single clean operation). This one
     * has no such ambiguity to worry about -- both full texts are known
     * -- so a straightforward DP table is safe.
     *
     * Deliberately refuses to run the O(N*M) LCS table beyond $maxLines
     * per side -- on shared hosting, a multi-thousand-line file could
     * make that table alone exhaust the request's memory/time budget.
     * Returns ['ok'=>false] in that case so the caller falls back to a
     * hash/size comparison instead of hanging or fataling.
     *
     * @return array{ok:bool, ops?:array<int,array{type:string,text:string}>}
     */
    public static function diffLines(string $old, string $new, int $maxLines = 2000): array
    {
        if ($old === $new) return ['ok' => true, 'ops' => []];

        $a = $old === '' ? [] : explode("\n", $old);
        $b = $new === '' ? [] : explode("\n", $new);
        if (count($a) > $maxLines || count($b) > $maxLines) {
            return ['ok' => false];
        }

        $m = count($a);
        $n = count($b);

        // Classic LCS length table, built bottom-up.
        $lcs = array_fill(0, $m + 1, array_fill(0, $n + 1, 0));
        for ($i = $m - 1; $i >= 0; $i--) {
            for ($j = $n - 1; $j >= 0; $j--) {
                $lcs[$i][$j] = $a[$i] === $b[$j]
                    ? $lcs[$i + 1][$j + 1] + 1
                    : max($lcs[$i + 1][$j], $lcs[$i][$j + 1]);
            }
        }

        // Walk the table to emit equal/remove/add ops in original order.
        $ops = [];
        $i = 0; $j = 0;
        while ($i < $m && $j < $n) {
            if ($a[$i] === $b[$j]) {
                $ops[] = ['type' => 'equal', 'text' => $a[$i]];
                $i++; $j++;
            } elseif ($lcs[$i + 1][$j] >= $lcs[$i][$j + 1]) {
                $ops[] = ['type' => 'remove', 'text' => $a[$i]];
                $i++;
            } else {
                $ops[] = ['type' => 'add', 'text' => $b[$j]];
                $j++;
            }
        }
        while ($i < $m) { $ops[] = ['type' => 'remove', 'text' => $a[$i]]; $i++; }
        while ($j < $n) { $ops[] = ['type' => 'add', 'text' => $b[$j]]; $j++; }

        return ['ok' => true, 'ops' => $ops];
    }

    /**
     * Verifies a file claiming to be an image (by extension) actually
     * contains real image data. getimagesize() is the ground truth here --
     * it sniffs the real format from content and is deliberately used
     * INSTEAD of a strict per-extension magic-byte match, because a real
     * image saved or served under a mismatched extension is common and
     * harmless (image-optimizer plugins/CDNs frequently rewrite JPGs to
     * WebP data while keeping the original .jpg filename for compatibility;
     * a tiny thumbnail can also legitimately have a minimal/nonstandard
     * header). Flagging on extension-vs-magic-byte mismatch alone produced
     * false positives on ordinary resized thumbnails -- so a successful
     * getimagesize() decode of ANY image format is accepted as proof this
     * is a real image, regardless of extension.
     *
     * Only once getimagesize() fails outright do we fall back to checking
     * magic bytes (again, against any known image format, not just the
     * extension's) to distinguish "not image data at all" (a webshell
     * simply renamed with an image extension -- high confidence) from
     * "looks like it starts as an image but the body won't decode"
     * (corrupted/truncated file, or a polyglot with data appended after
     * genuine image bytes -- lower confidence, worth a manual look).
     */
    public static function checkImageIntegrity(string $path, string $ext, string $contents): ?string
    {
        $checkedExts = ['png', 'jpg', 'jpeg', 'gif', 'webp'];
        if (!in_array($ext, $checkedExts, true)) return null;
        if ($contents === '') return null;

        if (@getimagesize($path) !== false) {
            return null;
        }

        $anyImageMagic = [
            "\x89PNG\r\n\x1a\n", "\xFF\xD8\xFF", "GIF87a", "GIF89a", "RIFF", "BM", "II*\x00", "MM\x00*",
        ];
        $looksLikeAnyImage = false;
        foreach ($anyImageMagic as $magic) {
            if (strncmp($contents, $magic, strlen($magic)) === 0) { $looksLikeAnyImage = true; break; }
        }

        if (!$looksLikeAnyImage) {
            return "File has a .$ext extension but its content does not match any known image file signature and fails to decode as an image — a strong sign of a webshell simply renamed/disguised with an image extension.";
        }

        return "File starts with a recognizable image header but the image data fails to fully decode — could be a corrupted/truncated file; worth a manual look if unexpected.";
    }

    /**
     * Builds a short, human-readable preview of a regex match plus a
     * little surrounding context, so a flagged finding shows exactly what
     * triggered it in the actual file instead of just a bare signature
     * name -- lets a human quickly judge for themselves whether it's a
     * real threat or a false positive, without opening the file.
     */
    private static function previewMatch(string $text, array $match, int $context = 30, int $maxLen = 180): string
    {
        $matchedText = $match[0][0] ?? '';
        $offset      = $match[0][1] ?? 0;
        $start       = max(0, $offset - $context);
        $length      = ($offset - $start) + strlen($matchedText) + $context;
        $snippet     = substr($text, $start, $length);
        $snippet     = trim(preg_replace('/\s+/', ' ', $snippet));
        return strlen($snippet) > $maxLen ? substr($snippet, 0, $maxLen) . '…' : $snippet;
    }

    /**
     * Decodes literal \xHH hex and \NNN octal escape sequences exactly as
     * PHP itself would when it parses a double-quoted string -- except
     * this runs against the RAW SOURCE TEXT of a file being scanned, not
     * as a live PHP string. Malware commonly spells a dangerous function
     * or superglobal name this way (e.g. "\x65\x76\x61\x6c" decodes to
     * "eval") specifically so the literal word never appears anywhere in
     * the file for a plain-text signature to match. This produces a
     * second, decoded copy of the text scanFileContent() also runs the
     * SAME CONTENT_SIGNATURES set against -- the original, unmodified
     * text is still scanned exactly as before either way, this is purely
     * additive.
     */
    public static function decodeEscapedText(string $text): string
    {
        $decoded = preg_replace_callback('/\\\\x([0-9A-Fa-f]{2})/', fn($m) => chr((int) hexdec($m[1])), $text);
        $decoded = preg_replace_callback('/\\\\([0-7]{3})/', fn($m) => chr((int) octdec($m[1])), (string) $decoded);
        return (string) $decoded;
    }

    // Archive content inspection budget -- deliberately conservative,
    // same shape as the equivalent HTProtect feature this closes the gap
    // against: a scan must never become a vector for a decompression-bomb
    // DoS against the very server it's trying to protect. A zip bigger
    // than the whole-archive cap, or an individual entry bigger than the
    // per-entry cap, is simply not opened/read past those limits -- never
    // fatal, just less coverage on an unusually large archive.
    private const ZIP_SCAN_MAX_ARCHIVE_SIZE = 4 * 1024 * 1024;   // 4MB
    private const ZIP_SCAN_MAX_ENTRY_SIZE   = 512 * 1024;        // 512KB/entry
    private const ZIP_SCAN_MAX_ENTRIES      = 256;
    private const ZIP_SCAN_MAX_TOTAL_UNPACK = 16 * 1024 * 1024;  // 16MB total

    /**
     * Opens a .zip and runs the SAME content-signature + polyglot checks
     * scanFileContent() runs on a real file against each entry inside it,
     * without ever extracting anything to disk -- ZipArchive::getFromIndex()
     * reads an entry straight into memory (capped at ZIP_SCAN_MAX_ENTRY_SIZE),
     * which is then written to one reused temp file per entry purely so
     * scanFileContent() can be called unchanged rather than duplicating its
     * entire signature-matching logic here. No entry from inside the zip is
     * ever left on disk after this returns -- the temp file is deleted
     * (in a finally block) whether or not scanning throws.
     */
    public static function scanZipArchiveContents(string $path, array $sig, array &$reasons, string $safeBrowsingApiKey = ''): bool
    {
        if (!class_exists('ZipArchive')) return false; // PHP built without the zip extension -- fail open, never fatal
        if (@filesize($path) > self::ZIP_SCAN_MAX_ARCHIVE_SIZE) return false;

        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) return false;

        $flagged = false;
        $totalUnpacked = 0;
        $entryCount = min($zip->numFiles, self::ZIP_SCAN_MAX_ENTRIES);
        $tmpEntryPath = sys_get_temp_dir() . '/muru_zip_entry_' . bin2hex(random_bytes(8));

        try {
            for ($i = 0; $i < $entryCount; $i++) {
                $stat = $zip->statIndex($i);
                if ($stat === false) continue;
                $entryName = (string) $stat['name'];
                if (substr($entryName, -1) === '/') continue; // directory entry
                if ((int) $stat['size'] > self::ZIP_SCAN_MAX_ENTRY_SIZE) continue;
                if ($totalUnpacked + (int) $stat['size'] > self::ZIP_SCAN_MAX_TOTAL_UNPACK) break;

                $entryExt = strtolower((string) pathinfo($entryName, PATHINFO_EXTENSION));
                $content = $zip->getFromIndex($i, self::ZIP_SCAN_MAX_ENTRY_SIZE);
                if ($content === false) continue;
                $totalUnpacked += strlen($content);

                @file_put_contents($tmpEntryPath, $content);
                $entryReasons = [];
                $entryFlagged = self::scanFileContent($tmpEntryPath, $entryExt, $sig, self::ZIP_SCAN_MAX_ENTRY_SIZE + 1, $entryReasons, $safeBrowsingApiKey);
                if ($entryFlagged) {
                    $flagged = true;
                    foreach ($entryReasons as $r) {
                        $reasons[] = "Inside archive entry \"{$entryName}\": {$r}";
                    }
                }
            }
        } finally {
            $zip->close();
            if (is_file($tmpEntryPath)) @unlink($tmpEntryPath);
        }

        return $flagged;
    }

    /** Runs content-signature + polyglot checks. Used in both scan modes. */
    public static function scanFileContent(string $path, string $ext, array $sig, int $maxSize, array &$reasons, string $safeBrowsingApiKey = ''): bool
    {
        if (!is_file($path)) return false;

        // Known-bad-hash check -- deliberately runs BEFORE the
        // max_file_scan_size cap below and regardless of extension.
        // hash_file() streams the file rather than loading it into
        // memory, so it's cheap even on a sample well over that cap --
        // unlike the regex content-signature pass further down, which IS
        // capped for performance. Real gap this closes: a 6.5MB
        // obfuscated backdoor (see KNOWN_MALWARE_HASHES in
        // getSignatures()) would otherwise skip every check below
        // entirely on the default 2MB cap.
        $flagged = false;
        if (!empty($sig['KNOWN_MALWARE_HASHES'])) {
            $knownHash = @hash_file('sha256', $path);
            if ($knownHash !== false && isset($sig['KNOWN_MALWARE_HASHES'][$knownHash])) {
                $flagged = true;
                $reasons[] = 'Known malware match: SHA-256 matches a confirmed malicious sample (' . $sig['KNOWN_MALWARE_HASHES'][$knownHash] . ') -- an exact byte-for-byte match, not a heuristic guess.';
            }
        }

        if (@filesize($path) === false || @filesize($path) > $maxSize) return $flagged;

        // Archive content inspection -- a .zip is opaque to every check
        // above and below this branch (they all work against text
        // content), so a webshell sitting inside an uploaded/dropped zip
        // that's never actually extracted would otherwise go completely
        // unseen. Own function, own budget limits -- see
        // scanZipArchiveContents()'s docblock.
        if ($ext === 'zip') {
            return self::scanZipArchiveContents($path, $sig, $reasons, $safeBrowsingApiKey) || $flagged;
        }

        // 'profile' and 'htaccess' aren't real extensions -- PHP's
        // pathinfo() treats everything after the leading dot in a bare
        // dotfile name (.profile, .htaccess) as its "extension" since
        // there's no second dot to split on. Included here so a .profile
        // dropped as a disguised backdoor (see checkRootLevelDotfile())
        // actually gets its content inspected, not silently skipped.
        // 'json' added so a webshell/marker dropped with a plain .json
        // extension (not just the .php.json double-extension case, which
        // was already caught by SUSPICIOUS_FILENAME_REGEXES on filename
        // alone) still gets its CONTENT inspected too -- real confirmed
        // samples: bare "hacked by <name>" defacement markers, and the
        // malicious .htaccess.json payload (see checkMaliciousHtaccess
        // Handler()). Legitimate JSON (language files, manifests,
        // composer.json, ...) never matches any signature below, so this
        // adds coverage with no new false-positive surface.
        $textLikeExts = ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phar', 'pht', 'js', 'html', 'htm', 'txt', 'css', 'xml', 'json', 'gif', 'png', 'jpg', 'jpeg', 'profile', 'htaccess'];
        if (!in_array($ext, $textLikeExts, true) && $ext !== '') return $flagged;
        $contents = @file_get_contents($path);
        if ($contents === false || $contents === '') return $flagged;

        // A legitimate image (especially a phone photo) can be several MB
        // of mostly-compressed, high-entropy pixel data. Scanning that
        // whole blob against short text signatures produces false
        // positives purely from random byte collisions -- the risk grows
        // with file size, which is exactly why large photos were getting
        // flagged. Real polyglot payloads are always prepended or appended
        // to the valid image bytes, never buried mid-stream inside them,
        // so signature scanning on image extensions is restricted to a
        // head+tail window instead of the full file. Actual code files
        // (php/js/html/...) are unaffected and still scanned in full.
        $isImageExt = in_array($ext, $sig['NON_PHP_EXTS_THAT_MUST_STAY_CLEAN'], true);
        $scanText = $isImageExt
            ? substr($contents, 0, 4096) . "\n" . substr($contents, -8192)
            : $contents;

        // Each signature carries its own severity + a plain-language "why"
        // (see getSignatures()). A high-severity match is unambiguous
        // enough on its own to mark the whole file High confidence; a
        // medium one names something that has a plausible benign
        // explanation and is surfaced for human review instead of an
        // automatic verdict. Either way the actual matched code is quoted
        // so the reason is verifiable, not just a signature label.
        // Safety net — caps runaway backtracking before any regex runs
        ini_set('pcre.backtrack_limit', '500000');
        ini_set('pcre.recursion_limit', '5000');

        foreach ($sig['CONTENT_SIGNATURES'] as $sigName => $def) {
            // Fast strpos pre-check: if ALL 'multi' strings aren't present in
            // the file, skip the regex entirely — prevents catastrophic
            // backtracking on large files (the 503 fix for rce_loader patterns).
            if (!empty($def['multi'])) {
                $allFound = true;
                foreach ($def['multi'] as $needle) {
                    if (strpos($scanText, $needle) === false) {
                        $allFound = false;
                        break;
                    }
                }
                if (!$allFound) continue;
            }

            if (preg_match($def['re'], $scanText, $m, PREG_OFFSET_CAPTURE)) {
                $flagged = true;
                $preview = self::previewMatch($scanText, $m);
                $tag = $def['severity'] === 'high' ? 'high-confidence exploit pattern' : 'needs manual review';
                $reasons[] = "Content signature: {$sigName} ({$tag}) — {$def['why']} Matched code: {$preview}";
            }
        }

        // Deep de-obfuscation pass -- see decodeEscapedText()'s own
        // docblock. Cheap strpos/regex gate first: only bother building
        // and re-scanning a decoded copy when the raw text actually
        // contains something that LOOKS like a \xHH or \NNN escape at
        // all, which the overwhelming majority of files (real code
        // included) never do. Runs the exact same CONTENT_SIGNATURES set
        // against the decoded text -- a payload hidden this way trips
        // whichever existing signature it would have tripped in plain
        // text, rather than needing its own separate copy of every rule.
        if (strpos($scanText, '\\x') !== false || preg_match('/\\\\[0-7]{3}/', $scanText)) {
            $decodedText = self::decodeEscapedText($scanText);
            if ($decodedText !== $scanText) {
                foreach ($sig['CONTENT_SIGNATURES'] as $sigName => $def) {
                    if (!empty($def['multi'])) {
                        $allFound = true;
                        foreach ($def['multi'] as $needle) {
                            if (strpos($decodedText, $needle) === false) { $allFound = false; break; }
                        }
                        if (!$allFound) continue;
                    }
                    if (preg_match($def['re'], $decodedText, $m, PREG_OFFSET_CAPTURE)) {
                        $flagged = true;
                        $preview = self::previewMatch($decodedText, $m);
                        $tag = $def['severity'] === 'high' ? 'high-confidence exploit pattern' : 'needs manual review';
                        // Prefix deliberately matches the exact
                        // "Content signature: {name} (" shape the
                        // scanText pass above uses -- filterSelfSignature
                        // Exemptions() matches on that literal prefix, so
                        // a signature already exempted for a given file
                        // stays exempted here too, decoded-pass duplicate
                        // included, instead of silently reappearing as an
                        // unfiltered "new" finding.
                        $reasons[] = "Content signature: {$sigName} ({$tag}, decoded from \\x/\\NNN escapes) — {$def['why']} Matched code: {$preview}";
                    }
                }
            }
        }

        // The PHP-open-tag check gets its own full-file pass instead of
        // sharing $scanText's narrow head+tail window above. A literal
        // "<?php" (or "<?=" followed by an identifier) is specific enough
        // -- 6+ exact bytes in a row -- that scanning it against the
        // entire file has effectively zero false-positive risk from
        // random binary collisions, unlike the broader CONTENT_SIGNATURES
        // patterns. Without this, a real image bigger than the 8KB tail
        // window with PHP appended further in (a valid, working image AND
        // a valid, working webshell at once) could slip past undetected.
        if ($isImageExt && preg_match($sig['PHP_OPEN_TAG_RE'], $contents, $m, PREG_OFFSET_CAPTURE)) {
            $flagged = true;
            $preview = self::previewMatch($contents, $m);
            $reasons[] = "Content signature: php_tag_in_image_file (polyglot shell disguised with an image extension) — Matched code: {$preview}";
        }

        $imageIssue = self::checkImageIntegrity($path, $ext, $contents);
        if ($imageIssue !== null) { $flagged = true; $reasons[] = $imageIssue; }

        $headIssue = self::checkHeadTagInjection($contents);
        if ($headIssue !== null) { $flagged = true; $reasons[] = $headIssue; }

        // Third-party reputation lookup (Google Safe Browsing) -- a
        // total no-op (zero API calls) unless the admin configured a
        // key, so this costs nothing on the overwhelming majority of
        // installs. Runs on $contents (not the narrower $scanText image
        // window) since a linked-out URL is exactly as suspicious buried
        // in an image's EXIF/metadata as anywhere else.
        if ($safeBrowsingApiKey !== '') {
            foreach (self::checkContentUrlsAgainstSafeBrowsing($contents, $safeBrowsingApiKey) as $sbReason) {
                $flagged = true;
                $reasons[] = $sbReason;
            }
        }

        // Prepended-payload check on the file's OWN Joomla access guard --
        // catches a genuinely legitimate core/extension/template file that
        // has been infected by prepending malicious code ahead of its own
        // `defined('_JEXEC') or die` guard, the same real-world technique
        // as core entry-point tampering but applicable to any PHP file,
        // not just the 4 named entry points.
        if (in_array($ext, ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'pht'], true)) {
            $guardIssue = self::checkGuardPrependedPayload($contents);
            if ($guardIssue !== null) { $flagged = true; $reasons[] = $guardIssue; }
        }

        return $flagged;
    }

    /**
     * Strips ONLY this scanner's own known, narrow, per-file content-
     * signature false positives (see SELF_CONTENT_SIGNATURE_EXEMPTIONS'
     * docblock for the full reasoning) out of a findings reasons list --
     * never used to skip a file from scanning entirely, only to remove
     * the specific self-referential matches after the fact. Any OTHER
     * reason (a different content signature, a structural/location
     * check, ...) present in the same list is left untouched. Returns the
     * filtered reasons list; the caller re-derives whether the file is
     * still flagged from whether it's non-empty.
     */
    public static function filterSelfSignatureExemptions(string $relPath, array $sig, array $reasons): array
    {
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');

        // A JED Checker unzip (see isJedCheckerOwnZipSnapshotPath()) is a
        // copy of this scanner's OWN raw distribution zip, whose internal
        // layout is admin/... (Joomla renames that to administrator/
        // components/com_muruguard/... only at install time -- see
        // muruguard.xml's <files folder="admin">). Normalize back to the
        // canonical installed path before the lookup below, so this exact
        // same file gets the exact same narrow exemption it already has
        // at its real install location, rather than duplicating the
        // SELF_CONTENT_SIGNATURE_EXEMPTIONS table for a second path shape.
        if (preg_match('#^tmp/jed_checker/unzipped/(com_muruguard|com_sppbscan)-[\d.]+\.zip/admin/(.+)$#i', $relNorm, $m)) {
            $relNorm = 'administrator/components/' . strtolower($m[1]) . '/' . $m[2];
        }

        $exemptSigNames = $sig['SELF_CONTENT_SIGNATURE_EXEMPTIONS'][$relNorm] ?? null;
        if ($exemptSigNames === null) return $reasons;

        return array_values(array_filter($reasons, function ($r) use ($exemptSigNames) {
            foreach ($exemptSigNames as $sigName) {
                if (stripos((string) $r, "Content signature: {$sigName} ") === 0) return false;
            }
            return true;
        }));
    }

    /**
     * See KNOWN_LIBRARY_SIGNATURE_EXEMPTIONS above -- same mechanism as
     * filterSelfSignatureExemptions(), but matched by path SUFFIX so it
     * still applies regardless of which extension vendored the library or
     * how deeply nested it ended up.
     */
    public static function filterKnownLibrarySignatureExemptions(string $relPath, array $sig, array $reasons): array
    {
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        foreach ($sig['KNOWN_LIBRARY_SIGNATURE_EXEMPTIONS'] as $suffix => $exemptSigNames) {
            if (substr($relNorm, -strlen($suffix)) !== $suffix) continue;
            return array_values(array_filter($reasons, function ($r) use ($exemptSigNames) {
                foreach ($exemptSigNames as $sigName) {
                    if (stripos((string) $r, "Content signature: {$sigName} ") === 0) return false;
                }
                return true;
            }));
        }
        return $reasons;
    }

    /**
     * Full snippet-bearing-reason exemption for this scanner's own stub-
     * protected data/backup files:
     *   - administrator/components/com_muruguard/helpers/data/scan-progress.php
     *   - administrator/components/com_muruguard/helpers/data/timemachine-index.php
     *   - anything under .../helpers/data/timemachine-blobs/ (Pro-only;
     *     random hex-id filenames, matched by directory prefix rather
     *     than one exact name)
     * These are never actually interpreted as PHP regardless of what
     * bytes follow the stub (see dataFileStubPrefix()) -- the stub's own
     * "?>" is the entire executable surface; everything after it is inert
     * text, only ever read back via file_get_contents()+json_decode(),
     * never include()/require()'d.
     *
     * scan-progress.php stores a live copy of the most recent scan's own
     * findings, several of which append a literal code snippet onto
     * their reason string. TimeMachine's index and blob files are the
     * same idea from a different direction: they store an exact "before"
     * copy of a file/DB row a repair action is about to change -- so if
     * what was actually there before cleanup WAS a real malicious
     * payload, that payload's own bytes are now durably sitting inside
     * this backup, on purpose, so Restore can put it back byte-for-byte
     * if the repair itself turns out to be wrong. Real reported false
     * positive: a TimeMachine snapshot of an already-cleaned finding
     * re-triggered the same content signature against its own backup.
     *
     * See formatReasonForDisplay()'s own "Matched code:"/"Offending
     * code:"/"Preview:" marker regex, reused below as the authoritative
     * test for "does this reason carry a snippet" -- so on the NEXT
     * scan, these files are guaranteed to eventually contain byte
     * sequences that look exactly like a real threat, purely by quoting
     * (or snapshotting) one back from wherever it was actually found,
     * regardless of which specific check originally found it.
     *
     * Unlike SELF_CONTENT_SIGNATURE_EXEMPTIONS (a fixed, small, reviewed
     * set of signatures known to self-match this scanner's own SOURCE
     * text), there's no fixed set of signatures/checks that could show up
     * here -- it depends entirely on what else a given site's scan
     * actually found, or what a repair action just backed up -- so this
     * strips every snippet-bearing reason for these files, justified by
     * them being structurally inert rather than by "every signature has
     * been reviewed." A reason with no snippet (a purely structural
     * finding) is left untouched, though none apply anyway since these
     * paths are normal, expected component locations, not an upload/tmp
     * directory.
     */
    public static function filterStubProtectedDataCacheExemptions(string $relPath, array $reasons): array
    {
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        $isScanProgress = $relNorm === 'administrator/components/com_muruguard/helpers/data/scan-progress.php';
        $isTimeMachineData = $relNorm === 'administrator/components/com_muruguard/helpers/data/timemachine-index.php'
            || strpos($relNorm, 'administrator/components/com_muruguard/helpers/data/timemachine-blobs/') === 0;
        if (!$isScanProgress && !$isTimeMachineData) {
            return $reasons;
        }
        return array_values(array_filter(
            $reasons,
            fn($r) => !preg_match('/(Matched code:|Offending code:|Preview:)/', (string) $r)
        ));
    }

    /**
     * @param string|array $reasons Either the already-joined display string
     *                              (legacy callers) or the raw list of
     *                              individual reason strings -- passing the
     *                              raw list also preserves each one
     *                              separately in 'reasons' for the
     *                              per-finding code-analysis modal in the UI.
     */
    public static function recordFinding(array &$arr, string $absPath, string $root, $reasons, bool $isDir = false): void
    {
        $reasonsList = is_array($reasons) ? array_values(array_unique($reasons)) : [(string) $reasons];
        $reasonText  = implode(' | ', $reasonsList);

        $rel = ltrim(str_replace($root, '', $absPath), '/');
        $size = $isDir ? self::dirSize($absPath) : (is_file($absPath) ? (int) @filesize($absPath) : 0);
        $highSignals = [
            'high-confidence exploit pattern', 'icon-font', 'malicious pattern', 'unrecognized', 'numeric',
            'non-standard index.php', 'core entry-point', 'stream-wrapper', 'backup/duplicate', 'bootstrap',
            'masquerade', 'disguise', 'polyglot', 'checksum mismatch',
        ];
        $confidence = 'medium';
        foreach ($highSignals as $sigName) {
            if (stripos($reasonText, $sigName) !== false) { $confidence = 'high'; break; }
        }
        $arr[$rel] = [
            'rel' => $rel, 'abs' => $absPath, 'reason' => $reasonText, 'reasons' => $reasonsList,
            'type' => $isDir ? 'dir' : 'file', 'confidence' => $confidence,
            'size' => $size, 'mtime' => (int) @filemtime($absPath),
        ];
    }

    /**
     * Splits a reason string into a lead sentence + an optional code
     * snippet (the "Matched code:" / "Offending code:" / "Preview:"
     * suffix that several checks append), and renders both as safe,
     * pre-escaped HTML for the code-analysis modal. Kept server-side so
     * the client never has to parse free text -- it just injects
     * ready-made HTML.
     */
    public static function formatReasonForDisplay(string $reason): string
    {
        if (preg_match('/^(.*?)(Matched code:|Offending code:|Preview:)\s*(.*)$/s', $reason, $m)) {
            $lead  = trim($m[1]);
            $label = trim($m[2], ': ');
            $code  = trim($m[3]);
            return '<div class="muru-reason-block"><p>' . htmlspecialchars($lead) . '</p>'
                 . '<div class="muru-reason-code-label">' . htmlspecialchars($label) . '</div>'
                 . '<pre class="muru-reason-code">' . htmlspecialchars($code) . '</pre></div>';
        }
        return '<div class="muru-reason-block"><p>' . htmlspecialchars($reason) . '</p></div>';
    }

    /** A short, single-line summary for the table row (full detail lives in the modal). */
    public static function shortReasonLabel(array $reasonsList): string
    {
        if (empty($reasonsList)) return '';
        $first = preg_replace('/\s*(Matched code:|Offending code:|Preview:).*$/s', '', $reasonsList[0]);
        $first = trim($first);
        if (strlen($first) > 90) $first = substr($first, 0, 90) . '…';
        $extra = count($reasonsList) - 1;
        return $extra > 0 ? "{$first} (+{$extra} more)" : $first;
    }

    /**
     * Pro: renders the standalone, print-optimized HTML for the one-click
     * security report (see MuruguardControllerScanner::report()). Deliberately
     * omits the raw "Matched code" snippets each finding carries -- this
     * report is meant to be shared (e.g. with a client or stakeholder) as
     * proof of monitoring, not as a vulnerability disclosure, so it only
     * lists the short reason label alongside the affected path.
     */
    public static function buildSecurityReportHtml(\MuruguardModelScanner $model): string
    {
        $app = Factory::getApplication();
        $siteName = htmlspecialchars((string) $app->get('sitename', 'Your Joomla Site'));
        $domain = htmlspecialchars(self::currentSiteDomain());

        $findings = $model->getFileFindings();
        $total = count($findings);
        $high = 0;
        foreach ($findings as $f) {
            if (($f['confidence'] ?? '') === 'high') $high++;
        }
        $medium = $total - $high;

        $cfgParams = \Joomla\CMS\Component\ComponentHelper::getParams('com_muruguard');
        $protectionActive = (bool) $cfgParams->get('shield_enabled', 0) && $model->isShieldPluginActive();

        $version = '';
        $manifestPath = JPATH_ADMINISTRATOR . '/components/com_muruguard/muruguard.xml';
        if (is_file($manifestPath)) {
            $manifestXml = @simplexml_load_file($manifestPath);
            if ($manifestXml !== false) $version = (string) $manifestXml->version;
        }
        $version = htmlspecialchars($version !== '' ? 'v' . $version : '');

        $generatedAt = date('Y-m-d H:i:s');

        $rows = '';
        $sorted = $findings;
        uasort($sorted, function ($a, $b) {
            if (($a['confidence'] ?? '') === ($b['confidence'] ?? '')) return 0;
            return ($a['confidence'] ?? '') === 'high' ? -1 : 1;
        });
        foreach ($sorted as $f) {
            $badgeClass = ($f['confidence'] ?? '') === 'high' ? 'badge-high' : 'badge-medium';
            $badgeLabel = ($f['confidence'] ?? '') === 'high' ? 'High' : 'Medium';
            $reason = self::shortReasonLabel($f['reasons'] ?? [(string) ($f['reason'] ?? '')]);
            $rows .= '<tr>'
                . '<td class="path">' . htmlspecialchars((string) ($f['rel'] ?? '')) . '</td>'
                . '<td><span class="badge ' . $badgeClass . '">' . $badgeLabel . '</span></td>'
                . '<td class="reason">' . htmlspecialchars($reason) . '</td>'
                . '</tr>';
        }
        if ($total === 0) {
            $rows = '<tr><td colspan="3" class="empty">No suspicious files found -- this site is clean as of the last scan.</td></tr>';
        }

        $statusLabel = $total === 0 ? 'Clean' : ($high > 0 ? 'Action Recommended' : 'Review Recommended');
        $statusClass = $total === 0 ? 'status-clean' : ($high > 0 ? 'status-high' : 'status-medium');
        $protectionLabel = $protectionActive ? 'ON' : 'OFF';

        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>MuRu Guard Security Report - {$siteName}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; color: #1f2937; margin: 0; padding: 40px; background: #f3f4f6; }
  .sheet { max-width: 860px; margin: 0 auto; background: #fff; padding: 48px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
  .brand { display: flex; align-items: center; justify-content: space-between; border-bottom: 3px solid #4f46e5; padding-bottom: 20px; margin-bottom: 24px; }
  .brand h1 { font-size: 20px; margin: 0; color: #4f46e5; }
  .brand .tagline { font-size: 11px; color: #9ca3af; margin-top: 2px; }
  .no-print { text-align: right; margin-bottom: 16px; }
  .no-print button { background: #4f46e5; color: #fff; border: 0; padding: 10px 18px; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; }
  h2.site { font-size: 22px; margin: 0 0 4px; }
  .meta { font-size: 12px; color: #6b7280; margin-bottom: 24px; }
  .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 28px; }
  .stat { border: 1px solid #e5e7eb; border-radius: 10px; padding: 14px; text-align: center; }
  .stat .n { font-size: 24px; font-weight: 800; }
  .stat .l { font-size: 10px; text-transform: uppercase; letter-spacing: .04em; color: #6b7280; margin-top: 2px; }
  .status-pill { display: inline-block; padding: 4px 12px; border-radius: 999px; font-size: 12px; font-weight: 700; margin-bottom: 24px; }
  .status-clean { background: #d1fae5; color: #065f46; }
  .status-medium { background: #fef3c7; color: #92400e; }
  .status-high { background: #fee2e2; color: #991b1b; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th { text-align: left; background: #f9fafb; padding: 8px 10px; font-size: 10px; text-transform: uppercase; letter-spacing: .03em; color: #6b7280; border-bottom: 2px solid #e5e7eb; }
  td { padding: 8px 10px; border-bottom: 1px solid #f3f4f6; vertical-align: top; }
  td.path { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; word-break: break-all; }
  td.reason { color: #4b5563; }
  td.empty { text-align: center; color: #6b7280; padding: 24px; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 10px; font-weight: 700; }
  .badge-high { background: #fee2e2; color: #991b1b; }
  .badge-medium { background: #fef3c7; color: #92400e; }
  .footer { margin-top: 32px; padding-top: 16px; border-top: 1px solid #e5e7eb; font-size: 10px; color: #9ca3af; text-align: center; }
  @media print {
    body { background: #fff; padding: 0; }
    .sheet { box-shadow: none; padding: 0; max-width: none; }
    .no-print { display: none; }
  }
</style>
</head>
<body>
<div class="sheet">
  <div class="no-print"><button onclick="window.print()">🖨️ Print / Save as PDF</button></div>
  <div class="brand">
    <div>
      <h1>🛡️ MuRu Guard</h1>
      <div class="tagline">Automated Security Scan Report</div>
    </div>
    <div class="tagline">{$version}</div>
  </div>
  <h2 class="site">{$siteName}</h2>
  <div class="meta">{$domain} &middot; Generated {$generatedAt}</div>
  <span class="status-pill {$statusClass}">{$statusLabel}</span>
  <div class="summary">
    <div class="stat"><div class="n">{$total}</div><div class="l">Total Findings</div></div>
    <div class="stat"><div class="n">{$high}</div><div class="l">High Confidence</div></div>
    <div class="stat"><div class="n">{$medium}</div><div class="l">Medium Confidence</div></div>
    <div class="stat"><div class="n">{$protectionLabel}</div><div class="l">Protection Mode</div></div>
  </div>
  <table>
    <thead><tr><th>Path</th><th>Confidence</th><th>Reason</th></tr></thead>
    <tbody>{$rows}</tbody>
  </table>
  <div class="footer">Generated by MuRu Guard for Joomla &middot; lyzerslab.com</div>
</div>
</body>
</html>
HTML;
    }

    /**
     * Surgically strips known XSS injection markers out of a Joomla menu
     * "params" JSON blob, preserving every other legitimate setting.
     *
     * Handles two shapes of nested value:
     *  1. A string that itself decodes as valid JSON (Helix Ultimate stores
     *     layout data as JSON-encoded strings, sometimes nested several
     *     levels deep) -- these are recursed into normally.
     *  2. A string that LOOKS like it was meant to be a JSON container
     *     (starts with '{' or '[') but FAILS to json_decode -- this happens
     *     when the attacker's own injected payload contains an unescaped
     *     quote that breaks JSON syntax. This is handled by
     *     regexStripMalformed(), which now ALSO applies a fail-safe:
     *     after targeted removal, if any signature still matches (or the
     *     tell-tale "(function(){'use strict'" scaffold survives), the
     *     entire value is blanked rather than left as a hollowed-out but
     *     still-present script skeleton.
     *
     * item_id is enforced as a plain integer unconditionally when reached
     * as a proper leaf (not gated behind pattern matching).
     */
    public static function cleanMenuParamsXss(string $paramsJson, array $patterns): array
    {
        $decoded = json_decode($paramsJson, true);
        if ($decoded === null && trim($paramsJson) !== 'null') {
            return ['cleaned' => $paramsJson, 'changed' => false];
        }
        $changed = false;

        $sanitizeLeaf = function (string $key, string $value) use ($patterns, &$changed): string {
            if (strcasecmp($key, 'item_id') === 0) {
                if (preg_match('/^\d+$/', trim($value))) return $value;
                $changed = true;
                return '';
            }

            $hit = false;
            foreach ($patterns as $re) { if (preg_match($re, $value)) { $hit = true; break; } }
            if (!$hit) return $value;
            $changed = true;

            $clean = $value;
            $clean = preg_replace('/<script\b[^>]*>.*?<\/script\s*>/is', '', $clean);
            $clean = preg_replace('/<img\b[^>]*>/is', '', $clean);
            $clean = preg_replace('/\bon[a-z]+\s*=\s*(".*?"|\'.*?\'|[^\s>]+)/is', '', $clean);
            $clean = preg_replace('/javascript\s*:/i', '', $clean);
            $clean = preg_replace('/localStorage\s*\.\s*(setItem|getItem)\s*\([^)]*\)/i', '', $clean);
            $clean = preg_replace('/sessionStorage\s*\.\s*(setItem|getItem)\s*\([^)]*\)/i', '', $clean);
            $clean = preg_replace('/MutationObserver/i', '', $clean);
            $clean = preg_replace('/xss\.report[^\s\'"<>]*/i', '', $clean);
            $clean = preg_replace('/_hu_?inject[^\s\'"<>]*/i', '', $clean);
            $clean = preg_replace('/document\s*\.\s*createElement\s*\(\s*[\'"]script[\'"]\s*\)/i', '', $clean);

            foreach ($patterns as $re) {
                if (preg_match($re, $clean)) return '';
            }
            if (preg_match('/\(\s*function\s*\(\s*\)\s*\{/i', $clean)) {
                return '';
            }
            return $clean;
        };

        // For strings that look like a JSON container but fail to parse --
        // regex-strip the malicious content directly instead of discarding
        // the whole field, with a fail-safe blank-out if residue survives.
        $regexStripMalformed = function (string $raw) use ($patterns, &$changed): string {
            $hit = false;
            foreach ($patterns as $re) { if (preg_match($re, $raw)) { $hit = true; break; } }
            if (!$hit) return $raw;
            $changed = true;

            // Blank any item_id value outright -- these should only ever
            // hold a plain numeric module/item ID, never markup or script.
            $raw = preg_replace('/"item_id"\s*:\s*"(?:[^"\\\\]|\\\\.)*"/is', '"item_id":""', $raw);

            // Targeted removal pass.
            $raw = preg_replace('/<script\b[^>]*>.*?<\/script\s*>/is', '', $raw);
            $raw = preg_replace('/<img\b[^>]*>/is', '', $raw);
            $raw = preg_replace('/\bon[a-z]+\s*=\s*(".*?"|\'.*?\'|[^\s>]+|`[^`]*`)/is', '', $raw);
            $raw = preg_replace('/javascript\s*:/i', '', $raw);
            $raw = preg_replace('/localStorage\s*\.\s*(setItem|getItem)\s*\([^)]*\)/i', '', $raw);
            $raw = preg_replace('/sessionStorage\s*\.\s*(setItem|getItem)\s*\([^)]*\)/i', '', $raw);
            $raw = preg_replace('/MutationObserver/i', '', $raw);
            $raw = preg_replace('/xss\.report[^\s\'"<>`]*/i', '', $raw);
            $raw = preg_replace('/_hu_?inject[^\s\'"<>`]*/i', '', $raw);
            $raw = preg_replace('/document\s*\.\s*createElement\s*\(\s*[\'"]script[\'"]\s*\)/i', '', $raw);

            // Fail-safe: targeted removal only deletes the specific tokens
            // matched above, but attacker payloads come in endless variants
            // (different function/variable names, different wrapper shape).
            // If ANY signature still matches after the targeted pass -- or
            // the tell-tale "(function(){'use strict'" scaffold is still
            // present -- the remaining text is unresolved malicious residue,
            // not a false positive. Blank the whole value rather than ship
            // a hollowed-out-but-still-present script skeleton.
            $stillDangerous = false;
            foreach ($patterns as $re) {
                if (preg_match($re, $raw)) { $stillDangerous = true; break; }
            }
            if (!$stillDangerous && preg_match('/\(\s*function\s*\(\s*\)\s*\{/i', $raw)) {
                $stillDangerous = true;
            }
            if ($stillDangerous) {
                return '';
            }

            return $raw;
        };

        $walk = function (&$node, $key = '') use (&$walk, &$sanitizeLeaf, &$regexStripMalformed) {
            if (is_array($node)) {
                foreach ($node as $k => &$v) { $walk($v, is_string($k) ? $k : $key); }
                unset($v);
                return;
            }
            if (!is_string($node)) return;

            $inner = json_decode($node, true);
            if (is_array($inner)) {
                $walk($inner, $key);
                $node = json_encode($inner, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                return;
            }

            $trimmed = ltrim($node);
            if ($trimmed !== '' && ($trimmed[0] === '{' || $trimmed[0] === '[')) {
                // Looks like it was meant to be a JSON container but the
                // attacker's own malformed escaping broke it. Regex-strip
                // instead of nuking the whole field.
                $node = $regexStripMalformed($node);
                return;
            }

            $node = $sanitizeLeaf($key, $node);
        };

        $walk($decoded);

        if (!$changed) return ['cleaned' => $paramsJson, 'changed' => false];
        return ['cleaned' => json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), 'changed' => true];
    }

    /**
     * Read-only .htaccess hardening advisor -- reads the site's actual
     * root .htaccess (if any) and checks it against a fixed set of
     * recommended directives, most directly relevant to what this
     * scanner exists to catch: PHP execution inside writable upload-style
     * directories is exactly how a dropped webshell gets run in the
     * first place, so blocking it at the web-server level is a strong,
     * independent layer even if a malicious file is never cleaned up.
     * Deliberately NEVER writes to .htaccess itself -- this only reports
     * what's missing and shows the suggested rule text for the admin to
     * add by hand, since a wrong edit to this specific file can 500 the
     * entire site and there's no reliable way to test a rewrite rule
     * server-side before it's live.
     *
     * Each check's regex is intentionally loose (matches the INTENT of a
     * directive, not one exact phrasing) to avoid a false "missing"
     * result against a site that already has equivalent protection
     * worded differently -- a false negative here just means a
     * redundant suggestion, which is far less harmful than repeatedly
     * telling an admin who already handled something that they haven't.
     *
     * @return array{
     *   exists: bool,
     *   path: string,
     *   checks: list<array{id:string,category:string,severity:string,label:string,present:bool,explanation:string,suggestion:string}>
     * }
     */

    /**
     * Shown on the pre-scan gate so an admin on a large site (many files,
     * or a slow disk) can see whether this host will actually let a scan
     * raise its own execution-time/memory limits BEFORE running one --
     * not after it dies partway through with a generic "500 - Whoops"
     * page (Joomla's error handler for an uncaught PHP fatal, which a
     * timeout or memory-exhaustion always is; PHP itself gives no way to
     * catch or gracefully degrade from either one mid-request). Probing
     * here (ini_set + immediate re-read) is exactly what scanFilesystem()'s
     * own controller action already does before a real scan -- this just
     * surfaces the same result earlier, where it's actually useful.
     */
    public static function getServerLimitsInfo(): array
    {
        $wantedExecTime = 300;
        $wantedMemory   = '512M';

        $execBefore = (string) ini_get('max_execution_time');
        // function_exists() first -- set_time_limit() in disable_functions
        // (common on shared hosts) makes calling it an uncaught fatal
        // Error, not a warning @ can suppress. Confirmed real: this exact
        // gap in the scan controller's own equivalent call was the actual
        // cause of a live "500 - Whoops" report.
        if (function_exists('set_time_limit')) {
            @set_time_limit($wantedExecTime);
        }
        $execAfter = (string) ini_get('max_execution_time');
        // 0 means "unlimited" -- always fine regardless of what we asked for.
        $execRaisable = $execAfter === '0' || (int) $execAfter >= $wantedExecTime;

        $memBefore = (string) ini_get('memory_limit');
        @ini_set('memory_limit', $wantedMemory);
        $memAfter = (string) ini_get('memory_limit');
        $memRaisable = $memAfter === '-1' || self::iniMemoryToBytes($memAfter) >= self::iniMemoryToBytes($wantedMemory);

        return [
            'execTimeBefore' => $execBefore,
            'execTimeAfter'  => $execAfter,
            'execRaisable'   => $execRaisable,
            'memoryBefore'   => $memBefore,
            'memoryAfter'    => $memAfter,
            'memRaisable'    => $memRaisable,
            'allGood'        => $execRaisable && $memRaisable,
        ];
    }

    /** Parses a php.ini-style shorthand memory value ("512M", "1G", "128K", "0") into bytes. */
    private static function iniMemoryToBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '' || $value === '-1') return PHP_INT_MAX; // -1 = unlimited
        $unit = strtoupper(substr($value, -1));
        $num  = (int) $value;
        switch ($unit) {
            case 'G': return $num * 1024 * 1024 * 1024;
            case 'M': return $num * 1024 * 1024;
            case 'K': return $num * 1024;
            default:  return (int) $value;
        }
    }

    public static function getHtaccessSuggestions(string $root): array
    {
        $path = $root . '/.htaccess';
        $exists = is_file($path);
        $contents = $exists ? (string) @file_get_contents($path) : '';

        $has = function (string $re) use ($contents): bool {
            return (bool) preg_match($re, $contents);
        };

        $checks = [];

        // 1. PHP/executable execution blocked inside writable upload-style
        // directories -- the single most directly relevant check this
        // tool can make: every real webshell drop this scanner detects
        // still runs the moment it's requested unless the server itself
        // refuses to execute PHP there.
        $blocksExecution = $has('/RewriteRule[^\n]*\[[^\]]*F[^\]]*\]/i')
            || $has('/<FilesMatch[^>]*php[^>]*>\s*(?:\r?\n)+\s*(?:Require\s+all\s+denied|Deny\s+from\s+all)/is');
        $mentionsUploadDir = $has('/\b(media|images|uploads|tmp|cache)\b/i');
        $checks[] = [
            'id' => 'block_php_in_uploads',
            'category' => 'critical',
            'severity' => 'high',
            'label' => 'Block PHP execution inside upload/writable directories',
            'present' => $blocksExecution && $mentionsUploadDir,
            'explanation' => 'A webshell dropped into a normally-writable folder (media, images, uploads, tmp, cache, ...) still runs the moment it\'s requested unless Apache itself refuses to execute PHP there -- this blocks it at the server level even before this scanner ever gets a chance to find and remove the file.',
            'suggestion' => "<IfModule mod_rewrite.c>\n    RewriteEngine On\n    RewriteCond %{REQUEST_URI} ^/(media|images|uploads|tmp|cache|files)/ [NC]\n    RewriteCond %{REQUEST_URI} \\.(php|phtml|phar|php[0-9]|pht)\$ [NC]\n    RewriteRule .* - [F,L]\n</IfModule>",
        ];

        // 2. Directory listing disabled.
        $checks[] = [
            'id' => 'disable_indexes',
            'category' => 'critical',
            'severity' => 'medium',
            'label' => 'Disable directory listing',
            'present' => $has('/Options\s+[^\n]*-Indexes/i') || $has('/IndexIgnore\s+\*/i'),
            'explanation' => 'Without this, browsing directly to a folder with no index file (e.g. an upload directory) lists every file in it -- handing an attacker a directory of exactly what to try requesting, and revealing dropped files that were otherwise hidden.',
            'suggestion' => "Options -Indexes",
        ];

        // 3. Sensitive files/dotfiles blocked from direct web access --
        // .env, .git internals, composer manifests, and backup/log files
        // can leak credentials or source layout if requested directly.
        $checks[] = [
            'id' => 'block_sensitive_files',
            'category' => 'critical',
            'severity' => 'medium',
            'label' => 'Block direct access to sensitive/dotfiles',
            'present' => $has('/<FilesMatch[^>]*\\\\\.(?:env|git|bak|sql)[^>]*>/i') || $has('/RewriteRule[^\n]*\\\\.(?:env|git)/i'),
            'explanation' => 'A .env file, .git directory, composer.lock, or a stray .sql/.bak backup sitting in the webroot can leak database credentials or the exact software versions in use if it\'s ever requested directly -- none of this is meant to be served over HTTP at all.',
            'suggestion' => "<FilesMatch \"(?i)(\\.env|\\.git.*|composer\\.(json|lock)|.*\\.sql|.*\\.bak)\$\">\n    Require all denied\n</FilesMatch>",
        ];

        // 4. X-Content-Type-Options.
        $checks[] = [
            'id' => 'header_nosniff',
            'category' => 'header',
            'severity' => 'low',
            'label' => 'X-Content-Type-Options: nosniff',
            'present' => $has('/X-Content-Type-Options/i'),
            'explanation' => 'Stops browsers from guessing ("sniffing") a file\'s type from its content instead of trusting the server\'s declared Content-Type -- closes off one way a maliciously-crafted upload can be tricked into executing as something other than what it was uploaded as.',
            'suggestion' => "<IfModule mod_headers.c>\n    Header always set X-Content-Type-Options \"nosniff\"\n</IfModule>",
        ];

        // 5. Permissions-Policy.
        $checks[] = [
            'id' => 'header_permissions_policy',
            'category' => 'header',
            'severity' => 'low',
            'label' => 'Permissions-Policy (restrictive baseline)',
            'present' => $has('/Permissions-Policy/i'),
            'explanation' => 'Disables browser features (camera, microphone, geolocation, payment, ...) this site has no legitimate reason to use, so an injected script can\'t invoke them even if one ever makes it onto the page.',
            'suggestion' => "<IfModule mod_headers.c>\n    Header always set Permissions-Policy \"geolocation=(), microphone=(), camera=(), payment=()\"\n</IfModule>",
        ];

        // 6. HSTS -- only actually meaningful (and safe to suggest) once
        // the site is already serving over HTTPS; suggesting it on a
        // plain-HTTP site would be premature and confusing.
        $isHttps = Uri::getInstance()->isSsl();
        $checks[] = [
            'id' => 'header_hsts',
            'category' => 'header',
            'severity' => 'low',
            'label' => 'Strict-Transport-Security (HSTS)',
            'present' => !$isHttps || $has('/Strict-Transport-Security/i'),
            'explanation' => $isHttps
                ? 'Tells browsers to always use HTTPS for this domain from now on, even if a user types or clicks a plain http:// link -- closes the window an attacker gets from a single unencrypted request.'
                : 'Not applicable yet -- this site isn\'t currently being served over HTTPS. Set up SSL first; adding this header before then would have no effect.',
            'suggestion' => "<IfModule mod_headers.c>\n    Header always set Strict-Transport-Security \"max-age=31536000; includeSubDomains\" env=HTTPS\n</IfModule>",
        ];

        // 7. CSP -- deliberately advisory-only with a strong caveat: a
        // misconfigured Content-Security-Policy can break legitimate site
        // functionality (many Joomla extensions rely on inline scripts),
        // so this is never treated as a "problem" the way the checks
        // above are, only offered as an optional next step.
        $checks[] = [
            'id' => 'header_csp',
            'category' => 'header',
            'severity' => 'info',
            'label' => 'Content-Security-Policy (advisory -- test before enabling)',
            'present' => $has('/Content-Security-Policy/i'),
            'explanation' => 'Restricts which sources scripts/styles/etc. can load from, meaningfully raising the bar against injected/XSS content actually executing. Test thoroughly before enabling on a live site -- an overly strict policy can silently break legitimate extension or template functionality, and \'unsafe-inline\'/\'unsafe-eval\' (often required for older Joomla extensions to keep working) meaningfully weakens the protection this header is meant to provide.',
            'suggestion' => "<IfModule mod_headers.c>\n    Header always set Content-Security-Policy \"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';\"\n</IfModule>",
        ];

        return ['exists' => $exists, 'path' => $path, 'checks' => $checks];
    }

    /**
     * nginx equivalent of getHtaccessSuggestions()'s rule set, as one
     * copy-paste `server {}` block -- .htaccess does nothing at all on
     * nginx (it doesn't read per-directory config files), so a site
     * running on it needs an entirely different syntax for the exact
     * same protections, added to the site's own nginx config and
     * reloaded, which this PHP process has no access to do itself.
     * Deliberately always advisory-only, unlike getHtaccessSuggestions()'s
     * write-capable checks -- there's no local file to detect "already
     * applied" from the way there is for .htaccess, so this only ever
     * offers the snippet, it never claims to know whether it's live.
     */
    public static function getNginxHardeningSnippet(): string
    {
        return <<<'NGINX'
# MuRu Guard -- nginx equivalent of the .htaccess hardening checklist.
# Add inside your site's `server { }` block and reload nginx
# (nginx -t && systemctl reload nginx). Adjust paths if your webroot
# layout differs from a stock Joomla install.

# 1. Block PHP execution inside upload/writable directories
location ~* ^/(media|images|uploads|tmp|cache|files)/.*\.(php|phtml|phar|php[0-9]|pht)$ {
    deny all;
    return 403;
}

# 2. Disable directory listing (off by default on nginx, listed for completeness)
autoindex off;

# 3. Block direct access to sensitive/dotfiles
location ~* (^|/)\.(env|git|ht|user\.ini)|composer\.(json|lock)|\.(sql|bak)$ {
    deny all;
    return 403;
}

# 4-6. Security headers
add_header X-Content-Type-Options "nosniff" always;
add_header Permissions-Policy "geolocation=(), microphone=(), camera=(), payment=()" always;
# Uncomment once this site is actually served over HTTPS:
# add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

# 7. Content-Security-Policy -- test thoroughly before enabling, same
# caveat as the .htaccess advisory: an overly strict policy can break
# legitimate extension/template functionality.
# add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';" always;
NGINX;
    }

    /**
     * Writes ONE of getHtaccessSuggestions()'s own recommended rules into
     * the site's real .htaccess -- closing the gap between "here's a
     * snippet, paste it in yourself" and it actually being applied. This
     * is deliberately narrower than a full self-test/auto-rollback
     * system: it backs up the current file first and never duplicates a
     * rule it already applied, but it does NOT verify the site still
     * loads correctly afterward the way some competitors' equivalent
     * feature does -- an admin applying a rule against unusual server
     * config should still check the site themselves. Meaningfully safer
     * than a blind edit; not a guarantee.
     *
     * Reuses getHtaccessSuggestions()'s own check list rather than a
     * second copy of the same rule text, so the "Apply" button can never
     * drift from what the advisory panel actually shows. 'header_csp' is
     * deliberately never write-able this way -- see that check's own
     * docblock on why it stays advisory-only.
     *
     * @return array{ok:bool,error?:string,alreadyPresent?:bool,backupFile?:string}
     */
    public static function applyHtaccessSuggestion(string $root, string $checkId): array
    {
        if ($checkId === 'header_csp') {
            return ['ok' => false, 'error' => 'This rule can silently break legitimate site functionality if applied blindly -- copy it and test manually instead.'];
        }
        if ($checkId === 'header_hsts' && !Uri::getInstance()->isSsl()) {
            return ['ok' => false, 'error' => "This site isn't served over HTTPS yet -- set up SSL first."];
        }

        $suggestions = self::getHtaccessSuggestions($root);
        $check = null;
        foreach ($suggestions['checks'] as $c) {
            if ($c['id'] === $checkId) { $check = $c; break; }
        }
        if ($check === null) {
            return ['ok' => false, 'error' => 'Unknown rule.'];
        }
        if ($check['present']) {
            return ['ok' => true, 'alreadyPresent' => true];
        }

        $path = $root . '/.htaccess';
        $existing = is_file($path) ? (string) @file_get_contents($path) : '';

        // Uniquely-identifiable markers (same spirit as third-party tools'
        // own begin/end comment blocks) -- lets this same code re-check
        // "did WE already apply this" independent of whatever
        // getHtaccessSuggestions()'s own regex thinks (a strict
        // AllowOverride server could silently ignore the directive while
        // the marker still proves an apply was attempted), and makes the
        // block trivially removable by hand later if ever needed.
        $marker = "# BEGIN MuRu Guard: {$checkId} #";
        $endMarker = "# END MuRu Guard: {$checkId} #";
        if (strpos($existing, $marker) !== false) {
            return ['ok' => true, 'alreadyPresent' => true];
        }

        // Back up whatever's there right now BEFORE writing -- same
        // stub-protected helpers/data/ convention as every other runtime
        // file this extension creates (attack-log.php, false-positives.php,
        // ...), never dropped into the public webroot itself where it'd
        // just be one more file for THIS scanner's own webroot-hygiene
        // check to flag.
        $backupDir = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/htaccess-backups';
        if (!is_dir($backupDir)) {
            @mkdir($backupDir, 0755, true);
        }
        @file_put_contents($backupDir . '/index.html', '<!-- Silence is golden. -->');
        $backupName = date('Ymd-His') . '-' . substr(md5($checkId . microtime()), 0, 6) . '.php';
        @file_put_contents($backupDir . '/' . $backupName, self::dataFileStubPrefix() . $existing);

        $block = "\n{$marker}\n{$check['suggestion']}\n{$endMarker}\n";
        $newContents = ($existing !== '' ? rtrim($existing) . "\n" : '') . $block;

        if (@file_put_contents($path, $newContents) === false) {
            return ['ok' => false, 'error' => "Could not write to .htaccess -- check the web server's file permissions on {$path}."];
        }

        // Self-test: an .htaccess syntax error, or a rule this specific
        // server config doesn't like (AllowOverride restrictions,
        // mod_rewrite not loaded, ...), commonly turns EVERY page on the
        // site into an immediate 500 -- the exact failure mode this
        // whole feature exists to make impossible to leave behind
        // unnoticed. selfTestHomepageReachable() makes one real outbound
        // request to the site's own homepage; a failure rolls back to
        // the exact bytes just backed up above and reports it rather
        // than leaving a broken .htaccess in place.
        if (!self::selfTestHomepageReachable()) {
            @file_put_contents($path, $existing);
            return [
                'ok' => false,
                'error' => "Applied, but the site's own homepage didn't respond correctly afterward -- rolled back to the previous .htaccess automatically. Nothing was left broken.",
                'rolledBack' => true,
            ];
        }

        return ['ok' => true, 'backupFile' => $backupName];
    }

    /**
     * One real outbound HTTP GET to this site's own homepage, short
     * timeout, used ONLY as applyHtaccessSuggestion()'s post-write self-
     * test. Isolated into its own method (rather than inlined) so it can
     * be mocked/overridden in a test -- swap this method, not the caller,
     * exactly the same pattern as fetchCountryFromApi()/
     * fetchVulnerabilityFeedFromApi() above. Fails CLOSED (returns false,
     * triggering a rollback) on anything but a clean 2xx/3xx response --
     * a timeout or connection failure on a request to the site's OWN
     * homepage is itself a strong signal something just broke.
     */
    protected static function selfTestHomepageReachable(): bool
    {
        try {
            $url = rtrim((string) Uri::root(), '/') . '/';
            $context = stream_context_create(['http' => ['timeout' => 8, 'ignore_errors' => true, 'method' => 'GET']]);
            $response = @file_get_contents($url, false, $context);
            if ($response === false) return false;

            $statusLine = $http_response_header[0] ?? '';
            if (!preg_match('/HTTP\/\S+\s+(\d{3})/', $statusLine, $m)) return false;
            $status = (int) $m[1];

            // 2xx/3xx is a live, correctly-responding server. Deliberately
            // NOT requiring exactly 200 -- a site with its own maintenance
            // redirect, cache-layer 304, or similar is still "working",
            // just not what a bare fetch happens to return right now.
            return $status >= 200 && $status < 400;
        } catch (\Throwable $e) {
            return false;
        }
    }

    // ==================================================================
    // Periodic homepage watch -- site-down/defacement/SEO-spam-injection
    // detection, independent of a full filesystem+DB scan. Runs on every
    // scheduledcheck() hit (see the controller) regardless of whether a
    // full scan also happens that cycle -- a real fetch of the site's
    // own live homepage, cheap enough to check every time the admin's
    // cron actually calls in, rather than being tied to the scan's own
    // (often much less frequent) cadence.
    // ==================================================================

    // Real-world "hacked site" SEO-spam injection categories -- pharma,
    // gambling, adult, counterfeit-goods, and payday-loan spam are the
    // standard, well-documented categories abused in these campaigns
    // (the same ones Sucuri/Wordfence incident writeups describe). A
    // single hit is only a "review this" signal, not automatically
    // confirmed -- a legitimate site could conceivably mention one of
    // these words once in passing; several hits together in the
    // homepage's own title/meta is a much stronger signal.
    private const SEO_SPAM_KEYWORDS = [
        'viagra', 'cialis', 'levitra', 'casino', 'poker online', 'judi online',
        'payday loan', 'replica watches', 'replica handbags', 'cheap nfl jerseys',
        'buy backlinks', 'escort service', 'porn', 'xxx video',
    ];

    private static function homepageWatchStateFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/homepage-watch-state.php';
    }

    /**
     * Protected-user snapshot storage -- same stub-protected-.php pattern
     * as homepageWatchStateFilePath() (see dataFileStubPrefix()'s own
     * docblock), except this file is more sensitive than any other data
     * file this extension writes: it holds password HASHES for every
     * currently-designated Super User, kept solely to detect and revert
     * tampering. Never exported (deliberately absent from
     * EXPORTABLE_CONFIG_KEYS below), never rendered in any view, never
     * logged in full -- only ever read back by
     * MuruguardModelScanner::checkAndRevertProtectedUsers().
     */
    private static function protectedUsersStateFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/protected-users-state.php';
    }

    /** Reads back the protected-user snapshot written by saveProtectedUsersState(), or null if none has ever been taken. */
    public static function loadProtectedUsersState(): ?array
    {
        $path = self::protectedUsersStateFilePath();
        if (!is_file($path)) return null;
        $decoded = json_decode(self::stripDataFileStub((string) @file_get_contents($path)), true);
        return is_array($decoded) ? $decoded : null;
    }

    /** Overwrites the protected-user snapshot state file. See protectedUsersStateFilePath()'s own docblock for why this needs the stub-protected .php treatment more than any other data file here. */
    public static function saveProtectedUsersState(array $state): void
    {
        @file_put_contents(self::protectedUsersStateFilePath(), self::dataFileStubPrefix() . json_encode($state));
    }

    /**
     * One real fetch of the site's own homepage -- checks whether it's
     * reachable at all, whether the response body matches a known
     * defacement calling-card (same DEFACEMENT_PATTERNS list the
     * database-row defacement check already uses), and whether the
     * <title>/<meta name="description"> contain injected SEO-spam
     * keywords. Fails open on any fetch error -- 'reachable' => false is
     * itself a real finding (the site being down), so this never throws
     * past a caller expecting a real result either way.
     *
     * @return array{reachable:bool,httpStatus:?int,defaced:bool,defacementMatch:?string,seoSpam:bool,seoSpamMatch:?string}
     */
    public static function checkHomepageHealth(array $sig): array
    {
        $result = ['reachable' => false, 'httpStatus' => null, 'defaced' => false, 'defacementMatch' => null, 'seoSpam' => false, 'seoSpamMatch' => null];

        try {
            $url = rtrim((string) Uri::root(), '/') . '/';
            $context = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true, 'method' => 'GET']]);
            $response = @file_get_contents($url, false, $context);
            if ($response === false) return $result;

            $statusLine = $http_response_header[0] ?? '';
            if (preg_match('/HTTP\/\S+\s+(\d{3})/', $statusLine, $m)) {
                $result['httpStatus'] = (int) $m[1];
            }
            $result['reachable'] = $result['httpStatus'] !== null && $result['httpStatus'] >= 200 && $result['httpStatus'] < 400;
            if (!$result['reachable']) return $result;

            foreach ($sig['DEFACEMENT_PATTERNS'] as $re) {
                if (preg_match($re, $response, $dm)) {
                    $result['defaced'] = true;
                    $result['defacementMatch'] = mb_substr((string) $dm[0], 0, 80);
                    break;
                }
            }

            $titleAndMeta = '';
            if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $response, $tm)) $titleAndMeta .= $tm[1] . ' ';
            if (preg_match('/<meta[^>]+name=["\']description["\'][^>]*content=["\']([^"\']*)["\']/is', $response, $dm2)) $titleAndMeta .= $dm2[1];
            foreach (self::SEO_SPAM_KEYWORDS as $kw) {
                if (stripos($titleAndMeta, $kw) !== false) {
                    $result['seoSpam'] = true;
                    $result['seoSpamMatch'] = $kw;
                    break;
                }
            }

            return $result;
        } catch (\Throwable $e) {
            return $result;
        }
    }

    /**
     * Compares a freshly-checked homepage state against the last known
     * one and updates the stored state either way. Returns a plain-
     * language change description ONLY when something meaningful
     * actually changed (down<->up, clean<->defaced, clean<->SEO-spam) --
     * null on every call where nothing changed, so the scheduled-check
     * caller only ever alerts on a real transition, never re-alerts
     * every single cron hit for a condition that's already been
     * reported once.
     */
    public static function updateHomepageWatchState(array $current): ?string
    {
        $path = self::homepageWatchStateFilePath();
        $previous = null;
        if (is_file($path)) {
            $decoded = json_decode(self::stripDataFileStub((string) @file_get_contents($path)), true);
            if (is_array($decoded)) $previous = $decoded;
        }

        @file_put_contents($path, self::dataFileStubPrefix() . json_encode($current + ['checkedAt' => time()]));

        if ($previous === null) return null; // first-ever check -- nothing to compare against yet

        $change = null;
        if ($previous['reachable'] !== $current['reachable']) {
            $change = $current['reachable']
                ? 'The site is reachable again (was unreachable on the previous check).'
                : 'The site appears to be DOWN -- the homepage did not respond correctly.';
        } elseif (!$current['reachable']) {
            return null; // still down, already reported the transition
        } elseif ($current['defaced'] && !$previous['defaced']) {
            $change = 'The homepage now matches a known defacement marker: ' . $current['defacementMatch'];
        } elseif (!$current['defaced'] && $previous['defaced']) {
            $change = 'The homepage no longer matches the previously-detected defacement marker.';
        } elseif ($current['seoSpam'] && !$previous['seoSpam']) {
            $change = 'The homepage title/description now contains a likely SEO-spam injection ("' . $current['seoSpamMatch'] . '").';
        } elseif (!$current['seoSpam'] && $previous['seoSpam']) {
            $change = 'The homepage no longer shows the previously-detected SEO-spam injection.';
        }

        return $change;
    }

    // ==================================================================
    // Configuration import/export -- a deliberately narrow, hand-
    // maintained ALLOWLIST of portable feature toggles/settings, never a
    // blanket dump of every stored param. Excludes every secret this
    // extension stores (license key, AI provider keys, Safe Browsing
    // key, cron token, backend-auth credentials) on purpose -- an
    // exported file is meant to be portable between sites (or kept as a
    // config backup) without ever becoming a credential leak if shared,
    // emailed, or committed to a repo by mistake.
    // ==================================================================

    private const EXPORTABLE_CONFIG_KEYS = [
        'items_per_page', 'alert_email', 'cron_enabled',
        'shield_enabled', 'shield_block_patterns', 'shield_block_bruteforce',
        'shield_bruteforce_threshold', 'shield_bruteforce_window',
        'shield_block_useragents', 'shield_block_countries', 'shield_blocked_countries',
        'shield_block_referrers', 'shield_block_pbl', 'shield_block_upload_extensions',
        'shield_autoblock_repeat_offenders', 'shield_autoblock_threshold', 'shield_autoblock_window',
        'waf_enabled', 'harden_remove_generator', 'harden_tmp_cleanup_enabled',
        'homepage_watch_enabled', 'harden_lock_admin_actions', 'protected_users_enabled',
        'fleet_reporting_enabled', 'autopilot_enabled',
        'alert_slack_enabled', 'alert_discord_enabled', 'alert_telegram_enabled',
        'timemachine_retention_days', 'timemachine_retention_max_snapshots',
    ];

    /** Builds the exportable config array from the component's current params -- see EXPORTABLE_CONFIG_KEYS' own docblock for why this is a narrow allowlist, never a blanket dump. */
    public static function buildExportableConfig($cfgParams): array
    {
        $out = [];
        foreach (self::EXPORTABLE_CONFIG_KEYS as $key) {
            $out[$key] = $cfgParams->get($key, null);
        }
        return ['exportedAt' => date('c'), 'exportedFrom' => self::currentSiteDomain(), 'settings' => $out];
    }

    /**
     * Validates and filters an uploaded config export back down to the
     * SAME allowlist -- an imported file's 'settings' object can only
     * ever affect keys this scanner already knows are safe to import;
     * any unrecognized/extra key in the uploaded JSON is silently
     * dropped rather than blindly merged into stored params, so a
     * hand-edited or malicious file can never smuggle in a setting
     * outside this list.
     *
     * @return array{ok:bool,settings?:array,error?:string,skipped?:int}
     */
    public static function parseImportableConfig(string $json): array
    {
        $decoded = json_decode($json, true);
        if (!is_array($decoded) || !isset($decoded['settings']) || !is_array($decoded['settings'])) {
            return ['ok' => false, 'error' => 'Not a recognizable MuRu Guard configuration export.'];
        }

        $settings = [];
        $skipped = 0;
        foreach ($decoded['settings'] as $key => $value) {
            if (!in_array($key, self::EXPORTABLE_CONFIG_KEYS, true)) { $skipped++; continue; }
            $settings[$key] = $value;
        }

        if (empty($settings)) {
            return ['ok' => false, 'error' => 'No recognizable settings found in this file.'];
        }

        return ['ok' => true, 'settings' => $settings, 'skipped' => $skipped];
    }

    // ==================================================================
    // One-click restore of a core file from its official checksum
    // baseline -- fetches the SAME Joomla version's file content
    // directly from joomla/joomla-cms' own public GitHub release tag
    // (plain PHP/text source files, not build artifacts -- a tag's
    // content matches the released package byte-for-byte), and NEVER
    // trusts that fetch on its own: the fetched content's own SHA-256 is
    // checked against the bundled, pre-verified expected hash in
    // getCoreChecksumManifest() before anything is written. A fetch
    // that doesn't match -- a MITM'd response, a transient GitHub issue,
    // an unexpected tag edit -- is refused outright rather than written
    // "close enough". Only ever offered for the small set of files
    // getCoreChecksumManifest() actually has a verified hash for; there
    // is deliberately no broader "restore any core file" capability.
    // ==================================================================

    private const CORE_FILE_RESTORE_SOURCE_URL = 'https://raw.githubusercontent.com/joomla/joomla-cms/';

    /** @return array{ok:bool,error?:string,backupFile?:?string} */
    public static function restoreCoreFileFromBaseline(string $root, string $relPath): array
    {
        $version = self::getInstalledJoomlaVersion($root);
        if ($version === null) {
            return ['ok' => false, 'error' => "Could not determine the installed Joomla version."];
        }

        $manifest = self::getCoreChecksumManifest();
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        if (!isset($manifest[$version][$relNorm])) {
            return ['ok' => false, 'error' => "No official checksum on file for \"{$relNorm}\" on Joomla {$version} -- restore is only offered for files this scanner has a verified official hash for."];
        }
        $expectedHash = $manifest[$version][$relNorm];

        $fetched = self::fetchOfficialCoreFileContent($version, $relNorm);
        if ($fetched === null || $fetched === '') {
            return ['ok' => false, 'error' => "Could not fetch the official Joomla {$version} release copy of this file right now -- try again shortly."];
        }

        $actualHash = hash('sha256', $fetched);
        if (!hash_equals($expectedHash, $actualHash)) {
            return ['ok' => false, 'error' => "The fetched official copy didn't match the expected checksum -- refused to write it. Nothing was changed."];
        }

        $absPath = rtrim($root, '/') . '/' . $relNorm;

        // Back up whatever's currently there (even if it's the tampered
        // version) before overwriting -- same stub-protected
        // helpers/data/ convention as htaccess-backups.
        $backupDir = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/core-restore-backups';
        if (!is_dir($backupDir)) @mkdir($backupDir, 0755, true);
        @file_put_contents($backupDir . '/index.html', '<!-- Silence is golden. -->');
        $backupName = null;
        if (is_file($absPath)) {
            $current = (string) @file_get_contents($absPath);
            $backupName = date('Ymd-His') . '-' . str_replace('/', '__', $relNorm) . '.php';
            @file_put_contents($backupDir . '/' . $backupName, self::dataFileStubPrefix() . $current);
        }

        $dir = dirname($absPath);
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        if (@file_put_contents($absPath, $fetched) === false) {
            return ['ok' => false, 'error' => "Could not write to {$relNorm} -- check the web server's file permissions."];
        }

        return ['ok' => true, 'backupFile' => $backupName];
    }

    /** Isolated for testability -- swap/mock this in tests rather than the caller. */
    protected static function fetchOfficialCoreFileContent(string $version, string $relPath): ?string
    {
        try {
            $url = self::CORE_FILE_RESTORE_SOURCE_URL . $version . '/' . $relPath;
            $context = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);
            $response = @file_get_contents($url, false, $context);
            if ($response === false) return null;
            return $response;
        } catch (\Throwable $e) {
            return null;
        }
    }
}