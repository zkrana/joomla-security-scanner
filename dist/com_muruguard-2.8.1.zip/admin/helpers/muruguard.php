<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     MIT
 *
 * Pure detection/cleaning logic, ported near-verbatim from the standalone
 * scanner script. None of this is Joomla-specific -- it is the same
 * regex/filesystem heuristics as before, just wrapped as static methods
 * so the model can call them. Signature arrays live in getSignatures().
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

class MuruguardHelper
{
    /**
     * Ensures the request is from a logged-in backend user with manage rights.
     * Call from entry point, controllers, views, and destructive model methods.
     * This is the BASE gate every task requires; see requireDeleteAccess() /
     * requireEditAccess() / requireAdminAccess() below for the finer-grained
     * checks layered on top of it for specific destructive or configuration-
     * changing tasks -- a user group can have core.manage alone to view scan
     * results without being able to act on them.
     */
    public static function requireManageAccess(): void
    {
        $user = Factory::getApplication()->getIdentity();

        if ($user->guest || (int) $user->id <= 0) {
            throw new \Joomla\CMS\Exception\NotAllowed(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        if (!$user->authorise('core.manage', 'com_muruguard')) {
            throw new \Joomla\CMS\Exception\NotAllowed(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    /** Required for destructive actions: deleting flagged files/folders, deleting rogue asset rows. */
    public static function requireDeleteAccess(): void
    {
        self::requirePermission('core.delete');
    }

    /** Required for in-place modification: Clean code, Clean menu XSS. */
    public static function requireEditAccess(): void
    {
        self::requirePermission('core.edit');
    }

    /** Required for changing component configuration: the Settings panel (scheduled scanning). */
    public static function requireAdminAccess(): void
    {
        self::requirePermission('core.admin');
    }

    private static function requirePermission(string $action): void
    {
        self::requireManageAccess();

        $user = Factory::getApplication()->getIdentity();
        if (!$user->authorise($action, 'com_muruguard')) {
            throw new \Joomla\CMS\Exception\NotAllowed(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    /**
     * Non-throwing permission checks, for the view to decide whether to
     * show/enable an action button at all -- offering a button that will
     * just 403 on click is bad UX, so the template hides or disables it
     * up front based on these.
     */
    public static function canDelete(): bool
    {
        return self::can('core.delete');
    }

    public static function canEdit(): bool
    {
        return self::can('core.edit');
    }

    public static function canAdmin(): bool
    {
        return self::can('core.admin');
    }

    private static function can(string $action): bool
    {
        $user = Factory::getApplication()->getIdentity();
        return !$user->guest && (int) $user->id > 0 && (bool) $user->authorise($action, 'com_muruguard');
    }

    /** Central place for every pattern list used across the scan. */
    public static function getSignatures(): array
    {
        return [
            'EXEC_EXTS' => ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phar', 'pht', 'shtml'],

            // Hidden dot-files with a well-known, ubiquitous benign
            // purpose -- shipped by countless legitimate composer/vendor
            // packages, not something an attacker planted. Exempted from
            // the "hidden dot-file with an executable extension" check.
            // Grow this list if another legitimate one turns up.
            'HIDDEN_DOTFILE_ALLOWLIST' => [
                '.phpstorm.meta.php',
            ],

            'SUSPICIOUS_FILENAME_REGEXES' => [
                '/^codex-sppb-[a-f0-9]+\.php$/i',
                '/^codex_sppb.*\.php$/i',
                '/queue_\d+\.php$/i',
                '/\.php\.gif$/i',
                '/\.xml\.php$/i',
                '/^x\.xml$/i',
                '/^filefuns\.php$/i',
                '/^elp\.php$/i',
                // Confirmed in a real backdoor sample: a webshell renamed
                // to double-extension .php.json (sometimes stacked twice,
                // .php.json.json) to slip past any filter that only blocks
                // .php, paired with a .htaccess that rewrites .json to
                // execute as PHP anyway (see checkMaliciousHtaccessHandler()).
                // No legitimate file is ever named this way -- always malicious.
                '/\.php(?:\.json)+$/i',
                // "kill.gif"/"kill.png" -- a recognized attacker calling-card
                // filename, dropped as a marker/flag file (sometimes empty,
                // sometimes a tiny webshell) rather than a real image. Flagged
                // on the exact bare filename alone regardless of content --
                // no legitimate site names a file this way.
                '/^kill\.(gif|png)$/i',
            ],

            'ROOT_SUSPICIOUS_FILENAME_REGEXES' => [
                '/^wp-[a-z0-9_-]*\.(php|txt|html?)$/i',
                '/file[-_]?ma[nr]+ger2?\.php$/i',
                '/^[a-z0-9]{1,3}\.php$/i',
                '/^\d{1,8}\.php$/i',
                '/^[a-z]{2,8}\.txt$/i',
            ],

            'CONFIG_BACKUP_PATTERNS' => [
                '/^configuration[\._\-]?bak\.php$/i',
                '/^configuration[\._\-]?old\.php$/i',
                '/^configuration\.php\.(bak|old|orig|save|swp|~)$/i',
                '/^config[\._\-]?backup\.php$/i',
                '/^configuration\d*\.php\.(txt|bak)$/i',
            ],

            // Each signature carries its own severity + a plain-language
            // explanation of why it's flagged, rather than one blanket
            // "any content signature match = High" rule. Signatures with a
            // plausible legitimate explanation (obfuscated-but-legal
            // commercial extension code, a legit extension using zip://
            // for archive handling, a dev-config placeholder domain, ...)
            // are scored 'medium' -- worth a human look, not an automatic
            // high-confidence verdict -- so a real webshell isn't diluted
            // down to "just another medium finding" next to false alarms.
            'CONTENT_SIGNATURES' => [
                'eval_base64_post'   => ['re' => '/eval\s*\(\s*(?:@)?base64_decode\s*\(\s*(?:@)?\$_(POST|REQUEST|GET)/i',
                    'severity' => 'high', 'why' => 'Executes attacker-supplied POST/REQUEST/GET data via base64-decoded eval() — the canonical one-line PHP webshell pattern, no legitimate use.'],
                'eval_encoded_blob'  => ['re' => '/eval\s*\(\s*(?:@)?(?:gzinflate\s*\(\s*)?(?:@)?(?:base64_decode|str_rot13|gzuncompress|gzdecode|convert_uudecode)\s*\(/i',
                    'severity' => 'medium', 'why' => 'eval() directly wrapping a decode/decompress call -- the classic shape of self-decoding, obfuscated PHP (a real, confirmed compromise on a live site used exactly this: a commercial obfuscation tool wrapping a fully-encoded backdoor across dozens of files with plausible extension-sounding names). Deliberately does not require the decoded value to come from a superglobal (that narrower, always-malicious case is eval_base64_post above, at high severity) -- some legitimate commercial extensions also self-obfuscate this way purely for license/anti-piracy protection, so this is flagged for review rather than treated as automatically confirmed, but it is now visible either way instead of being invisible.'],
                'cookie_gated_eval'  => ['re' => '/md5\s*\(\s*(?:@)?\$_COOKIE\[[\'"][^\'"]+[\'"]\]\s*\)\s*==\s*[\'"][a-f0-9]{32}[\'"]/i',
                    'severity' => 'high', 'why' => 'Gates hidden behavior behind a secret cookie value matched by MD5 hash — a common backdoor-access-control pattern.'],
                'assert_backdoor'    => ['re' => '/assert\s*\(\s*(?:@)?\$_(POST|REQUEST|GET)/i',
                    'severity' => 'high', 'why' => 'Passes attacker-supplied request data directly into assert(), which historically executes its string argument as PHP code — a known backdoor technique.'],
                'gsocket_indicator'  => ['re' => '/GS_ARGS|gsocket/i',
                    'severity' => 'high', 'why' => 'References gsocket, a reverse-shell/tunneling tool used to give an attacker an interactive shell on the server.'],
                'shell_exec_chain'   => ['re' => '/shell_exec\s*\(\s*\$_(POST|REQUEST|GET)/i',
                    'severity' => 'high', 'why' => 'Runs attacker-supplied request data as an OS shell command via shell_exec() — direct remote command execution.'],
                'xss_report_payload' => ['re' => '/xss\.report|_hu_inject/i',
                    'severity' => 'high', 'why' => 'Matches the known xss.report / _hu_inject marker used by the Helix Ultimate mega-menu XSS campaign tied to this SPPB compromise.'],
                'webshell_generic'   => ['re' => '/FilesMan|c99shell|r57shell|WSO\s*Web\s*Shell|H3K\s*\|\s*Tiny\s*File\s*Manager/i',
                    'severity' => 'high', 'why' => 'Matches the signature banner of a well-known, widely-distributed PHP webshell kit -- including "H3K | Tiny File Manager", a full filesystem-access file-manager backdoor commonly dropped to give an attacker browse/edit/upload/delete access to the entire site through a browser.'],
                'self_replicating_dropper' => ['re' => '/glob\s*\(.{0,40}GLOB_ONLYDIR.{0,200}?file_put_contents\s*\(.{0,400}?md5\s*\(\s*\$\w+\s*\)\s*==\s*md5\s*\(\s*file_get_contents/is',
                    'severity' => 'high', 'why' => 'Walks directories and rewrites files only when their content differs from a reference copy — a self-replicating/self-healing dropper pattern, not something legitimate code does.'],
                'noop_comment_padding' => ['re' => '/(;\s*\/\*\s*\w{3,12}\s*\*\/\s*;\s*){8,}/i',
                    'severity' => 'high', 'why' => 'Long chain of no-op statements padded with comments — a scanner-evasion technique to break up detectable strings, not something a compiler or formatter produces.'],
                'secure_local_marker' => ['re' => '/secure\.local/i',
                    'severity' => 'medium', 'why' => 'Matches the "secure.local" marker seen in this campaign\'s rogue accounts/payloads, but this string can also appear in ordinary dev/staging config examples — verify the surrounding code before treating as confirmed.'],
                'stream_wrapper_payload' => ['re' => '/require(?:_once)?\s*\(?\s*\$?\w*\s*\)?\s*;?.{0,200}?(zip|phar|compress\.zlib|compress\.bzip2|data):\/\//is',
                    'severity' => 'medium', 'why' => 'Loads code through a zip://phar://compress.*:// stream wrapper near a require -- a known payload-loading trick, but some legitimate extensions (backup/restore tools, archive handlers) use these wrappers for real archive access. Check what is actually being loaded.'],
                'chr_byte_array_decode' => ['re' => '/\$\w+\s*=\s*array\s*\(\s*(\d{2,3}\s*,\s*){6,}\d{2,3}\s*\)\s*;.{0,300}?chr\s*\(\s*\$\w+\[\$?\w+\]\s*\)/is',
                    'severity' => 'medium', 'why' => 'Reconstructs a string from a numeric byte array via chr() — common in obfuscated payloads, but also seen in some legitimately-obfuscated (not malicious) commercial extension license checks. Review what the reconstructed string does.'],
                'string_lookup_obfuscation' => ['re' => '/\$_?\w+\s*=\s*base64_decode\s*\(\s*[\'"][A-Za-z0-9+\/=]{40,}[\'"]\s*\)\s*;.{0,80}?\$\w+\[\d+\]\s*\.\s*\$\w+\[\d+\]/is',
                    'severity' => 'medium', 'why' => 'Decodes a long base64 blob then rebuilds identifiers via string-index lookups — a common obfuscation shape, but also used by some legitimate obfuscated/licensed commercial extensions. Review what the rebuilt identifiers resolve to.'],
                'opcache_reset_only' => ['re' => '/^\s*<\?php\s*opcache_reset\s*\(\s*\)\s*;\s*\?>\s*$/i',
                    'severity' => 'medium', 'why' => 'A file whose entire content is just opcache_reset() is functionally harmless by itself, but matches a known dropper self-cleanup helper used to force PHP to immediately pick up newly-written malicious files elsewhere.'],
                'phpkoru_encoder' => ['re' => '/\[PHPkoru_Code\]|phpkoru\.com|Aponkral\s+PHPkoru/i',
                    'severity' => 'high', 'why' => 'Matches the signature markers of "PHPkoru", a third-party PHP obfuscation/encoding service used to hide webshells and backdoors behind chained eval(base64_decode()) calls and a __halt_compiler()-appended encoded payload block that the file reads back out of its own source at runtime. No legitimate Joomla core or extension code is ever processed through this tool.'],
            ],

            // Checked against a LIVE incoming request (GET/POST/URI/User-Agent)
            // by the companion plg_system_muruguardshield plugin, not by the
            // component's own file-content scan. 'block_eligible' marks the
            // ones confident enough to actively reject with a 403 when the
            // admin has opted into blocking (not just logging) -- every
            // other severity level is log-only regardless of that setting,
            // since a false positive here rejects a real visitor's request
            // rather than just flagging a file for human review.
            'REQUEST_SIGNATURES' => [
                'webshell_param_exec' => ['re' => '/\b(?:system|exec|shell_exec|passthru|popen|proc_open|assert|create_function)\s*\(/i',
                    'severity' => 'high', 'block_eligible' => true,
                    'why' => 'A request parameter value itself contains a PHP code-execution function call -- the classic way an attacker interacts with an already-planted one-line eval/assert webshell, sending the actual command as the payload rather than in the file.'],
                'webshell_param_eval_b64' => ['re' => '/eval\s*\(\s*(?:@)?base64_decode\s*\(/i',
                    'severity' => 'high', 'block_eligible' => true,
                    'why' => 'A request parameter contains eval(base64_decode(...)) -- the exact payload shape used to run obfuscated PHP through a planted webshell.'],
                'sppb_upload_custom_icon' => ['re' => '/task\s*=\s*[\'"]?[^&\'"]*uploadcustomicon/i',
                    'severity' => 'high', 'block_eligible' => true,
                    'why' => 'Directly targets the SP Page Builder uploadCustomIcon task -- the exact unauthenticated RCE this whole tool exists to catch the aftermath of. A live probe against it is worth blocking outright, not just logging.'],
                'known_dropped_filename' => ['re' => '/^\/?.*(?:codex-sppb-[a-f0-9]+|codex_sppb\w*|queue_\d+)\.php(?:[?\/]|$)/i',
                    'severity' => 'high', 'block_eligible' => true,
                    'why' => 'The request path matches a known malware-drop filename pattern from this campaign -- either an attacker probing for a shell that was never dropped, or someone actively using one that was.'],
                'path_traversal_probe' => ['re' => '/(?:\.\.[\/\\\\]){2,}|\/etc\/passwd|wp-config\.php|configuration\.php~/i',
                    'severity' => 'medium', 'block_eligible' => false,
                    'why' => 'Directory-traversal sequences or a direct probe for a well-known sensitive file -- common reconnaissance, but broad enough (some legitimate frameworks use relative paths with ../ in query strings) that it is logged for review rather than blocked automatically.'],
                'known_scanner_user_agent' => ['re' => '/sqlmap|nikto|acunetix|nessus|masscan|zgrab|nuclei|dirbuster|wpscan/i',
                    'severity' => 'medium', 'block_eligible' => false,
                    'why' => 'The User-Agent string identifies a known vulnerability-scanning tool. Often a hostile scan, but also how a site owner\'s own authorised security testing shows up -- logged for review, not auto-blocked.'],
            ],

            'MENU_XSS_PATTERNS' => [
                'xss.report domain'            => '/xss\.report/i',
                '_hu_inject marker'            => '/_hu_?inject/i',
                'secure.local marker'          => '/secure\.local/i',
                'onerror/onload event handler' => '/on(error|load|mouseover|focus)\s*=/i',
                'inline <script> tag'          => '/<script[\s>]/i',
                'localStorage exfil/inject'    => '/localStorage\s*\.\s*(setItem|getItem)/i',
                'sessionStorage exfil/inject'  => '/sessionStorage\s*\.\s*(setItem|getItem)/i',
                'sessionStorage _hxd marker'   => '/sessionStorage\s*\.\s*_hxd/i',
                'MutationObserver persistence' => '/MutationObserver/i',
                'img src=x XSS payload'        => '/<img[^>]+src\s*=\s*["\']?x["\']?/i',
                'script element creation'      => '/document\s*\.\s*createElement\s*\(\s*[\'"]script[\'"]\s*\)/i',
                'self-invoking IIFE wrapper'   => '/\(\s*function\s*\(\s*\)\s*\{\s*[\'"]use strict[\'"]/i',
            ],

            'DEFACEMENT_PATTERNS' => [
                '/Hacked\s+by/i', '/Owned\s+by/i', '/Pwned\s+by/i', '/Defaced\s+by/i',
                '/H4cked/i', '/0wned/i', '/w4s\s+here/i', '/was\s+here/i',
                '/greetz\s+to/i', '/shell\s+by/i', '/r00ted/i',
            ],

            // Matches the "template" column of a mass-injected batch of junk
            // #__template_styles rows seen in real SPPB-compromise cleanups:
            // dozens of rows named tmpl_<6 random lowercase letters>, title
            // "<name> - 默认" ("- Default" in Chinese, regardless of the
            // site's actual language), params usually just "{}". This alone
            // is a secondary signal (a real template happening to be named
            // this way is vanishingly unlikely but not impossible) --
            // scanDatabase() treats it as confirmatory alongside the
            // stronger, independent signal of the row's "template" column
            // not matching any template folder that actually exists on disk.
            'TEMPLATE_STYLE_JUNK_NAME_RE' => '/^tmpl_[a-z0-9]{4,12}$/i',

            // Joomla's own bundled fallback template -- present on both the
            // site and admin side in every stock install (offline.php,
            // error.php, fatal.php, ...), used for maintenance/error pages.
            // It's core Joomla, never installed via the extension
            // installer, so it legitimately has no templateDetails.xml --
            // exempt from the no-manifest junk-folder check below.
            'TEMPLATE_SYSTEM_FOLDER_NAMES' => ['system'],

            'NON_PHP_EXTS_THAT_MUST_STAY_CLEAN' => ['png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'svg', 'bmp'],
            // <?php is 5 literal bytes -- vanishingly unlikely to occur by
            // chance in binary image data. The <?= short tag is only 3
            // bytes, which DOES turn up by pure random chance in the
            // megabytes of high-entropy compressed pixel data a large
            // photo can contain -- so it's required to be followed by a
            // plausible PHP token (optionally preceded by whitespace), not
            // matched bare, to avoid flagging ordinary large photos.
            'PHP_OPEN_TAG_RE' => '/<\?php|<\?=\s*[\$A-Za-z_(]/i',

            'CORE_ENTRY_POINTS' => ['index.php', 'administrator/index.php', 'api/index.php', 'includes/app.php'],

            'KNOWN_ROOT_FILES' => [
                'index.php', 'configuration.php', 'htaccess.txt', 'web.config.txt', 'robots.txt.dist',
                'robots.txt', 'LICENSE.txt', 'README.txt', 'joomla.xml', 'htaccess.bak',
                'php.ini', 'php.ini.bak', '.user.ini', '.htaccess', '.htaccess.bak', 'sitemap.xml', 'sitemap.xml.gz',
            ],

            'KNOWN_SAFE_RELATIVE_FILES' => [
                'index.php', 'administrator/index.php', '', 'api/index.php',
                'includes/app.php', 'includes/framework.php', 'cli/joomla.php',
                'files/index.html', 'images/index.html', 'media/index.html',
            ],

            'SAFE_COMPONENT_PATHS' => [
                // Deliberately does NOT include this scanner's own
                // component path (or its pre-2.2.0 name, com_sppbscan) --
                // see SELF_CONTENT_SIGNATURE_EXEMPTIONS below for why a
                // blanket "never scan yourself" exemption is actively
                // dangerous for a security tool (it would make the one
                // place an attacker would most want to backdoor -- the
                // scanner itself -- permanently invisible to it), and how
                // this scans its own files fully while still avoiding the
                // narrow, specific false positives that come from
                // literally containing its own signature definitions as
                // text.
                '/administrator/components/com_rsfirewall/',
                '/administrator/components/com_htprotect/',
                '/administrator/components/com_akeeba/',
                // com_akeebabackup is Akeeba Backup's newer Joomla 4/5
                // component id (com_akeeba is the legacy/Joomla 3 id
                // above) -- same vendor, same trust level.
                '/administrator/components/com_akeebabackup/',
                '/administrator/components/com_admintools/',
            ],

            // A security scanner's OWN files are exactly what a
            // sufficiently determined attacker would most want to
            // backdoor -- disabling or blinding the thing meant to catch
            // them, rather than risk detection elsewhere. A blanket
            // "don't scan your own component" exemption (the previous
            // design) would make that permanently invisible. Instead,
            // every one of this scanner's own files gets the SAME full
            // scan as any other file -- these are narrow, per-file,
            // per-signature exemptions covering ONLY the specific
            // content-signature false positives that come from this
            // scanner's helper/model files literally containing their own
            // signature definitions and marker strings as source text
            // (e.g. the literal text "xss.report", "FilesMan", "gsocket"
            // appearing inside the very CONTENT_SIGNATURES/REQUEST_SIGNATURES
            // table and the SPPB-asset marker check that reference them).
            // Every OTHER content signature not listed here (eval_base64_post,
            // assert_backdoor, shell_exec_chain, cookie_gated_eval,
            // self_replicating_dropper, phpkoru_encoder, ...) and every
            // structural check still runs normally against these exact
            // same files, so an actually-injected backdoor is still
            // caught. Verified empirically against the real files, not
            // guessed -- re-verify with an isolated scanFileContent() test
            // any time CONTENT_SIGNATURES/REQUEST_SIGNATURES changes,
            // since a new signature could introduce a new self-match here.
            // com_sppbscan is this scanner's own pre-2.2.0 name (see
            // CHANGELOG.md "Rebrand SPPB Scan to MuRu Guard") -- a
            // leftover copy from before that rebrand is the same source,
            // so it gets the same exemptions.
            'SELF_CONTENT_SIGNATURE_EXEMPTIONS' => [
                'administrator/components/com_muruguard/helpers/muruguard.php' =>
                    ['eval_encoded_blob', 'gsocket_indicator', 'xss_report_payload', 'webshell_generic', 'secure_local_marker', 'stream_wrapper_payload'],
                'administrator/components/com_sppbscan/helpers/muruguard.php' =>
                    ['eval_encoded_blob', 'gsocket_indicator', 'xss_report_payload', 'webshell_generic', 'secure_local_marker', 'stream_wrapper_payload'],
                'administrator/components/com_muruguard/models/scanner.php' =>
                    ['xss_report_payload', 'secure_local_marker'],
                'administrator/components/com_sppbscan/models/scanner.php' =>
                    ['xss_report_payload', 'secure_local_marker'],
            ],

            // "icomoon" is IcoMoon's own icon-font export/build tool name --
            // SP Page Builder (and many other extensions' icon pickers)
            // bundle their icon font exactly as IcoMoon exports it, top-
            // level folder name included, so this is a common, legitimate
            // subfolder name here, not a real red flag.
            'ICONFONT_ALLOWED_DIRNAMES'   => ['css', 'font', 'fonts', 'demo', 'docs', 'demo-files', 'icomoon'],
            'ICONFONT_ALLOWED_EXTENSIONS' => ['woff', 'woff2', 'ttf', 'eot', 'otf', 'svg', 'css', 'json', 'html', 'htm', 'txt', 'md'],
            'ICONFONT_ALLOWED_BARE_NAMES' => ['license', 'readme', 'changelog'],
            // #__sppagebuilder_assets rows of type "iconfont" named
            // something other than these are flagged as "Non-default" --
            // NOT because a non-default name is itself malicious (the
            // actual content checks run against every row regardless of
            // name, see scanDatabase()), just because it's a weaker,
            // secondary signal worth surfacing for manual review. "icofont"
            // is SP Page Builder's own bundled default; "icomoon" is
            // IcoMoon's own extremely common icon-font export/build tool
            // name (see ICONFONT_ALLOWED_DIRNAMES above) -- just as
            // legitimate a choice for a real site to have added, not a
            // red flag on its own.
            'KNOWN_GOOD_ICONFONT_NAMES'   => ['icofont', 'icomoon'],

            'JCE_UPLOAD_PATH_FRAGMENTS'      => ['/media/com_jce/editor/tiny_mce/plugins/filemanager/'],
            'JCE_UPLOAD_ALLOWED_EXTENSIONS'  => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'css', 'js', 'json', 'html', 'htm'],

            // Joomla's own core disk-cache storage driver (and template
            // frameworks that use it, e.g. Helix Ultimate's page cache)
            // writes cached data wrapped in an executable .php file named
            // "<md5>-cache-<group>-<md5>.php" -- <group> is whatever cache
            // group the caller registered (e.g. "page", "helixultimate",
            // a component name). This is standard, unmodified Joomla
            // caching behaviour, not a compromise, so cache/ (an 'upload'-
            // mode directory where .php would otherwise always be flagged)
            // exempts files matching this exact shape from the "executable
            // file in upload directory" structural check -- content
            // scanning still runs on them regardless, so an attacker
            // naming an actual backdoor to mimic this pattern is still
            // caught by what the file actually contains.
            'JOOMLA_CACHE_FILE_RE' => '/^[a-f0-9]{32}-cache-[a-z0-9_.-]+-[a-f0-9]{32}\.php$/i',

            'KNOWN_ROOT_DIRS' => [
                'administrator', 'api', 'bin', 'cache', 'cli', 'components', 'includes',
                'language', 'layouts', 'libraries', 'media', 'modules', 'plugins',
                'templates', 'tmp', 'images', 'files', 'node_modules', '.well-known', 'logs',
            ],

            'PROTECTED_TOP_DIRS' => [
                'administrator', 'components', 'libraries', 'media', 'images', 'templates',
                'plugins', 'modules', 'language', 'cache', 'tmp', 'layouts', 'includes', 'api', 'cli',
            ],

            // Genuinely required core/template entry files -- even when
            // infected (a "prepended payload" ahead of the bootstrap/
            // access guard), the fix is to CLEAN the injected code, never
            // to delete the file outright, since the site (or the active
            // template) cannot function without it. Matched exactly for
            // the fixed entry points; matched by pattern for any
            // template's own root index.php since the template name
            // varies per site. Also covers the other files the bundled
            // core-checksum manifest verifies (see
            // getCoreChecksumManifest()) -- a checksum mismatch on any of
            // these needs manual review/restore, never a one-click delete.
            'PROTECTED_ENTRY_FILES' => [
                'index.php', 'administrator/index.php', 'api/index.php', 'includes/app.php',
                'includes/framework.php', 'robots.txt.dist', 'htaccess.txt', 'web.config.txt',
            ],
            'PROTECTED_ENTRY_FILE_PATTERNS' => [
                '#^(administrator/)?templates/[^/]+/index\.php$#i',
            ],

            // Directories scanned recursively, and in which mode.
            // 'upload' = strict structural checks (no exec files, no numeric drop folders).
            // 'code'   = signature-only (this is real extension code, .php is expected).
            'SCAN_CONFIG' => [
                'media' => 'upload', 'images' => 'upload', 'tmp' => 'upload',
                'cache' => 'upload', 'files' => 'upload',
                'components' => 'code', 'administrator/components' => 'code',
                'modules' => 'code', 'administrator/modules' => 'code',
                'plugins' => 'code', 'administrator/includes' => 'code',
                'libraries' => 'code', 'templates' => 'code', 'administrator/templates' => 'code',
                'cli' => 'code', 'bin' => 'code',
            ],

            // Exact relative paths seen in real-world attacks where the
            // attacker names a dropped file to LOOK like a plausible core
            // Joomla file (blending into a legitimate-looking directory
            // structure) even though no such core file actually exists.
            // Grow this list every time a new masquerade path is found.
            'CORE_MASQUERADE_EXACT_PATHS' => [
                'libraries/system.php',
                'bin/cms.php',
                'cli/cli.php',
                'templates/system/network.php',
                'templates/system/online.php',
                'options.php',
                'plugins/content/joomla/content.php',
            ],

            // Third-party-template masquerade paths, matched against ANY
            // template name (not a fixed template like the core-path list
            // above). No clean install of any known Joomla template ships
            // a top-level "features" folder with an index.php inside it --
            // flagged on location alone, regardless of file content, since
            // an attacker can trivially make the payload look like a
            // blank access-guard stub to dodge a content-only check.
            // Grow this list every time a new masquerade path is found.
            'TEMPLATE_FOLDER_MASQUERADE_PATTERNS' => [
                '#^(administrator/)?templates/[^/]+/features/index\.php$#i',
            ],

            // Folders where real Joomla core only ever places a small,
            // fixed set of loose files directly at the top level -- any
            // OTHER file sitting directly there (not nested in a real
            // subfolder like libraries/src/ or libraries/vendor/) is
            // almost certainly a payload disguised with a core-sounding
            // path, which is a stealthier pattern than a randomly-named
            // webshell since the filename itself looks legitimate.
            'CORE_LOOSE_FILE_ALLOWLIST' => [
                // web.config is Joomla's IIS-hosting counterpart to
                // .htaccess and is shipped loose in several core
                // directories, not just the webroot -- allowed everywhere
                // this list applies.
                'libraries' => [
                    'bootstrap.php', 'loader.php', 'classmap.php', 'namespacemap.php',
                    'import.php', 'import.legacy.php', 'platform.php', 'fof30.autoload.php',
                    'cms.php', 'web.config',
                ],
                'cli' => [
                    'joomla.php', 'import.php', 'update_cron.php', 'deletefiles.php', 'garbagecron.php',
                    'web.config',
                ],
                'bin' => ['web.config'],
                // templates/system is Joomla's built-in system/error template.
                // Its top-level loose files are a small, fixed set; anything
                // else there (network.php, online.php, ...) is a disguise.
                'templates/system' => [
                    'index.php', 'error.php', 'error.full.php', 'fatal.php', 'offline.php', 'component.php', 'web.config',
                ],
            ],
        ];
    }

    /**
     * Canonical, user-selectable scan areas grouped for the pre-scan
     * directory picker. Filesystem keys match SCAN_CONFIG relative dirs so
     * the model can filter directly; the pseudo-keys core_entry / webroot /
     * database gate the non-SCAN_CONFIG passes.
     */
    /**
     * Keyed by a stable, never-translated group id (used for icon lookups
     * and other by-key logic in the view) rather than the display label
     * itself, so the label can be translated without breaking anything
     * that depends on the key.
     */
    public static function getScanAreas(): array
    {
        return [
            'upload_media' => [
                'label' => Text::_('COM_MURUGUARD_GROUP_UPLOAD_MEDIA'),
                'areas' => [
                    'media'  => 'media/',
                    'images' => 'images/',
                    'tmp'    => 'tmp/',
                    'cache'  => 'cache/',
                    'files'  => 'files/',
                ],
            ],
            'extension_code' => [
                'label' => Text::_('COM_MURUGUARD_GROUP_EXTENSION_CODE'),
                'areas' => [
                    'components'                => 'components/',
                    'administrator/components'  => 'administrator/components/',
                    'modules'                   => 'modules/',
                    'administrator/modules'     => 'administrator/modules/',
                    'plugins'                   => 'plugins/',
                    'libraries'                 => 'libraries/',
                    'templates'                 => 'templates/',
                    'administrator/templates'   => 'administrator/templates/',
                    'administrator/includes'    => 'administrator/includes/',
                    'cli'                       => 'cli/',
                    'bin'                       => 'bin/',
                ],
            ],
            'core_webroot' => [
                'label' => Text::_('COM_MURUGUARD_GROUP_CORE_WEBROOT'),
                'areas' => [
                    'core_entry' => Text::_('COM_MURUGUARD_AREA_CORE_ENTRY'),
                    'webroot'    => Text::_('COM_MURUGUARD_AREA_WEBROOT'),
                ],
            ],
            'database' => [
                'label' => Text::_('COM_MURUGUARD_GROUP_DATABASE'),
                'areas' => [
                    'database' => Text::_('COM_MURUGUARD_AREA_DATABASE'),
                ],
            ],
        ];
    }

    /**
     * Checks a LIVE incoming request against REQUEST_SIGNATURES. Called by
     * the companion plg_system_muruguardshield plugin on every page load
     * -- NOT by the component's own file-content scan, which never sees
     * request data at all. Everything (URI, every GET/POST value) is
     * flattened into one combined haystack and checked against every
     * signature except the User-Agent one, which checks that header
     * specifically. Returns the highest-severity match found, or null.
     */
    public static function scanRequestForAttack(array $get, array $post, string $uri, string $userAgent): ?array
    {
        $sig = self::getSignatures();

        $flatten = static function (array $arr) use (&$flatten): array {
            $out = [];
            foreach ($arr as $v) {
                $out = is_array($v) ? array_merge($out, $flatten($v)) : array_merge($out, [(string) $v]);
            }
            return $out;
        };
        $parts = array_filter(array_merge([$uri], $flatten($get), $flatten($post)), fn($p) => $p !== '');
        $combined = implode(' ', $parts);

        $best = null;
        foreach ($sig['REQUEST_SIGNATURES'] as $name => $def) {
            $haystack = $name === 'known_scanner_user_agent' ? $userAgent : $combined;
            if ($haystack === '' || !preg_match($def['re'], $haystack, $m)) continue;

            $candidate = [
                'rule'           => $name,
                'severity'       => $def['severity'],
                'block_eligible' => $def['block_eligible'],
                'why'            => $def['why'],
                'matched_text'   => mb_substr((string) $m[0], 0, 120),
            ];
            if ($best === null || ($candidate['severity'] === 'high' && $best['severity'] !== 'high')) {
                $best = $candidate;
            }
        }
        return $best;
    }

    /**
     * Every data file this component owns (attack log, login attempts,
     * false positives, IP list, geoip cache, scan history) is stored
     * under helpers/data/ starting with this exact PHP stub. Requesting
     * one of these files directly over HTTP executes the stub and gets a
     * plain-text 403 -- nothing after it is ever reached. This is the
     * only protection that's actually server-agnostic: the .htaccess
     * that used to be this folder's sole protection is Apache-only (with
     * mod_authz_core/mod_access_compat enabled and AllowOverride honoured
     * for this path) and is silently ignored by nginx, Caddy/FrankenPHP,
     * LiteSpeed running in its nginx-compatible mode, and IIS -- on any
     * of those, the old *.json files were readable, unauthenticated, by
     * anyone who knew (or guessed) the filename, leaking attacker IPs,
     * failed-login usernames, every visitor IP ever geolocated, and the
     * manual IP allow/block list. A .php file, in contrast, is executed
     * by definition on every server capable of running Joomla at all --
     * there is no server config this depends on getting right.
     */
    public static function dataFileStubPrefix(): string
    {
        return "<?php http_response_code(403); header('Content-Type: text/plain; charset=utf-8'); exit(\"Forbidden\\n\");\n?>\n";
    }

    /**
     * Strips the leading PHP stub (see dataFileStubPrefix()) so the real
     * payload after it can be decoded. A file with no recognizable stub
     * (nothing written yet, or unexpected content) is returned unchanged
     * rather than mangled.
     */
    public static function stripDataFileStub(string $contents): string
    {
        if (strpos($contents, '<?php') !== 0) return $contents;
        $end = strpos($contents, '?>');
        if ($end === false) return $contents;
        return ltrim(substr($contents, $end + 2), "\r\n");
    }

    /**
     * One-time upgrade migration: com_muruguard versions before this fix
     * stored this same data as a plain, unprotected *.json file at
     * $legacyPath. If that file still exists and the new stub-protected
     * $newPath doesn't yet, its content is carried over (stub-prefixed)
     * and the legacy file is deleted outright -- not just abandoned in
     * place, since an abandoned copy would still be the exact same
     * unauthenticated leak this fix exists to close. Safe to call on
     * every read/write; it's a fast no-op once the legacy file is gone.
     * Never throws -- a migration hiccup (e.g. unreadable/unwritable
     * legacy file) just means the new file starts empty rather than
     * losing the write that triggered this call.
     */
    public static function migrateLegacyDataFile(string $legacyPath, string $newPath): void
    {
        if (!is_file($legacyPath)) return;
        if (!is_file($newPath)) {
            $contents = @file_get_contents($legacyPath);
            if ($contents !== false && trim($contents) !== '') {
                @file_put_contents($newPath, self::dataFileStubPrefix() . $contents);
            }
        }
        @unlink($legacyPath);
    }

    /**
     * Deliberately the same JSON-file-under-this-component's-own-data-
     * folder pattern as scan-history.json (see MuruguardModelScanner::
     * scanHistoryFilePath() for the full reasoning) -- and here it also
     * doubles as the one thing both this component AND the separate
     * shield plugin can agree on without any cross-extension API: the
     * plugin just writes here directly using the same JPATH_ADMINISTRATOR
     * constant every Joomla extension has, no coupling beyond this path.
     * flock() is used on writes (unlike scan-history.json) because this
     * file can plausibly receive concurrent writes from simultaneous
     * requests during an actual attack burst, exactly when losing entries
     * matters most.
     */
    private static function attackLogFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/attack-log.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/attack-log.json', $new);
        return $new;
    }

    private static function attackLogArchiveFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/attack-log-archive.php';
    }

    /**
     * Appends entries evicted from the live 500-entry ring buffer here
     * instead of discarding them outright. Without this, an attacker who
     * knows (or guesses) how this log works could erase all trace of
     * their own intrusion by simply sending ~500 more requests afterward
     * -- ageing their own attack entries out of the only copy that ever
     * existed, a handful of cheap requests to destroy the exact evidence
     * this log exists to preserve. Capped at a much higher ceiling
     * (20,000, oldest-evicted-for-real beyond that) so this can't grow
     * completely unbounded under a truly sustained flood, but raises the
     * cost of "erase the evidence" by 40x over the live log alone. Same
     * stub-protected format and flock()-guarded write as every other data
     * file here; called with the live log's own lock already released, so
     * this never holds two file locks at once.
     */
    private static function archiveAttackLogEntries(array $evicted): void
    {
        if (empty($evicted)) return;

        $path = self::attackLogArchiveFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $archive = json_decode($contents, true);
            if (!is_array($archive)) $archive = [];

            array_push($archive, ...$evicted);
            if (count($archive) > 20000) {
                $archive = array_slice($archive, -20000);
            }

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($archive));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    /** Total count of entries preserved in the archive -- surfaced in the Protection Log UI so evicted entries are visibly retained, not silently gone. */
    public static function getAttackLogArchiveCount(): int
    {
        $path = self::attackLogArchiveFilePath();
        if (!is_file($path)) return 0;
        $contents = @file_get_contents($path);
        if ($contents === false) return 0;
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? count($decoded) : 0;
    }

    /** Newest first, capped at 500 entries so the live file stays small and fast to read regardless of traffic volume -- anything evicted past that is preserved in the archive (see archiveAttackLogEntries()), never just dropped. */
    public static function recordAttackLogEntry(array $entry): void
    {
        $path = self::attackLogFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        $evicted = [];
        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $log = json_decode($contents, true);
            if (!is_array($log)) $log = [];

            array_unshift($log, $entry);
            if (count($log) > 500) {
                $evicted = array_slice($log, 500);
                $log = array_slice($log, 0, 500);
            }

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($log));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        self::archiveAttackLogEntries($evicted);
    }

    public static function getAttackLog(): array
    {
        $path = self::attackLogFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    public static function clearAttackLog(): void
    {
        @file_put_contents(self::attackLogFilePath(), self::dataFileStubPrefix() . json_encode([]));
    }

    private static function loginAttemptsFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/login-attempts.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/login-attempts.json', $new);
        return $new;
    }

    /**
     * Records one failed backend login attempt for brute-force tracking.
     * Entries older than 24h are pruned on every write so this file can
     * never grow unbounded even under a sustained attack -- a rolling
     * window is all isBruteForceThresholdExceeded() ever needs anyway.
     */
    public static function recordLoginFailure(string $ip, string $username): void
    {
        $path = self::loginAttemptsFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $attempts = json_decode($contents, true);
            if (!is_array($attempts)) $attempts = [];

            $cutoff = time() - 86400;
            $attempts = array_values(array_filter($attempts, fn($a) => ($a['time'] ?? 0) >= $cutoff));
            $attempts[] = ['ip' => $ip, 'username' => $username, 'time' => time()];

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($attempts));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    public static function getLoginAttempts(): array
    {
        $path = self::loginAttemptsFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    /** True if $ip has failed $threshold or more times within the last $windowMinutes. */
    public static function isBruteForceThresholdExceeded(string $ip, int $threshold, int $windowMinutes): bool
    {
        if ($threshold <= 0) return false;
        $cutoff = time() - ($windowMinutes * 60);
        $count = 0;
        foreach (self::getLoginAttempts() as $a) {
            if (($a['ip'] ?? '') === $ip && ($a['time'] ?? 0) >= $cutoff) {
                $count++;
                if ($count >= $threshold) return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Admin-dismissed false positives ("Mark as Safe" on a finding row) --
    // same JSON-file-under-this-component's-own-data-folder pattern as
    // attack-log.json/ip-list.json. Deliberately NOT keyed on path/row-id
    // alone: every entry also stores a fingerprint of the exact reasons
    // text that was reviewed at the time it was dismissed. A future scan
    // only suppresses a finding when BOTH the identifier AND that
    // fingerprint still match -- if the same file/row later trips a
    // DIFFERENT or ADDITIONAL signature (e.g. an attacker overwrites a
    // previously-dismissed file with a real backdoor), the fingerprint no
    // longer matches and it reappears as a fresh finding rather than
    // staying silently hidden forever. This is what makes "Mark as Safe"
    // safe to offer at all on a security tool -- a naive path/id-only
    // suppression would be a standing blind spot an attacker could target
    // specifically (compromise something already dismissed once).
    // ------------------------------------------------------------------

    private static function falsePositivesFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/false-positives.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/false-positives.json', $new);
        return $new;
    }

    /** Deterministic fingerprint of a finding's reasons -- order-independent, so the same set of matched reasons in a different order still counts as the same review. */
    public static function fingerprintReasons(array $reasonsList): string
    {
        $normalized = array_values(array_unique(array_map('strval', $reasonsList)));
        sort($normalized);
        return md5(implode('|', $normalized));
    }

    public static function getFalsePositives(): array
    {
        $path = self::falsePositivesFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    /** ['<category>|<identifier>' => '<fingerprint>', ...] -- built once per scan and passed around, rather than re-reading/re-parsing the JSON file once per finding. */
    public static function getFalsePositiveLookup(): array
    {
        $lookup = [];
        foreach (self::getFalsePositives() as $entry) {
            $key = ($entry['category'] ?? '') . '|' . ($entry['identifier'] ?? '');
            $lookup[$key] = (string) ($entry['fingerprint'] ?? '');
        }
        return $lookup;
    }

    public static function isFalsePositive(array $lookup, string $category, string $identifier, string $currentFingerprint): bool
    {
        $key = $category . '|' . $identifier;
        return isset($lookup[$key]) && $lookup[$key] !== '' && $lookup[$key] === $currentFingerprint;
    }

    private const FALSE_POSITIVE_CATEGORIES = ['file', 'superusers', 'menu_xss', 'sppb_assets', 'rogue_iconfont', 'template_defacement'];

    /**
     * @param string $category One of FALSE_POSITIVE_CATEGORIES.
     * @param string $identifier Relative path for 'file', numeric row id (as string) for every DB category.
     * @param string $fingerprint See fingerprintReasons() -- the exact reasons/matches text being dismissed, so a later content change un-suppresses it.
     */
    public static function addFalsePositive(string $category, string $identifier, string $fingerprint, string $note = ''): array
    {
        $category = strtolower(trim($category));
        $identifier = trim($identifier);

        if (!in_array($category, self::FALSE_POSITIVE_CATEGORIES, true)) {
            return ['ok' => false, 'error' => 'Unknown finding category.'];
        }
        if ($identifier === '') {
            return ['ok' => false, 'error' => 'Missing identifier.'];
        }

        $entry = [
            'id'          => bin2hex(random_bytes(8)),
            'category'    => $category,
            'identifier'  => $identifier,
            'fingerprint' => $fingerprint,
            'note'        => mb_substr(trim($note), 0, 200),
            'addedAt'     => time(),
        ];

        $path = self::falsePositivesFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return ['ok' => false, 'error' => 'Could not open storage file.'];

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];

            // Replace an existing dismissal for the same category+
            // identifier (e.g. re-dismissing after the fingerprint
            // changed) rather than accumulating stale duplicate entries.
            $list = array_values(array_filter($list, fn($e) =>
                ($e['category'] ?? '') !== $category || ($e['identifier'] ?? '') !== $identifier
            ));
            $list[] = $entry;

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        return ['ok' => true, 'entry' => $entry];
    }

    public static function removeFalsePositive(string $id): void
    {
        $path = self::falsePositivesFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];

            $list = array_values(array_filter($list, fn($e) => ($e['id'] ?? '') !== $id));

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    // ------------------------------------------------------------------
    // Manual IP block/allow list -- same JSON-file-under-this-component's-
    // -own-data-folder pattern as attack-log.json/login-attempts.json
    // above. Independent of, and checked AHEAD of, every pattern/
    // threshold-based check in runShieldCheck(): an explicit "allow"
    // entry bypasses brute-force/pattern/country blocking entirely (the
    // whole point of an allowlist -- e.g. an admin's own static IP, or a
    // trusted external monitoring/uptime service that would otherwise
    // occasionally trip a rule), and an explicit "block" entry rejects
    // regardless of what the request itself looks like.
    // ------------------------------------------------------------------

    private static function ipListFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/ip-list.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/ip-list.json', $new);
        return $new;
    }

    public static function getIpList(): array
    {
        $path = self::ipListFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(self::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Accepts a plain IPv4/IPv6 address OR CIDR notation (e.g.
     * "203.0.113.0/24"). Returns ['ok' => true, 'entry' => ...] or
     * ['ok' => false, 'error' => '...'] -- never throws, since this is
     * called directly from a controller action handling raw admin input.
     */
    public static function addIpListEntry(string $ipOrCidr, string $mode, string $note): array
    {
        $ipOrCidr = trim($ipOrCidr);
        $mode = $mode === 'allow' ? 'allow' : 'block';

        if ($ipOrCidr === '') {
            return ['ok' => false, 'error' => 'Empty value.'];
        }

        if (strpos($ipOrCidr, '/') !== false) {
            [$addr, $prefix] = array_pad(explode('/', $ipOrCidr, 2), 2, '');
            if (filter_var($addr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false || !ctype_digit($prefix) || (int) $prefix > 32) {
                return ['ok' => false, 'error' => 'Invalid CIDR range -- only IPv4 CIDR notation is supported (e.g. 203.0.113.0/24).'];
            }
        } elseif (filter_var($ipOrCidr, FILTER_VALIDATE_IP) === false) {
            return ['ok' => false, 'error' => 'Not a valid IP address or CIDR range.'];
        }

        $entry = [
            'id'      => bin2hex(random_bytes(8)),
            'value'   => $ipOrCidr,
            'mode'    => $mode,
            'note'    => mb_substr(trim($note), 0, 200),
            'addedAt' => time(),
        ];

        $path = self::ipListFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return ['ok' => false, 'error' => 'Could not open storage file.'];

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];

            $list[] = $entry;

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        return ['ok' => true, 'entry' => $entry];
    }

    public static function removeIpListEntry(string $id): void
    {
        $path = self::ipListFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
            $list = json_decode((string) $contents, true);
            if (!is_array($list)) $list = [];

            $list = array_values(array_filter($list, fn($e) => ($e['id'] ?? '') !== $id));

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, self::dataFileStubPrefix() . json_encode($list));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    /** True if $ip falls inside IPv4 CIDR range $cidr (e.g. "203.0.113.0/24"). IPv6 CIDR is not supported -- returns false rather than a wrong answer. */
    public static function ipMatchesCidr(string $ip, string $cidr): bool
    {
        if (strpos($cidr, '/') === false) return false;
        [$subnet, $prefix] = explode('/', $cidr, 2);
        if (!ctype_digit($prefix)) return false;
        $prefix = (int) $prefix;

        $ipLong = ip2long($ip);
        $subnetLong = ip2long($subnet);
        if ($ipLong === false || $subnetLong === false) return false;

        if ($prefix === 0) return true;
        $mask = -1 << (32 - $prefix);
        return ($ipLong & $mask) === ($subnetLong & $mask);
    }

    /**
     * Resolves the IP address every check in the shield plugin should key
     * on. By default (empty $trustedHeader, off unless an admin
     * explicitly opts in from Settings) this is always plain REMOTE_ADDR
     * -- the safe default. Behind a proxy/CDN/load balancer that was
     * never configured here, REMOTE_ADDR is the proxy's own IP for every
     * single visitor, which turns IP-keyed brute-force blocking into a
     * site-wide outage: a handful of failed logins from anyone behind
     * that shared edge IP locks out every other visitor sharing it too.
     * $trustedHeader (an $_SERVER key, e.g. "HTTP_CF_CONNECTING_IP") is
     * only ever honoured when the admin has explicitly selected it --
     * trusting a client-supplied header by default would let any visitor
     * spoof their own IP outright. A comma-separated value (the shape
     * X-Forwarded-For chains take: client, proxy1, proxy2, ...) uses the
     * first entry, and the result must parse as a syntactically valid IP
     * or this silently falls back to REMOTE_ADDR rather than trust
     * garbage input.
     */
    public static function resolveClientIp($serverInput, string $trustedHeader): string
    {
        $remoteAddr = (string) $serverInput->get('REMOTE_ADDR', '', 'string');

        if ($trustedHeader === '') {
            return $remoteAddr;
        }

        $headerValue = (string) $serverInput->get($trustedHeader, '', 'string');
        if ($headerValue === '') {
            return $remoteAddr;
        }

        $candidate = trim(explode(',', $headerValue)[0]);

        return filter_var($candidate, FILTER_VALIDATE_IP) !== false ? $candidate : $remoteAddr;
    }

    /**
     * Checked FIRST in runShieldCheck(), ahead of brute-force/pattern/
     * country blocking -- see the list's own docblock above for why.
     * Returns 'allow', 'block', or null (no matching entry). If an IP
     * somehow matches both an allow and a block entry, allow wins --
     * an allowlist entry is always a deliberate, specific admin action,
     * so it should never be silently overridden by a broader block rule.
     */
    public static function checkIpList(string $ip): ?string
    {
        if ($ip === '') return null;
        $blocked = false;
        foreach (self::getIpList() as $entry) {
            $value = (string) ($entry['value'] ?? '');
            $mode  = (string) ($entry['mode'] ?? '');
            $matches = $value === $ip || (strpos($value, '/') !== false && self::ipMatchesCidr($ip, $value));
            if (!$matches) continue;
            if ($mode === 'allow') return 'allow';
            if ($mode === 'block') $blocked = true;
        }
        return $blocked ? 'block' : null;
    }

    // ------------------------------------------------------------------
    // GeoIP / country blocking -- deliberately does NOT bundle a GeoIP
    // database (MaxMind's GeoLite2 requires a free account + license key
    // this project can't obtain on an admin's behalf, and a stale bundled
    // copy would silently rot). Instead uses a free lookup API
    // (ip-api.com) with an aggressive, indefinite local cache keyed by
    // IP -- a given IP's country essentially never changes, so this is a
    // ONE-TIME network call per unique visitor IP ever seen, not a
    // per-request dependency. Fails open (returns null, never blocks) on
    // any lookup error/timeout/malformed response -- a third-party
    // service hiccup must never be able to take real visitors down.
    // ------------------------------------------------------------------

    private static function geoipCacheFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/geoip-cache.php';
        self::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/geoip-cache.json', $new);
        return $new;
    }

    /** Returns a 2-letter ISO country code, or null if unknown/lookup failed. */
    public static function lookupCountryForIp(string $ip): ?string
    {
        if ($ip === '' || filter_var($ip, FILTER_VALIDATE_IP) === false) return null;
        // Private/reserved ranges (localhost, LAN, Docker/CI runners, ...)
        // are never geolocatable and would otherwise burn a lookup (and
        // cache slot) on every dev/staging environment.
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) return null;

        $cachePath = self::geoipCacheFilePath();
        $cache = [];
        if (is_file($cachePath)) {
            $decoded = json_decode(self::stripDataFileStub((string) @file_get_contents($cachePath)), true);
            if (is_array($decoded)) $cache = $decoded;
        }

        if (array_key_exists($ip, $cache)) {
            return $cache[$ip]['country'] !== '' ? $cache[$ip]['country'] : null;
        }

        $country = self::fetchCountryFromApi($ip);

        $fh = @fopen($cachePath, 'c+');
        if ($fh !== false) {
            if (@flock($fh, LOCK_EX)) {
                $size = filesize($cachePath) ?: 0;
                $contents = $size > 0 ? self::stripDataFileStub(fread($fh, $size)) : '';
                $freshCache = json_decode((string) $contents, true);
                if (!is_array($freshCache)) $freshCache = [];

                // Cap cache size so a distributed scan/attack hitting
                // thousands of unique IPs can't grow this file unbounded
                // -- oldest entries are dropped first (insertion order).
                if (count($freshCache) > 20000) {
                    $freshCache = array_slice($freshCache, -15000, null, true);
                }
                $freshCache[$ip] = ['country' => (string) $country, 'cachedAt' => time()];

                ftruncate($fh, 0);
                rewind($fh);
                fwrite($fh, self::dataFileStubPrefix() . json_encode($freshCache));
                fflush($fh);
                flock($fh, LOCK_UN);
            }
            fclose($fh);
        }

        return $country;
    }

    /** Isolated for testability -- swap/mock this in tests rather than the caching wrapper above. */
    protected static function fetchCountryFromApi(string $ip): ?string
    {
        try {
            $context = stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]);
            $response = @file_get_contents("http://ip-api.com/json/{$ip}?fields=status,countryCode", false, $context);
            if ($response === false) return null;

            $data = json_decode($response, true);
            if (!is_array($data) || ($data['status'] ?? '') !== 'success') return null;

            $code = (string) ($data['countryCode'] ?? '');
            return preg_match('/^[A-Z]{2}$/', $code) ? $code : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** $blockedCountriesCsv is a comma-separated list of 2-letter ISO codes from the Settings panel, e.g. "CN,RU,KP". */
    public static function isCountryBlocked(?string $countryCode, string $blockedCountriesCsv): bool
    {
        if ($countryCode === null || $countryCode === '') return false;
        $blocked = array_filter(array_map('trim', explode(',', strtoupper($blockedCountriesCsv))));
        return in_array(strtoupper($countryCode), $blocked, true);
    }

    /**
     * Detects files whose PATH masquerades as legitimate Joomla core even
     * though no such file exists in a clean install -- the stealthiest
     * dropper pattern, because the filename itself looks trustworthy.
     * Complements the content-signature scan (which only fires on payload
     * text): a masquerade file can be flagged on its location alone.
     *
     * Returns a human-readable reason string, or null if nothing matched.
     */
    /**
     * Short, collapsed preview of a file's own content, used to append a
     * "Matched code:" snippet onto location-based reasons (masquerade
     * paths, stray index.php, ...) that don't otherwise quote any code --
     * without this, the code-analysis modal has nothing to show for these
     * checks even though the file's actual content is exactly what a
     * reviewer needs to see to judge the finding.
     */
    private static function filePreview(string $absPath, int $maxLen = 220): string
    {
        if ($absPath === '' || !is_file($absPath)) return '';
        $chunk = @file_get_contents($absPath, false, null, 0, 4096);
        if ($chunk === false || trim($chunk) === '') return '';
        $preview = trim(preg_replace('/\s+/', ' ', $chunk));
        return strlen($preview) > $maxLen ? substr($preview, 0, $maxLen) . '…' : $preview;
    }

    public static function checkCoreMasquerade(string $relPath, bool $isDir, array $sig, string $absPath = ''): ?string
    {
        $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
        if ($relPath === '') return null;

        $base = basename($relPath);
        $ext  = strtolower(pathinfo($base, PATHINFO_EXTENSION));
        $preview = $isDir ? '' : self::filePreview($absPath);
        $suffix  = $preview !== '' ? " Matched code: {$preview}" : '';

        // 1. Exact known-masquerade relative paths.
        if (!$isDir && in_array($relPath, $sig['CORE_MASQUERADE_EXACT_PATHS'], true)) {
            return 'Path masquerades as a legitimate Joomla core file, but no such file exists in a clean Joomla install — a stealthy dropper disguise.' . $suffix;
        }

        // 2. Hidden dot-file carrying an executable extension, anywhere.
        //    Joomla never stores runnable code in a hidden file (e.g.
        //    administrator/.../toolbar/.module.php) -- except a small,
        //    known set of IDE/tooling metadata files that legitimate
        //    composer packages ship this way by convention (e.g.
        //    PhpStorm's .phpstorm.meta.php), which are exempted.
        if (!$isDir && $base !== '' && $base[0] === '.' && in_array($ext, $sig['EXEC_EXTS'], true)
            && !in_array(strtolower($base), array_map('strtolower', $sig['HIDDEN_DOTFILE_ALLOWLIST']), true)) {
            return "Hidden dot-file with an executable extension (\"{$base}\") — legitimate Joomla code is never stored in hidden executable files." . $suffix;
        }

        // 3. File placed directly (loosely) in a core directory whose full
        //    set of top-level files is known and small. Executable files by
        //    an unknown name are the classic disguise; unusual non-code
        //    extensions (e.g. a ".lock" marker) dropped there are almost
        //    always attacker toolkit artifacts too. Legitimate Joomla stub
        //    files (index.html, web.config.txt, .htaccess, ...) are allowed.
        if (!$isDir) {
            $dir = strtolower(dirname($relPath));
            if ($dir === '.') $dir = '';
            if (isset($sig['CORE_LOOSE_FILE_ALLOWLIST'][$dir])) {
                $allowed   = array_map('strtolower', $sig['CORE_LOOSE_FILE_ALLOWLIST'][$dir]);
                $stubExts  = ['html', 'htm', 'xml', 'txt', 'ini', 'json', 'md', 'dist', 'htaccess'];
                $baseLower = strtolower($base);
                if (!in_array($baseLower, $allowed, true)) {
                    if (in_array($ext, $sig['EXEC_EXTS'], true)) {
                        return "Executable file placed directly in the core \"{$dir}/\" directory, which never holds a file by this name in a clean Joomla install — a core-path disguise." . $suffix;
                    }
                    if ($ext !== '' && !in_array($ext, $stubExts, true) && $baseLower !== '.htaccess') {
                        return "Unexpected file (\"{$base}\") loose in the core \"{$dir}/\" directory — clean Joomla never ships this file, a common malware toolkit artifact." . $suffix;
                    }
                }
            }
        }

        return null;
    }

    /**
     * Flags anything sitting inside a top-level templates/<name> or
     * administrator/templates/<name> folder whose <name> matches the same
     * auto-generated "tmpl_xxxxxx" junk-naming pattern checked against
     * #__template_styles rows in scanDatabase() (see
     * TEMPLATE_STYLE_JUNK_NAME_RE) -- a confirmed, real mass-injection
     * pattern: dozens of these folders dropped at once, each holding a
     * handful of PHP files given plausible-sounding-but-fake framework
     * names (handler.php, loader.php, registry.php, session.php, ...) to
     * blend in, paired with a matching junk row in the database. Unlike
     * scanFileContent()'s signature checks, this doesn't depend on
     * recognizing the payload's code at all -- it flags purely on the
     * folder naming, so it still catches the drop even if the file
     * contents don't match any known webshell signature. Applies to the
     * folder itself and everything inside it, at any depth, regardless of
     * scan mode.
     */
    /** Per-request cache for the templateDetails.xml check below, keyed by template folder absolute path -- avoids re-stat()ing the same folder once per file inside it. */
    private static array $templateManifestCache = [];

    public static function checkJunkTemplateFolder(string $relPath, array $sig, ?string $absPath = null, ?array $registeredTemplates = null): ?string
    {
        $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
        $parts = explode('/', $relPath);

        if (($parts[0] ?? '') === 'templates') {
            $topFolder = $parts[1] ?? '';
            $depthAfterTop = count($parts) - 2;
            $clientId = 0;
        } elseif (($parts[0] ?? '') === 'administrator' && ($parts[1] ?? '') === 'templates') {
            $topFolder = $parts[2] ?? '';
            $depthAfterTop = count($parts) - 3;
            $clientId = 1;
        } else {
            return null;
        }

        if ($topFolder === '') {
            return null;
        }

        // Joomla's own "prevent directory listing" blank stub sits
        // directly in templates/ (and administrator/templates/) itself --
        // never a real template name, so a bare file at that level (not a
        // template subfolder) is never treated as one.
        if (count($parts) === $clientId + 2 && in_array(strtolower($topFolder), ['index.html', 'index.php'], true)) {
            return null;
        }

        // "system" is Joomla's own bundled fallback template (offline.php,
        // error.php, fatal.php, ...), present in a stock install on both the
        // site and admin side. It's core Joomla, not an installed extension
        // -- it never goes through the extension installer and so
        // legitimately has no templateDetails.xml, unlike every other
        // folder under templates/. Exempt it from the no-manifest check
        // below so it isn't misclassified as a fake/junk template folder;
        // it can still be flagged separately by the actual content-
        // signature scan if a file inside it is genuinely infected.
        if (in_array(strtolower($topFolder), $sig['TEMPLATE_SYSTEM_FOLDER_NAMES'], true)) {
            return null;
        }

        $junkName = (bool) preg_match($sig['TEMPLATE_STYLE_JUNK_NAME_RE'], $topFolder);

        // Second, independent signal: does this folder have a
        // templateDetails.xml manifest at all? Joomla has no code path
        // that installs a template without one, so a folder that lacks
        // one was never actually installed as a real template -- a much
        // broader net than the tmpl_xxxxxx name check above, which only
        // catches one specific naming convention. Real-world mass
        // webshell-drop attacks have also been seen using an EXISTING
        // template's own name plus a random suffix (e.g. "beez3_degj",
        // "cassiopeia_hhnm") specifically to look more legitimate than an
        // obviously-fake tmpl_xxxxxx name at a glance.
        $noManifest = false;
        if ($absPath !== null && $depthAfterTop >= 0) {
            $templateRootAbs = $absPath;
            for ($i = 0; $i < $depthAfterTop; $i++) {
                $templateRootAbs = dirname($templateRootAbs);
            }
            if (!array_key_exists($templateRootAbs, self::$templateManifestCache)) {
                self::$templateManifestCache[$templateRootAbs] = is_file($templateRootAbs . '/templateDetails.xml');
            }
            $noManifest = !self::$templateManifestCache[$templateRootAbs];
        }

        // Strongest, hardest-to-fake signal: cross-reference Joomla's own
        // #__extensions registry -- the actual source of truth for "is
        // this installed at all". A real attack seen on a live site faked
        // BOTH the folder's templateDetails.xml AND a matching
        // #__template_styles row, but could not make its injected
        // #__extensions rows enabled -- every one was left at enabled=0,
        // unlike every genuinely-installed template. Checked ahead of, and
        // independent of, the two on-disk signals above, since those alone
        // are exactly what a sufficiently determined attacker can spoof.
        $registryProblem = null;
        if ($registeredTemplates !== null) {
            $key = $clientId . '|' . strtolower($topFolder);
            if (!array_key_exists($key, $registeredTemplates)) {
                $registryProblem = 'no matching #__extensions row of type "template" exists for it';
            } elseif (!$registeredTemplates[$key]) {
                $registryProblem = 'its #__extensions template record exists but is disabled (enabled = 0)';
            }
        }

        if ($registryProblem === null && !$junkName && !$noManifest) {
            return null;
        }

        if ($registryProblem !== null) {
            return "Sits inside \"{$topFolder}\" — {$registryProblem}, meaning Joomla's own extension registry never actually installed this as a real, active template. This is checked independently of the folder's own files, so a faked manifest or folder structure alone cannot hide it.";
        }

        if ($junkName) {
            return "Sits inside \"{$topFolder}\" — an auto-generated junk template folder name (tmpl_xxxxxx) seen paired with a matching fake #__template_styles database row in a real, confirmed mass-injection attack, not a legitimately installed template.";
        }

        return "Sits inside \"{$topFolder}\" — this folder has no templateDetails.xml manifest, so Joomla could never have installed it as a real template. A common mass webshell-drop pattern: an existing template's name plus a random suffix used purely to host a backdoor file behind a legitimate-looking path, not a real template.";
    }

    /**
     * Same idea as checkJunkTemplateFolder(), for modules/, plugins/, and
     * components/ -- a real, live compromise dropped fake folders in all
     * three (e.g. modules/helper/helper.php, plugins/system/loader/loader.php,
     * components/com_feed/feed.php), each holding a self-decoding backdoor
     * (see CONTENT_SIGNATURES' eval_encoded_blob).
     *
     * Modules: Joomla requires every real module's #__extensions element
     * to start with "mod_" -- a folder that doesn't is disqualified on
     * naming alone, no DB query needed.
     *
     * Plugins: cross-referenced against #__extensions the same way
     * templates are (see $registeredPlugins / getRegisteredPlugins()) --
     * but ONLY a completely missing row is flagged. Unlike templates,
     * "enabled=0" is NOT used here: several genuinely core Joomla plugins
     * (LDAP authentication, Basic Auth for the Web Services API, ...) ship
     * disabled by default, so treating "disabled" as suspicious flags a
     * stock, unmodified Joomla install.
     *
     * A folder whose name doesn't match any #__extensions element isn't
     * automatically fake, either: renaming a plugin's folder (prefixing
     * "x", "_", "OFF-", ...) to disable it without touching the database
     * is a common, legitimate admin technique -- the #__extensions row
     * survives under the plugin's ORIGINAL element. Before concluding a
     * folder is fake, its own manifest XML (if present -- Joomla's
     * installer convention names it <element>.xml, matching the plugin's
     * real element regardless of what the folder is currently called) is
     * also checked against the registry (see findPluginManifestElement()).
     *
     * Components: the attack above faked its #__extensions rows with
     * enabled=1, so neither the module nor plugin signal applies --
     * cross-referenced instead against manifest_cache (see
     * $registeredComponents / getRegisteredComponents()).
     */
    public static function checkJunkExtensionFolder(string $relPath, array $sig, ?array $registeredPlugins = null, ?array $registeredComponents = null, ?string $absPath = null): ?string
    {
        $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
        $parts = explode('/', $relPath);

        $modIdx = null;
        if (($parts[0] ?? '') === 'modules') {
            $modIdx = 1;
        } elseif (($parts[0] ?? '') === 'administrator' && ($parts[1] ?? '') === 'modules') {
            $modIdx = 2;
        }
        if ($modIdx !== null) {
            $modName = $parts[$modIdx] ?? '';

            // Joomla's own "prevent directory listing" blank stub sits
            // directly in modules/ itself -- never a real module name, so
            // a bare file at that level (not a module subfolder) is never
            // treated as one.
            if (count($parts) === $modIdx + 1 && in_array(strtolower($modName), ['index.html', 'index.php'], true)) {
                return null;
            }

            if ($modName !== '' && stripos($modName, 'mod_') !== 0) {
                return "Sits inside \"{$modName}\" — a modules/ folder not named with Joomla's required \"mod_\" prefix, meaning this could never be a real installed module.";
            }
            return null;
        }

        if (($parts[0] ?? '') === 'plugins' && isset($parts[2]) && $parts[2] !== '') {
            $group = $parts[1];
            $name  = $parts[2];

            // Joomla's own "prevent directory listing" blank stub sits
            // directly in every plugins/<group>/ folder -- never a real
            // plugin name, so a bare file at the group level (not a
            // plugin subfolder) is never treated as one.
            if (count($parts) === 3 && in_array(strtolower($name), ['index.html', 'index.php'], true)) {
                return null;
            }

            if ($registeredPlugins !== null) {
                $key = strtolower($group) . '|' . strtolower($name);
                if (array_key_exists($key, $registeredPlugins)) {
                    return null;
                }

                if ($absPath !== null) {
                    $depth = count($parts) - 3;
                    $folderAbs = $absPath;
                    for ($i = 0; $i < $depth; $i++) {
                        $folderAbs = dirname($folderAbs);
                    }
                    $manifestElement = self::findPluginManifestElement($folderAbs);
                    if ($manifestElement !== null) {
                        $altKey = strtolower($group) . '|' . strtolower($manifestElement);
                        if (array_key_exists($altKey, $registeredPlugins)) {
                            return null;
                        }
                    }
                }

                // This scanner's own companion plugin (MuRu Guard Shield)
                // is a real, expected exception to "unregistered = fake":
                // its files can legitimately sit here without a matching
                // #__extensions row simply because the admin uploaded/
                // extracted them but hasn't clicked Install in Extensions
                // > Manage yet -- not a compromise, just an incomplete
                // setup step. A distinct, accurate, non-alarming message
                // replaces the generic "fake plugin" wording so it's
                // obvious what this actually is and how to resolve it,
                // while still SHOWING it (rather than silently hiding it)
                // so the admin is prompted to actually finish installing
                // it and get real-time protection active.
                if (strtolower($group) === 'system' && strtolower($name) === 'muruguardshield') {
                    return "This is MuRu Guard Shield — this scanner's own companion real-time-protection plugin, not a malicious file. Its files are present but not yet installed through Joomla. Go to Extensions → Manage → Install (or Discover) and install it to activate real-time protection; this notice clears automatically once it's registered.";
                }

                return "Sits inside plugins/{$group}/{$name} — no matching #__extensions row of type \"plugin\" exists for it, meaning Joomla never actually installed this as a real plugin.";
            }
            return null;
        }

        $compIdx = null;
        if (($parts[0] ?? '') === 'components') {
            $compIdx = 1;
        } elseif (($parts[0] ?? '') === 'administrator' && ($parts[1] ?? '') === 'components') {
            $compIdx = 2;
        }
        if ($compIdx !== null) {
            $compName = $parts[$compIdx] ?? '';
            if ($compName === '' || stripos($compName, 'com_') !== 0) {
                return null;
            }
            if ($registeredComponents !== null) {
                $key = strtolower($compName);
                if (!array_key_exists($key, $registeredComponents)) {
                    return "Sits inside \"{$compName}\" — no matching #__extensions row of type \"component\" exists for it, meaning Joomla never actually installed this as a real component.";
                }
                if (!$registeredComponents[$key]) {
                    return "Sits inside \"{$compName}\" — its #__extensions component record has no populated install manifest (manifest_cache), which every genuinely Joomla-installed extension has; a strong sign of a directly-inserted database row rather than a real installation.";
                }
            }
            return null;
        }

        return null;
    }

    /**
     * Detects the ".htaccess makes a non-PHP extension execute as PHP"
     * technique -- confirmed in a real backdoor sample:
     *   <FilesMatch "\.json$">
     *   SetHandler application/x-httpd-php
     *   </FilesMatch>
     * paired with a webshell dropped as e.g. "shell.php.json" (see the
     * \.php\.json$ entry in SUSPICIOUS_FILENAME_REGEXES) -- this makes
     * Apache execute it as PHP despite the .json extension, defeating any
     * filter/scanner that only blocks the literal ".php" extension.
     * Deliberately requires BOTH a php-execution handler directive AND a
     * <FilesMatch> targeting a NON-php extension in the same file --
     * `<FilesMatch "\.php$"> SetHandler application/x-httpd-php
     * </FilesMatch>` is a completely ordinary, common directive on shared
     * hosting (it's how PHP itself often gets enabled for .php files) and
     * must never be flagged.
     */
    public static function checkMaliciousHtaccessHandler(string $content): ?string
    {
        $hasPhpHandler = (bool) preg_match(
            '/(?:SetHandler|AddHandler|AddType)\s+["\']?application\/x-httpd-php\d*["\']?/i',
            $content
        );
        if (!$hasPhpHandler) {
            return null;
        }

        if (preg_match('/<FilesMatch\s+["\']?\\\\?\.(?!php\b)[a-z0-9]+\$?["\']?\s*>/i', $content, $m)) {
            return "Contains a directive that executes a non-PHP file extension as PHP ({$m[0]} combined with a PHP execution handler) — the exact technique used to run a dropped webshell despite a disguised extension (e.g. \".json\"), defeating any filter that only blocks \".php\" files directly.";
        }

        return null;
    }

    /**
     * ".profile" is a Unix shell-startup dotfile (bash/sh reads it from a
     * user's home directory) -- it has no meaning to Joomla or to a web
     * server request at all, and a clean Joomla install never creates one.
     * On shared hosting, the account's actual home directory and its
     * public webroot are normally two different locations, so a
     * legitimate shell ".profile" wouldn't even be reachable this way in
     * the first place. Its presence directly in the webroot is a known
     * technique for hiding a backdoor behind an filename that looks like
     * routine account configuration rather than site content, and that
     * many admins/scanners overlook precisely because it's a dotfile.
     * Flagged purely on being present at the webroot root, independent of
     * whatever its content turns out to be (which is also now scanned --
     * see the 'profile' entry added to scanFileContent()'s text-like
     * extensions -- for a more specific reason when it matches a known
     * pattern).
     */
    public static function checkRootLevelDotfile(string $basename): ?string
    {
        if (strtolower($basename) !== '.profile') {
            return null;
        }

        return 'A ".profile" file exists directly in the Joomla webroot. This is a Unix shell-startup dotfile that has no legitimate reason to be there — Joomla never creates one, and a real account ".profile" lives in the hosting account\'s home directory, not the public webroot. Commonly used to hide a backdoor behind an unassuming, easily-overlooked dotfile name.';
    }

    /** Per-request cache for findPluginManifestElement() below, keyed by plugin folder absolute path. */
    private static array $pluginManifestElementCache = [];

    /**
     * Looks for a plugin manifest XML directly inside $folderAbs (Joomla's
     * installer convention names it <element>.xml, e.g. formea.xml for a
     * plugin whose real element is "formea" -- matching its other internal
     * files like formea.php and en-GB.plg_system_formea.ini even when the
     * containing folder itself has been renamed to something else, e.g.
     * "xformea", to disable it). Returns the manifest's filename (without
     * extension) if a real Joomla plugin manifest is found, null otherwise.
     */
    private static function findPluginManifestElement(string $folderAbs): ?string
    {
        if (array_key_exists($folderAbs, self::$pluginManifestElementCache)) {
            return self::$pluginManifestElementCache[$folderAbs];
        }

        $result = null;
        if (is_dir($folderAbs)) {
            foreach (glob($folderAbs . '/*.xml') ?: [] as $xmlFile) {
                $contents = @file_get_contents($xmlFile, false, null, 0, 2048);
                if ($contents !== false && preg_match('/<extension\b[^>]*\btype\s*=\s*"plugin"/i', $contents)) {
                    $result = strtolower(pathinfo($xmlFile, PATHINFO_FILENAME));
                    break;
                }
            }
        }

        return self::$pluginManifestElementCache[$folderAbs] = $result;
    }

    /**
     * Any index.php file OUTSIDE a template's own top-level root should be
     * nothing more than Joomla's standard blank "no direct access" stub --
     * this convention holds almost universally across the ENTIRE Joomla
     * tree (components, modules, plugins, libraries, and every nested
     * template subfolder like a "features" or "layouts" directory).
     * Only a template's own root index.php (templates/<name>/index.php)
     * legitimately contains real rendering code. A non-stub index.php
     * anywhere else is a strong sign of a webshell hiding behind the
     * single most innocuous-looking filename in the whole codebase --
     * exactly the kind of file a plain executable-extension check inside
     * "code" mode directories (where .php is otherwise expected and
     * unremarkable) would never catch.
     *
     * A known-masquerade LOCATION (see TEMPLATE_FOLDER_MASQUERADE_PATTERNS)
     * is checked first and flagged unconditionally, before even looking at
     * content -- an attacker can trivially make a dropped file's content
     * look like a blank stub specifically to dodge a content-only check,
     * so a folder that shouldn't exist in any clean template at all is
     * flagged purely on where it sits, not what it contains.
     */
    public static function checkStrayIndexPhp(string $relPath, string $absPath, array $sig): ?string
    {
        $relPath = ltrim(str_replace('\\', '/', $relPath), '/');
        if (strcasecmp(basename($relPath), 'index.php') !== 0) return null;

        foreach ($sig['TEMPLATE_FOLDER_MASQUERADE_PATTERNS'] as $re) {
            if (preg_match($re, $relPath)) {
                $preview = self::filePreview($absPath);
                $suffix  = $preview !== '' ? " Matched code: {$preview}" : '';
                return 'Path masquerades as a template asset folder that does not exist in a clean install of any known Joomla template — flagged regardless of file content (even a blank stub here is a known real-world compromise artifact).' . $suffix;
            }
        }

        if (preg_match('#^(administrator/)?templates/[^/]+/index\.php$#i', $relPath)) return null;

        // libraries/vendor/ is Joomla's bundled Composer dependency tree --
        // hundreds of third-party open-source packages, none of which
        // follow Joomla's own "blank stub" index.php convention (it's not
        // their convention to begin with). A package's own test fixtures,
        // examples, or dev tooling can legitimately ship a fully
        // functional index.php (e.g. Symfony's http-client-contracts test
        // fixtures, which run a real local HTTP server for integration
        // tests) -- structurally indistinguishable from this check's
        // "webshell hiding behind a blank-stub filename" pattern, since
        // that's exactly what a real one looks like: code where a blank
        // stub was expected. This one structural signal isn't reliable
        // enough to flag arbitrary vendor code on its own; the ordinary
        // content-signature scan (scanFileContent(), which runs on every
        // file regardless of location) still catches an actual malicious
        // payload dropped/injected here.
        if (stripos($relPath, 'libraries/vendor/') === 0 || stripos($relPath, '/libraries/vendor/') !== false) {
            return null;
        }

        // components/com_jce/editor/libraries/views/plugin/index.php is a
        // real, legitimate JCE editor view layout -- the HTML wrapper for
        // the editor's plugin dialog windows -- confirmed byte-identical
        // in structure (real markup, JCE's own `defined('JPATH_PLATFORM')
        // or die` guard rather than Joomla's `_JEXEC` stub convention)
        // across many real installs. isStandardJoomlaStub() correctly
        // doesn't recognize JPATH_PLATFORM as Joomla's blank-stub guard,
        // so this real file's real markup looked structurally identical
        // to a webshell disguise. Exempted from this STRUCTURAL check
        // only -- the ordinary content-signature scan (scanFileContent(),
        // which runs on every file regardless of location) still runs on
        // it, so an actual backdoor dropped/injected at this exact path
        // is still caught.
        if (strcasecmp($relPath, 'components/com_jce/editor/libraries/views/plugin/index.php') === 0) {
            return null;
        }

        $contents = @file_get_contents($absPath, false, null, 0, 4096);
        if ($contents === false) return null;
        if (self::isStandardJoomlaStub($contents)) return null;

        $preview = trim(preg_replace('/\s+/', ' ', $contents));
        $preview = strlen($preview) > 220 ? substr($preview, 0, 220) . '…' : $preview;

        return "Non-standard index.php — Joomla only ever places a blank \"no direct access\" stub here (outside a template's own root layout file); this one contains extra code, a common disguise for a webshell. Matched code: {$preview}";
    }

    /**
     * True if any reason in a finding's reasons list corresponds to a
     * pattern this scanner can safely auto-repair (see
     * cleanPrependedPayload() / cleanHeadTagInjection()) -- used to build
     * the dedicated "Cleanable Files" tab in the UI, distinct from
     * findings that only support review/delete.
     */
    public static function isCleanablePattern(array $reasonsList): bool
    {
        foreach ($reasonsList as $r) {
            if (stripos($r, 'before the joomla bootstrap (_jexec)') !== false) return true;
            if (stripos($r, "before its own joomla bootstrap/access guard") !== false) return true;
            if (stripos($r, 'obfuscated script injected right after <head> tag') !== false) return true;
        }
        return false;
    }

    /**
     * True if $relPath is a genuinely required core/template entry file
     * that deleteTargets() refuses to delete (offering Clean instead).
     *
     * For a template's own root index.php (the only pattern in
     * PROTECTED_ENTRY_FILE_PATTERNS), "required" only holds if the
     * template is real. The strongest available evidence of that is a
     * matching, ENABLED row in Joomla's own #__extensions registry (see
     * $registeredTemplates / checkJunkTemplateFolder()'s docblock for why
     * this is checked ahead of, not instead of, the on-disk manifest
     * check) -- a real attack was able to fake a folder and its
     * templateDetails.xml both, but not an enabled #__extensions row. A
     * template that's neither registered nor manifested was never a real
     * template; a webshell dropped there should be deletable like any
     * other suspicious file, not steered toward "clean, never delete".
     * Pass $absPath/$registeredTemplates when available (callers that
     * only have a bare relative path fall back to the old, safer-by-
     * default "always required" behaviour).
     */
    public static function isProtectedEntryPath(string $relPath, array $sig, ?string $absPath = null, ?array $registeredTemplates = null): bool
    {
        $relNorm = str_replace('\\', '/', $relPath);
        if (in_array($relNorm, $sig['PROTECTED_ENTRY_FILES'], true)) return true;
        foreach ($sig['PROTECTED_ENTRY_FILE_PATTERNS'] as $re) {
            if (preg_match($re, $relNorm)) {
                // Joomla's own bundled "system" fallback template (see
                // checkJunkTemplateFolder()) has no templateDetails.xml but
                // is still a genuinely required core file -- always
                // protected, regardless of the checks below.
                if (preg_match('#(?:^|/)templates/system/index\.php$#i', $relNorm)) {
                    return true;
                }

                if ($registeredTemplates !== null
                    && preg_match('#^(administrator/)?templates/([^/]+)/index\.php$#i', $relNorm, $m)) {
                    $key = ($m[1] !== '' ? 1 : 0) . '|' . strtolower($m[2]);
                    return array_key_exists($key, $registeredTemplates) && $registeredTemplates[$key];
                }

                if ($absPath !== null) {
                    return is_file(dirname($absPath) . '/templateDetails.xml');
                }
                return true;
            }
        }
        return false;
    }

    /** True if $relPath sits inside one of SCAN_CONFIG's 'code' directories (components, modules, plugins, libraries, templates, cli, bin, ...) -- an area where real, actively-used source files are expected to exist. */
    public static function isCodeAreaPath(string $relPath, array $sig): bool
    {
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        foreach ($sig['SCAN_CONFIG'] as $dir => $mode) {
            if ($mode !== 'code') continue;
            if ($relNorm === $dir || strpos($relNorm, $dir . '/') === 0) return true;
        }
        return false;
    }

    /**
     * True when a finding inside a real code directory (see
     * isCodeAreaPath()) is flagged ONLY by content-signature matches --
     * i.e. every one of its reasons is a "Content signature: ..." hit,
     * with no structural/location red flag (core-masquerade, stray
     * index.php, unrecognized directory, suspicious filename, ...)
     * alongside it. That's the exact shape of a legitimate, actively-used
     * file that had a backdoor snippet injected into otherwise-normal
     * code, not a foreign file an attacker dropped -- the file's name and
     * location are completely unremarkable, only its content is
     * compromised. Deleting it outright would take down real site
     * functionality, so it must never be offered as a one-click-delete
     * candidate even when no auto-clean pattern recognizes this specific
     * infection -- landing in the Cleanable Files tab for manual review
     * is the safe outcome, not the destructive one.
     *
     * That reasoning only holds for a genuinely AMBIGUOUS content match,
     * though (see CONTENT_SIGNATURES' severity tagging in getSignatures()
     * -- 'medium' names things with a plausible benign explanation, e.g.
     * a commercial extension self-obfuscating for license protection).
     * A 'high' severity match (tagged "high-confidence exploit pattern"
     * in the reason text scanFileContent() builds) is by this codebase's
     * own definition unambiguous enough to mark the whole file High
     * confidence on its own -- code/library/plugin/module/template areas
     * with zero structural corroboration and nothing but a webshell
     * signature this unambiguous aren't legitimate files with something
     * merely injected into them; a real, confirmed live compromise
     * (a PHPkoru-obfuscated backdoor dropped at libraries/init/init.php,
     * no matching structural signal available since libraries/ has no
     * #__extensions-style registry to check against) landed here purely
     * because eval_encoded_blob is deliberately medium -- but the file
     * also carries other high-confidence markers, so a high match present
     * anywhere in the reasons list takes it out of this softening
     * entirely, letting it fall through to Suspicious Files/Delete
     * instead of sitting stuck in Cleanable with no working auto-clean
     * pattern.
     */
    public static function isContentOnlyCodeAreaFinding(string $relPath, array $reasonsList, array $sig): bool
    {
        if (empty($reasonsList) || !self::isCodeAreaPath($relPath, $sig)) return false;
        foreach ($reasonsList as $r) {
            $r = (string) $r;
            if (stripos($r, 'Content signature:') !== 0) return false;
            if (stripos($r, 'high-confidence exploit pattern') !== false) return false;
        }
        return true;
    }

    public static function humanSize(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $i = 0;
        while ($bytes >= 1024 && $i < 3) { $bytes /= 1024; $i++; }
        return round($bytes, 1) . ' ' . $units[$i];
    }

    public static function walkDir(string $dir, callable $callback, array $skipDirNames = ['node_modules', '.git']): void
    {
        if (!is_dir($dir)) return;
        $items = @scandir($dir);
        if ($items === false) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            if (in_array($item, $skipDirNames, true)) continue;
            $path = $dir . '/' . $item;
            $isDir = is_dir($path);
            $callback($path, $isDir);
            if ($isDir) self::walkDir($path, $callback, $skipDirNames);
        }
    }

    public static function dirSize(string $dir): int
    {
        $total = 0;
        $items = @scandir($dir);
        if (!$items) return 0;
        foreach ($items as $it) {
            if ($it === '.' || $it === '..') continue;
            $p = $dir . '/' . $it;
            if (is_dir($p)) $total += self::dirSize($p);
            elseif (is_file($p)) $total += (int) @filesize($p);
        }
        return $total;
    }

    public static function deleteRecursive(string $path): bool
    {
        if (is_link($path)) return @unlink($path);
        if (is_file($path)) return @unlink($path);
        if (!is_dir($path)) return true;
        $items = @scandir($path);
        if ($items === false) return false;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            if (!self::deleteRecursive($path . '/' . $item)) return false;
        }
        return @rmdir($path);
    }

    public static function isDateLikeNumericFolderName(string $name): bool
    {
        return (bool) preg_match('/^\d{1,4}$/', $name);
    }

    /**
     * True if $contents is (after stripping comments/whitespace) nothing
     * more than Joomla's standard "no direct access" guard. Joomla and
     * countless legitimate extensions place this blank stub in every
     * subfolder by convention -- an index.php existing somewhere is normal
     * and NOT a threat on its own, even inside an "upload" directory like
     * media/ or images/. Only flag a stub file if it contains more than
     * this guard.
     */
    public static function isStandardJoomlaStub(string $contents): bool
    {
        $trimmed = trim($contents);
        if ($trimmed === '') return true; // some older stubs are just blank files

        $noBlockComments = preg_replace('#/\*.*?\*/#s', '', $trimmed);
        $noLineComments  = preg_replace('#//[^\n]*#', '', $noBlockComments);
        $normalized = trim(preg_replace('/\s+/', ' ', $noLineComments));

        $guardPatterns = [
            '/<\?php\s*defined\(\s*[\'"]_JEXEC[\'"]\s*\)\s*or\s*die(\s*\(\s*[\'"]?.*?[\'"]?\s*\))?\s*;?/i',
            '/<\?php\s*\?>/i',
            '/<\?php/i',
            '/\?>/',
        ];
        $stripped = $normalized;
        foreach ($guardPatterns as $p) {
            $stripped = preg_replace($p, '', $stripped);
        }
        $stripped = trim($stripped);

        // After removing the guard, comments, and PHP tags, almost nothing
        // should remain. Allow a small margin (e.g. a trailing "exit;").
        return strlen($stripped) <= 12;
    }

    /**
     * Joomla's real root index.php never executes anything before defining
     * _JEXEC. Any code before that point is a strong sign of a prepended
     * payload -- the exact `$db = array(122,105,...); require zip://...`
     * pattern seen in real Joomla compromises.
     */
    /** Patterns indicating executable/obfuscated code, used to judge whether text found before Joomla's bootstrap/guard marker is a real threat. */
    private static function suspiciousPrefixPatterns(): array
    {
        return [
            'stream-wrapper reference (zip://, phar://, etc.)' => '/(zip|phar|compress\.zlib|compress\.bzip2|data):\/\//i',
            'numeric byte-array (chr() decode obfuscation)'    => '/array\s*\(\s*(\d{2,3}\s*,\s*){6,}\d{2,3}\s*\)/i',
            'eval()'                                            => '/\beval\s*\(/i',
            'base64_decode()'                                   => '/base64_decode\s*\(/i',
            'assert()'                                           => '/\bassert\s*\(/i',
            'shell/process execution function'                  => '/\b(system|exec|shell_exec|passthru|proc_open)\s*\(/i',
        ];
    }

    /**
     * Locates the earliest point in a PHP file where Joomla's own
     * convention guarantees nothing should have executed yet -- either
     * the strict `define('_JEXEC', 1)` bootstrap constant (only the 4
     * true core entry points: index.php, administrator/index.php,
     * api/index.php, includes/app.php) or the universal
     * `defined('_JEXEC') or die(...)` guard that is the first statement
     * in virtually every OTHER Joomla PHP file (core libraries,
     * extensions, template root files, ...). Returns the matched
     * anchor's position plus everything between the opening <?php tag
     * and it, so callers can both FLAG suspicious content in that prefix
     * (checkCoreIndexIntegrity / checkGuardPrependedPayload) and, once
     * confirmed, safely CLEAN it (cleanPrependedPayload) by removing
     * exactly that prefix and nothing else -- the boundary is a hard
     * Joomla-convention marker, not a guess.
     */
    public static function checkPrependedPayload(string $contents): ?array
    {
        $openTagPos = stripos($contents, '<?php');
        if ($openTagPos === false) return null;

        $bootstrapPattern = '/(?:\\\\?\bdefine\s*\(\s*[\'"]_JEXEC[\'"]\s*,\s*1\s*\)|\bconst\s+_JEXEC\s*=\s*1)\s*;/i';
        $guardPattern      = '/defined\s*\(\s*[\'"]_JEXEC[\'"]\s*\)\s*or\s+die\s*(\([^)]*\))?\s*;/i';

        if (preg_match($bootstrapPattern, $contents, $m, PREG_OFFSET_CAPTURE)) {
            $anchorType = 'bootstrap';
        } elseif (preg_match($guardPattern, $contents, $m, PREG_OFFSET_CAPTURE)) {
            $anchorType = 'guard';
        } else {
            return null;
        }

        $prefixStart = $openTagPos + 5;
        $anchorPos   = $m[0][1];
        if ($anchorPos < $prefixStart) return null;
        $prefix = substr($contents, $prefixStart, $anchorPos - $prefixStart);

        foreach (self::suspiciousPrefixPatterns() as $label => $re) {
            if (preg_match($re, $prefix)) {
                return [
                    'anchor_type'  => $anchorType,
                    'label'        => $label,
                    'prefix'       => $prefix,
                    'open_tag_pos' => $openTagPos,
                    'anchor_pos'   => $anchorPos,
                ];
            }
        }
        return null;
    }

    /**
     * Loads the bundled per-Joomla-version SHA-256 checksum manifest for a
     * curated set of security-critical, site-independent core files (see
     * helpers/data/joomla_core_checksums.php for how it was generated and
     * exactly which files/versions it covers). Cached in a static so the
     * small data file is only read once per request no matter how many
     * files get checksum-checked.
     */
    public static function getCoreChecksumManifest(): array
    {
        static $manifest = null;
        if ($manifest === null) {
            $path = __DIR__ . '/data/joomla_core_checksums.php';
            $manifest = is_file($path) ? (include $path) : [];
        }
        return $manifest;
    }

    /**
     * Reads the exact installed Joomla core version from
     * administrator/manifests/files/joomla.xml -- the same file Joomla's
     * own update-checker relies on, present in every install. Plain
     * text/regex, no PHP execution, so this is safe to call against an
     * untrusted/potentially-infected codebase.
     */
    public static function getInstalledJoomlaVersion(string $root): ?string
    {
        $path = $root . '/administrator/manifests/files/joomla.xml';
        if (!is_file($path)) return null;
        $contents = @file_get_contents($path, false, null, 0, 4096);
        if ($contents === false) return null;
        if (preg_match('/<version>\s*([0-9]+\.[0-9]+\.[0-9]+)\s*<\/version>/i', $contents, $m)) {
            return $m[1];
        }
        return null;
    }

    /**
     * Compares a core file's actual SHA-256 against the bundled official
     * hash for the site's exact installed Joomla version. Returns null
     * (no finding) whenever the version or path isn't covered by the
     * manifest -- an unlisted version/file is a "we don't know" gap,
     * never treated as evidence of tampering, so this can only ever add
     * true findings on top of the existing heuristics, never introduce a
     * false positive from missing coverage. A mismatch is unambiguous,
     * byte-for-byte proof of tampering -- stronger than any heuristic
     * pattern match elsewhere in this scanner.
     */
    public static function checkCoreFileChecksum(string $relPath, string $absPath, ?string $version, array $manifest): ?string
    {
        if ($version === null || !isset($manifest[$version])) return null;
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        if (!isset($manifest[$version][$relNorm])) return null;
        if (!is_file($absPath)) return null;
        $actual = @hash_file('sha256', $absPath);
        if ($actual === false) return null;
        $expected = $manifest[$version][$relNorm];
        if (hash_equals($expected, $actual)) return null;

        return "Core file checksum mismatch — this file's content does not match the official Joomla {$version} release byte-for-byte "
             . '(expected sha256 ' . substr($expected, 0, 12) . '…, found ' . substr($actual, 0, 12) . '…). '
             . 'This is direct, unambiguous evidence of tampering, not a heuristic guess.';
    }

    public static function checkCoreIndexIntegrity(string $contents): ?string
    {
        $info = self::checkPrependedPayload($contents);
        if ($info === null || $info['anchor_type'] !== 'bootstrap') return null;

        $preview = trim(preg_replace('/\s+/', ' ', $info['prefix']));
        $preview = strlen($preview) > 160 ? substr($preview, 0, 160) . '…' : $preview;
        return "Core entry-point file contains suspicious code before the Joomla bootstrap (_JEXEC) — {$info['label']} detected. Offending code: {$preview}";
    }

    /**
     * Same threat detection as checkCoreIndexIntegrity(), but for ANY
     * Joomla PHP file (core library, extension, template) using its own
     * universal `defined('_JEXEC') or die` access guard as the anchor
     * instead of the bootstrap constant only the 4 true entry points
     * define. Catches a legitimate core/extension file that has had
     * malicious code prepended ahead of its own guard -- the same
     * real-world "prepended payload" technique, just outside the 4 named
     * entry points, which previously went undetected by this check.
     */
    public static function checkGuardPrependedPayload(string $contents): ?string
    {
        $info = self::checkPrependedPayload($contents);
        if ($info === null || $info['anchor_type'] !== 'guard') return null;

        $preview = trim(preg_replace('/\s+/', ' ', $info['prefix']));
        $preview = strlen($preview) > 160 ? substr($preview, 0, 160) . '…' : $preview;
        return "File contains suspicious code before its own Joomla bootstrap/access guard (defined('_JEXEC') or die) — {$info['label']} detected; a legitimate Joomla file never executes anything before this line. Offending code: {$preview}";
    }

    /**
     * Repairs a "prepended payload" infection (see checkPrependedPayload())
     * by removing exactly the code sitting between the opening <?php tag
     * and Joomla's own bootstrap/guard statement, leaving everything from
     * that statement onward -- the entire legitimate file -- completely
     * untouched. Use this instead of deleting the file: index.php,
     * administrator/index.php, and a template's own root index.php are
     * all genuinely required files that should never simply be removed.
     */
    public static function cleanPrependedPayload(string $contents): array
    {
        $info = self::checkPrependedPayload($contents);
        if ($info === null) return ['cleaned' => $contents, 'changed' => false];

        $replacement = '<?php' . "\n";
        $before  = substr($contents, 0, $info['open_tag_pos']);
        $after   = substr($contents, $info['anchor_pos']);
        $cleaned = $before . $replacement . $after;

        $preview = trim(preg_replace('/\s+/', ' ', $info['prefix']));
        $preview = strlen($preview) > 160 ? substr($preview, 0, 160) . '…' : $preview;

        return [
            'cleaned' => $cleaned, 'changed' => true, 'removed_preview' => $preview,
            'removed_start' => $info['open_tag_pos'], 'removed_end' => $info['anchor_pos'],
            'replacement' => $replacement,
        ];
    }

    /**
     * Locates the first <script>...</script> block appearing after a
     * <head> tag, if its content matches known payload-loading markers
     * (base64/atob/eval/String.fromCharCode/document.write) or is simply
     * unusually large for an inline head script. Implemented with plain
     * string search (stripos/strpos/substr) rather than a single
     * monolithic regex spanning the whole file -- a nested-lazy-quantifier
     * regex applied to tens of KB of heavily-obfuscated real-world payload
     * is exactly the kind of input that can behave inconsistently under
     * PHP's PCRE backtrack limit, which would let detection and repair
     * silently disagree. This is the single source of truth for both
     * checkHeadTagInjection() (report) and cleanHeadTagInjection()
     * (repair), so they can never drift out of sync with each other.
     */
    private static function findInjectedHeadScript(string $contents): ?array
    {
        // A real script-injection defacement plants its payload as the
        // very FIRST thing inside <head>, before any legitimate meta/
        // title/link tag -- that's what makes it run on every single
        // page. This used to just search for a <script> tag ANYWHERE
        // later in the file, which matched countless entirely legitimate
        // files: any page/template/vendor library with BOTH a <head> tag
        // and an unrelated <script> block somewhere else in the document
        // (a near-universal combination) -- Joomla's own templates/system
        // error pages, com_finder's HTML parser, php-debugbar's and
        // Symfony's own large debug-toolbar/exception-page renderers, a
        // template framework's "coming soon" countdown page, ... none of
        // which have anything actually injected. Only a script tag
        // sitting IMMEDIATELY after <head> (nothing but whitespace in
        // between) counts now.
        if (!preg_match('/<head\b[^>]*>\s*/i', $contents, $headMatch, PREG_OFFSET_CAPTURE)) return null;
        $headOpenEnd = $headMatch[0][1] + strlen($headMatch[0][0]);

        if (stripos($contents, '<script', $headOpenEnd) !== $headOpenEnd) return null;

        $scriptOpenPos = $headOpenEnd;
        $openTagCloseAt = strpos($contents, '>', $scriptOpenPos);
        if ($openTagCloseAt === false) return null;
        $bodyStart = $openTagCloseAt + 1;

        $scriptClosePos = stripos($contents, '</script', $bodyStart);
        if ($scriptClosePos === false) return null;
        $closeTagEndAt = strpos($contents, '>', $scriptClosePos);
        if ($closeTagEndAt === false) return null;
        $blockEnd = $closeTagEndAt + 1;

        $scriptBody = substr($contents, $bodyStart, $scriptClosePos - $bodyStart);
        $fullBlock  = substr($contents, $scriptOpenPos, $blockEnd - $scriptOpenPos);

        $hasMarker = (bool) preg_match('/base64|atob|eval|String\.fromCharCode|document\.write/i', $scriptBody);
        $isLarge   = strlen($scriptBody) > 200;
        if (!$hasMarker && !$isLarge) return null;

        return [
            'start' => $scriptOpenPos,
            'end'   => $blockEnd,
            'block' => $fullBlock,
            'label' => $hasMarker ? 'known payload-loading marker (base64/atob/eval/...)' : 'unusually large inline script',
        ];
    }

    public static function checkHeadTagInjection(string $contents): ?string
    {
        $info = self::findInjectedHeadScript($contents);
        if ($info === null) return null;

        $preview = trim(preg_replace('/\s+/', ' ', $info['block']));
        $preview = strlen($preview) > 200 ? substr($preview, 0, 200) . '…' : $preview;
        return "Suspicious obfuscated script injected right after <head> tag ({$info['label']}). Preview: {$preview}";
    }

    /**
     * Repairs a <head> script-injection infection (see
     * checkHeadTagInjection()) by removing exactly the injected
     * <script>...</script> block that check matched, leaving the <head>
     * tag and every other legitimate line in the template untouched.
     */
    public static function cleanHeadTagInjection(string $contents): array
    {
        $info = self::findInjectedHeadScript($contents);
        if ($info === null) return ['cleaned' => $contents, 'changed' => false];

        $cleaned = substr($contents, 0, $info['start']) . substr($contents, $info['end']);

        $preview = trim(preg_replace('/\s+/', ' ', $info['block']));
        $preview = strlen($preview) > 160 ? substr($preview, 0, 160) . '…' : $preview;

        return [
            'cleaned' => $cleaned, 'changed' => true, 'removed_preview' => $preview,
            'removed_start' => $info['start'], 'removed_end' => $info['end'], 'replacement' => '',
        ];
    }

    /**
     * Renders a ready-made, pre-escaped HTML block showing exactly what
     * the Clean action would remove (and add back, if anything) -- kept
     * server-side, like formatReasonForDisplay(), so the client never
     * parses or escapes free text, it just injects finished HTML. Takes
     * the exact removed/replacement strings a clean*() function reports
     * (see 'removed_start'/'removed_end'/'replacement' in
     * cleanPrependedPayload()/cleanHeadTagInjection()) rather than trying
     * to reverse-engineer the change from before/after content -- a
     * generic character-diff is ambiguous whenever the removed region's
     * boundary bytes repeat (e.g. a "<script...>" block sitting right
     * after "<head>" -- both start with "<"), which silently misaligns
     * the shown snippet by a few bytes. Using the exact positions the
     * clean function already computed avoids that class of bug entirely.
     */
    public static function formatCleanPreview(string $removed, string $replacement): string
    {
        $removedLen = strlen($removed);
        $removedTrim = trim($removed);
        $removedTrunc = strlen($removedTrim) > 400 ? substr($removedTrim, 0, 400) . '…' : $removedTrim;

        $addedTrim = trim($replacement);

        $html  = '<div class="muru-diff-block">';
        $html .= '<div class="muru-diff-label muru-diff-label-before">Before — Clean would remove ' . $removedLen . ' byte' . ($removedLen === 1 ? '' : 's') . '</div>';
        $html .= '<pre class="muru-diff-removed">' . htmlspecialchars($removedTrunc !== '' ? $removedTrunc : '(only whitespace)') . '</pre>';
        if ($addedTrim !== '') {
            $html .= '<div class="muru-diff-label muru-diff-label-after">After — replaced with</div>';
            $html .= '<pre class="muru-diff-added">' . htmlspecialchars($addedTrim) . '</pre>';
        } else {
            $html .= '<div class="muru-diff-label muru-diff-label-after">After — removed entirely, nothing put in its place</div>';
        }
        $html .= '</div>';
        return $html;
    }

    /**
     * Read-only dry run of cleanCodeFiles()'s exact repair logic (same
     * two functions, same order) against a file's CURRENT on-disk content
     * -- never writes anything. Returns a ready-to-display HTML diff
     * block when an auto-clean pattern is recognized, or null when it
     * isn't (unreadable file, or no pattern this scanner knows how to
     * auto-repair), so the UI can show an accurate "Preview Clean" only
     * where clicking Clean would actually change something.
     */
    public static function previewCleanDiff(string $absPath): ?string
    {
        if (!is_file($absPath)) return null;
        $contents = @file_get_contents($absPath);
        if ($contents === false) return null;

        $result = self::cleanPrependedPayload($contents);
        if (!$result['changed']) {
            $result = self::cleanHeadTagInjection($contents);
        }
        if (!$result['changed']) return null;

        $removed = substr($contents, $result['removed_start'], $result['removed_end'] - $result['removed_start']);
        return self::formatCleanPreview($removed, $result['replacement']);
    }

    /**
     * Verifies a file claiming to be an image (by extension) actually
     * contains real image data. getimagesize() is the ground truth here --
     * it sniffs the real format from content and is deliberately used
     * INSTEAD of a strict per-extension magic-byte match, because a real
     * image saved or served under a mismatched extension is common and
     * harmless (image-optimizer plugins/CDNs frequently rewrite JPGs to
     * WebP data while keeping the original .jpg filename for compatibility;
     * a tiny thumbnail can also legitimately have a minimal/nonstandard
     * header). Flagging on extension-vs-magic-byte mismatch alone produced
     * false positives on ordinary resized thumbnails -- so a successful
     * getimagesize() decode of ANY image format is accepted as proof this
     * is a real image, regardless of extension.
     *
     * Only once getimagesize() fails outright do we fall back to checking
     * magic bytes (again, against any known image format, not just the
     * extension's) to distinguish "not image data at all" (a webshell
     * simply renamed with an image extension -- high confidence) from
     * "looks like it starts as an image but the body won't decode"
     * (corrupted/truncated file, or a polyglot with data appended after
     * genuine image bytes -- lower confidence, worth a manual look).
     */
    public static function checkImageIntegrity(string $path, string $ext, string $contents): ?string
    {
        $checkedExts = ['png', 'jpg', 'jpeg', 'gif', 'webp'];
        if (!in_array($ext, $checkedExts, true)) return null;
        if ($contents === '') return null;

        if (@getimagesize($path) !== false) {
            return null;
        }

        $anyImageMagic = [
            "\x89PNG\r\n\x1a\n", "\xFF\xD8\xFF", "GIF87a", "GIF89a", "RIFF", "BM", "II*\x00", "MM\x00*",
        ];
        $looksLikeAnyImage = false;
        foreach ($anyImageMagic as $magic) {
            if (strncmp($contents, $magic, strlen($magic)) === 0) { $looksLikeAnyImage = true; break; }
        }

        if (!$looksLikeAnyImage) {
            return "File has a .$ext extension but its content does not match any known image file signature and fails to decode as an image — a strong sign of a webshell simply renamed/disguised with an image extension.";
        }

        return "File starts with a recognizable image header but the image data fails to fully decode — could be a corrupted/truncated file; worth a manual look if unexpected.";
    }

    /**
     * Builds a short, human-readable preview of a regex match plus a
     * little surrounding context, so a flagged finding shows exactly what
     * triggered it in the actual file instead of just a bare signature
     * name -- lets a human quickly judge for themselves whether it's a
     * real threat or a false positive, without opening the file.
     */
    private static function previewMatch(string $text, array $match, int $context = 30, int $maxLen = 180): string
    {
        $matchedText = $match[0][0] ?? '';
        $offset      = $match[0][1] ?? 0;
        $start       = max(0, $offset - $context);
        $length      = ($offset - $start) + strlen($matchedText) + $context;
        $snippet     = substr($text, $start, $length);
        $snippet     = trim(preg_replace('/\s+/', ' ', $snippet));
        return strlen($snippet) > $maxLen ? substr($snippet, 0, $maxLen) . '…' : $snippet;
    }

    /** Runs content-signature + polyglot checks. Used in both scan modes. */
    public static function scanFileContent(string $path, string $ext, array $sig, int $maxSize, array &$reasons): bool
    {
        if (!is_file($path) || @filesize($path) === false || @filesize($path) > $maxSize) return false;
        // 'profile' and 'htaccess' aren't real extensions -- PHP's
        // pathinfo() treats everything after the leading dot in a bare
        // dotfile name (.profile, .htaccess) as its "extension" since
        // there's no second dot to split on. Included here so a .profile
        // dropped as a disguised backdoor (see checkRootLevelDotfile())
        // actually gets its content inspected, not silently skipped.
        $textLikeExts = ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phar', 'pht', 'js', 'html', 'htm', 'txt', 'css', 'xml', 'gif', 'png', 'jpg', 'jpeg', 'profile', 'htaccess'];
        if (!in_array($ext, $textLikeExts, true) && $ext !== '') return false;
        $contents = @file_get_contents($path);
        if ($contents === false || $contents === '') return false;

        $flagged = false;

        // A legitimate image (especially a phone photo) can be several MB
        // of mostly-compressed, high-entropy pixel data. Scanning that
        // whole blob against short text signatures produces false
        // positives purely from random byte collisions -- the risk grows
        // with file size, which is exactly why large photos were getting
        // flagged. Real polyglot payloads are always prepended or appended
        // to the valid image bytes, never buried mid-stream inside them,
        // so signature scanning on image extensions is restricted to a
        // head+tail window instead of the full file. Actual code files
        // (php/js/html/...) are unaffected and still scanned in full.
        $isImageExt = in_array($ext, $sig['NON_PHP_EXTS_THAT_MUST_STAY_CLEAN'], true);
        $scanText = $isImageExt
            ? substr($contents, 0, 4096) . "\n" . substr($contents, -8192)
            : $contents;

        // Each signature carries its own severity + a plain-language "why"
        // (see getSignatures()). A high-severity match is unambiguous
        // enough on its own to mark the whole file High confidence; a
        // medium one names something that has a plausible benign
        // explanation and is surfaced for human review instead of an
        // automatic verdict. Either way the actual matched code is quoted
        // so the reason is verifiable, not just a signature label.
        foreach ($sig['CONTENT_SIGNATURES'] as $sigName => $def) {
            if (preg_match($def['re'], $scanText, $m, PREG_OFFSET_CAPTURE)) {
                $flagged = true;
                $preview = self::previewMatch($scanText, $m);
                $tag = $def['severity'] === 'high' ? 'high-confidence exploit pattern' : 'needs manual review';
                $reasons[] = "Content signature: {$sigName} ({$tag}) — {$def['why']} Matched code: {$preview}";
            }
        }
        // The PHP-open-tag check gets its own full-file pass instead of
        // sharing $scanText's narrow head+tail window above. A literal
        // "<?php" (or "<?=" followed by an identifier) is specific enough
        // -- 6+ exact bytes in a row -- that scanning it against the
        // entire file has effectively zero false-positive risk from
        // random binary collisions, unlike the broader CONTENT_SIGNATURES
        // patterns. Without this, a real image bigger than the 8KB tail
        // window with PHP appended further in (a valid, working image AND
        // a valid, working webshell at once) could slip past undetected.
        if ($isImageExt && preg_match($sig['PHP_OPEN_TAG_RE'], $contents, $m, PREG_OFFSET_CAPTURE)) {
            $flagged = true;
            $preview = self::previewMatch($contents, $m);
            $reasons[] = "Content signature: php_tag_in_image_file (polyglot shell disguised with an image extension) — Matched code: {$preview}";
        }

        $imageIssue = self::checkImageIntegrity($path, $ext, $contents);
        if ($imageIssue !== null) { $flagged = true; $reasons[] = $imageIssue; }

        $headIssue = self::checkHeadTagInjection($contents);
        if ($headIssue !== null) { $flagged = true; $reasons[] = $headIssue; }

        // Prepended-payload check on the file's OWN Joomla access guard --
        // catches a genuinely legitimate core/extension/template file that
        // has been infected by prepending malicious code ahead of its own
        // `defined('_JEXEC') or die` guard, the same real-world technique
        // as core entry-point tampering but applicable to any PHP file,
        // not just the 4 named entry points.
        if (in_array($ext, ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'pht'], true)) {
            $guardIssue = self::checkGuardPrependedPayload($contents);
            if ($guardIssue !== null) { $flagged = true; $reasons[] = $guardIssue; }
        }

        return $flagged;
    }

    /**
     * Strips ONLY this scanner's own known, narrow, per-file content-
     * signature false positives (see SELF_CONTENT_SIGNATURE_EXEMPTIONS'
     * docblock for the full reasoning) out of a findings reasons list --
     * never used to skip a file from scanning entirely, only to remove
     * the specific self-referential matches after the fact. Any OTHER
     * reason (a different content signature, a structural/location
     * check, ...) present in the same list is left untouched. Returns the
     * filtered reasons list; the caller re-derives whether the file is
     * still flagged from whether it's non-empty.
     */
    public static function filterSelfSignatureExemptions(string $relPath, array $sig, array $reasons): array
    {
        $relNorm = ltrim(str_replace('\\', '/', $relPath), '/');
        $exemptSigNames = $sig['SELF_CONTENT_SIGNATURE_EXEMPTIONS'][$relNorm] ?? null;
        if ($exemptSigNames === null) return $reasons;

        return array_values(array_filter($reasons, function ($r) use ($exemptSigNames) {
            foreach ($exemptSigNames as $sigName) {
                if (stripos((string) $r, "Content signature: {$sigName} ") === 0) return false;
            }
            return true;
        }));
    }

    /**
     * @param string|array $reasons Either the already-joined display string
     *                              (legacy callers) or the raw list of
     *                              individual reason strings -- passing the
     *                              raw list also preserves each one
     *                              separately in 'reasons' for the
     *                              per-finding code-analysis modal in the UI.
     */
    public static function recordFinding(array &$arr, string $absPath, string $root, $reasons, bool $isDir = false): void
    {
        $reasonsList = is_array($reasons) ? array_values(array_unique($reasons)) : [(string) $reasons];
        $reasonText  = implode(' | ', $reasonsList);

        $rel = ltrim(str_replace($root, '', $absPath), '/');
        $size = $isDir ? self::dirSize($absPath) : (is_file($absPath) ? (int) @filesize($absPath) : 0);
        $highSignals = [
            'high-confidence exploit pattern', 'icon-font', 'malicious pattern', 'unrecognized', 'numeric',
            'non-standard index.php', 'core entry-point', 'stream-wrapper', 'backup/duplicate', 'bootstrap',
            'masquerade', 'disguise', 'polyglot', 'checksum mismatch',
        ];
        $confidence = 'medium';
        foreach ($highSignals as $sigName) {
            if (stripos($reasonText, $sigName) !== false) { $confidence = 'high'; break; }
        }
        $arr[$rel] = [
            'rel' => $rel, 'abs' => $absPath, 'reason' => $reasonText, 'reasons' => $reasonsList,
            'type' => $isDir ? 'dir' : 'file', 'confidence' => $confidence,
            'size' => $size, 'mtime' => (int) @filemtime($absPath),
        ];
    }

    /**
     * Splits a reason string into a lead sentence + an optional code
     * snippet (the "Matched code:" / "Offending code:" / "Preview:"
     * suffix that several checks append), and renders both as safe,
     * pre-escaped HTML for the code-analysis modal. Kept server-side so
     * the client never has to parse free text -- it just injects
     * ready-made HTML.
     */
    public static function formatReasonForDisplay(string $reason): string
    {
        if (preg_match('/^(.*?)(Matched code:|Offending code:|Preview:)\s*(.*)$/s', $reason, $m)) {
            $lead  = trim($m[1]);
            $label = trim($m[2], ': ');
            $code  = trim($m[3]);
            return '<div class="muru-reason-block"><p>' . htmlspecialchars($lead) . '</p>'
                 . '<div class="muru-reason-code-label">' . htmlspecialchars($label) . '</div>'
                 . '<pre class="muru-reason-code">' . htmlspecialchars($code) . '</pre></div>';
        }
        return '<div class="muru-reason-block"><p>' . htmlspecialchars($reason) . '</p></div>';
    }

    /** A short, single-line summary for the table row (full detail lives in the modal). */
    public static function shortReasonLabel(array $reasonsList): string
    {
        if (empty($reasonsList)) return '';
        $first = preg_replace('/\s*(Matched code:|Offending code:|Preview:).*$/s', '', $reasonsList[0]);
        $first = trim($first);
        if (strlen($first) > 90) $first = substr($first, 0, 90) . '…';
        $extra = count($reasonsList) - 1;
        return $extra > 0 ? "{$first} (+{$extra} more)" : $first;
    }

    /**
     * Surgically strips known XSS injection markers out of a Joomla menu
     * "params" JSON blob, preserving every other legitimate setting.
     *
     * Handles two shapes of nested value:
     *  1. A string that itself decodes as valid JSON (Helix Ultimate stores
     *     layout data as JSON-encoded strings, sometimes nested several
     *     levels deep) -- these are recursed into normally.
     *  2. A string that LOOKS like it was meant to be a JSON container
     *     (starts with '{' or '[') but FAILS to json_decode -- this happens
     *     when the attacker's own injected payload contains an unescaped
     *     quote that breaks JSON syntax. This is handled by
     *     regexStripMalformed(), which now ALSO applies a fail-safe:
     *     after targeted removal, if any signature still matches (or the
     *     tell-tale "(function(){'use strict'" scaffold survives), the
     *     entire value is blanked rather than left as a hollowed-out but
     *     still-present script skeleton.
     *
     * item_id is enforced as a plain integer unconditionally when reached
     * as a proper leaf (not gated behind pattern matching).
     */
    public static function cleanMenuParamsXss(string $paramsJson, array $patterns): array
    {
        $decoded = json_decode($paramsJson, true);
        if ($decoded === null && trim($paramsJson) !== 'null') {
            return ['cleaned' => $paramsJson, 'changed' => false];
        }
        $changed = false;

        $sanitizeLeaf = function (string $key, string $value) use ($patterns, &$changed): string {
            if (strcasecmp($key, 'item_id') === 0) {
                if (preg_match('/^\d+$/', trim($value))) return $value;
                $changed = true;
                return '';
            }

            $hit = false;
            foreach ($patterns as $re) { if (preg_match($re, $value)) { $hit = true; break; } }
            if (!$hit) return $value;
            $changed = true;

            $clean = $value;
            $clean = preg_replace('/<script\b[^>]*>.*?<\/script\s*>/is', '', $clean);
            $clean = preg_replace('/<img\b[^>]*>/is', '', $clean);
            $clean = preg_replace('/\bon[a-z]+\s*=\s*(".*?"|\'.*?\'|[^\s>]+)/is', '', $clean);
            $clean = preg_replace('/javascript\s*:/i', '', $clean);
            $clean = preg_replace('/localStorage\s*\.\s*(setItem|getItem)\s*\([^)]*\)/i', '', $clean);
            $clean = preg_replace('/sessionStorage\s*\.\s*(setItem|getItem)\s*\([^)]*\)/i', '', $clean);
            $clean = preg_replace('/MutationObserver/i', '', $clean);
            $clean = preg_replace('/xss\.report[^\s\'"<>]*/i', '', $clean);
            $clean = preg_replace('/_hu_?inject[^\s\'"<>]*/i', '', $clean);
            $clean = preg_replace('/document\s*\.\s*createElement\s*\(\s*[\'"]script[\'"]\s*\)/i', '', $clean);

            foreach ($patterns as $re) {
                if (preg_match($re, $clean)) return '';
            }
            if (preg_match('/\(\s*function\s*\(\s*\)\s*\{/i', $clean)) {
                return '';
            }
            return $clean;
        };

        // For strings that look like a JSON container but fail to parse --
        // regex-strip the malicious content directly instead of discarding
        // the whole field, with a fail-safe blank-out if residue survives.
        $regexStripMalformed = function (string $raw) use ($patterns, &$changed): string {
            $hit = false;
            foreach ($patterns as $re) { if (preg_match($re, $raw)) { $hit = true; break; } }
            if (!$hit) return $raw;
            $changed = true;

            // Blank any item_id value outright -- these should only ever
            // hold a plain numeric module/item ID, never markup or script.
            $raw = preg_replace('/"item_id"\s*:\s*"(?:[^"\\\\]|\\\\.)*"/is', '"item_id":""', $raw);

            // Targeted removal pass.
            $raw = preg_replace('/<script\b[^>]*>.*?<\/script\s*>/is', '', $raw);
            $raw = preg_replace('/<img\b[^>]*>/is', '', $raw);
            $raw = preg_replace('/\bon[a-z]+\s*=\s*(".*?"|\'.*?\'|[^\s>]+|`[^`]*`)/is', '', $raw);
            $raw = preg_replace('/javascript\s*:/i', '', $raw);
            $raw = preg_replace('/localStorage\s*\.\s*(setItem|getItem)\s*\([^)]*\)/i', '', $raw);
            $raw = preg_replace('/sessionStorage\s*\.\s*(setItem|getItem)\s*\([^)]*\)/i', '', $raw);
            $raw = preg_replace('/MutationObserver/i', '', $raw);
            $raw = preg_replace('/xss\.report[^\s\'"<>`]*/i', '', $raw);
            $raw = preg_replace('/_hu_?inject[^\s\'"<>`]*/i', '', $raw);
            $raw = preg_replace('/document\s*\.\s*createElement\s*\(\s*[\'"]script[\'"]\s*\)/i', '', $raw);

            // Fail-safe: targeted removal only deletes the specific tokens
            // matched above, but attacker payloads come in endless variants
            // (different function/variable names, different wrapper shape).
            // If ANY signature still matches after the targeted pass -- or
            // the tell-tale "(function(){'use strict'" scaffold is still
            // present -- the remaining text is unresolved malicious residue,
            // not a false positive. Blank the whole value rather than ship
            // a hollowed-out-but-still-present script skeleton.
            $stillDangerous = false;
            foreach ($patterns as $re) {
                if (preg_match($re, $raw)) { $stillDangerous = true; break; }
            }
            if (!$stillDangerous && preg_match('/\(\s*function\s*\(\s*\)\s*\{/i', $raw)) {
                $stillDangerous = true;
            }
            if ($stillDangerous) {
                return '';
            }

            return $raw;
        };

        $walk = function (&$node, $key = '') use (&$walk, &$sanitizeLeaf, &$regexStripMalformed) {
            if (is_array($node)) {
                foreach ($node as $k => &$v) { $walk($v, is_string($k) ? $k : $key); }
                unset($v);
                return;
            }
            if (!is_string($node)) return;

            $inner = json_decode($node, true);
            if (is_array($inner)) {
                $walk($inner, $key);
                $node = json_encode($inner, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                return;
            }

            $trimmed = ltrim($node);
            if ($trimmed !== '' && ($trimmed[0] === '{' || $trimmed[0] === '[')) {
                // Looks like it was meant to be a JSON container but the
                // attacker's own malformed escaping broke it. Regex-strip
                // instead of nuking the whole field.
                $node = $regexStripMalformed($node);
                return;
            }

            $node = $sanitizeLeaf($key, $node);
        };

        $walk($decoded);

        if (!$changed) return ['cleaned' => $paramsJson, 'changed' => false];
        return ['cleaned' => json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), 'changed' => true];
    }

    /**
     * Read-only .htaccess hardening advisor -- reads the site's actual
     * root .htaccess (if any) and checks it against a fixed set of
     * recommended directives, most directly relevant to what this
     * scanner exists to catch: PHP execution inside writable upload-style
     * directories is exactly how a dropped webshell gets run in the
     * first place, so blocking it at the web-server level is a strong,
     * independent layer even if a malicious file is never cleaned up.
     * Deliberately NEVER writes to .htaccess itself -- this only reports
     * what's missing and shows the suggested rule text for the admin to
     * add by hand, since a wrong edit to this specific file can 500 the
     * entire site and there's no reliable way to test a rewrite rule
     * server-side before it's live.
     *
     * Each check's regex is intentionally loose (matches the INTENT of a
     * directive, not one exact phrasing) to avoid a false "missing"
     * result against a site that already has equivalent protection
     * worded differently -- a false negative here just means a
     * redundant suggestion, which is far less harmful than repeatedly
     * telling an admin who already handled something that they haven't.
     *
     * @return array{
     *   exists: bool,
     *   path: string,
     *   checks: list<array{id:string,category:string,severity:string,label:string,present:bool,explanation:string,suggestion:string}>
     * }
     */
    public static function getHtaccessSuggestions(string $root): array
    {
        $path = $root . '/.htaccess';
        $exists = is_file($path);
        $contents = $exists ? (string) @file_get_contents($path) : '';

        $has = function (string $re) use ($contents): bool {
            return (bool) preg_match($re, $contents);
        };

        $checks = [];

        // 1. PHP/executable execution blocked inside writable upload-style
        // directories -- the single most directly relevant check this
        // tool can make: every real webshell drop this scanner detects
        // still runs the moment it's requested unless the server itself
        // refuses to execute PHP there.
        $blocksExecution = $has('/RewriteRule[^\n]*\[[^\]]*F[^\]]*\]/i')
            || $has('/<FilesMatch[^>]*php[^>]*>\s*(?:\r?\n)+\s*(?:Require\s+all\s+denied|Deny\s+from\s+all)/is');
        $mentionsUploadDir = $has('/\b(media|images|uploads|tmp|cache)\b/i');
        $checks[] = [
            'id' => 'block_php_in_uploads',
            'category' => 'critical',
            'severity' => 'high',
            'label' => 'Block PHP execution inside upload/writable directories',
            'present' => $blocksExecution && $mentionsUploadDir,
            'explanation' => 'A webshell dropped into a normally-writable folder (media, images, uploads, tmp, cache, ...) still runs the moment it\'s requested unless Apache itself refuses to execute PHP there -- this blocks it at the server level even before this scanner ever gets a chance to find and remove the file.',
            'suggestion' => "<IfModule mod_rewrite.c>\n    RewriteEngine On\n    RewriteCond %{REQUEST_URI} ^/(media|images|uploads|tmp|cache|files)/ [NC]\n    RewriteCond %{REQUEST_URI} \\.(php|phtml|phar|php[0-9]|pht)\$ [NC]\n    RewriteRule .* - [F,L]\n</IfModule>",
        ];

        // 2. Directory listing disabled.
        $checks[] = [
            'id' => 'disable_indexes',
            'category' => 'critical',
            'severity' => 'medium',
            'label' => 'Disable directory listing',
            'present' => $has('/Options\s+[^\n]*-Indexes/i') || $has('/IndexIgnore\s+\*/i'),
            'explanation' => 'Without this, browsing directly to a folder with no index file (e.g. an upload directory) lists every file in it -- handing an attacker a directory of exactly what to try requesting, and revealing dropped files that were otherwise hidden.',
            'suggestion' => "Options -Indexes",
        ];

        // 3. Sensitive files/dotfiles blocked from direct web access --
        // .env, .git internals, composer manifests, and backup/log files
        // can leak credentials or source layout if requested directly.
        $checks[] = [
            'id' => 'block_sensitive_files',
            'category' => 'critical',
            'severity' => 'medium',
            'label' => 'Block direct access to sensitive/dotfiles',
            'present' => $has('/<FilesMatch[^>]*\\\\\.(?:env|git|bak|sql)[^>]*>/i') || $has('/RewriteRule[^\n]*\\\\.(?:env|git)/i'),
            'explanation' => 'A .env file, .git directory, composer.lock, or a stray .sql/.bak backup sitting in the webroot can leak database credentials or the exact software versions in use if it\'s ever requested directly -- none of this is meant to be served over HTTP at all.',
            'suggestion' => "<FilesMatch \"(?i)(\\.env|\\.git.*|composer\\.(json|lock)|.*\\.sql|.*\\.bak)\$\">\n    Require all denied\n</FilesMatch>",
        ];

        // 4. X-Content-Type-Options.
        $checks[] = [
            'id' => 'header_nosniff',
            'category' => 'header',
            'severity' => 'low',
            'label' => 'X-Content-Type-Options: nosniff',
            'present' => $has('/X-Content-Type-Options/i'),
            'explanation' => 'Stops browsers from guessing ("sniffing") a file\'s type from its content instead of trusting the server\'s declared Content-Type -- closes off one way a maliciously-crafted upload can be tricked into executing as something other than what it was uploaded as.',
            'suggestion' => "<IfModule mod_headers.c>\n    Header always set X-Content-Type-Options \"nosniff\"\n</IfModule>",
        ];

        // 5. Permissions-Policy.
        $checks[] = [
            'id' => 'header_permissions_policy',
            'category' => 'header',
            'severity' => 'low',
            'label' => 'Permissions-Policy (restrictive baseline)',
            'present' => $has('/Permissions-Policy/i'),
            'explanation' => 'Disables browser features (camera, microphone, geolocation, payment, ...) this site has no legitimate reason to use, so an injected script can\'t invoke them even if one ever makes it onto the page.',
            'suggestion' => "<IfModule mod_headers.c>\n    Header always set Permissions-Policy \"geolocation=(), microphone=(), camera=(), payment=()\"\n</IfModule>",
        ];

        // 6. HSTS -- only actually meaningful (and safe to suggest) once
        // the site is already serving over HTTPS; suggesting it on a
        // plain-HTTP site would be premature and confusing.
        $isHttps = Uri::getInstance()->isSsl();
        $checks[] = [
            'id' => 'header_hsts',
            'category' => 'header',
            'severity' => 'low',
            'label' => 'Strict-Transport-Security (HSTS)',
            'present' => !$isHttps || $has('/Strict-Transport-Security/i'),
            'explanation' => $isHttps
                ? 'Tells browsers to always use HTTPS for this domain from now on, even if a user types or clicks a plain http:// link -- closes the window an attacker gets from a single unencrypted request.'
                : 'Not applicable yet -- this site isn\'t currently being served over HTTPS. Set up SSL first; adding this header before then would have no effect.',
            'suggestion' => "<IfModule mod_headers.c>\n    Header always set Strict-Transport-Security \"max-age=31536000; includeSubDomains\" env=HTTPS\n</IfModule>",
        ];

        // 7. CSP -- deliberately advisory-only with a strong caveat: a
        // misconfigured Content-Security-Policy can break legitimate site
        // functionality (many Joomla extensions rely on inline scripts),
        // so this is never treated as a "problem" the way the checks
        // above are, only offered as an optional next step.
        $checks[] = [
            'id' => 'header_csp',
            'category' => 'header',
            'severity' => 'info',
            'label' => 'Content-Security-Policy (advisory -- test before enabling)',
            'present' => $has('/Content-Security-Policy/i'),
            'explanation' => 'Restricts which sources scripts/styles/etc. can load from, meaningfully raising the bar against injected/XSS content actually executing. Test thoroughly before enabling on a live site -- an overly strict policy can silently break legitimate extension or template functionality, and \'unsafe-inline\'/\'unsafe-eval\' (often required for older Joomla extensions to keep working) meaningfully weakens the protection this header is meant to provide.',
            'suggestion' => "<IfModule mod_headers.c>\n    Header always set Content-Security-Policy \"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';\"\n</IfModule>",
        ];

        return ['exists' => $exists, 'path' => $path, 'checks' => $checks];
    }
}