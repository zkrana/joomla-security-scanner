<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     MIT
 */

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Component\ComponentHelper;

class MuruguardControllerScanner extends BaseController
{
    /**
     * Bulk selection forms (delete/clean actions) submit one checkbox per
     * row -- a large scan result (thousands of flagged files, or hundreds
     * of junk #__template_styles rows) can trip PHP's default
     * max_input_vars (1000) well before Joomla even gets a chance to look
     * at the request, silently truncating the POST body. Depending on
     * where in the field order the truncation lands, this can drop the
     * CSRF token field itself, surfacing as a confusing "invalid security
     * token" error that has nothing to do with the token actually being
     * wrong. The view's JS now consolidates every checked checkbox into a
     * single JSON-encoded hidden field (see muruConsolidateCheckboxes() in
     * default.php) BEFORE submit, so the request carries one field
     * regardless of how many rows are selected. This reads that field
     * first and only falls back to the legacy one-field-per-row array
     * (still emitted by the raw HTML for no-JS resilience) when it's
     * absent or invalid, so old cached page loads / JS-disabled browsers
     * still work exactly as before, just with the original scaling limit.
     */
    private function getBulkField(string $jsonName, string $arrayName): array
    {
        $input = Factory::getApplication()->input;
        $json  = $input->post->get($jsonName, '', 'raw');
        if ($json !== '') {
            $decoded = json_decode($json, true);
            if (is_array($decoded)) {
                return array_values(array_map('strval', $decoded));
            }
        }
        return $input->post->get($arrayName, [], 'array');
    }

    /**
     * Triggered by the "Run Scan" and "Re-scan" forms.
     * Runs the full filesystem + DB scan, stores results in the session,
     * then redirects back to the display view so the URL stays clean.
     */
public function scan()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));

        $app    = Factory::getApplication();
        $input  = $app->input;

        // Large sites (many extensions, big vendor/ trees) can genuinely
        // take longer than a host's default max_execution_time to scan.
        // Try to raise both -- @-suppressed because some hosts disable
        // ini_set entirely, in which case this silently no-ops rather
        // than fatal-ing on its own. Note this is a best-effort request,
        // not a guarantee: some hosts lock memory_limit at the php.ini/
        // SAPI level (common with suPHP or certain FastCGI pools), where
        // ini_set() silently returns without actually changing anything
        // -- if a site is still hitting OOM at exactly PHP's 128M default
        // despite this call, that's the signal it's happening, and the
        // real fix has to happen in that host's php.ini/.user.ini, not
        // in this component.
        // set_time_limit() throws an uncaught fatal Error (not a suppressible
        // warning) when the function itself is listed in disable_functions --
        // @ does not protect against that, so it must be guarded explicitly.
        if (function_exists('set_time_limit')) {
            @set_time_limit(300);
        }
        @ini_set('memory_limit', '512M');

        // Suppress PHP deprecation/notice/warning-level reporting for the
        // duration of the scan -- a large site's Global Configuration
        // Error Reporting can be set high enough that Joomla's own error
        // handler logs every PHP notice/deprecation via Log::add(), and
        // each LogEntry captures a full debug_backtrace(). A scan walks
        // thousands of files; if even one line anywhere in that path
        // trips a deprecation notice per iteration, that's thousands of
        // backtrace-carrying log entries accumulating in memory over the
        // course of one request -- a real, confirmed contributor to an
        // OOM crash on a run that otherwise completes fine. A security
        // scan has no need for PHP-level deprecation notices to be
        // logged at all. Restored in a finally so a later action in the
        // same request (there isn't one here, but as a matter of
        // discipline) never inherits a suppressed error level.
        $previousErrorReporting = error_reporting(E_ERROR | E_PARSE);

        // Persist the directory picker selection so both this scan and the
        // cached-result re-display honour it. Only overwrite when the gate
        // form actually submitted the picker (the "Re-scan now" button does
        // not, so it reuses the previous selection). An empty selection is
        // treated as "scan everything".
        if ($input->post->get('areas_submitted', 0, 'int') === 1) {
            $areas = $input->post->get('scan_areas', [], 'array');
            $areas = array_values(array_map('strval', $areas));
            $app->getSession()->set('muruguard.scan_areas', $areas);
        }

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        try {
            $model->runScan();
        } catch (\Throwable $e) {
            // Don't let a mid-scan failure produce a raw 500 -- redirect
            // back with a clear message instead, so the user gets a
            // working page (and a fresh CSRF token) rather than a dead end.
            $app->enqueueMessage(
                Text::sprintf('COM_MURUGUARD_SCAN_FAILED_MSG', $e->getMessage()),
                'error'
            );
            $this->setRedirect('index.php?option=com_muruguard');
            error_reporting($previousErrorReporting);
            return;
        }

        // Pro: Fleet Dashboard -- keeps "last scan" accurate for manual
        // scans too, not just scheduled ones. Same best-effort, never-
        // throws call as the scheduled check uses.
        $cfgParamsForFleet = ComponentHelper::getParams('com_muruguard');
        if (\MuruguardAiHelper::isProLicenseActive() && (bool) $cfgParamsForFleet->get('fleet_reporting_enabled', 0)) {
            $this->reportFleetStatus($model);
        }

        error_reporting($previousErrorReporting);
        $this->setRedirect('index.php?option=com_muruguard');
    }

    /**
     * AJAX/JSON chunk endpoint backing the "Run a Scan" progress bar (see
     * the scanner-form JS in tmpl/default.php). Each call does at most
     * CHUNK_TIME_BUDGET_SECONDS of work and returns -- the JS keeps calling
     * this until it reports done, at which point the results are already
     * sitting in the session exactly as if scan() above had produced them,
     * and the page does a normal reload to show them. This is what makes a
     * large site's scan safe regardless of the host's execution-time
     * limit: no single request here can run long enough to hit it.
     *
     * Same CSRF/token handling as every other action in this controller --
     * checkToken()'s default 'post' mode is correct because the token
     * travels as a normal POST field, same as a form submit.
     */
    public function scanchunk()
    {
        $app = Factory::getApplication();

        if (!Session::checkToken()) {
            $this->jsonResponse(['error' => Text::_('JINVALID_TOKEN')], 403);
        }

        $input = $app->input;
        $reset = $input->post->getBool('reset', false);

        // Same area-selection persistence scan() does, only on the call
        // that actually starts a fresh run -- follow-up chunk calls for
        // the same run don't resubmit the picker, they just keep going.
        if ($reset && $input->post->get('areas_submitted', 0, 'int') === 1) {
            $areas = $input->post->get('scan_areas', [], 'array');
            $areas = array_values(array_map('strval', $areas));
            $app->getSession()->set('muruguard.scan_areas', $areas);
        }

        // Same deprecation/notice suppression scan() uses, and for the same
        // reason -- kept even though a single chunk covers far fewer files,
        // since a pathologically large single directory can still walk
        // enough files in one chunk to matter.
        $previousErrorReporting = error_reporting(E_ERROR | E_PARSE);

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        try {
            $status = $model->runScanChunk($reset);
        } catch (\Throwable $e) {
            error_reporting($previousErrorReporting);
            $this->jsonResponse(['error' => $e->getMessage()], 500);
        }

        error_reporting($previousErrorReporting);

        if ($status['done']) {
            // Pro: Fleet Dashboard -- same best-effort, never-throws hook
            // scan() calls after a normal (unchunked) run, so a chunked
            // scan keeps a licensed site's Fleet status just as current.
            $cfgParamsForFleet = ComponentHelper::getParams('com_muruguard');
            if (\MuruguardAiHelper::isProLicenseActive() && (bool) $cfgParamsForFleet->get('fleet_reporting_enabled', 0)) {
                $this->reportFleetStatus($model);
            }
        }

        $status['currentAreaLabel'] = $status['currentArea'] !== null
            ? \MuruguardHelper::getChunkAreaLabel($status['currentArea'])
            : null;
        $status['truncatedLabels'] = array_map(
            [\MuruguardHelper::class, 'getChunkAreaLabel'],
            $status['truncated']
        );

        $this->jsonResponse($status, 200);
    }

    /**
     * AJAX/JSON endpoints backing File Integrity Monitoring (Pro): baseline
     * build and drift check both reuse the exact same chunked-request
     * pattern as scanchunk() above, for the same reason -- hashing a
     * genuinely large site can't safely happen inside one HTTP request
     * either. See MuruguardModelScanner's FIM section for the actual
     * hashing/comparison logic; this layer is just license-gating, CSRF,
     * and JSON transport.
     */
    public function fimbuildchunk()
    {
        if (!Session::checkToken()) {
            $this->jsonResponse(['error' => Text::_('JINVALID_TOKEN')], 403);
        }
        \MuruguardHelper::requireAdminAccess();
        if (!\MuruguardAiHelper::isProLicenseActive()) {
            $this->jsonResponse(['error' => 'license_required'], 402);
        }

        $reset = Factory::getApplication()->input->post->getBool('reset', false);

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        try {
            $status = $model->runFimBuildChunk($reset);
        } catch (\Throwable $e) {
            $this->jsonResponse(['error' => $e->getMessage()], 500);
        }

        $status['currentAreaLabel'] = $status['currentArea'] !== null
            ? \MuruguardHelper::getChunkAreaLabel($status['currentArea'])
            : null;

        $this->jsonResponse($status, 200);
    }

    public function fimcheckchunk()
    {
        if (!Session::checkToken()) {
            $this->jsonResponse(['error' => Text::_('JINVALID_TOKEN')], 403);
        }
        \MuruguardHelper::requireAdminAccess();
        if (!\MuruguardAiHelper::isProLicenseActive()) {
            $this->jsonResponse(['error' => 'license_required'], 402);
        }

        $reset = Factory::getApplication()->input->post->getBool('reset', false);

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        try {
            $status = $model->runFimCheckChunk($reset);
        } catch (\Throwable $e) {
            $this->jsonResponse(['error' => $e->getMessage()], 500);
        }

        $status['currentAreaLabel'] = $status['currentArea'] !== null
            ? \MuruguardHelper::getChunkAreaLabel($status['currentArea'])
            : null;

        $this->jsonResponse($status, 200);
    }

    /**
     * Clears the cached scan result so the directory picker (scan gate)
     * reappears, keeping the previous selection pre-ticked.
     */
    public function reset()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));

        $session = Factory::getApplication()->getSession();
        $session->set('muruguard.filefindings', null);
        $session->set('muruguard.filefindings_time', 0);

        $this->setRedirect('index.php?option=com_muruguard');
    }

    /**
     * Delete selected flagged files/folders.
     */
    public function delete()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireDeleteAccess();

        $app     = Factory::getApplication();
        $targets = $this->getBulkField('targets_json', 'targets');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $flash = $model->deleteTargets($targets);

        $app->enqueueMessage('<pre>' . implode("\n", array_map('htmlspecialchars', $flash)) . '</pre>', 'info');
        $this->setRedirect('index.php?option=com_muruguard');
    }

    /**
     * Surgically clean selected flagged files instead of deleting them --
     * for a legitimate core/template file (index.php, administrator's own
     * index.php, a template's root index.php, a core library file, ...)
     * that has been infected, this strips just the injected code and
     * keeps the file in place, since deleting it would break the site.
     */
    public function cleancode()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireEditAccess();

        $app     = Factory::getApplication();
        $targets = $this->getBulkField('targets_json', 'targets');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $flash = $model->cleanCodeFiles($targets);

        $combined = implode("\n", $flash);
        $type = 'message';
        if (stripos($combined, 'FAILED') !== false || stripos($combined, 'WARNING') !== false) {
            $type = 'error';
        } elseif (stripos($combined, 'SKIPPED') !== false) {
            $type = 'warning';
        }

        $app->enqueueMessage('<pre>' . implode("\n", array_map('htmlspecialchars', $flash)) . '</pre>', $type);
        $this->setRedirect('index.php?option=com_muruguard');
    }

    /**
     * Surgically clean XSS from selected #__menu rows.
     */
    public function cleanmenu()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireEditAccess();

        $app = Factory::getApplication();
        $ids = $this->getBulkField('menu_xss_ids_json', 'menu_xss_ids');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $flash = $model->cleanMenuXss($ids);

        $app->enqueueMessage('<pre>' . implode("\n", array_map('htmlspecialchars', $flash)) . '</pre>', 'info');
        $this->setRedirect('index.php?option=com_muruguard');
    }

    /**
     * Surgically clean XSS from selected #__template_styles rows (a
     * template's Custom JavaScript/Custom CSS fields).
     */
    public function cleantemplatestylexss()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireEditAccess();

        $app = Factory::getApplication();
        $ids = $this->getBulkField('template_style_xss_ids_json', 'template_style_xss_ids');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $flash = $model->cleanTemplateStyleXss($ids);

        $app->enqueueMessage('<pre>' . implode("\n", array_map('htmlspecialchars', $flash)) . '</pre>', 'info');
        $this->setRedirect('index.php?option=com_muruguard');
    }

    /**
     * Delete selected rogue iconfont rows from #__sppagebuilder_assets.
     */
    public function deleteassets()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireDeleteAccess();

        $app = Factory::getApplication();
        $ids = $this->getBulkField('rogue_asset_ids_json', 'rogue_asset_ids');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->deleteRogueAssets($ids);

        $app->enqueueMessage(Text::_('COM_MURUGUARD_ASSETS_DELETED_MSG'), 'message');
        $this->setRedirect('index.php?option=com_muruguard');
    }

    /**
     * Deletes selected #__template_styles rows that MuruguardModelScanner::
     * cleanTemplateDefacement() independently confirms as junk/injected.
     * Rows flagged only for defacement text are left for manual review --
     * see that method's docblock for why.
     */
    public function cleantemplatedefacement()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireDeleteAccess();

        $app = Factory::getApplication();
        $ids = $this->getBulkField('template_defacement_ids_json', 'template_defacement_ids');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $flash = $model->cleanTemplateDefacement($ids);

        $app->enqueueMessage('<pre>' . implode("\n", array_map('htmlspecialchars', $flash)) . '</pre>', 'info');
        $this->setRedirect('index.php?option=com_muruguard');
    }

    /**
     * Webcron entry point for scheduled scanning -- reached as
     * administrator/index.php?option=com_muruguard&task=scanner.scheduledcheck&token=...
     * so any cron system (server crontab via curl/wget, a host's Cron
     * Jobs control panel, or a free external cron service) can trigger a
     * scan without a logged-in admin session. There is deliberately no
     * Session::checkToken()/requireManageAccess() call here -- a cron
     * request has no Joomla session or CSRF token to present -- auth is
     * instead a shared secret (COM_MURUGUARD_CONFIG_CRON_TOKEN) compared
     * with hash_equals(), gated behind an explicit master switch
     * (COM_MURUGUARD_CONFIG_CRON_ENABLED) so disabling it doesn't require
     * clearing/losing the configured token and email. NEVER accepted when
     * the switch is off or either side of the token is empty, so
     * scheduled scanning is off by default.
     *
     * Responds with plain text (not the admin HTML template) and exits
     * immediately, matching how a cron/curl caller expects a response.
     */
    public function scheduledcheck()
    {
        $app = Factory::getApplication();
        $params = ComponentHelper::getParams('com_muruguard');
        $cronEnabled = (bool) $params->get('cron_enabled', 0);
        $configuredToken = trim((string) $params->get('cron_token', ''));
        $suppliedToken = (string) $app->input->getString('token', '');

        header('Content-Type: text/plain; charset=utf-8');

        if (!$cronEnabled || $configuredToken === '' || $suppliedToken === '' || !hash_equals($configuredToken, $suppliedToken)) {
            http_response_code(403);
            echo "Forbidden\n";
            $app->close();
        }

        // A full unchunked scanFilesystem()+scanDatabase() pass, now
        // possibly followed by one or more real AI verification calls
        // (Autopilot Mode, each up to 60s -- see runAutopilotPass()), can
        // genuinely exceed PHP's stock 30s/128M defaults on a real site
        // with a non-trivial extension count -- unlike a browser-driven
        // scan, nothing is waiting on this response, so a generous
        // ceiling costs nothing. Same pattern already used by
        // bulkaicheck() above, just larger: this is the one call site
        // that can legitimately run the longest (whole-site scan +
        // multiple AI round-trips in one request, no per-chunk budget).
        if (function_exists('set_time_limit')) {
            @set_time_limit(600);
        }
        @ini_set('memory_limit', '512M');

        // Constructed directly rather than via $this->getModel('Scanner') --
        // this action is also reached through plg_muruguardshield's
        // onAjaxMuruguardshield() bridge (see that method's own docblock
        // for why the bridge exists at all), which instantiates this
        // exact controller manually, outside Joomla's normal component
        // dispatch. BaseController::getModel() resolves through the
        // legacy MVC factory, which needs component context
        // (base_path/prefix wiring) that only Joomla's own dispatcher
        // sets up -- confirmed empirically that it silently returns
        // false when this controller is constructed manually, which then
        // crashed PHP-FPM outright calling a method on that false rather
        // than throwing a catchable error. A direct `new` has no such
        // dependency and works identically either way.
        /** @var MuruguardModelScanner $model */
        $model = new MuruguardModelScanner();
        $result = $model->runScheduledCheck();

        // Autopilot (Pro) removes some findings from $result['newFindings']/
        // newCount entirely before this point (see runScheduledCheck()) --
        // a run where autopilot fixed everything new would otherwise have
        // newCount=0 and silently never notify anyone that anything
        // happened at all. hasNews covers both: something still needs a
        // human, or autopilot already acted and the admin should know.
        $autopilotFixedCount = (int) ($result['autopilotFixed'] ?? 0);
        $hasNews = $result['newCount'] > 0 || $autopilotFixedCount > 0;

        $alertEmail = trim((string) $params->get('alert_email', ''));
        $emailed = false;
        if (!$result['isFirstRun'] && $hasNews && $alertEmail !== '') {
            $emailed = $this->sendScheduledAlertEmail($alertEmail, $result['newFindings'], $result['newCount'], $autopilotFixedCount);
        }

        // Pro: Alert Channels -- same "only when there's something new to
        // say" gate as the email alert above, just fanned out to whichever
        // webhook channels are configured and enabled.
        $webhooksSent = 0;
        if (\MuruguardAiHelper::isProLicenseActive() && !$result['isFirstRun'] && $hasNews) {
            $webhooksSent = $this->sendScheduledAlertWebhooks($params, $result['newFindings'], $result['newCount'], $autopilotFixedCount);
        }

        // Pro: Fleet Dashboard -- reports a status SUMMARY only (counts +
        // booleans), never the findings themselves. Fires on every
        // scheduled check regardless of whether anything new was found,
        // so "last scan" stays accurate on the fleet dashboard even on a
        // clean run.
        if (\MuruguardAiHelper::isProLicenseActive() && (bool) $params->get('fleet_reporting_enabled', 0)) {
            $this->reportFleetStatus($model);
        }

        // Periodic homepage watch -- deliberately independent of the
        // full scan above: runs every time this action is hit (on
        // whatever schedule the admin's own real cron is set to),
        // regardless of newCount/isFirstRun, and only ever alerts on an
        // actual state TRANSITION (see runHomepageWatch()'s own
        // docblock) -- not on every single cron hit for a condition
        // that's already been reported once.
        $homepageWatchChange = null;
        if ((bool) $params->get('homepage_watch_enabled', 0)) {
            try {
                $homepageWatchChange = $model->runHomepageWatch();
                if ($homepageWatchChange !== null && $alertEmail !== '') {
                    $this->sendHomepageWatchAlertEmail($alertEmail, $homepageWatchChange);
                }
            } catch (\Throwable $e) {
                // Never let the homepage watch itself break the scheduled check response.
            }
        }

        $status = $result['isFirstRun'] ? 'baseline recorded' : 'ok';
        echo "MuRu Guard: {$status}, total={$result['totalCount']} new={$result['newCount']} emailed=" . ($emailed ? 'yes' : 'no') . " webhooks={$webhooksSent} homepageWatch=" . ($homepageWatchChange !== null ? 'changed' : 'unchanged') . "\n";
        $app->close();
    }

    /**
     * Sends the homepage-watch state-transition alert -- a small,
     * separate email from sendScheduledAlertEmail() below since this is
     * never about a set of file/DB findings, just one plain-language
     * sentence describing what changed (site down/up, defaced/clean,
     * SEO-spam/clean). Never throws -- same reasoning as every other
     * scheduled-check mail send.
     */
    private function sendHomepageWatchAlertEmail(string $to, string $change): bool
    {
        try {
            $app = Factory::getApplication();
            $siteName = (string) $app->get('sitename', 'your Joomla site');
            $mailer = Factory::getMailer();
            $mailer->setSender([$app->get('mailfrom'), $app->get('fromname')]);
            $mailer->addRecipient($to);
            $mailer->setSubject("[MuRu Guard] Homepage watch: {$siteName}");
            $mailer->isHtml(false);
            $mailer->setBody("MuRu Guard's homepage watch detected a change on {$siteName}:\n\n{$change}\n\n" . \Joomla\CMS\Uri\Uri::root() . 'administrator/index.php?option=com_muruguard');
            return (bool) $mailer->Send();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Sends the "new findings since last scheduled check" alert email.
     * Never throws -- a mail-transport failure shouldn't turn a
     * successful scan into a confusing error response for the cron
     * caller, it should just report emailed=no in the plain-text status.
     */
    private function sendScheduledAlertEmail(string $to, array $newFindings, int $newCount, int $autopilotFixedCount = 0): bool
    {
        $app = Factory::getApplication();
        $siteName = (string) $app->get('sitename', 'your Joomla site');
        $adminUrl = \Joomla\CMS\Uri\Uri::root() . 'administrator/index.php?option=com_muruguard';
        $subjectBits = [];
        if ($newCount > 0) $subjectBits[] = "{$newCount} new suspicious finding" . ($newCount === 1 ? '' : 's');
        if ($autopilotFixedCount > 0) $subjectBits[] = "{$autopilotFixedCount} auto-fixed by Autopilot";
        $subject = '[MuRu Guard] ' . implode(', ', $subjectBits) . " on {$siteName}";

        // Plain-text alternative (PHPMailer's AltBody) -- shown by clients
        // that can't/won't render HTML, and by spam filters that weigh a
        // missing text part negatively.
        $textLines = [];
        if ($autopilotFixedCount > 0) {
            $textLines[] = "Autopilot Mode automatically removed {$autopilotFixedCount} file" . ($autopilotFixedCount === 1 ? '' : 's') . " it and the AI Assistant both independently confirmed were malicious. Every removal was snapshotted first and can be restored from Settings > Backup & Restore: {$adminUrl}&view_panel=settings&settings_tab=backup";
            $textLines[] = '';
        }
        if ($newCount > 0) {
            $textLines[] = "MuRu Guard found {$newCount} new suspicious file finding" . ($newCount === 1 ? '' : 's') . " since the last scheduled check on {$siteName} that still need your review.";
            $textLines[] = '';
        }
        $shown = 0;
        foreach ($newFindings as $rel => $f) {
            if (++$shown > 25) {
                $textLines[] = '… and ' . ($newCount - 25) . ' more -- see the full list in Components > MuRu Guard.';
                break;
            }
            $textLines[] = "- [{$f['confidence']}] {$rel}";
            $textLines[] = '  ' . $f['reason'];
        }
        $textLines[] = '';
        $textLines[] = "Review and act on these: {$adminUrl}";
        $textBody = implode("\n", $textLines);

        // Same red/amber high-vs-medium confidence colours as the Pro
        // Security Report (see MuruguardHelper::buildSecurityReportHtml())
        // -- one consistent visual language for every MuRu Guard document,
        // not a third, different-looking template.
        $rows = '';
        $shown = 0;
        foreach ($newFindings as $rel => $f) {
            if (++$shown > 25) {
                $rows .= '<tr><td colspan="2" style="padding:10px;color:#6b7280;font-size:12px;">… and ' . ($newCount - 25) . ' more — see the full list in Components &gt; MuRu Guard.</td></tr>';
                break;
            }
            $isHigh = ($f['confidence'] ?? '') === 'high';
            $badgeBg = $isHigh ? '#fee2e2' : '#fef3c7';
            $badgeFg = $isHigh ? '#991b1b' : '#92400e';
            $badgeLabel = $isHigh ? 'High' : 'Medium';
            $reason = \MuruguardHelper::shortReasonLabel($f['reasons'] ?? [(string) ($f['reason'] ?? '')]);
            $rows .= '<tr>'
                . '<td style="padding:10px;border-bottom:1px solid #f3f4f6;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;color:#111827;word-break:break-all;">' . htmlspecialchars((string) $rel) . '</td>'
                . '<td style="padding:10px;border-bottom:1px solid #f3f4f6;text-align:right;white-space:nowrap;"><span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:10px;font-weight:700;background:' . $badgeBg . ';color:' . $badgeFg . ';">' . $badgeLabel . '</span></td>'
                . '</tr>'
                . '<tr><td colspan="2" style="padding:0 10px 10px;font-size:12px;color:#6b7280;">' . htmlspecialchars($reason) . '</td></tr>';
        }

        $autopilotNoteHtml = '';
        if ($autopilotFixedCount > 0) {
            $restoreUrl = $adminUrl . '&view_panel=settings&settings_tab=backup';
            $autopilotNoteHtml = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;margin:0 0 16px;"><tr><td style="padding:14px 16px;color:#166534;font-size:13px;line-height:20px;">'
                . '🤖 <strong>Autopilot Mode</strong> automatically removed <strong>' . $autopilotFixedCount . '</strong> file' . ($autopilotFixedCount === 1 ? '' : 's') . " it and the AI Assistant both independently confirmed were malicious. Every removal was snapshotted first — <a href=\"{$restoreUrl}\" style=\"color:#166534;\">restore anytime from Backup &amp; Restore</a>."
                . '</td></tr></table>';
        }
        $findingsIntroHtml = $newCount > 0
            ? "<p style=\"margin:0 0 8px;color:#111827;font-size:16px;line-height:26px;\"><strong>{$newCount}</strong> new suspicious file finding{$this->pluralS($newCount)} on <strong>{$siteName}</strong> still need your review.</p>"
            : '';

        $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px;">
    <tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #e5e7eb;">
        <tr><td align="center" style="background:#111827;padding:36px 28px;">
          <div style="color:#ffffff;font-size:22px;font-weight:700;">🛡️ MuRu Guard</div>
          <p style="margin:8px 0 0;color:#9ca3af;font-size:13px;">Scheduled Scan Alert</p>
        </td></tr>
        <tr><td style="padding:32px 28px;">
          {$autopilotNoteHtml}
          {$findingsIntroHtml}
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:20px 0;">
            {$rows}
          </table>
          <table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 4px;">
            <tr><td style="background:#111827;border-radius:10px;">
              <a href="{$adminUrl}" style="display:inline-block;padding:13px 26px;color:#ffffff;text-decoration:none;font-size:15px;font-weight:600;">Review in Admin Panel</a>
            </td></tr>
          </table>
        </td></tr>
        <tr><td align="center" style="padding:20px 28px;background:#f9fafb;border-top:1px solid #e5e7eb;">
          <p style="margin:0;color:#9ca3af;font-size:12px;">Sent by MuRu Guard on {$siteName} &middot; lyzerslab.com</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;

        try {
            $mailer = Factory::getMailer();
            $mailer->setSender([$app->get('mailfrom'), $app->get('fromname')]);
            $mailer->addRecipient($to);
            $mailer->setSubject($subject);
            $mailer->isHtml(true);
            $mailer->setBody($htmlBody);
            $mailer->AltBody = $textBody;
            return (bool) $mailer->Send();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Tiny pluralisation helper -- "1 finding" vs "2 findings" inside the alert email's inline HTML string. */
    private function pluralS(int $n): string
    {
        return $n === 1 ? '' : 's';
    }

    /**
     * Pro: Alert Channels -- fans the same "new findings since last
     * scheduled check" event out to whichever webhook channels the admin
     * has configured and enabled in Settings > Pro Features. Same
     * never-throw, best-effort philosophy as the email alert -- a
     * misconfigured/unreachable webhook must never turn a successful scan
     * into a confusing cron failure. Returns how many channels actually
     * succeeded, purely for the plain-text cron status line.
     */
    private function sendScheduledAlertWebhooks($params, array $newFindings, int $newCount, int $autopilotFixedCount = 0): int
    {
        $app = Factory::getApplication();
        $siteName = (string) $app->get('sitename', 'your Joomla site');
        $siteUrl = \MuruguardHelper::currentSiteDomain();

        $shown = [];
        $i = 0;
        foreach ($newFindings as $rel => $f) {
            if (++$i > 10) { $shown[] = '… and ' . ($newCount - 10) . ' more'; break; }
            $shown[] = "[{$f['confidence']}] {$rel}";
        }
        $lines = ["MuRu Guard: {$siteName} ({$siteUrl})"];
        if ($autopilotFixedCount > 0) {
            $lines[] = "🤖 Autopilot auto-removed {$autopilotFixedCount} AI-confirmed malicious file" . ($autopilotFixedCount === 1 ? '' : 's') . " -- restorable from Backup & Restore.";
        }
        if ($newCount > 0) {
            $lines[] = "{$newCount} new suspicious finding" . ($newCount === 1 ? '' : 's') . " still need review:";
            $lines = array_merge($lines, $shown);
        }
        $summary = implode("\n", $lines);

        $sent = 0;

        if ((bool) $params->get('alert_slack_enabled', 0)) {
            $url = trim((string) $params->get('alert_slack_webhook', ''));
            if ($url !== '' && \MuruguardHelper::postWebhook($url, ['text' => $summary])) $sent++;
        }

        if ((bool) $params->get('alert_discord_enabled', 0)) {
            $url = trim((string) $params->get('alert_discord_webhook', ''));
            if ($url !== '' && \MuruguardHelper::postWebhook($url, ['content' => $summary])) $sent++;
        }

        if ((bool) $params->get('alert_telegram_enabled', 0)) {
            $botToken = trim((string) $params->get('alert_telegram_bot_token', ''));
            $chatId = trim((string) $params->get('alert_telegram_chat_id', ''));
            if ($botToken !== '' && $chatId !== '') {
                $telegramUrl = 'https://api.telegram.org/bot' . rawurlencode($botToken) . '/sendMessage';
                if (\MuruguardHelper::postWebhook($telegramUrl, ['chat_id' => $chatId, 'text' => $summary])) $sent++;
            }
        }

        return $sent;
    }

    /**
     * Pro: Fleet Dashboard -- pushes a status SUMMARY (finding counts,
     * whether Protection Mode is active, installed version) to the
     * dashboard's /api/license/fleet/report, never the findings
     * themselves. Never throws -- same best-effort philosophy as the
     * alert channels above.
     *
     * Also the delivery/ack channel for Fleet bulk actions (re-scan /
     * push hardening config, queued from the dashboard's Fleet page):
     * the response to this same check-in can carry any commands queued
     * for this exact domain, which are executed immediately below and
     * acked on a second, follow-up check-in. There's no way to reach
     * into a site directly (arbitrary hosting, no guaranteed inbound
     * reachability), so this check-in is the only channel a command can
     * ever travel through.
     */
    private function reportFleetStatus(MuruguardModelScanner $model): void
    {
        try {
            $cfgParams = ComponentHelper::getParams('com_muruguard');
            $licenseKey = trim((string) $cfgParams->get('license_key', ''));
            $domain = \MuruguardHelper::currentSiteDomain();
            $version = $this->currentComponentVersion();

            $response = \MuruguardHelper::callDashboardApi(
                '/license/fleet/report',
                $this->buildFleetStatusPayload($model, $licenseKey, $domain, $version),
                4096,
                15
            );

            if ($response['ok'] && !empty($response['data']['commands']) && is_array($response['data']['commands'])) {
                $this->executeFleetCommands($model, $response['data']['commands'], $licenseKey, $domain, $version);
            }
        } catch (\Throwable $e) {
            // Never let fleet reporting affect the scan/cron response itself.
        }
    }

    /** Shared by reportFleetStatus() and its post-command follow-up ack call below. */
    private function buildFleetStatusPayload(MuruguardModelScanner $model, string $licenseKey, string $domain, string $version): array
    {
        // getCurrentFileFindings(), NOT getFileFindings() -- the latter
        // re-runs a full scanFilesystem() whenever there's no fresh
        // session cache to read, which is the ordinary case for a cron
        // request (no browser session), silently doubling the
        // filesystem walk on top of whatever the caller already
        // computed on this exact model instance instead of just
        // reading it back.
        $findings = $model->getCurrentFileFindings();
        $findingCount = count($findings);
        $highCount = 0;
        foreach ($findings as $f) {
            if (($f['confidence'] ?? '') === 'high') $highCount++;
        }

        $cfgParams = ComponentHelper::getParams('com_muruguard');

        return [
            'licenseKey'        => $licenseKey,
            'domain'            => $domain,
            'findingCount'      => $findingCount,
            'highFindingCount'  => $highCount,
            'protectionEnabled' => (bool) $cfgParams->get('shield_enabled', 0) && $model->isShieldPluginActive(),
            'componentVersion'  => $version,
            // Lets the dashboard attempt an immediate direct trigger call
            // (see fleettrigger() below) the next time a bulk action is
            // queued, instead of only waiting for this site's own next
            // incidental check-in. Resent every report so the dashboard
            // always has the current value even if it's ever rotated.
            'fleetTriggerToken' => $model->getOrCreateFleetTriggerToken(),
        ];
    }

    private function currentComponentVersion(): string
    {
        $manifestPath = JPATH_ADMINISTRATOR . '/components/com_muruguard/muruguard.xml';
        if (!is_file($manifestPath)) return '';
        $manifestXml = @simplexml_load_file($manifestPath);
        return $manifestXml !== false ? (string) $manifestXml->version : '';
    }

    /**
     * Executes Fleet bulk-action commands delivered by the check-in
     * above, then acks whichever ones actually ran with a follow-up
     * report call carrying completedCommandIds -- the dashboard flips
     * those from DELIVERED to DONE on receipt. A command this site
     * doesn't recognise (future type, malformed row) is silently
     * skipped rather than acked, so it stays visible as "delivered" on
     * the dashboard instead of falsely showing as done.
     */
    private function executeFleetCommands(MuruguardModelScanner $model, array $commands, string $licenseKey, string $domain, string $version): void
    {
        $completedIds = [];
        $rescanned = false;

        foreach ($commands as $cmd) {
            $id = is_string($cmd['id'] ?? null) ? $cmd['id'] : '';
            $type = is_string($cmd['type'] ?? null) ? $cmd['type'] : '';
            if ($id === '') continue;

            if ($type === 'RESCAN') {
                // Only ever run one fresh scan per check-in even if
                // multiple RESCAN commands were somehow queued -- the
                // dashboard already avoids creating duplicates, this is
                // just a second line of defence against running the
                // full filesystem+database scan twice in one request.
                if (!$rescanned) {
                    $model->runScheduledCheck();
                    $rescanned = true;
                }
                $completedIds[] = $id;
            } elseif ($type === 'APPLY_HARDENING') {
                $payload = is_array($cmd['payload'] ?? null) ? $cmd['payload'] : [];
                if ($model->applyFleetHardeningCommand($payload)) {
                    $completedIds[] = $id;
                }
            }
        }

        if (empty($completedIds)) return;

        try {
            $ackPayload = $this->buildFleetStatusPayload($model, $licenseKey, $domain, $version);
            $ackPayload['completedCommandIds'] = $completedIds;
            \MuruguardHelper::callDashboardApi('/license/fleet/report', $ackPayload, 4096, 15);
        } catch (\Throwable $e) {
            // Best-effort ack -- an unacked command just stays visible
            // as "delivered" on the dashboard instead of "done".
        }
    }

    /**
     * Fleet bulk-action DIRECT trigger (Pro) -- lets the dashboard poke
     * this site immediately when "Re-scan selected"/"Push hardening
     * config" is clicked, instead of only waiting for this site's own
     * next incidental check-in (login-triggered scan, or a configured
     * scheduled-scan cron). Public, no admin session -- same reasoning
     * as scheduledcheck() below, authenticated purely by a secret token
     * instead of Joomla's own ACL/CSRF machinery, since the caller here
     * is the dashboard server, not a logged-in browser.
     *
     * Authenticated by fleetTriggerToken ALONE, deliberately a SEPARATE
     * secret from the admin's own external-cron token (see
     * MuruguardModelScanner::getOrCreateFleetTriggerToken()'s docblock)
     * -- a leaked dashboard-side token can never be used to impersonate
     * the admin's own cron caller or vice versa. Rate-limited on top of
     * the token check itself, since unlike the admin's own cron (whose
     * calling frequency the admin controls), this is called by a third
     * party whenever THEY want -- a stolen/guessed token shouldn't be
     * able to hammer this site with repeated full scans.
     *
     * Runs the exact same full scan scheduledcheck() runs, then
     * delivers/executes whatever Fleet commands are actually pending via
     * reportFleetStatus() -- a re-scan trigger and a hardening-push
     * trigger both funnel through here identically, since both are just
     * "wake this site up to check in right now, whatever's queued gets
     * picked up" underneath.
     */
    public function fleettrigger()
    {
        $app = Factory::getApplication();
        $params = ComponentHelper::getParams('com_muruguard');
        header('Content-Type: application/json; charset=utf-8');

        if (!\MuruguardAiHelper::isProLicenseActive() || !(bool) $params->get('fleet_reporting_enabled', 0)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'fleet_reporting_disabled']);
            $app->close();
        }

        $configuredToken = trim((string) $params->get('fleet_trigger_token', ''));
        $suppliedToken = (string) $app->input->getString('token', '');
        if ($configuredToken === '' || $suppliedToken === '' || !hash_equals($configuredToken, $suppliedToken)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'invalid_token']);
            $app->close();
        }

        // A full scan is genuinely expensive (filesystem + database walk)
        // -- a much wider window than scheduledcheck() itself needs,
        // since this exists purely so a manually-clicked "Re-scan
        // selected" isn't stuck waiting for the next incidental check-in,
        // not for repeated automated polling. Defends a leaked/guessed
        // token from being used to keep this site running full scans
        // back-to-back.
        $lastTriggeredAt = (int) $params->get('fleet_trigger_last_at', 0);
        if ($lastTriggeredAt > 0 && (time() - $lastTriggeredAt) < 300) {
            http_response_code(429);
            echo json_encode(['ok' => false, 'error' => 'rate_limited']);
            $app->close();
        }

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->recordFleetTriggerTimestamp(time());

        // Keeps running to completion server-side even if the dashboard's
        // own outbound call doesn't wait around for the full scan to
        // finish (it shouldn't -- a full scan can take 10-30s+, longer
        // than a serverless function wants to block on). Same execution-
        // time/memory best-effort raise scan() already does for the
        // interactive "Run Scan" button.
        ignore_user_abort(true);
        if (function_exists('set_time_limit')) {
            @set_time_limit(300);
        }
        @ini_set('memory_limit', '512M');

        $result = $model->runScheduledCheck();

        $alertEmail = trim((string) $params->get('alert_email', ''));
        if (!$result['isFirstRun'] && $result['newCount'] > 0 && $alertEmail !== '') {
            $this->sendScheduledAlertEmail($alertEmail, $result['newFindings'], $result['newCount']);
        }
        if (!$result['isFirstRun'] && $result['newCount'] > 0) {
            $this->sendScheduledAlertWebhooks($params, $result['newFindings'], $result['newCount']);
        }

        // Reports fresh status AND delivers/executes any pending Fleet
        // commands (including the very RESCAN/APPLY_HARDENING command
        // that likely caused this trigger call in the first place) --
        // same mechanism scheduledcheck() and scan() already use.
        $this->reportFleetStatus($model);

        echo json_encode(['ok' => true, 'totalCount' => $result['totalCount'], 'newCount' => $result['newCount']]);
        $app->close();
    }

    /**
     * Saves the Settings panel's 3 scheduled-scanning fields, reached from
     * the scanner page itself rather than requiring a trip to System >
     * Global Configuration. Writes to the exact same storage Global
     * Configuration uses (see MuruguardModelScanner::saveScheduledSettings()),
     * so both stay in sync automatically.
     */
    /** Saves the "items per page" display preference for the scan-result file lists. */
    public function savedisplaysettings()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $app = Factory::getApplication();
        $itemsPerPage = $app->input->getInt('items_per_page', 50);

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->saveDisplaySettings($itemsPerPage);

        $app->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Saves the Pro Features settings (Fleet Dashboard reporting + Alert Channels). Pro-gated -- a non-Pro admin submitting this form (e.g. an expired license) still can't actually turn these on. */
    public function saveprofeatures()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        if (!\MuruguardAiHelper::isProLicenseActive()) {
            Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_AI_LICENSE_REQUIRED_MSG'), 'error');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }

        $input = Factory::getApplication()->input;
        $settings = [
            'fleet_reporting_enabled'  => $input->getInt('fleet_reporting_enabled', 0),
            'autopilot_enabled'        => $input->getInt('autopilot_enabled', 0),
            'alert_slack_enabled'      => $input->getInt('alert_slack_enabled', 0),
            'alert_slack_webhook'      => trim($input->getString('alert_slack_webhook', '')),
            'alert_discord_enabled'    => $input->getInt('alert_discord_enabled', 0),
            'alert_discord_webhook'    => trim($input->getString('alert_discord_webhook', '')),
            'alert_telegram_enabled'   => $input->getInt('alert_telegram_enabled', 0),
            'alert_telegram_bot_token' => trim($input->getString('alert_telegram_bot_token', '')),
            'alert_telegram_chat_id'   => trim($input->getString('alert_telegram_chat_id', '')),
        ];

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->saveProFeatureSettings($settings);

        // Fleet reporting only otherwise fires as a side effect of a scan
        // (manual Re-scan or the scheduled cron check) -- without this, an
        // admin who just flipped this toggle on would see "Not reporting
        // yet" / "Never" on the Fleet Dashboard until whichever of those
        // happens next, which reads as broken even though it's just
        // pending. Push one report immediately using whatever findings
        // are already cached (or a fresh scan if the cache is cold) so the
        // site shows up connected right away.
        if (!empty($settings['fleet_reporting_enabled'])) {
            $this->reportFleetStatus($model);
        }

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** AJAX "Test" button for each Alert Channel -- sends one real test message through whichever channel's fields are currently filled in (not necessarily saved yet), so the admin can verify it works before relying on it. */
    public function testalertchannel()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        if (!\MuruguardAiHelper::isProLicenseActive()) {
            $this->jsonResponse(['error' => 'license_required'], 402);
        }

        $body = $this->readJsonBody();
        $channel = (string) ($body['channel'] ?? '');
        $testMessage = '✅ MuRu Guard test alert from ' . (string) Factory::getApplication()->get('sitename', 'your site') . ' -- if you can see this, the channel is configured correctly.';

        $ok = false;
        if ($channel === 'slack') {
            $url = trim((string) ($body['webhook'] ?? ''));
            $ok = $url !== '' && \MuruguardHelper::postWebhook($url, ['text' => $testMessage]);
        } elseif ($channel === 'discord') {
            $url = trim((string) ($body['webhook'] ?? ''));
            $ok = $url !== '' && \MuruguardHelper::postWebhook($url, ['content' => $testMessage]);
        } elseif ($channel === 'telegram') {
            $botToken = trim((string) ($body['botToken'] ?? ''));
            $chatId = trim((string) ($body['chatId'] ?? ''));
            if ($botToken !== '' && $chatId !== '') {
                $telegramUrl = 'https://api.telegram.org/bot' . rawurlencode($botToken) . '/sendMessage';
                $ok = \MuruguardHelper::postWebhook($telegramUrl, ['chat_id' => $chatId, 'text' => $testMessage]);
            }
        }

        $this->jsonResponse(['ok' => $ok]);
    }

    /**
     * Pro: one-click branded security report -- a standalone, print-
     * optimized HTML page (no Joomla admin chrome) opened in a new tab.
     * The admin uses the browser's own "Print > Save as PDF" to turn it
     * into a PDF -- no PDF library dependency needed. Read-only, so no
     * CSRF token is required, only the standard view-access gate.
     */
    public function report()
    {
        \MuruguardHelper::requireManageAccess();

        if (!\MuruguardAiHelper::isProLicenseActive()) {
            Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_AI_LICENSE_REQUIRED_MSG'), 'error');
            $this->setRedirect('index.php?option=com_muruguard');
            return;
        }

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        $app = Factory::getApplication();
        header('Content-Type: text/html; charset=utf-8');
        echo \MuruguardHelper::buildSecurityReportHtml($model);
        $app->close();
    }

    public function savesettings()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $app = Factory::getApplication();
        $input = $app->input;
        $redirectUrl = $this->settingsRedirectUrl();

        $cronEnabled = (bool) $input->getInt('cron_enabled', 0);
        $cronToken = trim($input->getString('cron_token', ''));
        $alertEmail = trim($input->getString('alert_email', ''));

        if ($alertEmail !== '' && !filter_var($alertEmail, FILTER_VALIDATE_EMAIL)) {
            $app->enqueueMessage(Text::sprintf('COM_MURUGUARD_SETTINGS_INVALID_EMAIL', htmlspecialchars($alertEmail)), 'error');
            $this->setRedirect($redirectUrl);
            return;
        }

        if ($cronEnabled && $cronToken === '') {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_NEEDS_TOKEN'), 'error');
            $this->setRedirect($redirectUrl);
            return;
        }

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->saveScheduledSettings($cronEnabled, $cronToken, $alertEmail);

        $app->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        $this->setRedirect($redirectUrl);
    }

    /**
     * Every Settings-saving action redirects here instead of a bare
     * 'index.php?option=com_muruguard' -- that used to drop the admin
     * back on the Dashboard panel entirely (savesettings()/
     * saveshieldsettings() never included view_panel=settings at all),
     * and even where it did (savelicense()), the settings sub-tab itself
     * always reset to whichever one is hardcoded "active" in the markup
     * (Protection) regardless of which tab the save actually came from.
     * settings_tab is filled in client-side right before submit (see the
     * generic form-submit listener in default.php) with whichever tab
     * was open at the time.
     */
    private function settingsRedirectUrl(): string
    {
        $tab = Factory::getApplication()->input->getCmd('settings_tab', '');
        // Settings tabs were consolidated from 9 down to 6 -- see the
        // matching legacy-id map in MuruguardViewScanner::display(),
        // which this mirrors so a save from (what used to be) any of
        // the merged sub-tabs still redirects back into the correct
        // NEW tab rather than silently falling back to the default.
        $legacyTabMap = [
            'protection' => 'site_protection', 'iplist' => 'site_protection',
            'scheduled' => 'general',
            'ai' => 'automation', 'pro' => 'automation',
            'timemachine' => 'backup', 'integrity' => 'site_protection',
        ];
        $tab = $legacyTabMap[$tab] ?? $tab;
        $validTabs = ['general', 'site_protection', 'license', 'automation', 'backup', 'guide'];
        $tab = in_array($tab, $validTabs, true) ? $tab : 'general';
        return 'index.php?option=com_muruguard&view_panel=settings&settings_tab=' . $tab;
    }

    /**
     * Saves the Protection Mode settings the companion
     * plg_system_muruguardshield plugin reads on every request. Same
     * storage/permission level as savesettings() above -- this only
     * controls the plugin's behaviour, it does not check whether that
     * plugin is actually installed/enabled (the Settings panel surfaces
     * that separately so the admin isn't misled by a setting with no
     * effect).
     */
    public function saveshieldsettings()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $app   = Factory::getApplication();
        $input = $app->input;

        $enabled          = (bool) $input->getInt('shield_enabled', 0);
        $blockPatterns    = (bool) $input->getInt('shield_block_patterns', 0);
        $blockBruteForce  = (bool) $input->getInt('shield_block_bruteforce', 0);
        $threshold        = $input->getInt('shield_bruteforce_threshold', 5);
        $window           = $input->getInt('shield_bruteforce_window', 15);
        $blockUserAgents  = (bool) $input->getInt('shield_block_useragents', 0);
        $blockCountries   = (bool) $input->getInt('shield_block_countries', 0);
        $blockedCountries = $input->getString('shield_blocked_countries', '');
        $blockReferrers   = (bool) $input->getInt('shield_block_referrers', 0);
        $blockPbl         = (bool) $input->getInt('shield_block_pbl', 0);
        $blockUploadExts  = (bool) $input->getInt('shield_block_upload_extensions', 0);
        $autoblockRepeatOffenders = (bool) $input->getInt('shield_autoblock_repeat_offenders', 0);
        $autoblockThreshold       = $input->getInt('shield_autoblock_threshold', 3);
        $autoblockWindow          = $input->getInt('shield_autoblock_window', 60);
        // Force-false whenever the license isn't active, regardless of
        // what was posted -- a direct POST can't turn Pro's WAF on any
        // more than the disabled/locked toggle in the template can.
        $wafEnabled = \MuruguardAiHelper::isProLicenseActive() && (bool) $input->getInt('waf_enabled', 0);

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        // These switches do nothing without plg_system_muruguardshield
        // actually installed and enabled -- the template already disables
        // every input in this form when that's the case, but that's only
        // a UI courtesy; a direct POST (or a stale page left open from
        // before the plugin was removed) could still reach here, so the
        // save itself is refused server-side too rather than silently
        // persisting settings with no effect.
        if (!$model->isShieldPluginActive()) {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_SHIELD_PLUGIN_MISSING'), 'warning');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }

        $model->saveShieldSettings(
            $enabled,
            $blockPatterns,
            $blockBruteForce,
            $threshold,
            $window,
            $blockUserAgents,
            $blockCountries,
            $blockedCountries,
            $wafEnabled,
            $blockReferrers,
            $autoblockRepeatOffenders,
            $autoblockThreshold,
            $autoblockWindow,
            $blockPbl,
            $blockUploadExts
        );

        $app->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * Saves a new/changed license key -- verifies it against the
     * dashboard SYNCHRONOUSLY before reporting success, so a mistyped or
     * revoked key is never shown a "License key saved" message while the
     * License panel simultaneously says "Key not found" (see
     * MuruguardModelScanner::saveAndVerifyLicenseKey() for exactly which
     * outcomes get persisted vs. rejected).
     */
    public function savelicense()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $app = Factory::getApplication();
        $key = trim($app->input->getString('license_key', ''));

        // The field is deliberately always blank on load (see
        // MuruguardHelper::maskLicenseKey()), so submitting it empty means
        // "I didn't type a new key" -- tell the admin nothing changed
        // rather than implying a key was saved.
        if ($key === '') {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_LICENSE_EMPTY_NOCHANGE_MSG'), 'warning');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }

        // Same defensive bump scan()/rechecklicense() use -- this action
        // now makes a real outbound HTTP call before it can redirect.
        @ini_set('memory_limit', '256M');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $result = $model->saveAndVerifyLicenseKey($key);

        switch ($result['status']) {
            case 'active':
                $app->enqueueMessage(Text::_('COM_MURUGUARD_LICENSE_SAVED_MSG'), 'message');
                break;
            case 'unreachable':
                $app->enqueueMessage(Text::_('COM_MURUGUARD_LICENSE_SAVED_UNVERIFIED_MSG'), 'warning');
                break;
            default:
                $app->enqueueMessage(Text::_('COM_MURUGUARD_LICENSE_INVALID_MSG'), 'error');
                break;
        }
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Forces an immediate re-check against the dashboard, bypassing the cache -- the Settings panel's "Re-check now" button. */
    public function rechecklicense()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        // Same defensive bump scan() uses -- an outbound HTTP call plus a
        // full page render on a host already close to a low memory_limit
        // (many shared hosts still default to 128M) shouldn't be able to
        // fatal the request. @-suppressed because some hosts disable
        // ini_set entirely, in which case this silently no-ops.
        @ini_set('memory_limit', '256M');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->getLicenseStatus(true);

        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * Adds one entry to the manual IP Access List (see
     * MuruguardHelper::addIpListEntry() for validation/storage). Same
     * admin-level permission as changing Protection Mode settings, since
     * a wrong entry here can lock an admin out of the site.
     */
    public function addipentry()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $app   = Factory::getApplication();
        $input = $app->input;

        $value = $input->getString('ip_value', '');
        $mode  = $input->getString('ip_mode', 'block');
        $note  = $input->getString('ip_note', '');

        $result = \MuruguardHelper::addIpListEntry($value, $mode, $note);
        if ($result['ok']) {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_IPLIST_ADDED_MSG'), 'message');
        } else {
            $app->enqueueMessage(htmlspecialchars($result['error']), 'error');
        }

        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Adds one MD5 to the Known-Bad Hashes list. See MuruguardHelper::addCustomMalwareHash(). */
    public function addknownhash()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $input = Factory::getApplication()->input;
        $result = \MuruguardHelper::addCustomMalwareHash($input->getString('hash_md5', ''), $input->getString('hash_note', ''));

        if ($result['ok']) {
            Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_KNOWNHASH_ADDED_MSG'), 'message');
        } else {
            Factory::getApplication()->enqueueMessage(htmlspecialchars($result['error']), 'error');
        }
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Removes one entry from the Known-Bad Hashes list. */
    public function removeknownhash()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $id = Factory::getApplication()->input->getString('hash_id', '');
        if ($id !== '') {
            \MuruguardHelper::removeCustomMalwareHash($id);
        }
        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_KNOWNHASH_REMOVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Removes one entry from the manual IP Access List. */
    public function removeipentry()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $id = Factory::getApplication()->input->getString('ip_id', '');
        if ($id !== '') {
            \MuruguardHelper::removeIpListEntry($id);
        }

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_IPLIST_REMOVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * MuRu Shield Hardening: activates the /administrator HTTP Basic
     * Auth gate. The password itself is never round-tripped back from
     * the server -- the "Generate securely" button fills the form
     * fields client-side, so the browser (and the admin looking at the
     * screen) already has it before this ever submits; the model
     * self-tests with real outbound requests and rolls back
     * automatically on any failure (see MuruguardHardeningHelper).
     */
    public function activatebackendauth()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $app = Factory::getApplication();
        $username = trim($app->input->getString('backend_auth_username', ''));
        $password = (string) $app->input->get('backend_auth_password', '', 'raw');
        $repeat   = (string) $app->input->get('backend_auth_password_repeat', '', 'raw');

        if ($username === '' || $password === '') {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_HARDENING_MISSING_FIELDS_MSG'), 'error');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }
        if (strlen($password) < 8) {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_HARDENING_PASSWORD_TOO_SHORT_MSG'), 'error');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }
        if ($password !== $repeat) {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_HARDENING_PASSWORD_MISMATCH_MSG'), 'error');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }

        @ini_set('memory_limit', '256M');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $result = $model->activateBackendAuth($username, $password);

        if ($result['ok']) {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_HARDENING_ACTIVATED_MSG'), 'message');
        } else {
            $app->enqueueMessage(Text::sprintf('COM_MURUGUARD_HARDENING_FAILED_MSG', $result['reason']), 'error');
        }
        $this->setRedirect($this->settingsRedirectUrl());
    }

    public function deactivatebackendauth()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->deactivateBackendAuth();

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_HARDENING_DEACTIVATED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * Two small, independent hardening toggles that don't warrant their
     * own settings screen: the generator-meta-tag strip (see
     * plg_system_muruguardshield's onBeforeCompileHead()) and automatic
     * tmp/ folder cleanup on every scheduled check (see
     * MuruguardModelScanner::cleanupTmpFolder()). Saved together since
     * they share a form in Settings > Site Protection.
     */
    public function savemischardening()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $input = Factory::getApplication()->input;
        $removeGenerator = (bool) $input->getInt('harden_remove_generator', 0);
        $tmpCleanup      = (bool) $input->getInt('harden_tmp_cleanup_enabled', 0);
        $homepageWatch   = (bool) $input->getInt('homepage_watch_enabled', 0);

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->saveGeneratorTagSetting($removeGenerator);
        $model->saveTmpCleanupSetting($tmpCleanup);
        $model->saveHomepageWatchSetting($homepageWatch);

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Saves the Google Safe Browsing API key. See MuruguardModelScanner::saveSafeBrowsingApiKey() for the blank-means-unchanged convention. */
    public function savesafebrowsingkey()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $key = trim((string) Factory::getApplication()->input->get('safe_browsing_api_key', '', 'raw'));

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        if ($key === '') {
            Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_LICENSE_EMPTY_NOCHANGE_MSG'), 'warning');
        } else {
            $model->saveSafeBrowsingApiKey($key);
            Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        }
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Clears the Google Safe Browsing API key. */
    public function clearsafebrowsingkey()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->clearSafeBrowsingApiKey();

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Saves the Gemini API key -- the Free-tier "Ask AI" path. See MuruguardModelScanner::saveGeminiApiKey(). */
    public function savegeminikey()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $key = trim((string) Factory::getApplication()->input->get('gemini_api_key', '', 'raw'));

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        if ($key === '') {
            Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_LICENSE_EMPTY_NOCHANGE_MSG'), 'warning');
        } else {
            $model->saveGeminiApiKey($key);
            Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        }
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /** Clears the Gemini API key. */
    public function cleargeminikey()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->clearGeminiApiKey();

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * Streams the site's exportable (secret-free) config as a JSON
     * download -- see MuruguardHelper::buildExportableConfig()'s own
     * docblock for exactly which settings this covers and why every
     * secret this extension stores is deliberately excluded.
     */
    public function exportconfig()
    {
        Session::checkToken('request') or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $export = $model->getExportableConfig();

        $filename = 'muruguard-config-' . date('Ymd-His') . '.json';
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo json_encode($export, JSON_PRETTY_PRINT);
        Factory::getApplication()->close();
    }

    /**
     * Accepts an uploaded config export file and applies only the
     * allowlisted settings it contains -- see
     * MuruguardHelper::parseImportableConfig()'s own docblock for the
     * validation/allowlist-filtering an uploaded file goes through
     * before anything is saved.
     */
    public function importconfig()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $app = Factory::getApplication();
        $file = $app->input->files->get('config_file');
        if (empty($file) || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_CONFIG_IMPORT_NO_FILE'), 'error');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }

        $json = (string) @file_get_contents($file['tmp_name']);
        $result = \MuruguardHelper::parseImportableConfig($json);
        if (!$result['ok']) {
            $app->enqueueMessage(htmlspecialchars($result['error']), 'error');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->saveImportedConfig($result['settings']);

        $skipped = (int) ($result['skipped'] ?? 0);
        $msg = $skipped > 0
            ? Text::sprintf('COM_MURUGUARD_CONFIG_IMPORT_OK_WITH_SKIPPED_MSG', count($result['settings']), $skipped)
            : Text::sprintf('COM_MURUGUARD_CONFIG_IMPORT_OK_MSG', count($result['settings']));
        $app->enqueueMessage($msg, 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * AJAX: restores one core file from its official checksum baseline
     * -- see MuruguardModelScanner::restoreCoreFile() /
     * MuruguardHelper::restoreCoreFileFromBaseline() for the actual
     * fetch+verify+backup sequence. Same admin-only trust boundary as
     * applyhtaccesssuggestion() -- this writes to the filesystem.
     */
    public function restorecorefile()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $relPath = Factory::getApplication()->input->getString('rel_path', '');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $result = $model->restoreCoreFile($relPath);

        header('Content-Type: application/json; charset=utf-8');
        if (!$result['ok']) {
            http_response_code(400);
        }
        echo json_encode($result);
        Factory::getApplication()->close();
    }

    /** Manual "Clean tmp/ folder now" button -- see MuruguardModelScanner::cleanupTmpFolder(). Same cleanup the scheduled check runs automatically when harden_tmp_cleanup_enabled is on, just on demand. */
    public function cleanuptmp()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $result = $model->cleanupTmpFolder();

        Factory::getApplication()->enqueueMessage(
            Text::sprintf('COM_MURUGUARD_TMP_CLEANUP_RESULT_MSG', $result['deleted'], $result['skipped']),
            empty($result['errors']) ? 'message' : 'warning'
        );
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * Extends the SAME backend credentials to the whole site. Requires
     * re-typing the current backend password (never persisted in
     * plaintext -- see activateBackendAuth()'s docblock) so the model
     * can confirm it's actually correct before writing anything.
     */
    public function activateemergencymode()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $app = Factory::getApplication();
        $username = trim($app->input->getString('emergency_username', ''));
        $password = (string) $app->input->get('emergency_password', '', 'raw');

        if ($username === '' || $password === '') {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_HARDENING_MISSING_FIELDS_MSG'), 'error');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }

        @ini_set('memory_limit', '256M');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $result = $model->activateEmergencyMode($username, $password);

        if ($result['ok']) {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_EMERGENCY_ACTIVATED_MSG'), 'message');
        } else {
            $app->enqueueMessage(Text::sprintf('COM_MURUGUARD_HARDENING_FAILED_MSG', $result['reason']), 'error');
        }
        $this->setRedirect($this->settingsRedirectUrl());
    }

    public function deactivateemergencymode()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->deactivateEmergencyMode();

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_EMERGENCY_DEACTIVATED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * Help Center's direct contact form -- deliberately requires only
     * view access (not edit/admin), matching this being free and
     * account-independent: anyone who can see the scanner should be able
     * to ask a question about it. Sends a branded email straight to the
     * project's own support address; the optional system-info block
     * (version/PHP/server/status -- never file paths or findings) is
     * built server-side in the view and only included if the admin
     * ticked the box, exactly as shown to them before sending.
     */
    public function sendhelprequest()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireManageAccess();

        $app = Factory::getApplication();
        $input = $app->input;

        $name    = trim($input->getString('help_name', ''));
        $email   = trim($input->getString('help_email', ''));
        $subject = trim($input->getString('help_subject', ''));
        $message = trim($input->get('help_message', '', 'raw'));
        $sendSystemInfo = (bool) $input->getInt('help_send_system_info', 0);
        $systemInfo = $sendSystemInfo ? (string) $input->get('help_system_info', '', 'raw') : '';

        if ($subject === '' || $message === '') {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_HELP_MISSING_FIELDS_MSG'), 'error');
            $this->setRedirect('index.php?option=com_muruguard&view_panel=help');
            return;
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $app->enqueueMessage(Text::_('COM_MURUGUARD_HELP_INVALID_EMAIL_MSG'), 'error');
            $this->setRedirect('index.php?option=com_muruguard&view_panel=help');
            return;
        }

        $sent = $this->sendHelpEmail($name, $email, $subject, $message, $systemInfo);

        $app->enqueueMessage(Text::_($sent ? 'COM_MURUGUARD_HELP_SENT_MSG' : 'COM_MURUGUARD_HELP_FAILED_MSG'), $sent ? 'message' : 'error');
        $this->setRedirect('index.php?option=com_muruguard&view_panel=help');
    }

    private function sendHelpEmail(string $name, string $email, string $subject, string $message, string $systemInfo): bool
    {
        $app = Factory::getApplication();
        $siteName = (string) $app->get('sitename', 'a MuRu Guard site');
        $safeName = htmlspecialchars($name !== '' ? $name : 'A MuRu Guard user');
        $safeSubject = htmlspecialchars($subject);
        $safeMessage = nl2br(htmlspecialchars($message));

        $htmlBody = '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"></head>'
            . '<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Arial,sans-serif;">'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px;"><tr><td align="center">'
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #e5e7eb;">'
            . '<tr><td align="center" style="background:#111827;padding:32px 28px;">'
            . '<div style="color:#ffffff;font-size:20px;font-weight:700;">🛡️ MuRu Guard Help Center</div>'
            . '<p style="margin:8px 0 0;color:#9ca3af;font-size:13px;">New message from ' . $safeName . '</p>'
            . '</td></tr>'
            . '<tr><td style="padding:28px;">'
            . '<p style="margin:0 0 6px;color:#111827;font-size:14px;"><strong>From:</strong> ' . $safeName . ($email !== '' ? ' (' . htmlspecialchars($email) . ')' : '') . '</p>'
            . '<p style="margin:0 0 6px;color:#111827;font-size:14px;"><strong>Site:</strong> ' . htmlspecialchars($siteName) . ' (' . htmlspecialchars(\MuruguardHelper::currentSiteDomain()) . ')</p>'
            . '<p style="margin:0 0 16px;color:#111827;font-size:14px;"><strong>Subject:</strong> ' . $safeSubject . '</p>'
            . '<div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:16px;color:#374151;font-size:14px;line-height:22px;margin-bottom:16px;">' . $safeMessage . '</div>'
            . ($systemInfo !== '' ? '<div style="background:#f3f4f6;border-radius:10px;padding:12px 16px;color:#6b7280;font-size:12px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap;">' . htmlspecialchars($systemInfo) . '</div>' : '')
            . '</td></tr>'
            . '</table></td></tr></table></body></html>';

        $textBody = "New Help Center message from {$name} ({$email})\nSite: {$siteName}\nSubject: {$subject}\n\n{$message}"
            . ($systemInfo !== '' ? "\n\n---\n{$systemInfo}" : '');

        try {
            $mailer = Factory::getMailer();
            $mailer->setSender([$app->get('mailfrom'), $app->get('fromname')]);
            $mailer->addRecipient('zkranao@gmail.com');
            if ($email !== '') {
                $mailer->addReplyTo($email, $name !== '' ? $name : $email);
            }
            $mailer->setSubject('[MuRu Guard Help Center] ' . $subject);
            $mailer->isHtml(true);
            $mailer->setBody($htmlBody);
            $mailer->AltBody = $textBody;
            return (bool) $mailer->Send();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Dismisses a single finding as a false positive ("Mark as Safe" on
     * its row) -- see MuruguardHelper::addFalsePositive()/
     * fingerprintReasons() for why this is keyed on the exact reasons
     * text, not just the path/row-id, so a later genuine compromise of
     * the same path/row isn't silently hidden by an old dismissal. Same
     * edit-level permission as Clean, since dismissing a security finding
     * is a comparable judgment call.
     */
    public function markfalsepositive()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireEditAccess();

        $app   = Factory::getApplication();
        $input = $app->input;

        $category    = $input->getCmd('fp_category', '');
        $identifier  = $input->getString('fp_identifier', '');
        $fingerprint = $input->getString('fp_fingerprint', '');
        $note        = $input->getString('fp_note', '');

        $result = \MuruguardHelper::addFalsePositive($category, $identifier, $fingerprint, $note);

        // Only ever called via fetch() from the "Mark as Safe" button's JS
        // (see default.php) -- unmarkfalsepositive() below is the one
        // real <form> submit still needs a redirect. This one used to
        // redirect too, back to the bare results page, which the fetch()
        // call transparently followed and then discarded the resulting
        // full HTML page -- wasted work, and the actual source of a
        // real-world "gets kicked back to the plain results page" report,
        // since the JS then did its OWN reload on top of that. A small
        // JSON response is both cheaper and lets the button remove its
        // own row and update the surrounding counts in place, with zero
        // navigation at all.
        header('Content-Type: application/json; charset=utf-8');
        if ($result['ok']) {
            // The scan-results page reads from a 5-minute session cache, not
            // a fresh scan, on every load -- without invalidating it here,
            // a dismissal was saved correctly but the next full reload
            // (e.g. after a later "Run Scan") kept showing the same stale
            // pre-dismissal list, making it look like nothing happened.
            // Same cache-busting the delete/clean actions already do after
            // their own mutations.
            $session = $app->getSession();
            $session->set('muruguard.filefindings', null);
            $session->set('muruguard.filefindings_time', 0);
            echo json_encode(['ok' => true]);
        } else {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => (string) $result['error']]);
        }
        $app->close();
    }

    /**
     * Writes one of the .htaccess Hardening advisory panel's own
     * recommended rules into the real .htaccess -- see
     * MuruguardHelper::applyHtaccessSuggestion() for what this does and
     * deliberately doesn't do. Admin-only: this is a real write to a
     * security-critical file, same bar as Settings changes, not the
     * lower edit-access bar most AJAX actions on this page use.
     */
    public function applyhtaccesssuggestion()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        $checkId = Factory::getApplication()->input->getCmd('check_id', '');
        $result = \MuruguardHelper::applyHtaccessSuggestion(JPATH_ROOT, $checkId);

        header('Content-Type: application/json; charset=utf-8');
        if (!$result['ok']) {
            http_response_code(400);
        }
        echo json_encode($result);
        Factory::getApplication()->close();
    }

    /** Reverses a "Mark as Safe" dismissal, making the finding reappear on the next scan. */
    public function unmarkfalsepositive()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireEditAccess();

        $id = Factory::getApplication()->input->getString('fp_id', '');
        if ($id !== '') {
            \MuruguardHelper::removeFalsePositive($id);
        }

        // Same reasoning as markfalsepositive() above -- without this, an
        // un-dismissed finding wouldn't reappear until the cache happened
        // to expire or the user manually re-scanned.
        $session = Factory::getApplication()->getSession();
        $session->set('muruguard.filefindings', null);
        $session->set('muruguard.filefindings_time', 0);

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_FP_UNMARKED_MSG'), 'message');
        // This form lives inside Settings > Protection's False Positives
        // list (a real form submit, not fetch, unlike markfalsepositive()
        // above) -- redirecting to the bare dashboard URL previously
        // kicked the admin out of Settings entirely on every Restore
        // click, same class of bug as savesettings()/saveshieldsettings()
        // before they were fixed to use settingsRedirectUrl().
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * Bulk "Mark as Safe" -- dismisses every finding in the submitted
     * list, for the multi-select toolbar on each results tab. Same
     * fetch-only, JSON-in/JSON-out shape as markfalsepositive() (see its
     * docblock for why that one moved off a redirect), just looped --
     * each item goes through the exact same MuruguardHelper::addFalsePositive()
     * the single-item button already uses, so there's no separate
     * "bulk" code path to keep in sync with the real one. The session
     * findings cache is only invalidated once at the end, not once per
     * item, since it's the same cache regardless of how many rows changed.
     */
    public function bulkmarkfalsepositive()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireEditAccess();

        $body = $this->readJsonBody();
        $items = is_array($body['items'] ?? null) ? $body['items'] : [];

        // Same reasoning as the fleet-command batch caps elsewhere in this
        // codebase -- bounds the work a single request can be made to do
        // regardless of what a malformed or hostile body claims, before
        // any of it is touched.
        if (count($items) > 500) {
            $items = array_slice($items, 0, 500);
        }

        $markedCount = 0;
        $failed = [];
        foreach ($items as $item) {
            if (!is_array($item)) continue;
            $category    = is_string($item['category'] ?? null) ? $item['category'] : '';
            $identifier  = is_string($item['identifier'] ?? null) ? $item['identifier'] : '';
            $fingerprint = is_string($item['fingerprint'] ?? null) ? $item['fingerprint'] : '';
            if ($identifier === '') continue;

            $result = \MuruguardHelper::addFalsePositive($category, $identifier, $fingerprint, '');
            if ($result['ok']) {
                $markedCount++;
            } else {
                $failed[] = $identifier;
            }
        }

        if ($markedCount > 0) {
            // Same cache-bust markfalsepositive() does -- once here covers
            // every item in this batch, no need to repeat it per item.
            $session = Factory::getApplication()->getSession();
            $session->set('muruguard.filefindings', null);
            $session->set('muruguard.filefindings_time', 0);
        }

        $this->jsonResponse(['ok' => true, 'marked' => $markedCount, 'failed' => $failed]);
    }

    /** Clears the Protection Log. Requires the same admin-level permission as changing settings, since it's destroying a security audit trail, not just tidying a scan result. */
    public function clearattacklog()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        \MuruguardHelper::clearAttackLog();

        Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_ATTACK_LOG_CLEARED_MSG'), 'message');
        $this->setRedirect('index.php?option=com_muruguard');
    }

    // ------------------------------------------------------------------
    // Smart AI Assistant -- Pro-only. See MuruguardAiHelper for the
    // actual file-tool implementations and MuruguardHelper::
    // callDashboardApi() for the outbound-call safety pattern these
    // reuse. Every action here is JSON-in/JSON-out (AJAX from the chat
    // UI), not a normal form-post-and-redirect action like the rest of
    // this controller.
    // ------------------------------------------------------------------

    /** Reads and JSON-decodes the raw POST body -- Joomla's JInput has no built-in JSON body parser, and these are all AJAX calls with a JSON payload, not a normal form post. */
    private function readJsonBody(): array
    {
        $raw = file_get_contents('php://input');
        $decoded = json_decode((string) $raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    /** Emits a JSON response and terminates the request -- every AI action below ends by calling this, same "never returns" contract as the framework's own jexit(). */
    private function jsonResponse(array $data, int $httpStatus = 200): void
    {
        http_response_code($httpStatus);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        Factory::getApplication()->close();
    }

    private const AI_MUTATING_TOOLS = ['write_file', 'rename_file', 'delete_file'];

    /** Tool definitions sent to the dashboard on every step -- executeAiTool() below is the actual authority on what each one does; this is just its JSON-schema description for the LLM. */
    private function aiToolDefinitions(): array
    {
        return [
            ['name' => 'list_files', 'description' => 'List files and folders at a path relative to the site root (empty path = root).', 'parameters' => ['type' => 'object', 'properties' => ['path' => ['type' => 'string']], 'required' => []]],
            ['name' => 'read_file', 'description' => 'Read the contents of a file, given a path relative to the site root.', 'parameters' => ['type' => 'object', 'properties' => ['path' => ['type' => 'string']], 'required' => ['path']]],
            ['name' => 'search_project', 'description' => 'Search filenames and file contents across the whole project for a text query.', 'parameters' => ['type' => 'object', 'properties' => ['query' => ['type' => 'string']], 'required' => ['query']]],
            ['name' => 'write_file', 'description' => 'Create a new file or overwrite an existing one with the given content. Requires the user to explicitly confirm before it actually runs.', 'parameters' => ['type' => 'object', 'properties' => ['path' => ['type' => 'string'], 'content' => ['type' => 'string']], 'required' => ['path', 'content']]],
            ['name' => 'rename_file', 'description' => 'Rename or move a file. Requires the user to explicitly confirm before it actually runs.', 'parameters' => ['type' => 'object', 'properties' => ['from' => ['type' => 'string'], 'to' => ['type' => 'string']], 'required' => ['from', 'to']]],
            ['name' => 'delete_file', 'description' => 'Permanently delete a file. Requires the user to explicitly confirm before it actually runs.', 'parameters' => ['type' => 'object', 'properties' => ['path' => ['type' => 'string']], 'required' => ['path']]],
        ];
    }

    /**
     * The single biggest lever over how USEFUL the assistant actually is
     * -- confirmed against a real transcript that a "scan my project"
     * request produced a shallow directory-listing summary with no file
     * actually read, because nothing here told the model that wasn't
     * acceptable. The tool set (list_files/read_file/search_project) was
     * always capable of a real investigation; this prompt is what makes
     * it actually do one instead of taking the cheapest path that looks
     * plausible. Written as a nowdoc (not a normal single-quoted string)
     * purely so the prose below can use plain apostrophes/quotes without
     * an escaping mess -- no variable interpolation happens in here.
     */
    private function aiSystemPrompt(): string
    {
        $base = <<<'PROMPT'
You are the Smart AI Assistant inside the MuRu Guard Joomla security extension's admin panel. You help the site owner with their Joomla project: scanning for issues, finding bugs, suggesting and applying fixes, explaining code, refactoring, creating/editing/renaming/deleting files, searching the project, generating new components/classes/modules, writing documentation and unit tests, and giving performance/security recommendations. You only have access to this ONE Joomla project's files via the provided tools -- nothing else. Always explain what you are about to do in plain text before calling write_file, rename_file, or delete_file, since the user must explicitly approve those specific actions before they take effect.

Know your tools precisely, since guessing their behavior produces a shallow result:
- list_files(path) returns only ONE directory level, not a recursive tree. To map a folder's contents you must call it again on each subfolder you want to descend into.
- read_file(path) returns a file's actual content (up to 256KB). This is the ONLY way to know what a file actually contains -- its name and location tell you nothing about whether it's safe or correct.
- search_project(query) is a literal, case-insensitive SUBSTRING search across filenames and file content (not a regex) -- run one call per distinct term you're hunting for (e.g. separate calls for "eval(", "base64_decode(", "system(", "shell_exec(", "assert(", "create_function(", not one call trying to match several at once), and it returns at most the first matching line per file, so a hit is a lead to read_file(), not the full picture.

When the user asks you to scan, review, audit, or check their project (or some area of it) -- for bugs, security issues, or quality problems -- a directory listing is NEVER a substitute for actually opening files. Naming a file in your answer is not the same as having read it. Follow this approach:
1. list_files() to map the relevant scope. For a whole-project request that means administrator/components, components, modules, plugins, and templates -- skip libraries/, media/, cache/, tmp/, node_modules/, and vendor/ unless the user specifically asks about them, since that's framework/third-party code, not this site's own.
2. read_file() every file in scope that's plausibly relevant to what was asked -- this site's own custom PHP/JS, not everything that exists.
3. search_project() across the whole project (one call per term) for risk-relevant substrings you haven't already ruled out by reading -- this catches things outside whatever you happened to open in step 2. Follow up any hit with read_file() on that file before drawing a conclusion from it.
4. Only state something as an actual finding once you've read the file and can point to the specific line(s) -- if you never opened it, don't make claims about its contents.
5. Keep going across as many tool calls as the scope actually needs. Stopping after one or two calls on a "scan my project" request is not a scan -- it's a guess.

When you finish this kind of review, present it as a well-organized report, not a loose paragraph:
- Lead with a one- or two-sentence verdict (clean, or N issues found and the worst severity among them).
- Group findings by severity (Critical / High / Medium / Low). For each: the file path (and line number or a short quoted snippet), what's wrong, why it matters, and a concrete fix.
- Close with a short Recommendations section for anything broader than a single-file fix (patterns to avoid, areas worth a deeper look later, etc.) -- clearly separated from the findings themselves, never blended in as if it were one.
- If you checked and found nothing, say so plainly and name what you actually checked. Don't pad a clean result with generic advice presented as though it were something you discovered.
PROMPT;

        // Customer-authored project instructions (Settings > AI
        // Integrations > Custom Skill) -- appended, never replacing the
        // base prompt above, so the assistant's core safety behaviour
        // (explaining itself before mutating anything) and the
        // investigation standard above can't be overridden by whatever
        // the customer writes here.
        $customSkill = trim(\MuruguardAiHelper::getCustomSkill());
        if ($customSkill !== '') {
            $base .= "\n\nThe project owner has provided these additional project-specific instructions -- follow them alongside everything above:\n\n" . $customSkill;
        }

        return $base;
    }

    /** Dispatches a tool name/input pair to the matching MuruguardAiHelper method -- the one place a tool name string actually becomes a filesystem operation. $transactionId is only meaningful for (and only passed to) the three mutating cases -- it's how TimeMachine groups every repair one AI request makes across possibly several approved tool calls into a single rollback-able unit. */
    private function executeAiTool(string $name, array $input, string $transactionId = ''): array
    {
        switch ($name) {
            case 'list_files':
                return \MuruguardAiHelper::listFiles((string) ($input['path'] ?? ''));
            case 'read_file':
                return \MuruguardAiHelper::readFile((string) ($input['path'] ?? ''));
            case 'search_project':
                return \MuruguardAiHelper::searchProject((string) ($input['query'] ?? ''));
            case 'write_file':
                return \MuruguardAiHelper::writeFile((string) ($input['path'] ?? ''), (string) ($input['content'] ?? ''), $transactionId);
            case 'rename_file':
                return \MuruguardAiHelper::renameFile((string) ($input['from'] ?? ''), (string) ($input['to'] ?? ''), $transactionId);
            case 'delete_file':
                return \MuruguardAiHelper::deleteFile((string) ($input['path'] ?? ''), $transactionId);
            default:
                return ['ok' => false, 'error' => 'Unknown tool: ' . $name];
        }
    }

    private function callAiStep(array $conversation, ?string $provider): array
    {
        $cfgParams = ComponentHelper::getParams('com_muruguard');
        $payload = [
            'licenseKey'   => trim((string) $cfgParams->get('license_key', '')),
            'domain'       => \MuruguardHelper::currentSiteDomain(),
            'provider'     => $provider,
            'systemPrompt' => $this->aiSystemPrompt(),
            'messages'     => $conversation,
            'tools'        => $this->aiToolDefinitions(),
        ];

        // Much larger than a license check's tiny JSON reply -- an LLM
        // completion, or a tool call carrying a full file's contents (up
        // to MuruguardAiHelper's own write-size cap), can legitimately be
        // this big.
        return \MuruguardHelper::callDashboardApi('/ai/step', $payload, 512000, 60);
    }

    /**
     * The Smart AI Assistant chat panel's single entry point -- stateless,
     * ONE step per call. The browser sends the full conversation-so-far;
     * this makes exactly one call to the dashboard's /api/ai/step and
     * returns one of three outcomes:
     *   - the model gave a final answer -> {status:'done', message}
     *   - the model requested a READ-ONLY tool (list/read/search) -> this
     *     executes it immediately (no confirmation needed) and returns
     *     {status:'continue', conversation} for the browser to
     *     immediately call this same action again with
     *   - the model requested a MUTATING tool (write/rename/delete) ->
     *     returns {status:'confirm_required', toolCall, conversation}
     *     WITHOUT executing it; the browser must show a confirmation
     *     dialog and call aiexecutetool() below once the user approves.
     * Deliberately never loops itself -- see MuruguardHelper::
     * callDashboardApi()'s docblock for why the multi-step loop is
     * browser-driven rather than a single long-running PHP loop, which
     * would risk a shared host's execution time limit on anything
     * non-trivial ("scan the whole project" can take many tool round-
     * trips).
     */
    public function aichat()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        if (!\MuruguardAiHelper::isProLicenseActive()) {
            $this->jsonResponse(['error' => 'license_required'], 402);
        }

        $body = $this->readJsonBody();
        $conversation = is_array($body['conversation'] ?? null) ? $body['conversation'] : [];
        $provider = isset($body['provider']) && is_string($body['provider']) ? $body['provider'] : null;

        $result = $this->callAiStep($conversation, $provider);
        if (!$result['ok']) {
            $this->jsonResponse(['error' => $result['error']], 502);
        }

        // A transport-level success (valid JSON came back) can still
        // carry a provider-side failure -- a bad/expired API key, a rate
        // limit, the provider being down -- which the dashboard reports
        // as {error:'provider_error', message}, not a {result:...}
        // payload. Surface that message directly rather than falling
        // through to a generic "bad_response", since it's exactly what
        // the customer needs to see to fix their Settings > AI
        // Integrations config.
        if (isset($result['data']['error'])) {
            $this->jsonResponse([
                'error'   => (string) $result['data']['error'],
                'message' => (string) ($result['data']['message'] ?? ''),
            ], 502);
        }

        $step = $result['data']['result'] ?? null;
        if (!is_array($step) || !isset($step['type'])) {
            $this->jsonResponse(['error' => 'bad_response'], 502);
        }

        if ($step['type'] === 'text') {
            $this->jsonResponse(['status' => 'done', 'message' => (string) ($step['content'] ?? '')]);
        }

        if ($step['type'] === 'tool_use') {
            $toolName = (string) ($step['name'] ?? '');
            $toolCallEntry = ['id' => $step['id'] ?? '', 'name' => $toolName, 'input' => $step['input'] ?? []];
            // Gemini-only: the model's "thought signature" for this exact
            // function call, which must be echoed back verbatim once this
            // turn is replayed as history on the next aichat()/
            // aiexecutetool() call -- see aiProviders.ts's callGemini()
            // docblock on the dashboard side for why. Every other
            // provider never sets this, so it's simply absent here.
            if (isset($step['signature']) && is_string($step['signature']) && $step['signature'] !== '') {
                $toolCallEntry['signature'] = $step['signature'];
            }
            $conversation[] = [
                'role'       => 'assistant',
                'content'    => null,
                'tool_calls' => [$toolCallEntry],
            ];

            if (in_array($toolName, self::AI_MUTATING_TOOLS, true)) {
                // TimeMachine repair preview -- read-only, computed here
                // rather than trusted from the client, so what's shown in
                // the confirmation card is always what resolvePath()
                // itself would see (never a denied file's real content).
                $preview = \MuruguardAiHelper::previewMutation($toolName, (array) ($step['input'] ?? []));
                $this->jsonResponse([
                    'status'       => 'confirm_required',
                    'toolCall'     => ['id' => $step['id'] ?? '', 'name' => $toolName, 'input' => $step['input'] ?? []],
                    'preview'      => $preview,
                    'conversation' => $conversation,
                ]);
            }

            $toolResult = $this->executeAiTool($toolName, (array) ($step['input'] ?? []));
            $conversation[] = [
                'role'         => 'tool',
                'tool_call_id' => (string) ($step['id'] ?? ''),
                'content'      => json_encode($toolResult),
            ];

            $this->jsonResponse(['status' => 'continue', 'conversation' => $conversation]);
        }

        $this->jsonResponse(['error' => 'unexpected_response'], 502);
    }

    /**
     * Executes a previously-proposed MUTATING tool call after the
     * browser's confirmation dialog was approved. Never called for
     * read-only tools -- aichat() above already executes those
     * immediately without confirmation, since there's nothing
     * irreversible to approve.
     */
    public function aiexecutetool()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        if (!\MuruguardAiHelper::isProLicenseActive()) {
            $this->jsonResponse(['error' => 'license_required'], 402);
        }

        $body = $this->readJsonBody();
        $conversation = is_array($body['conversation'] ?? null) ? $body['conversation'] : [];
        $toolCall = is_array($body['toolCall'] ?? null) ? $body['toolCall'] : [];
        $toolName = (string) ($toolCall['name'] ?? '');
        // Client-generated once per user turn, reused across every
        // approved tool call in that turn (see the chat panel's
        // sendMessage()) -- a missing/malformed value just means this
        // one mutation gets its own single-entry transaction, degrading
        // gracefully rather than blocking anything (see
        // MuruguardAiHelper::normalizeTransactionId()).
        $transactionId = isset($body['transactionId']) && is_string($body['transactionId']) ? $body['transactionId'] : '';

        if (!in_array($toolName, self::AI_MUTATING_TOOLS, true)) {
            $this->jsonResponse(['error' => 'not_a_mutating_tool'], 400);
        }

        $toolResult = $this->executeAiTool($toolName, (array) ($toolCall['input'] ?? []), $transactionId);
        $conversation[] = [
            'role'         => 'tool',
            'tool_call_id' => (string) ($toolCall['id'] ?? ''),
            'content'      => json_encode($toolResult),
        ];

        $this->jsonResponse(['status' => 'continue', 'conversation' => $conversation]);
    }

    /**
     * A destructive tool call the browser decided NOT to approve --
     * still needs a tool_result message appended (every provider's tool-
     * use protocol requires one per tool_use block, Claude's especially),
     * so the conversation can continue coherently instead of leaving a
     * dangling, unanswered tool call.
     */
    public function airejecttool()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        $body = $this->readJsonBody();
        $conversation = is_array($body['conversation'] ?? null) ? $body['conversation'] : [];
        $toolCall = is_array($body['toolCall'] ?? null) ? $body['toolCall'] : [];

        $conversation[] = [
            'role'         => 'tool',
            'tool_call_id' => (string) ($toolCall['id'] ?? ''),
            'content'      => json_encode(['ok' => false, 'error' => 'The user declined to approve this action.']),
        ];

        $this->jsonResponse(['status' => 'continue', 'conversation' => $conversation]);
    }

    /**
     * TimeMachine -- restores a single snapshot or every not-yet-rolled-
     * back snapshot in a whole transaction. The one rollback entry point
     * regardless of origin: file-kind snapshots (from the AI assistant
     * OR from the non-AI cleanup actions' bulk-delete/surgical-clean
     * calls) roll back through MuruguardAiHelper, since that's the one
     * class that can safely resolve+revalidate a filesystem path; db_row
     * snapshots (from the four DB-mutating cleanup actions) roll back
     * through the model, since it owns database access. Always responds
     * 200 with per-item results rather than an opaque all-or-nothing
     * failure, so a transaction rollback can partially succeed and
     * report exactly which entries still need force=true.
     */
    public function timemachinerollback()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        if (!\MuruguardAiHelper::isProLicenseActive()) {
            $this->jsonResponse(['error' => 'license_required'], 402);
        }

        $body  = $this->readJsonBody();
        $scope = (string) ($body['scope'] ?? 'snapshot');
        $id    = (string) ($body['id'] ?? '');
        $force = !empty($body['force']);

        if ($id === '') {
            $this->jsonResponse(['error' => 'missing_id'], 400);
        }

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        if ($scope === 'transaction') {
            $fileResult   = \MuruguardAiHelper::rollbackTransaction($id, $force);
            $results      = $fileResult['results'];
            $hasConflicts = $fileResult['hasConflicts'];

            foreach (\MuruguardTimeMachineHelper::getSnapshotsForTransaction($id) as $snap) {
                if (($snap['kind'] ?? '') !== 'db_row' || !empty($snap['rolled_back_at'])) continue;
                $dbResult = $model->rollbackDbRowSnapshot($snap, $force);
                if (!$dbResult['ok'] && ($dbResult['error'] ?? '') === 'conflict') $hasConflicts = true;
                $results[] = $dbResult;
            }

            $this->jsonResponse(['ok' => true, 'results' => $results, 'hasConflicts' => $hasConflicts]);
        }

        $snap = \MuruguardTimeMachineHelper::getSnapshot($id);
        if ($snap === null) {
            $this->jsonResponse(['ok' => true, 'results' => [['ok' => false, 'snapshotId' => $id, 'error' => 'not_found']], 'hasConflicts' => false]);
        }

        $result = ($snap['kind'] ?? '') === 'db_row'
            ? $model->rollbackDbRowSnapshot($snap, $force)
            : \MuruguardAiHelper::rollbackSnapshot($id, $force);

        $this->jsonResponse([
            'ok'           => true,
            'results'      => [$result],
            'hasConflicts' => !$result['ok'] && ($result['error'] ?? '') === 'conflict',
        ]);
    }

    /** TimeMachine -- toggles the "keep this one" override that exempts a snapshot (or every snapshot in a transaction) from retention eviction. */
    public function timemachinepin()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        if (!\MuruguardAiHelper::isProLicenseActive()) {
            $this->jsonResponse(['error' => 'license_required'], 402);
        }

        $body  = $this->readJsonBody();
        $scope = (string) ($body['scope'] ?? 'snapshot');
        $id    = (string) ($body['id'] ?? '');
        $keep  = !empty($body['keep']);

        $ok = $scope === 'transaction'
            ? \MuruguardTimeMachineHelper::setKeepTransaction($id, $keep)
            : \MuruguardTimeMachineHelper::setKeep($id, $keep);

        $this->jsonResponse(['ok' => $ok]);
    }

    /** Saves the TimeMachine retention settings (Settings > AI Integrations tab) -- same storage/save pattern as every other settings method, form-submit style rather than JSON since this is an ordinary settings form, not an AJAX chat action. */
    public function savetimemachinesettings()
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        \MuruguardHelper::requireAdminAccess();

        // TimeMachine, like the AI Assistant itself, is Pro-only -- unlike
        // savedisplaysettings()'s items-per-page (a plain display
        // preference with no Pro gate), so this needs the same
        // graceful redirect+message saveprofeatures() uses rather than
        // that method's ungated pattern.
        if (!\MuruguardAiHelper::isProLicenseActive()) {
            Factory::getApplication()->enqueueMessage(Text::_('COM_MURUGUARD_AI_LICENSE_REQUIRED_MSG'), 'error');
            $this->setRedirect($this->settingsRedirectUrl());
            return;
        }

        $app = Factory::getApplication();
        $retentionDays = $app->input->getInt('timemachine_retention_days', 14);
        $retentionMax  = $app->input->getInt('timemachine_retention_max_snapshots', 500);

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $model->saveTimeMachineSettings($retentionDays, $retentionMax);

        $app->enqueueMessage(Text::_('COM_MURUGUARD_SETTINGS_SAVED_MSG'), 'message');
        $this->setRedirect($this->settingsRedirectUrl());
    }

    /**
     * Smart AI Assistant (Pro) -- one-shot AI triage for a SINGLE scan
     * finding, purely advisory. Sends the flagged file's own content plus
     * why the scanner flagged it to the AI provider and returns its
     * plain-English opinion for the admin to read alongside the finding.
     * Deliberately never mutates anything: it doesn't mark a finding
     * safe, doesn't delete it, doesn't change confidence -- the existing
     * "Mark as Safe" and delete actions remain the only things that
     * actually change a finding's state, since the AI's opinion can be
     * wrong too and a human stays the one who decides.
     *
     * A single non-agentic /ai/step call with an empty tools array (no
     * file-tool loop needed -- the file is already read locally and
     * handed over directly), unlike aichat()'s multi-turn conversation.
     */
    public function aireviewfinding()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        // "Ask AI" works on every edition now -- Pro routes through the
        // dashboard's own licensed multi-provider system (unchanged);
        // a non-Pro site with a Gemini key saved in Settings routes
        // directly to Gemini instead (see reviewOneFinding()). Only a
        // site with NEITHER is actually blocked, with a distinct error
        // the UI turns into a "configure a key" prompt rather than a
        // generic failure.
        $geminiApiKey = trim((string) ComponentHelper::getParams('com_muruguard')->get('gemini_api_key', ''));
        if (!\MuruguardAiHelper::isProLicenseActive() && $geminiApiKey === '') {
            $this->jsonResponse(['error' => 'ai_not_configured'], 402);
        }

        $body = $this->readJsonBody();
        $relPath = is_string($body['path'] ?? null) ? trim($body['path']) : '';
        if ($relPath === '') {
            $this->jsonResponse(['error' => 'missing_path'], 400);
        }

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');
        $result = $this->reviewOneFinding($model, $relPath);

        if (!$result['ok']) {
            $extra = isset($result['message']) ? ['message' => $result['message']] : [];
            $this->jsonResponse(array_merge(['error' => $result['error']], $extra), $result['httpStatus']);
        }

        $this->jsonResponse(['ok' => true, 'review' => $result['review']]);
    }

    /**
     * Shared by aireviewfinding() (single finding, Code Issues modal /
     * row shortcut) and bulkaicheck() (multi-select toolbar) -- the exact
     * same one-shot AI triage logic either way, so there's only ever one
     * place that builds the prompt and calls the dashboard. Returns a
     * plain result array instead of calling jsonResponse() itself, since
     * the bulk caller needs to keep looping after a single item fails
     * rather than have the whole request exit on the first bad one.
     */
    private function reviewOneFinding(MuruguardModelScanner $model, string $relPath): array
    {
        // Re-derives the finding's own reason(s) from the current scan
        // results rather than trusting whatever the browser sends --
        // this is read-only either way, but there's no reason to trust
        // client-supplied text over the scanner's own record when it's
        // already sitting right there.
        $findings = $model->getFileFindings();
        $finding = $findings[$relPath] ?? null;
        if ($finding === null) {
            return ['ok' => false, 'error' => 'finding_not_found', 'httpStatus' => 404];
        }

        $fileResult = \MuruguardAiHelper::readFile($relPath);
        if (!$fileResult['ok']) {
            return ['ok' => false, 'error' => 'file_unreadable', 'httpStatus' => 404];
        }

        $content = (string) $fileResult['content'];
        if (!empty($fileResult['truncated'])) {
            $content .= "\n\n[... truncated, file is larger than what's shown above ...]";
        }

        $reasons = implode('; ', (array) ($finding['reasons'] ?? []));
        $confidence = (string) ($finding['confidence'] ?? '');
        $userMessage = "File: {$relPath}\nFlagged confidence: {$confidence}\nWhy the scanner flagged it: {$reasons}\n\n--- File content ---\n{$content}";

        $cfgParams = ComponentHelper::getParams('com_muruguard');

        // Pro routes through the dashboard's own licensed multi-provider
        // system (unchanged, whatever provider that account has
        // configured/defaulted to via aiproviders()). A non-Pro site
        // never reaches that far -- it goes straight to Gemini using
        // its own locally-saved key instead. aireviewfinding()'s own
        // gate already guarantees one of these two is actually usable
        // by the time this runs.
        if (\MuruguardAiHelper::isProLicenseActive()) {
            $result = \MuruguardHelper::callDashboardApi('/ai/step', [
                'licenseKey'   => trim((string) $cfgParams->get('license_key', '')),
                'domain'       => \MuruguardHelper::currentSiteDomain(),
                'provider'     => null,
                'systemPrompt' => $this->aiReviewSystemPrompt(),
                'messages'     => [['role' => 'user', 'content' => $userMessage]],
                'tools'        => [],
            ], 512000, 60);

            if (!$result['ok']) {
                return ['ok' => false, 'error' => $result['error'], 'httpStatus' => 502];
            }
            if (isset($result['data']['error'])) {
                return [
                    'ok' => false,
                    'error' => (string) $result['data']['error'],
                    'message' => (string) ($result['data']['message'] ?? ''),
                    'httpStatus' => 502,
                ];
            }

            $step = $result['data']['result'] ?? null;
            if (!is_array($step) || ($step['type'] ?? '') !== 'text') {
                return ['ok' => false, 'error' => 'bad_response', 'httpStatus' => 502];
            }

            return ['ok' => true, 'review' => (string) ($step['content'] ?? '')];
        }

        $geminiApiKey = trim((string) $cfgParams->get('gemini_api_key', ''));
        $geminiResult = \MuruguardHelper::callGeminiApi($this->aiReviewSystemPrompt(), $userMessage, $geminiApiKey);
        if (!$geminiResult['ok']) {
            return ['ok' => false, 'error' => $geminiResult['error'] ?? 'gemini_error', 'httpStatus' => 502];
        }

        return ['ok' => true, 'review' => (string) $geminiResult['text']];
    }

    /**
     * Bulk AI review (Pro) -- the multi-select toolbar's "Check via AI"
     * action. Only ever meaningful for file-based findings (Suspicious
     * Files / Cleanable Files) since reviewOneFinding() reads real file
     * content -- a database-row finding (Super User, Menu XSS, ...) has
     * no file for the AI to read, so the JS only ever offers this button
     * on the two file tabs to begin with; this endpoint just trusts that
     * and returns finding_not_found for anything else submitted anyway,
     * rather than needing its own separate validation for it.
     *
     * Runs sequentially, not in parallel -- each call already blocks on
     * a real AI round-trip (tens of seconds is normal), so this raises
     * the same execution-time/memory allowances runScheduledCheck()'s
     * callers already do, and caps how many files one request will
     * process so a large selection can't run past a host's hard limit;
     * the client-side JS chunks a bigger selection into multiple calls
     * of this size rather than the admin needing to do that themselves.
     */
    public function bulkaicheck()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        // Same "Pro OR a Gemini key" gate as aireviewfinding() -- see its
        // own comment for why.
        $geminiApiKey = trim((string) ComponentHelper::getParams('com_muruguard')->get('gemini_api_key', ''));
        if (!\MuruguardAiHelper::isProLicenseActive() && $geminiApiKey === '') {
            $this->jsonResponse(['error' => 'ai_not_configured'], 402);
        }

        $body = $this->readJsonBody();
        $paths = is_array($body['paths'] ?? null) ? $body['paths'] : [];
        $paths = array_values(array_filter(array_map(
            fn($p) => is_string($p) ? trim($p) : '',
            $paths
        ), fn($p) => $p !== ''));

        // A one-shot AI call per file, sequentially, is genuinely slow at
        // scale -- capped well below bulkmarkfalsepositive()'s much
        // cheaper 500-item limit so one request can realistically finish
        // inside a host's execution-time window.
        if (count($paths) > 10) {
            $paths = array_slice($paths, 0, 10);
        }

        if (function_exists('set_time_limit')) {
            @set_time_limit(300);
        }
        @ini_set('memory_limit', '512M');

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        $results = [];
        foreach ($paths as $relPath) {
            $result = $this->reviewOneFinding($model, $relPath);
            $results[] = $result['ok']
                ? ['path' => $relPath, 'ok' => true, 'review' => $result['review']]
                : ['path' => $relPath, 'ok' => false, 'error' => $result['error']];
        }

        $this->jsonResponse(['ok' => true, 'results' => $results]);
    }

    /** System prompt for aireviewfinding() -- deliberately separate from aiSystemPrompt() above, since this is a narrow one-shot classification task, not the general multi-turn coding assistant. */
    private function aiReviewSystemPrompt(): string
    {
        return <<<'PROMPT'
You are helping review a single file flagged by an automated Joomla security scanner. You are given the file's path, why the scanner flagged it (a structural reason, a content-signature match, or both), and the file's actual content.

Give a short, plain-English assessment: state whether this looks like a genuine security concern, a benign/expected file that the scanner's heuristics simply don't recognize (e.g. a legitimate vendor/plugin file, a standard Joomla core file, a harmless utility script), or something you're genuinely unsure about from the content alone. Ground your answer in specifics from the actual code shown -- don't speculate about anything you weren't given.

You are being asked for an opinion only. Nothing you say takes any action -- it cannot delete, modify, or mark anything, a human reads your assessment and decides for themselves. Say plainly when you're not confident rather than guessing either way.

Keep your response to 2-4 sentences.
PROMPT;
    }

    /**
     * Proxies the Settings > AI Integrations panel's list/save/test/
     * default actions straight through to the dashboard's license-key-
     * authenticated endpoints (see app/api/license/ai-providers/* in the
     * dashboard repo) -- Joomla never stores a provider API key itself,
     * only relays the request. ai_action picks which of the 4 dashboard
     * endpoints to call.
     *
     * getskill/saveskill are handled entirely locally instead (see
     * MuruguardAiHelper::getCustomSkill()/saveCustomSkill()) -- the
     * custom-skill text is specific to THIS site's own codebase, not an
     * account-level credential, so there's no reason for it to leave
     * this server at all.
     */
    public function aiproviders()
    {
        Session::checkToken('request') or $this->jsonResponse(['error' => 'invalid_token'], 403);
        \MuruguardHelper::requireAdminAccess();

        if (!\MuruguardAiHelper::isProLicenseActive()) {
            $this->jsonResponse(['error' => 'license_required'], 402);
        }

        $app = Factory::getApplication();
        $action = $app->input->getCmd('ai_action', 'list');

        if ($action === 'getskill') {
            $this->jsonResponse(['content' => \MuruguardAiHelper::getCustomSkill()]);
        }
        if ($action === 'saveskill') {
            $body = $this->readJsonBody();
            \MuruguardAiHelper::saveCustomSkill((string) ($body['content'] ?? ''));
            $this->jsonResponse(['ok' => true]);
        }

        $routes = [
            'list'    => '/license/ai-providers/list',
            'save'    => '/license/ai-providers/save',
            'test'    => '/license/ai-providers/test',
            'default' => '/license/ai-providers/default',
        ];
        if (!isset($routes[$action])) {
            $this->jsonResponse(['error' => 'unknown_action'], 400);
        }

        $cfgParams = ComponentHelper::getParams('com_muruguard');
        $body = $this->readJsonBody();
        $payload = array_merge($body, [
            'licenseKey' => trim((string) $cfgParams->get('license_key', '')),
            'domain'     => \MuruguardHelper::currentSiteDomain(),
        ]);

        $result = \MuruguardHelper::callDashboardApi($routes[$action], $payload, 65536, 20);
        if (!$result['ok']) {
            $this->jsonResponse(['error' => $result['error']], 502);
        }

        // The gate above (isProLicenseActive()) only trusts the LOCAL
        // cached status -- it can still say "active" for up to the cache
        // window (see MuruguardHelper::LICENSE_CACHE_SECONDS) after an
        // admin revokes/deletes the license on the dashboard, since
        // nothing here proactively re-checks. This call, however,
        // just asked the dashboard directly and got an authoritative
        // answer back. If that answer says the license is no longer
        // good, force a real recheck now so the cached status (and every
        // OTHER panel that reads it -- Settings > License, the Pro
        // Features tab, isProLicenseActive() itself) reflects reality on
        // the very next load instead of a stale "Active" the site owner
        // has no reason to distrust.
        $invalidReasons = ['not_found', 'revoked', 'expired', 'site_limit_reached'];
        if (in_array((string) ($result['data']['error'] ?? ''), $invalidReasons, true)) {
            /** @var MuruguardModelScanner $model */
            $model = $this->getModel('Scanner');
            $model->getLicenseStatus(true);
        }

        $this->jsonResponse($result['data']);
    }
}