<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     MIT
 */

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;

require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/muruguard.php';
require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/timemachine.php';
require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/aiassistant.php';

/**
 * Internal control-flow signal only -- thrown from inside scanFilesystem()'s
 * walkDir() callback when a chunked scan's wall-clock deadline is reached
 * mid-directory, caught one level up around that single area's walk so the
 * area is marked truncated and the next chunk request can move on to the
 * next area instead of the whole HTTP request running past a host's
 * execution-time limit. Never escapes scanFilesystem() itself.
 */
class MuruguardScanChunkTimeout extends \RuntimeException
{
}

class MuruguardModelScanner extends BaseDatabaseModel
{
    protected string $root;
    protected array $fileFindings = [];
    protected array $dbFindings = [
        'superusers' => [], 'menu_xss' => [], 'sppb_assets' => [],
        'rogue_iconfont' => [], 'template_defacement' => [], 'template_style_xss' => [],
        'vulnerable_extensions' => [],
    ];
    protected array $seenAbs = [];
    protected ?array $registeredTemplatesCache = null;
    protected ?array $registeredPluginsCache = null;
    protected ?array $registeredComponentsCache = null;
    // Areas whose walk was cut off by a chunk deadline mid-directory rather
    // than finishing naturally -- see MuruguardScanChunkTimeout. Surfaced by
    // runScanChunk() so a pathologically large single folder is reported
    // honestly as "scanned up to the time budget" instead of silently
    // passing as complete.
    protected array $truncatedAreas = [];

    public function __construct($config = [])
    {
        parent::__construct($config);
        $this->root = JPATH_ROOT;
    }

    /**
     * Joomla's own #__extensions table is the actual source of truth for
     * "is this template really installed" -- a real, in-the-wild attack
     * seen on a live site faked EVERY filesystem-level signal at once
     * (the template folder, a templateDetails.xml manifest inside it, and
     * a matching #__template_styles row), so a check based purely on
     * what's sitting on disk can be, and was, fully spoofed. It could not,
     * however, make its faked #__extensions rows enabled -- every one of
     * them was left at enabled=0, unlike every genuinely-installed
     * template. Returns ['<client_id>|<element lowercase>' => enabled
     * (bool)] for every row of type "template", built once per request
     * and shared by both scanFilesystem() and scanDatabase() so a single
     * DB scan (in runScheduledCheck()) only queries this once. Public so
     * the view layer can also cross-reference it when deciding which tab
     * (Suspicious vs Cleanable) a template-root index.php finding
     * belongs in -- see default.php's $notDeletable closure.
     */
    public function getRegisteredTemplates(): ?array
    {
        if ($this->registeredTemplatesCache !== null) {
            return $this->registeredTemplatesCache;
        }

        try {
            $registry = [];
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['element', 'client_id', 'enabled']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('template'));
            $db->setQuery($query);
            foreach ($db->loadAssocList() ?: [] as $row) {
                $key = ((int) $row['client_id']) . '|' . strtolower((string) $row['element']);
                $registry[$key] = (bool) $row['enabled'];
            }
        } catch (\Throwable $e) {
            // Query failed for some reason -- return null (not an empty
            // array) so callers fall back to weaker filesystem-only
            // signals instead of treating a failed query as "definitely no
            // templates are registered", which would flood false positives.
            return null;
        }

        return $this->registeredTemplatesCache = $registry;
    }

    /**
     * Same idea as getRegisteredTemplates(), for plugins -- a real, live
     * compromise dropped fake plugin folders (plugins/system/data,
     * plugins/system/loader, plugins/system/core, ...) each holding a
     * self-decoding backdoor, WITH matching #__extensions rows.
     *
     * IMPORTANT: unlike templates, "enabled=0" is NOT a reliable fake
     * signal for plugins on its own -- a stock Joomla install ships
     * several genuinely core plugins disabled by default (e.g.
     * plg_authentication_ldap, plg_api-authentication_basic), so a naive
     * "disabled = suspicious" check flags every real site running with
     * Joomla's own defaults. Only a completely MISSING #__extensions row
     * (checkJunkExtensionFolder() checks array_key_exists against this
     * map) is used as the structural signal; "enabled" is still returned
     * here for callers that want it, but is deliberately not treated as
     * suspicious by itself. Components were also faked in that attack but
     * with enabled=1 -- see getRegisteredComponents() for why that needs
     * yet another signal (manifest_cache, not enabled). Returns
     * ['<folder>|<element lowercase>' => enabled (bool)] for every row of
     * type "plugin" (folder = the plugin group, e.g. "system"; element =
     * the plugin name, e.g. "log" -- together they match a
     * plugins/<folder>/<element> path).
     */
    protected function getRegisteredPlugins(): ?array
    {
        if ($this->registeredPluginsCache !== null) {
            return $this->registeredPluginsCache;
        }

        try {
            $registry = [];
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['element', 'folder', 'enabled']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'));
            $db->setQuery($query);
            foreach ($db->loadAssocList() ?: [] as $row) {
                $key = strtolower((string) $row['folder']) . '|' . strtolower((string) $row['element']);
                $registry[$key] = (bool) $row['enabled'];
            }
        } catch (\Throwable $e) {
            return null;
        }

        return $this->registeredPluginsCache = $registry;
    }

    /**
     * Components equivalent of getRegisteredTemplates()/getRegisteredPlugins()
     * -- but keyed on a DIFFERENT signal. A real, live compromise faked
     * components/com_feed, com_stat, com_base, com_track, com_util with
     * matching #__extensions rows left ENABLED (unlike the disabled fake
     * template/plugin rows), so "enabled" doesn't discriminate here at
     * all. What a raw SQL-inserted fake row realistically won't have is a
     * populated manifest_cache -- Joomla's installer generates this JSON
     * blob (name, version, description, ...) from the extension's XML
     * manifest at install time for every genuinely-installed extension,
     * including every core component; an attacker forging a single
     * #__extensions row directly has no reason to also hand-craft a
     * matching manifest_cache blob. Returns ['<element lowercase>' =>
     * hasManifestCache (bool)] for every row of type "component".
     */
    protected function getRegisteredComponents(): ?array
    {
        if ($this->registeredComponentsCache !== null) {
            return $this->registeredComponentsCache;
        }

        try {
            $registry = [];
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['element', 'manifest_cache']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'));
            $db->setQuery($query);
            foreach ($db->loadAssocList() ?: [] as $row) {
                $key = strtolower((string) $row['element']);
                $cache = trim((string) $row['manifest_cache']);
                $registry[$key] = $cache !== '' && $cache !== '{}' && strtolower($cache) !== 'null';
            }
        } catch (\Throwable $e) {
            return null;
        }

        return $this->registeredComponentsCache = $registry;
    }

    /**
     * The scan areas the user ticked in the pre-scan directory picker.
     * Stored in the session so both the fresh scan and the cached-result
     * re-display honour the same selection. An empty selection means
     * "scan everything" (backwards-compatible default).
     */
    protected function selectedAreas(): array
    {
        return (array) Factory::getApplication()->getSession()->get('muruguard.scan_areas', []);
    }

    /** True if $key was selected (or if nothing was explicitly selected). */
    protected function isAreaSelected(string $key): bool
    {
        $sel = $this->selectedAreas();
        return empty($sel) || in_array($key, $sel, true);
    }

    // ------------------------------------------------------------------
    // Public accessors used by the view
    // ------------------------------------------------------------------

    /**
     * Whatever this model instance has already found, in memory, right
     * now -- no session cache, no re-scan. Deliberately the ONLY safe way
     * to read findings after runScan()/runScanChunk()/runScheduledCheck()
     * on the SAME instance: getFileFindings() below re-runs scanFilesystem()
     * whenever the session cache is empty or stale, which is the normal
     * case in a cron/webcron request (no browser session to have cached
     * anything) -- calling it there would silently run a second, wasted
     * filesystem walk on top of results a caller already has, purely
     * because it was written for the browser-page-load use case.
     */
    public function getCurrentFileFindings(): array
    {
        return $this->fileFindings;
    }

    public function getFileFindings(): array
    {
        $session = Factory::getApplication()->getSession();
        $forceRescan = Factory::getApplication()->input->getBool('rescan', false);

        if (!$forceRescan) {
            $cached = $session->get('muruguard.filefindings');
            $cachedAt = $session->get('muruguard.filefindings_time', 0);
            if (is_array($cached) && (time() - $cachedAt) < 300) {
                $this->fileFindings = $cached;
                return $this->fileFindings;
            }
        }

        $this->scanFilesystem();
        $session->set('muruguard.filefindings', $this->fileFindings);
        $session->set('muruguard.filefindings_time', time());
        return $this->fileFindings;
    }

    public function getDbFindings(): array
    {
        $this->scanDatabase();
        return $this->dbFindings;
    }

    /** True if a scan result is already sitting in the session cache. */
    public function hasCachedScan(): bool
    {
        $cached = Factory::getApplication()->getSession()->get('muruguard.filefindings');
        return is_array($cached);
    }

    /**
     * Called by the controller's scan() task.
     * Forces a fresh filesystem walk, stores result in session, returns time.
     */
    public function runScan(): int
    {
        $session = Factory::getApplication()->getSession();
        $this->scanFilesystem();
        $now = time();
        $session->set('muruguard.filefindings', $this->fileFindings);
        $session->set('muruguard.filefindings_time', $now);
        return $now;
    }

    /**
     * Full scan + diff-against-last-run, for the scheduled/webcron entry
     * point (see ScannerController::scheduledcheck()). There's no HTTP
     * session in a cron context, so the set of finding keys from the
     * PREVIOUS run is persisted in a small JSON file this component owns
     * (see loadLastScanKeys()/saveLastScanKeys() below) rather than the
     * session -- no new DB table, and deliberately NOT the component's
     * config params (see scanHistoryFilePath() for why).
     *
     * Deliberately never sends anything itself -- it only decides WHAT is
     * new, so the Joomla-Mailer-specific code stays in the controller.
     * On the very first run ever (no previous snapshot exists yet) this
     * only records a baseline and reports isFirstRun = true, so the
     * caller can skip alerting on a site's entire pre-existing finding
     * list the first time this ever runs.
     */
    /**
     * Deletes stale (>24h old, never a directory, never one of the
     * well-known protective stubs) files from Joomla's own tmp/ folder --
     * see MuruguardHelper::cleanupStaleTmpFiles() for exactly what
     * "stale" means and why it's this conservative. Reads the SAME
     * tmp_path Joomla's own core config uses, falling back to the
     * conventional <root>/tmp only if that config value is somehow empty
     * (never seen in practice, but cheap to guard against).
     */
    public function cleanupTmpFolder(): array
    {
        $tmpPath = trim((string) Factory::getConfig()->get('tmp_path', ''));
        if ($tmpPath === '') $tmpPath = $this->root . '/tmp';
        return MuruguardHelper::cleanupStaleTmpFiles($tmpPath, 24);
    }

    /**
     * Single-glance security score -- assembles the signal array
     * MuruguardHelper::computeSecurityScore() scores, from data this
     * scanner already has lying around (nothing new is computed here).
     * Deliberately doesn't attempt a Joomla-core-version or PHP-version
     * "is this current" check -- that needs either a live call to
     * Joomla's own update server or a hand-maintained latest-version
     * constant that would silently go stale, neither of which this
     * method should take on as a side effect of a read-only summary
     * widget. Safe to call on every Dashboard page load: every input is
     * either already-cached params or a fast local read (findings
     * counts, .htaccess file parse), no new network calls.
     */
    public function getSecurityScore(): array
    {
        $cfgParams = ComponentHelper::getParams('com_muruguard');

        $htaccess = MuruguardHelper::getHtaccessSuggestions(JPATH_ROOT);
        $htTotal = count($htaccess['checks']);
        $htPresent = count(array_filter($htaccess['checks'], fn($c) => $c['present']));

        // Excludes 'vulnerable_extensions' -- that bucket is already
        // scored on its own below with its own (steeper) weight; folding
        // it into open_findings too would penalize the same signal twice.
        $dbFindingsCount = 0;
        foreach ($this->getDbFindings() as $category => $rows) {
            if ($category === 'vulnerable_extensions') continue;
            $dbFindingsCount += is_array($rows) ? count($rows) : 0;
        }

        return MuruguardHelper::computeSecurityScore([
            'https'                      => \Joomla\CMS\Uri\Uri::getInstance()->isSsl(),
            'shield_enabled'              => (bool) $cfgParams->get('shield_enabled', 0),
            'backend_auth_enabled'        => (bool) $cfgParams->get('backend_auth_enabled', 0),
            'waf_enabled'                 => (bool) $cfgParams->get('waf_enabled', 0),
            'htaccess_checks_present'     => $htPresent,
            'htaccess_checks_total'       => $htTotal,
            'vulnerable_extension_count'  => count($this->getDbFindings()['vulnerable_extensions'] ?? []),
            'open_findings'               => count($this->getFileFindings()) + $dbFindingsCount,
        ]);
    }

    public function runScheduledCheck(): array
    {
        // Automatic tmp/ cleanup -- opt-in, runs ahead of the scan itself
        // so a dropper sitting in tmp/ that's about to be swept never
        // shows up as a "just found, now suddenly gone" flicker in the
        // SAME run's findings.
        $cfgParams = ComponentHelper::getParams('com_muruguard');
        if ((bool) $cfgParams->get('harden_tmp_cleanup_enabled', 0)) {
            try {
                $this->cleanupTmpFolder();
            } catch (\Throwable $e) {
                // Never let tmp housekeeping block the scan itself.
            }
        }

        $this->scanFilesystem();
        $this->scanDatabase();

        // Pro: File Integrity Monitoring -- folds any baseline drift into
        // $this->fileFindings before the new-vs-previous-run diff below,
        // so a drifted file rides the exact same email/webhook alert
        // pipeline as a signature-based finding, with no separate
        // notification code needed. No-op (and no baseline to check)
        // for a non-Pro site, since a baseline can only exist if one was
        // built while Pro was active.
        if (($this->getLicenseStatus()['status'] ?? '') === 'active') {
            $this->mergeInFimDrift();
        }

        $currentKeys = array_keys($this->fileFindings);
        sort($currentKeys);

        $previousKeys = $this->loadLastScanKeys();
        $this->saveLastScanKeys($currentKeys);

        $newKeys = $previousKeys === null ? [] : array_values(array_diff($currentKeys, $previousKeys));
        $newFindings = [];
        foreach ($newKeys as $rel) {
            if (isset($this->fileFindings[$rel])) $newFindings[$rel] = $this->fileFindings[$rel];
        }

        // Autopilot Mode (Pro) -- only ever considers NEWLY-appeared
        // findings from a run that has an established baseline to compare
        // against ($previousKeys !== null). A first-ever scan on an
        // existing site has no baseline of what's "new" vs. always-been-
        // there, so every finding looks new and auto-fixing on that
        // signal alone would be far riskier than on a genuinely fresh
        // finding on a previously-clean site.
        $autopilot = ['autoFixedCount' => 0, 'reviewedCount' => 0];
        if ($previousKeys !== null && !empty($newFindings)) {
            $cfgParams = ComponentHelper::getParams('com_muruguard');
            if ((bool) $cfgParams->get('autopilot_enabled', 0) && MuruguardAiHelper::isProLicenseActive()) {
                $autopilot = $this->runAutopilotPass($newFindings);
                foreach ($autopilot['autoFixed'] as $rel) {
                    unset($newFindings[$rel]);
                    unset($this->fileFindings[$rel]);
                }
            }
        }

        return [
            'newFindings'       => $newFindings,
            'newCount'          => count($newFindings),
            'totalCount'        => count($this->fileFindings),
            'isFirstRun'        => $previousKeys === null,
            'autopilotFixed'    => $autopilot['autoFixedCount'],
            'autopilotReviewed' => $autopilot['reviewedCount'],
        ];
    }

    /**
     * Autopilot Mode (Pro) -- for each candidate finding matching one of
     * the narrow AUTOPILOT_ELIGIBLE_SIGNATURES entries (see getSignatures()'
     * own docblock for exactly why those four and no others), gets an
     * INDEPENDENT AI verdict before touching anything, and only deletes
     * (via the same deleteTargets() every manual/AI-Assistant delete
     * already goes through -- TimeMachine-snapshotted, restorable from
     * Backup & Restore like any other repair) when that verdict is an
     * unambiguous MALICIOUS. Fails closed at every step: a finding whose
     * signature isn't in the allowlist, that's already dismissed as a
     * false positive, or whose AI review errors/times out/returns
     * anything other than a clean MALICIOUS verdict is left completely
     * alone as an ordinary finding for the admin to review manually --
     * autopilot only ever REMOVES items from the admin's queue by fixing
     * them, never by silently suppressing them.
     *
     * @param array $candidateFindings rel => finding, same shape as $this->fileFindings
     * @return array{autoFixed: list<string>, autoFixedCount: int, reviewedCount: int, reviews: list<array>}
     */
    private function runAutopilotPass(array $candidateFindings): array
    {
        $sig = MuruguardHelper::getSignatures();
        $eligible = $sig['AUTOPILOT_ELIGIBLE_SIGNATURES'] ?? [];
        $falsePositives = MuruguardHelper::getFalsePositiveLookup();

        $autoFixed = [];
        $reviews = [];

        foreach ($candidateFindings as $rel => $finding) {
            if (($finding['type'] ?? '') !== 'file') continue; // no content for the AI to read on a directory

            $reasons = (array) ($finding['reasons'] ?? []);
            $matchedSignature = null;
            foreach ($reasons as $r) {
                foreach ($eligible as $sigName) {
                    if (stripos((string) $r, "Content signature: {$sigName} ") === 0) {
                        $matchedSignature = $sigName;
                        break 2;
                    }
                }
            }
            if ($matchedSignature === null) continue; // not an autopilot-eligible signature -- ordinary finding, untouched

            $fingerprint = MuruguardHelper::fingerprintReasons($reasons);
            if (MuruguardHelper::isFalsePositive($falsePositives, 'file', $rel, $fingerprint)) continue;

            $verdict = $this->verifyFindingWithAi($rel, $finding);
            $reviews[] = ['path' => $rel, 'signature' => $matchedSignature, 'verdict' => $verdict['verdict'], 'reason' => $verdict['reason']];

            if ($verdict['verdict'] !== 'MALICIOUS') continue; // LIKELY_FALSE_POSITIVE, UNCERTAIN, or a failed/unparseable call -- never auto-act

            // deleteTargets() calls getFileFindings() internally, which
            // falls back to a full re-scan when the session cache is cold
            // (normal for a webcron-triggered scheduled run, no browser
            // session continuity) -- at most one extra full scan per
            // autopilot pass (later calls in this loop hit the
            // now-populated cache), never one per file. Wasteful but
            // harmless: it only makes $this->fileFindings MORE current,
            // and this method never reads $this->fileFindings itself,
            // only the stable local $candidateFindings copy.
            // deleteTargets() itself decides whether the delete actually
            // happened (protected path, vanished, unreadable, ...) via its
            // own $flash messages -- re-check the file is really gone
            // rather than trusting the call didn't throw.
            $this->deleteTargets([$rel]);
            if (!is_file($this->root . '/' . $rel)) {
                $autoFixed[] = $rel;
                MuruguardHelper::recordAttackLogEntry([
                    'type' => 'autopilot', 'time' => time(), 'ip' => '', 'blocked' => false,
                    'rule' => 'autopilot_' . $matchedSignature, 'severity' => 'high',
                    'why' => "Autopilot auto-removed this file: content signature {$matchedSignature}, AI-confirmed malicious ({$verdict['reason']}). TimeMachine snapshot taken -- restorable from Backup & Restore.",
                    'matched' => $rel,
                ]);
            }
        }

        return [
            'autoFixed'      => $autoFixed,
            'autoFixedCount' => count($autoFixed),
            'reviewedCount'  => count($reviews),
            'reviews'        => $reviews,
        ];
    }

    /**
     * One-shot, structured-output AI classification -- deliberately
     * separate from the human-facing "Check via AI" review (see
     * MuruguardControllerScanner::reviewOneFinding()/aiReviewSystemPrompt(),
     * which asks for free-form prose a human reads and decides on). This
     * one drives an automated decision, so it demands a strict
     * machine-parseable verdict line and fails closed (UNCERTAIN) on
     * absolutely anything unexpected: an API error, a malformed response,
     * or output that doesn't match the required format. UNCERTAIN and
     * LIKELY_FALSE_POSITIVE are handled identically by the caller -- only
     * a clean, parseable MALICIOUS ever leads to a delete.
     *
     * Known, accepted residual risk: a file's own content is what's sent
     * to the model, so a sufficiently model-aware attacker could attempt
     * a prompt-injection payload inside the flagged file trying to talk
     * the reviewer into LIKELY_FALSE_POSITIVE/UNCERTAIN for THEIR OWN
     * file -- inherent to any AI-based classifier, not fixable by response
     * parsing (verified fail-closed against malformed/adversarial OUTPUT
     * shapes, not model-level manipulation of the verdict itself). The
     * blast radius is bounded either way: a successful bypass here only
     * means the file falls back to being an ordinary reported finding
     * (exactly today's behavior without Autopilot at all), never a
     * silent miss, and the reverse case -- getting an unrelated
     * LEGITIMATE file wrongly auto-deleted -- would require controlling
     * that other file's own content, which an attacker manipulating
     * their own dropped file's content cannot do.
     */
    private function verifyFindingWithAi(string $relPath, array $finding): array
    {
        $fileResult = MuruguardAiHelper::readFile($relPath);
        if (!$fileResult['ok']) {
            return ['verdict' => 'UNCERTAIN', 'reason' => 'Could not read the file to verify it.'];
        }

        $content = (string) $fileResult['content'];
        if (!empty($fileResult['truncated'])) {
            $content .= "\n\n[... truncated, file is larger than what's shown above ...]";
        }

        $reasons = implode('; ', (array) ($finding['reasons'] ?? []));
        $userMessage = "File: {$relPath}\nWhy the scanner flagged it: {$reasons}\n\n--- File content ---\n{$content}";

        $cfgParams = ComponentHelper::getParams('com_muruguard');
        $result = MuruguardHelper::callDashboardApi('/ai/step', [
            'licenseKey'   => trim((string) $cfgParams->get('license_key', '')),
            'domain'       => MuruguardHelper::currentSiteDomain(),
            'provider'     => null,
            'systemPrompt' => self::autopilotVerifySystemPrompt(),
            'messages'     => [['role' => 'user', 'content' => $userMessage]],
            'tools'        => [],
        ], 512000, 60);

        if (!$result['ok'] || isset($result['data']['error'])) {
            return ['verdict' => 'UNCERTAIN', 'reason' => 'AI verification call failed -- left for manual review rather than risking a wrong auto-delete.'];
        }

        $step = $result['data']['result'] ?? null;
        if (!is_array($step) || ($step['type'] ?? '') !== 'text') {
            return ['verdict' => 'UNCERTAIN', 'reason' => 'Unexpected AI response shape.'];
        }

        $text = (string) ($step['content'] ?? '');
        $verdict = 'UNCERTAIN';
        if (preg_match('/VERDICT:\s*(MALICIOUS|LIKELY_FALSE_POSITIVE|UNCERTAIN)/i', $text, $m)) {
            $verdict = strtoupper($m[1]);
        }
        $reason = $text;
        if (preg_match('/REASON:\s*(.+)/is', $text, $rm)) {
            $reason = trim($rm[1]);
        }

        return ['verdict' => $verdict, 'reason' => $reason];
    }

    private static function autopilotVerifySystemPrompt(): string
    {
        return <<<'PROMPT'
You are a strict, fully-automated triage step inside a security scanner's Autopilot Mode. The file you are given already matched one of a small, hand-picked set of content signatures with essentially no legitimate/false-positive history (a raw incoming request superglobal fed directly into eval/assert/shell_exec, or a secret-cookie-gated eval). Your ONLY job is to catch the rare case where THIS SPECIFIC file is still a false positive before it gets deleted with no human ever reviewing it.

Respond in EXACTLY this format and nothing else, two lines:
VERDICT: MALICIOUS
REASON: <one sentence, grounded in the specific code shown>

or:
VERDICT: LIKELY_FALSE_POSITIVE
REASON: <one sentence>

or:
VERDICT: UNCERTAIN
REASON: <one sentence>

Default to UNCERTAIN unless you have a clear, specific reason grounded in the actual content shown to say otherwise. Both LIKELY_FALSE_POSITIVE and UNCERTAIN mean the file will NOT be deleted and a human will review it instead -- only answer MALICIOUS when you are genuinely confident, since that answer alone triggers an automatic, unattended delete.
PROMPT;
    }

    /**
     * Deliberately a plain JSON file under this component's own data/
     * folder, NOT a key inside #__extensions.params -- Joomla's own
     * Global Configuration save for this component replaces that whole
     * params blob with just the config.xml-declared fields, which would
     * silently wipe an internal bookkeeping key living there every time
     * an admin saves Options, with no error or warning. A dedicated file
     * is immune to that entirely and needs no schema/migration.
     */
    private function scanHistoryFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/scan-history.php';
        MuruguardHelper::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/scan-history.json', $new);
        return $new;
    }

    /** Null means the scheduled check has never run on this site. For the Settings panel's "Last run" indicator. */
    public function getLastScheduledRunTime(): ?int
    {
        $path = $this->scanHistoryFilePath();
        if (!is_file($path)) return null;

        $contents = @file_get_contents($path);
        if ($contents === false) return null;

        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        return is_array($decoded) && isset($decoded['saved_at']) ? (int) $decoded['saved_at'] : null;
    }

    /** Null means "never run before" (as opposed to an empty array, which means the last run found nothing). */
    private function loadLastScanKeys(): ?array
    {
        $path = $this->scanHistoryFilePath();
        if (!is_file($path)) return null;

        $contents = @file_get_contents($path);
        if ($contents === false) return null;

        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        if (!is_array($decoded) || !isset($decoded['keys']) || !is_array($decoded['keys'])) return null;
        return $decoded['keys'];
    }

    private function saveLastScanKeys(array $keys): void
    {
        $path = $this->scanHistoryFilePath();
        @file_put_contents($path, MuruguardHelper::dataFileStubPrefix() . json_encode(['keys' => $keys, 'saved_at' => time()]));
    }

    // ------------------------------------------------------------------
    // Chunked / resumable scanning
    //
    // A single "Run a Scan" click used to run the entire filesystem+DB
    // scan inside one HTTP request -- fine for a small site, but a large
    // one (many extensions, big vendor/media trees) could genuinely
    // outrun a host's max_execution_time before finishing, which surfaced
    // to the admin as a bare "500 - Whoops" with no results at all. Each
    // call to runScanChunk() below instead does AS MUCH work as fits in a
    // fixed wall-clock budget (one SCAN_CONFIG directory at a time, plus
    // the webroot/core-entry checks and the DB scan as their own single
    // items), persists progress to a small data file, and returns
    // immediately -- the scanner.php view's JS then calls it again, and
    // again, until it reports done. No single request can ever run longer
    // than the budget, regardless of how large the site is.
    // ------------------------------------------------------------------

    /** Wall-clock budget per HTTP request/chunk call -- comfortably inside even a conservative host's default execution-time limit. */
    private const CHUNK_TIME_BUDGET_SECONDS = 20;
    public const CHUNK_WEBROOT_CORE_KEY = '__webroot_core__';
    public const CHUNK_DATABASE_KEY = '__database__';

    /** Ordered list of chunk-queue items, respecting the user's current area selection -- same selection getFileFindings()/runScan() already honour. */
    private function buildChunkQueue(): array
    {
        $sig = MuruguardHelper::getSignatures();
        $queue = [];
        foreach (array_keys($sig['SCAN_CONFIG']) as $relDir) {
            if ($this->isAreaSelected($relDir)) $queue[] = $relDir;
        }
        if ($this->isAreaSelected('webroot') || $this->isAreaSelected('core_entry')) {
            $queue[] = self::CHUNK_WEBROOT_CORE_KEY;
        }
        if ($this->isAreaSelected('database')) {
            $queue[] = self::CHUNK_DATABASE_KEY;
        }
        return $queue;
    }

    /**
     * Deliberately the same stub-protected data-file technique as
     * scanHistoryFilePath() (see that method's own comment for why this
     * is never session-only or component-params) -- a chunked scan of a
     * genuinely huge site can span several minutes across many chunk
     * calls, longer than it's safe to assume a session survives, and
     * Global Configuration saves would otherwise be able to wipe it.
     */
    private function scanProgressFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/scan-progress.php';
    }

    private function loadScanProgress(): ?array
    {
        $path = $this->scanProgressFilePath();
        if (!is_file($path)) return null;
        $contents = @file_get_contents($path);
        if ($contents === false) return null;
        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : null;
    }

    private function saveScanProgress(array $progress): void
    {
        @file_put_contents($this->scanProgressFilePath(), MuruguardHelper::dataFileStubPrefix() . json_encode($progress));
    }

    /**
     * Runs one chunk's worth of work (bounded by CHUNK_TIME_BUDGET_SECONDS)
     * and returns progress for the calling AJAX loop.
     *
     * @param bool $reset Start a brand-new scan, abandoning any in-progress
     *   chunked scan -- passed true only by the very first call of a fresh
     *   "Run a Scan" click; every follow-up call from the same run passes
     *   false so it continues the existing queue instead of restarting it.
     * @return array{done:bool,completedCount:int,totalCount:int,currentArea:?string,truncated:list<string>}
     */
    public function runScanChunk(bool $reset = false): array
    {
        $progress = $reset ? null : $this->loadScanProgress();

        if ($progress === null || !empty($progress['done'])) {
            $queue = $this->buildChunkQueue();
            $progress = [
                'queue'      => $queue,
                'completed'  => [],
                'findings'   => [],
                'dbFindings' => $this->dbFindings,
                'truncated'  => [],
                'totalItems' => count($queue),
                'startedAt'  => time(),
                'updatedAt'  => time(),
                'done'       => false,
            ];
        }

        $deadline = microtime(true) + self::CHUNK_TIME_BUDGET_SECONDS;

        while (!empty($progress['queue']) && microtime(true) < $deadline) {
            $item = array_shift($progress['queue']);

            if ($item === self::CHUNK_DATABASE_KEY) {
                $this->scanDatabase();
                foreach ($this->dbFindings as $category => $rows) {
                    $progress['dbFindings'][$category] = $rows;
                }
            } elseif ($item === self::CHUNK_WEBROOT_CORE_KEY) {
                $this->fileFindings = [];
                $this->truncatedAreas = [];
                $this->scanFilesystem([], true, $deadline);
                $progress['findings'] = array_merge($progress['findings'], $this->fileFindings);
                $progress['truncated'] = array_merge($progress['truncated'], array_keys($this->truncatedAreas));
            } else {
                $this->fileFindings = [];
                $this->truncatedAreas = [];
                $this->scanFilesystem([$item], false, $deadline);
                $progress['findings'] = array_merge($progress['findings'], $this->fileFindings);
                $progress['truncated'] = array_merge($progress['truncated'], array_keys($this->truncatedAreas));
            }

            $progress['completed'][] = $item;
        }

        $progress['updatedAt'] = time();
        $progress['done'] = empty($progress['queue']);

        if ($progress['done']) {
            // Publish through the exact same session keys the unchunked
            // runScan()/getFileFindings() path already uses, so the results
            // view renders identically regardless of which path produced
            // them -- chunking only changes HOW the scan runs, never the
            // shape of its output.
            $session = Factory::getApplication()->getSession();
            $session->set('muruguard.filefindings', $progress['findings']);
            $session->set('muruguard.filefindings_time', time());
            $this->fileFindings = $progress['findings'];
            $this->dbFindings   = $progress['dbFindings'];
        }

        $this->saveScanProgress($progress);

        return [
            'done'           => $progress['done'],
            'completedCount' => count($progress['completed']),
            'totalCount'     => $progress['totalItems'],
            'currentArea'    => $progress['done'] ? null : ($progress['queue'][0] ?? null),
            'truncated'      => array_values(array_unique($progress['truncated'])),
        ];
    }

    // ------------------------------------------------------------------
    // File Integrity Monitoring (Pro)
    //
    // Signature-based scanning only catches content matching a KNOWN
    // pattern. A payload hand-inserted into an already-trusted file (a
    // legitimate plugin's own PHP, for instance) can dodge every
    // signature check while still being a real backdoor. FIM catches
    // that class of compromise instead: hash every file once as a
    // "known good" baseline, then flag any file whose content no longer
    // matches that hash -- independent of whether the new content looks
    // malicious by pattern-matching at all.
    //
    // Deliberately narrower than a naive "diff everything": only files
    // that exist in BOTH the baseline and the current scan, with a
    // DIFFERENT hash, are reported. A brand-new file since baseline is
    // left to the regular scanner's own unrecognized-file/signature
    // checks (which already cover "new"), and a file the baseline no
    // longer sees at all isn't reported either -- keeping this signal
    // narrowly about "a file that used to be there changed", the one
    // thing nothing else in this scanner checks for. Confidence is
    // deliberately 'medium' (see recordFinding()'s $highSignals list --
    // this reason text avoids every trigger word in it on purpose): a
    // legitimate extension/core update changes files too, and this has
    // no way to distinguish that from tampering on its own. The baseline
    // is never updated automatically for exactly that reason -- only an
    // explicit "Rebuild Baseline" click moves it forward.
    // ------------------------------------------------------------------

    /** Ordered list of hashable directory keys, respecting the user's current area selection. Deliberately just the SCAN_CONFIG dirs -- webroot/core-entry files already have stronger, official-checksum-based integrity checking (see getCoreChecksumManifest()). */
    private function buildFimQueue(): array
    {
        $sig = MuruguardHelper::getSignatures();
        $queue = [];
        foreach (array_keys($sig['SCAN_CONFIG']) as $relDir) {
            if ($this->isAreaSelected($relDir)) $queue[] = $relDir;
        }
        return $queue;
    }

    /**
     * Hashes every file under one SCAN_CONFIG directory. Uses hash_file()
     * (streams the file rather than loading it fully into memory like the
     * content-signature scanner's file_get_contents() does), so this
     * deliberately does NOT apply the max_file_scan_size cap that content
     * scanning uses -- there's no memory-pressure reason to skip a large
     * file here. Excludes this scanner's own transient log/backup files
     * for the same reason scanFilesystem() does: without this, the
     * scanner's own operation would constantly "change" the baseline.
     */
    private function hashDirectoryFiles(string $relDir, ?float $deadline): array
    {
        $dir = $this->root . '/' . $relDir;
        if (!is_dir($dir)) return ['hashes' => [], 'truncated' => false];

        $sig = MuruguardHelper::getSignatures();
        $selfLogPattern = '/^\.muruguard-[a-f0-9]{16}\.(log|lock)$/i';
        $selfBackupPattern = '/\.muruguard-\d{8}-\d{6}\.bak$/i';
        $hashes = [];
        $truncated = false;

        try {
            MuruguardHelper::walkDir($dir, function (string $path, bool $isDir) use (&$hashes, $deadline, $sig, $selfLogPattern, $selfBackupPattern) {
                if ($deadline !== null && microtime(true) > $deadline) {
                    throw new MuruguardScanChunkTimeout();
                }
                if ($isDir) return;
                foreach ($sig['SAFE_COMPONENT_PATHS'] as $safeFrag) {
                    if (stripos($path, $safeFrag) !== false) return;
                }
                if (preg_match('#/tmp/install_[a-z0-9]+(/|$)#i', $path)) return;
                $basename = basename($path);
                if (preg_match($selfLogPattern, $basename) || preg_match($selfBackupPattern, $basename)) return;

                $hash = @hash_file('sha256', $path);
                if ($hash === false) return;
                $rel = ltrim(str_replace($this->root, '', $path), '/');
                $hashes[$rel] = $hash;
            });
        } catch (MuruguardScanChunkTimeout $e) {
            $truncated = true;
        }

        return ['hashes' => $hashes, 'truncated' => $truncated];
    }

    private function fimBaselineFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/fim-baseline.php';
    }

    private function fimProgressFilePath(string $mode): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/fim-' . ($mode === 'build' ? 'build' : 'check') . '-progress.php';
    }

    public function loadFimBaseline(): ?array
    {
        $path = $this->fimBaselineFilePath();
        if (!is_file($path)) return null;
        $contents = @file_get_contents($path);
        if ($contents === false) return null;
        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : null;
    }

    private function saveFimBaseline(array $baseline): void
    {
        @file_put_contents($this->fimBaselineFilePath(), MuruguardHelper::dataFileStubPrefix() . json_encode($baseline));
    }

    private function loadFimProgress(string $mode): ?array
    {
        $path = $this->fimProgressFilePath($mode);
        if (!is_file($path)) return null;
        $contents = @file_get_contents($path);
        if ($contents === false) return null;
        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : null;
    }

    private function saveFimProgress(string $mode, array $progress): void
    {
        @file_put_contents($this->fimProgressFilePath($mode), MuruguardHelper::dataFileStubPrefix() . json_encode($progress));
    }

    /** For the Pro settings panel's baseline status card. */
    public function getFimBaselineStatus(): array
    {
        $baseline = $this->loadFimBaseline();
        if ($baseline === null || empty($baseline['hashes'])) {
            return ['exists' => false, 'fileCount' => 0, 'createdAt' => null];
        }
        return [
            'exists'    => true,
            'fileCount' => count($baseline['hashes']),
            'createdAt' => (int) ($baseline['createdAt'] ?? 0),
        ];
    }

    /**
     * Chunked baseline build -- same bounded-per-request, resumable-via-
     * progress-file pattern as runScanChunk(), reused here rather than
     * reinvented since hashing a genuinely large site has the exact same
     * "one request can't do it all" problem scanning did.
     */
    public function runFimBuildChunk(bool $reset = false): array
    {
        $progress = $reset ? null : $this->loadFimProgress('build');

        if ($progress === null || !empty($progress['done'])) {
            $queue = $this->buildFimQueue();
            $progress = [
                'queue'      => $queue,
                'completed'  => [],
                'hashes'     => [],
                'truncated'  => [],
                'totalItems' => count($queue),
                'startedAt'  => time(),
                'updatedAt'  => time(),
                'done'       => false,
            ];
        }

        $deadline = microtime(true) + self::CHUNK_TIME_BUDGET_SECONDS;

        while (!empty($progress['queue']) && microtime(true) < $deadline) {
            $item = array_shift($progress['queue']);
            $result = $this->hashDirectoryFiles($item, $deadline);
            $progress['hashes'] = array_merge($progress['hashes'], $result['hashes']);
            if ($result['truncated']) $progress['truncated'][] = $item;
            $progress['completed'][] = $item;
        }

        $progress['updatedAt'] = time();
        $progress['done'] = empty($progress['queue']);

        if ($progress['done']) {
            $this->saveFimBaseline([
                'hashes'    => $progress['hashes'],
                'fileCount' => count($progress['hashes']),
                'createdAt' => time(),
            ]);
        }

        $this->saveFimProgress('build', $progress);

        return [
            'done'           => $progress['done'],
            'completedCount' => count($progress['completed']),
            'totalCount'     => $progress['totalItems'],
            'currentArea'    => $progress['done'] ? null : ($progress['queue'][0] ?? null),
            'truncated'      => array_values(array_unique($progress['truncated'])),
        ];
    }

    /**
     * Merges freshly-found findings into an existing findings array
     * without clobbering an entry the main scan already recorded for the
     * same path -- FIM runs as its own separate pass, potentially after a
     * scan already populated the session, so overwriting outright would
     * silently drop whatever the signature scanner found on that file.
     */
    private function mergeFindingsInto(array &$target, array $newFindings): void
    {
        foreach ($newFindings as $rel => $finding) {
            if (isset($target[$rel])) {
                $existingReasons = $target[$rel]['reasons'] ?? [];
                $mergedReasons = array_values(array_unique(array_merge($existingReasons, $finding['reasons'] ?? [])));
                $target[$rel]['reasons'] = $mergedReasons;
                $target[$rel]['reason'] = implode(' | ', $mergedReasons);
                if (($finding['confidence'] ?? 'medium') === 'high') {
                    $target[$rel]['confidence'] = 'high';
                }
            } else {
                $target[$rel] = $finding;
            }
        }
    }

    /**
     * Chunked integrity check against the existing baseline. A no-op
     * (returns done immediately with an 'error' key) if no baseline has
     * ever been built. On completion, merges any drift findings into the
     * SAME session key the regular scan uses, so they show up in the
     * normal results tabs rather than needing a separate results view.
     */
    public function runFimCheckChunk(bool $reset = false): array
    {
        $baseline = $this->loadFimBaseline();
        if ($baseline === null || empty($baseline['hashes'])) {
            return [
                'done' => true, 'completedCount' => 0, 'totalCount' => 0,
                'currentArea' => null, 'truncated' => [], 'changedCount' => 0,
                'error' => 'no_baseline',
            ];
        }

        $progress = $reset ? null : $this->loadFimProgress('check');

        if ($progress === null || !empty($progress['done'])) {
            $queue = $this->buildFimQueue();
            $progress = [
                'queue'      => $queue,
                'completed'  => [],
                'findings'   => [],
                'truncated'  => [],
                'totalItems' => count($queue),
                'startedAt'  => time(),
                'updatedAt'  => time(),
                'done'       => false,
            ];
        }

        $deadline = microtime(true) + self::CHUNK_TIME_BUDGET_SECONDS;
        $baselineDate = date('Y-m-d', (int) ($baseline['createdAt'] ?? time()));
        $falsePositives = MuruguardHelper::getFalsePositiveLookup();

        while (!empty($progress['queue']) && microtime(true) < $deadline) {
            $item = array_shift($progress['queue']);
            $result = $this->hashDirectoryFiles($item, $deadline);

            $drift = $this->buildFimDriftFindings($baseline, $result['hashes'], $falsePositives, $baselineDate);
            foreach ($drift as $rel => $finding) {
                $progress['findings'][$rel] = $finding;
            }

            if ($result['truncated']) $progress['truncated'][] = $item;
            $progress['completed'][] = $item;
        }

        $progress['updatedAt'] = time();
        $progress['done'] = empty($progress['queue']);

        if ($progress['done']) {
            $session = Factory::getApplication()->getSession();
            $existing = $session->get('muruguard.filefindings');
            $merged = is_array($existing) ? $existing : [];
            $this->mergeFindingsInto($merged, $progress['findings']);
            $session->set('muruguard.filefindings', $merged);
            $session->set('muruguard.filefindings_time', time());
            $this->fileFindings = $merged;
        }

        $this->saveFimProgress('check', $progress);

        return [
            'done'           => $progress['done'],
            'completedCount' => count($progress['completed']),
            'totalCount'     => $progress['totalItems'],
            'currentArea'    => $progress['done'] ? null : ($progress['queue'][0] ?? null),
            'truncated'      => array_values(array_unique($progress['truncated'])),
            'changedCount'   => count($progress['findings']),
        ];
    }

    /**
     * Compares one batch of freshly-hashed files against the baseline,
     * returning findings for files present in BOTH with a DIFFERENT hash.
     * Shared by runFimCheckChunk() (interactive, chunked) and
     * mergeInFimDrift() (scheduled check, unbounded) so the actual
     * comparison/false-positive/reason-text logic only lives in one place.
     */
    private function buildFimDriftFindings(array $baseline, array $currentHashes, array $falsePositives, string $baselineDate): array
    {
        $findings = [];
        foreach ($currentHashes as $rel => $currentHash) {
            // Not in the baseline (added since) -- the regular scan's own
            // unrecognized-file/signature checks already cover a new
            // file; FIM's unique signal is specifically "a previously-
            // known file changed", so a brand-new path is deliberately
            // not reported here.
            if (!isset($baseline['hashes'][$rel])) continue;
            if ($baseline['hashes'][$rel] === $currentHash) continue;

            $reason = "Content changed since your integrity baseline (established {$baselineDate}). If this was an intentional update, rebuild the baseline to clear this.";
            $fingerprint = MuruguardHelper::fingerprintReasons([$reason]);
            if (MuruguardHelper::isFalsePositive($falsePositives, 'file', $rel, $fingerprint)) continue;

            $abs = $this->root . '/' . $rel;
            $findings[$rel] = [
                'rel' => $rel, 'abs' => $abs, 'reason' => $reason, 'reasons' => [$reason],
                'type' => 'file', 'confidence' => 'medium',
                'size' => is_file($abs) ? (int) @filesize($abs) : 0,
                'mtime' => is_file($abs) ? (int) @filemtime($abs) : 0,
            ];
        }
        return $findings;
    }

    /**
     * Folds FIM drift directly into $this->fileFindings for the scheduled
     * check (see runScheduledCheck()) -- deliberately unbounded (no chunk
     * deadline), the same tradeoff scanFilesystem()/scanDatabase() already
     * accept in that same method, since a cron request has no browser
     * polling it the way the interactive "Check Integrity" flow does to
     * spread work across several requests. A no-op when there's no
     * baseline (the common case for any site that hasn't set one up),
     * so this costs nothing for sites not using the feature.
     *
     * Deliberately merges into fileFindings BEFORE runScheduledCheck()'s
     * own new-vs-previous-run diff runs, rather than sending a separate
     * notification -- that diff (and therefore the existing email/webhook
     * alert pipeline in the controller) already does exactly what FIM
     * alerting needs: a drifted file is reported as "new" the first
     * scheduled run after it's detected, then stops being reported once
     * its key is saved to the previous-run snapshot, even though the
     * drift itself is still there. That's what keeps an unresolved,
     * ongoing change from re-alerting every single day.
     */
    private function mergeInFimDrift(): void
    {
        $baseline = $this->loadFimBaseline();
        if ($baseline === null || empty($baseline['hashes'])) return;

        $baselineDate = date('Y-m-d', (int) ($baseline['createdAt'] ?? time()));
        $falsePositives = MuruguardHelper::getFalsePositiveLookup();

        foreach ($this->buildFimQueue() as $relDir) {
            $result = $this->hashDirectoryFiles($relDir, null);
            $drift = $this->buildFimDriftFindings($baseline, $result['hashes'], $falsePositives, $baselineDate);
            foreach ($drift as $rel => $finding) {
                $this->fileFindings[$rel] = $finding;
            }
        }
    }

    /**
     * Persists the 3 scheduled-scanning settings into this component's
     * own extension params -- the same storage Global Configuration reads
     * from, so the in-page Settings panel and System > Global
     * Configuration > MuRu Guard always agree with each other. Safe
     * from the wipe risk documented on scanHistoryFilePath() because it
     * ONLY ever touches these 3 known keys, never the internal scan
     * history (which deliberately never lives in this params blob at
     * all anymore).
     */
    public function saveScheduledSettings(bool $enabled, string $token, string $email): void
    {
        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];
        $params['cron_enabled'] = $enabled ? 1 : 0;
        $params['cron_token'] = $token;
        $params['alert_email'] = $email;
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /** How many rows the scan-result file lists (Suspicious/Cleanable) show per page before pagination kicks in -- purely a display preference, same storage/save pattern as the other settings above. */
    public function saveDisplaySettings(int $itemsPerPage): void
    {
        $allowed = [25, 50, 100, 250, 500];
        if (!in_array($itemsPerPage, $allowed, true)) $itemsPerPage = 50;

        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];
        $params['items_per_page'] = $itemsPerPage;
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /** TimeMachine retention settings (Settings > AI Integrations tab) -- same storage/save pattern as every other settings method here. */
    public function saveTimeMachineSettings(int $retentionDays, int $retentionMaxSnapshots): void
    {
        if ($retentionDays < 1) $retentionDays = 14;
        if ($retentionMaxSnapshots < 10) $retentionMaxSnapshots = 500;

        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];
        $params['timemachine_retention_days'] = $retentionDays;
        $params['timemachine_retention_max_snapshots'] = $retentionMaxSnapshots;
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /**
     * Pro Features settings -- Fleet Dashboard reporting + the 3 Alert
     * Channels (Slack/Discord/Telegram). Same storage/save pattern as
     * every other settings method here. Deliberately accepts everything
     * as already-validated scalars (the controller is responsible for
     * pulling these out of the request) -- this method's only job is
     * persisting them.
     */
    public function saveProFeatureSettings(array $settings): void
    {
        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];

        $params['fleet_reporting_enabled']  = !empty($settings['fleet_reporting_enabled']) ? 1 : 0;
        $params['autopilot_enabled']        = !empty($settings['autopilot_enabled']) ? 1 : 0;
        $params['alert_slack_enabled']      = !empty($settings['alert_slack_enabled']) ? 1 : 0;
        $params['alert_slack_webhook']      = (string) ($settings['alert_slack_webhook'] ?? '');
        $params['alert_discord_enabled']    = !empty($settings['alert_discord_enabled']) ? 1 : 0;
        $params['alert_discord_webhook']    = (string) ($settings['alert_discord_webhook'] ?? '');
        $params['alert_telegram_enabled']   = !empty($settings['alert_telegram_enabled']) ? 1 : 0;
        $params['alert_telegram_bot_token'] = (string) ($settings['alert_telegram_bot_token'] ?? '');
        $params['alert_telegram_chat_id']   = (string) ($settings['alert_telegram_chat_id'] ?? '');

        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    private function saveHardeningParams(array $set): void
    {
        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;
        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];
        foreach ($set as $key => $value) {
            $params[$key] = $value;
        }
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /**
     * MuRu Shield Hardening: activates the /administrator HTTP Basic
     * Auth gate. Only ever persists username + a bcrypt hash + an
     * activation timestamp -- never the plaintext password, which is
     * returned to the caller exactly once so it can be shown to the
     * admin, and is not retrievable again afterward (matching every
     * other secret in this codebase -- see maskLicenseKey()'s docblock
     * for the same "never echo a secret back" discipline).
     */
    public function activateBackendAuth(string $username, string $password): array
    {
        $testUrl = \Joomla\CMS\Uri\Uri::root() . 'administrator/index.php';
        $result = \MuruguardHardeningHelper::activateBackendAuth(JPATH_ADMINISTRATOR, $testUrl, $username, $password);
        if ($result['ok']) {
            $this->saveHardeningParams([
                'backend_auth_enabled'    => 1,
                'backend_auth_username'   => $username,
                'backend_auth_activated'  => time(),
            ]);
        } elseif (!$this->isShieldPluginActive()) {
            // The single most common reason the self-test fails on a non-
            // Apache host: plg_system_muruguardshield is what actually
            // enforces this at the PHP layer there (see its
            // checkBasicAuthGate()) -- .htaccess-only enforcement only
            // ever works on Apache. If it's not installed/enabled, no
            // amount of retrying will help, so say so explicitly instead
            // of leaving the admin to guess between three generic causes.
            $result['reason'] = 'The MuRu Guard Shield plugin (System > Plugins > "System - MuRu Guard Shield") is not installed or enabled. '
                . 'On any server other than Apache, this plugin is what actually enforces Backend Access -- install/enable it, then try again. '
                . 'Original error: ' . $result['reason'];
        }
        return $result;
    }

    public function deactivateBackendAuth(): void
    {
        \MuruguardHardeningHelper::deactivateBackendAuth(JPATH_ADMINISTRATOR);
        // Emergency Mode reuses backend auth's .htpasswd -- it cannot be
        // left active pointing at a file that just got deleted.
        \MuruguardHardeningHelper::deactivateEmergencyMode($this->root);
        $this->saveHardeningParams([
            'backend_auth_enabled'   => 0,
            'backend_auth_username'  => '',
            'backend_auth_activated' => 0,
            'emergency_mode_enabled' => 0,
        ]);
    }

    public function activateEmergencyMode(string $username, string $password): array
    {
        // The plaintext password is never persisted once backend auth is
        // active (see activateBackendAuth()'s docblock) -- Emergency Mode
        // reuses those same credentials rather than minting new ones, so
        // the admin re-supplies the password here and it's checked
        // against the already-active .htpasswd BEFORE anything is
        // written, refusing outright rather than writing an Emergency
        // Mode block self-tested with a password that turns out wrong.
        if (!\MuruguardHardeningHelper::verifyBackendPassword(JPATH_ADMINISTRATOR, $username, $password)) {
            return ['ok' => false, 'reason' => 'That username/password doesn\'t match your currently-active backend access credentials.'];
        }

        $testUrl = \Joomla\CMS\Uri\Uri::root();
        $result = \MuruguardHardeningHelper::activateEmergencyMode($this->root, JPATH_ADMINISTRATOR, $testUrl, $username, $password);
        if ($result['ok']) {
            $this->saveHardeningParams(['emergency_mode_enabled' => 1, 'emergency_mode_activated' => time()]);
        } elseif (!$this->isShieldPluginActive()) {
            // Same reasoning as activateBackendAuth() above -- on any
            // non-Apache host, plg_system_muruguardshield's
            // checkBasicAuthGate() is what actually enforces this.
            $result['reason'] = 'The MuRu Guard Shield plugin (System > Plugins > "System - MuRu Guard Shield") is not installed or enabled. '
                . 'On any server other than Apache, this plugin is what actually enforces this. '
                . 'Original error: ' . $result['reason'];
        }
        return $result;
    }

    public function deactivateEmergencyMode(): void
    {
        \MuruguardHardeningHelper::deactivateEmergencyMode($this->root);
        $this->saveHardeningParams(['emergency_mode_enabled' => 0, 'emergency_mode_activated' => 0]);
    }

    /** Toggles plg_system_muruguardshield's onBeforeCompileHead() generator-meta-tag strip (see that method's own docblock). */
    public function saveGeneratorTagSetting(bool $remove): void
    {
        $this->saveHardeningParams(['harden_remove_generator' => $remove ? 1 : 0]);
    }

    /** Toggles automatic tmp/ cleanup running as part of every scheduled check (see runScheduledCheck() / cleanupTmpFolder()). */
    public function saveTmpCleanupSetting(bool $enabled): void
    {
        $this->saveHardeningParams(['harden_tmp_cleanup_enabled' => $enabled ? 1 : 0]);
    }

    /** Toggles the periodic homepage watch (see runHomepageWatch(), called from the controller's scheduledcheck()). */
    public function saveHomepageWatchSetting(bool $enabled): void
    {
        $this->saveHardeningParams(['homepage_watch_enabled' => $enabled ? 1 : 0]);
    }

    /**
     * One real fetch-and-compare of the site's own live homepage,
     * independent of a full filesystem+DB scan -- see
     * MuruguardHelper::checkHomepageHealth()/updateHomepageWatchState()
     * for the actual check + state-transition logic. Returns a plain-
     * language change description only when something actually changed
     * since the last check (down/up, defaced/clean, SEO-spam/clean), or
     * null on an unchanged/first-ever check -- the controller only
     * alerts when this returns non-null.
     */
    public function runHomepageWatch(): ?string
    {
        $sig = MuruguardHelper::getSignatures();
        $current = MuruguardHelper::checkHomepageHealth($sig);
        return MuruguardHelper::updateHomepageWatchState($current);
    }

    /** Builds the exportable (secret-free) config JSON -- see MuruguardHelper::buildExportableConfig()'s own docblock for the allowlist reasoning. */
    public function getExportableConfig(): array
    {
        return MuruguardHelper::buildExportableConfig(ComponentHelper::getParams('com_muruguard'));
    }

    /** Merges a validated, already-allowlist-filtered settings array (see MuruguardHelper::parseImportableConfig()) into stored params. */
    public function saveImportedConfig(array $settings): void
    {
        $this->saveHardeningParams($settings);
    }

    /** Restores one core file from its official checksum baseline -- see MuruguardHelper::restoreCoreFileFromBaseline()'s own docblock for the fetch+verify+backup sequence. */
    public function restoreCoreFile(string $relPath): array
    {
        return MuruguardHelper::restoreCoreFileFromBaseline($this->root, $relPath);
    }

    /**
     * Saves a new Google Safe Browsing API key. Same "blank means no
     * change" convention as saveAndVerifyLicenseKey() -- the field is
     * always blank on load (see MuruguardHelper::maskLicenseKey()), so an
     * empty submit means "I didn't type a new key," not "clear it."
     * Pass an empty string here for that case and this is a no-op.
     * Unlike the license key, this isn't verified against anything
     * before saving -- there's no "is this key valid" endpoint to check
     * against without spending an actual Safe Browsing API call, so
     * whether it works is discovered the same way a wrong key on any
     * BYO-key integration is: the next scan's Safe Browsing checks
     * simply return nothing (see checkUrlAgainstSafeBrowsing()'s fail-
     * open behavior).
     */
    public function saveSafeBrowsingApiKey(string $key): void
    {
        $key = trim($key);
        if ($key === '') return;
        $this->saveHardeningParams(['safe_browsing_api_key' => $key]);
    }

    /** Clears a previously-saved Safe Browsing API key, turning the check back off. */
    public function clearSafeBrowsingApiKey(): void
    {
        $this->saveHardeningParams(['safe_browsing_api_key' => '']);
    }

    /**
     * Saves a new Gemini API key -- the Free-tier "Ask AI" path. Same
     * blank-means-unchanged convention as saveSafeBrowsingApiKey() just
     * above.
     */
    public function saveGeminiApiKey(string $key): void
    {
        $key = trim($key);
        if ($key === '') return;
        $this->saveHardeningParams(['gemini_api_key' => $key]);
    }

    /** Clears a previously-saved Gemini API key, turning "Ask AI" back off for a non-Pro site. */
    public function clearGeminiApiKey(): void
    {
        $this->saveHardeningParams(['gemini_api_key' => '']);
    }

    /**
     * Same storage the plg_system_muruguardshield plugin reads from on
     * every request via ComponentHelper::getParams('com_muruguard') --
     * this is the only place that plugin's behaviour is actually
     * configured, there is no separate plugin-side settings screen.
     */
    public function saveShieldSettings(
        bool $enabled,
        bool $blockPatterns,
        bool $blockBruteForce,
        int $threshold,
        int $window,
        bool $blockUserAgents = false,
        bool $blockCountries = false,
        string $blockedCountries = '',
        bool $wafEnabled = false,
        bool $blockReferrers = false,
        bool $autoblockRepeatOffenders = false,
        int $autoblockThreshold = 3,
        int $autoblockWindow = 60,
        bool $blockPbl = false,
        bool $blockUploadExts = false
    ): void {
        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];
        $params['shield_enabled'] = $enabled ? 1 : 0;
        $params['shield_block_patterns'] = $blockPatterns ? 1 : 0;
        $params['shield_block_bruteforce'] = $blockBruteForce ? 1 : 0;
        $params['shield_bruteforce_threshold'] = max(2, min(50, $threshold));
        $params['shield_bruteforce_window'] = max(1, min(1440, $window));
        $params['shield_block_useragents'] = $blockUserAgents ? 1 : 0;
        $params['shield_block_countries'] = $blockCountries ? 1 : 0;
        $params['shield_block_referrers'] = $blockReferrers ? 1 : 0;
        $params['shield_block_pbl'] = $blockPbl ? 1 : 0;
        $params['shield_block_upload_extensions'] = $blockUploadExts ? 1 : 0;
        // Repeat-offender auto-blocklisting -- see
        // MuruguardHelper::autoBlockRepeatOffender(). Threshold/window are
        // deliberately a separate pair from the brute-force ones above:
        // this counts BLOCKED requests of any kind (pattern/UA/country/
        // referrer/brute-force alike), not just failed logins.
        $params['shield_autoblock_repeat_offenders'] = $autoblockRepeatOffenders ? 1 : 0;
        $params['shield_autoblock_threshold'] = max(2, min(50, $autoblockThreshold));
        $params['shield_autoblock_window'] = max(5, min(1440, $autoblockWindow));
        // The controller only passes $wafEnabled=true through when the
        // license is currently active -- a non-Pro site's own other
        // Shield settings (patterns/brute-force/countries/...) still save
        // normally, only this one flag is force-false, so losing Pro
        // doesn't silently block saving everything else in this form.
        $params['waf_enabled'] = $wafEnabled ? 1 : 0;
        // Normalise to a clean, de-duplicated, comma-separated list of
        // 2-letter codes -- whatever stray formatting an admin pastes in
        // (extra spaces, lowercase, trailing commas) still works.
        $codes = array_unique(array_filter(array_map(
            fn($c) => strtoupper(trim($c)),
            explode(',', $blockedCountries)
        ), fn($c) => preg_match('/^[A-Z]{2}$/', $c)));
        $params['shield_blocked_countries'] = implode(',', $codes);
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /**
     * Fleet Dashboard (Pro) -- applies a whitelisted subset of Shield
     * toggles pushed as a bulk "hardening config" command from the
     * dashboard's Fleet page. Merges into whatever is already saved
     * rather than replacing the whole settings row, so a site's own
     * country-block list, WAF toggle, and brute-force thresholds are
     * left untouched by a bulk push. No-ops (returns false) if the
     * Shield plugin isn't installed/active -- flipping shield_enabled
     * on for a plugin that isn't running would do nothing but leave a
     * misleading "on" toggle behind.
     */
    public function applyFleetHardeningCommand(array $payload): bool
    {
        if (!$this->isShieldPluginActive()) return false;

        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return false;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];

        $allowedKeys = ['shield_enabled', 'shield_block_patterns', 'shield_block_bruteforce', 'shield_block_useragents'];
        foreach ($allowedKeys as $key) {
            if (array_key_exists($key, $payload)) {
                $params[$key] = !empty($payload[$key]) ? 1 : 0;
            }
        }

        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');

        return true;
    }

    /**
     * Fleet bulk-action direct trigger (Pro) -- a dedicated secret this
     * site generates once and resends on every fleet report, so the
     * dashboard can attempt an immediate outbound trigger call (see
     * MuruguardControllerScanner::fleettrigger()) instead of only
     * waiting for this site's own next incidental check-in. Deliberately
     * separate from the admin's own external-cron token (Settings >
     * Scheduled Scanning, a value the admin types in themselves) -- a
     * different trust boundary and a different holder (this dashboard,
     * generated and never shown in the UI, vs. whatever the admin points
     * their own cron at). Generated lazily on first use, then stable.
     */
    public function getOrCreateFleetTriggerToken(): string
    {
        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return '';

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];

        $existing = trim((string) ($params['fleet_trigger_token'] ?? ''));
        if ($existing !== '') return $existing;

        $token = bin2hex(random_bytes(32));
        $params['fleet_trigger_token'] = $token;
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');

        return $token;
    }

    /** Rate-limit bookkeeping for fleettrigger() -- a leaked/guessed token shouldn't be able to hammer this site with repeated full scans. */
    public function recordFleetTriggerTimestamp(int $unixTime): void
    {
        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];

        $params['fleet_trigger_last_at'] = $unixTime;
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /**
     * Saves a new/changed license key and immediately clears the cached
     * verification result (by zeroing license_last_checked) so the very
     * next getLicenseStatus() call is guaranteed to actually check the
     * new key against the dashboard rather than serving yesterday's
     * cached result for a completely different key.
     *
     * A blank submission is a deliberate no-op, not a clear -- the
     * Settings panel no longer echoes the saved key back into the input
     * (see MuruguardHelper::maskLicenseKey()), so the field is normally
     * empty on page load; submitting the form without typing a new key
     * must never silently wipe out a previously-saved one. Returns false
     * for that no-op case so the controller can tell the admin nothing
     * changed instead of implying a key was saved.
     */
    /**
     * Verifies $key against the dashboard BEFORE persisting anything, so
     * a mistyped/invalid key can never be reported as "saved" (the old
     * saveLicenseKey() saved unconditionally and cleared the status,
     * leaving the actual pass/fail to whatever happened to render the
     * page next -- which is also what silently produced a "License key
     * saved" success message for a key the dashboard immediately
     * rejected). Only two outcomes persist the submitted key:
     *  - 'active'      -- the normal, expected case.
     *  - 'unreachable' -- the dashboard couldn't be reached for this one
     *    check; saved optimistically (same fail-open philosophy as
     *    getLicenseStatus() elsewhere) with status left blank so the
     *    very next page load retries immediately instead of caching a
     *    non-verdict until the next check-in.
     * Every other outcome (not_found/revoked/expired/site_limit_reached)
     * is a real "no" from the dashboard -- whatever key/status was
     * already saved is left completely untouched, so a mistyped key can
     * never clobber a previously-working license.
     */
    public function saveAndVerifyLicenseKey(string $key): array
    {
        $key = trim($key);
        $domain = \MuruguardHelper::currentSiteDomain();
        $result = \MuruguardHelper::verifyLicenseRemote($key, $domain);

        if ($result['status'] === 'active') {
            $this->persistLicenseKeyAndStatus($key, $result);
            $this->registerUpdateSiteLicenseKey($key);
        } elseif ($result['status'] === 'unreachable') {
            $this->persistLicenseKeyAndStatus($key, ['status' => '', 'expiresAt' => null, 'lastChecked' => null, 'product' => null]);
        }

        return $result;
    }

    /**
     * Points this site's own MuRu Guard update-site registration at a URL
     * that includes the license key, so Joomla's native "Check for
     * Updates" (Extensions > Manage > Update) can actually download a
     * Pro update -- the manifest's own <updateservers> URL is static and
     * has no way to carry a per-customer key, but Joomla appends
     * #__update_sites.extra_query to whatever downloadurl the update XML
     * gives it right before fetching the package (see
     * administrator/components/com_installer/src/Model/UpdateModel.php's
     * install() -- confirmed against real Joomla core source, not just
     * docs), which is exactly what extra_query exists for. Same mechanism
     * real commercial Joomla extensions use to gate updates without a
     * personalized update-CHECK XML. Silently does nothing if the
     * update_sites row doesn't exist yet (e.g. a fresh install before
     * Joomla's own installer has synced <updateservers> into the DB, or a
     * pre-2.8.8 install that predates this feature) -- self-heals on the
     * next license re-check once it does, since this also runs from
     * getLicenseStatus() on every cache-expiry re-verification, not just
     * on first save.
     */
    private function registerUpdateSiteLicenseKey(string $key): void
    {
        try {
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName('us.update_site_id'))
                ->from($db->quoteName('#__update_sites', 'us'))
                ->join('INNER', $db->quoteName('#__update_sites_extensions', 'use') . ' ON ' . $db->quoteName('use.update_site_id') . ' = ' . $db->quoteName('us.update_site_id'))
                ->join('INNER', $db->quoteName('#__extensions', 'ext') . ' ON ' . $db->quoteName('ext.extension_id') . ' = ' . $db->quoteName('use.extension_id'))
                ->where($db->quoteName('ext.element') . ' = ' . $db->quote('com_muruguard'))
                ->where($db->quoteName('ext.type') . ' = ' . $db->quote('component'));
            $db->setQuery($query);
            $updateSiteIds = $db->loadColumn() ?: [];

            $extraQuery = 'key=' . rawurlencode($key);
            foreach ($updateSiteIds as $updateSiteId) {
                $update = $db->getQuery(true)
                    ->update($db->quoteName('#__update_sites'))
                    ->set($db->quoteName('extra_query') . ' = ' . $db->quote($extraQuery))
                    ->where($db->quoteName('update_site_id') . ' = ' . (int) $updateSiteId);
                $db->setQuery($update)->execute();
            }
        } catch (\Throwable $e) {
            // Never let a DB hiccup here (unexpected schema on some exotic
            // host, permissions, ...) break license verification itself --
            // this is a nice-to-have that self-heals on the next check-in.
        }
    }

    private function persistLicenseKeyAndStatus(string $key, array $result): void
    {
        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];
        $params['license_key'] = $key;
        $params['license_status'] = (string) ($result['status'] ?? '');
        $params['license_expires_at'] = $result['expiresAt'] !== null ? (string) $result['expiresAt'] : '';
        $params['license_last_checked'] = $result['lastChecked'] !== null ? (string) $result['lastChecked'] : '';
        $params['license_product'] = $result['product'] !== null ? (string) $result['product'] : '';
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /**
     * Persists a verification result (see MuruguardHelper::
     * verifyLicenseRemote()) back into the component's own params, so
     * the NEXT page load's readCachedLicenseStatus() sees it without
     * another network round-trip.
     */
    private function saveLicenseStatusResult(array $result): void
    {
        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;

        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];
        $params['license_status'] = (string) $result['status'];
        $params['license_expires_at'] = $result['expiresAt'] !== null ? (string) $result['expiresAt'] : '';
        $params['license_last_checked'] = $result['lastChecked'] !== null ? (string) $result['lastChecked'] : (string) time();
        $params['license_product'] = $result['product'] !== null ? (string) $result['product'] : '';
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /**
     * The single entry point the view calls -- reads the cached result
     * and, only if it's stale (or $forceRecheck is set, e.g. the
     * Settings panel's "Re-check now" button), makes the actual network
     * call and persists the fresh result before returning it. Ordinary
     * admin page loads never wait on an outbound HTTP call unless the
     * cache has genuinely expired.
     */
    public function getLicenseStatus(bool $forceRecheck = false): array
    {
        $cfgParams = \Joomla\CMS\Component\ComponentHelper::getParams('com_muruguard');
        $key = trim((string) $cfgParams->get('license_key', ''));

        if ($key === '') {
            return ['status' => 'none', 'expiresAt' => null, 'lastChecked' => null, 'product' => null];
        }

        if (!$forceRecheck && !\MuruguardHelper::isLicenseCacheStale($cfgParams)) {
            return \MuruguardHelper::readCachedLicenseStatus($cfgParams);
        }

        $domain = \MuruguardHelper::currentSiteDomain();
        $result = \MuruguardHelper::verifyLicenseRemote($key, $domain);
        $this->saveLicenseStatusResult($result);
        if ($result['status'] === 'active') {
            $this->registerUpdateSiteLicenseKey($key);
        }

        return $result;
    }

    /**
     * True only if plg_system_muruguardshield is both installed AND
     * enabled -- the Settings panel uses this to warn when the shield
     * toggles are turned on but have no extension actually reading them,
     * since that combination looks configured but silently does nothing.
     */
    public function isShieldPluginActive(): bool
    {
        $db    = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select($db->quoteName('enabled'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('muruguardshield'));

        $db->setQuery($query);
        return (bool) $db->loadResult();
    }

    // ------------------------------------------------------------------
    // Filesystem scan
    // ------------------------------------------------------------------

    /**
     * @param ?array $onlyDirs Restricts the SCAN_CONFIG directory walk to
     *   just these relative-dir keys (e.g. ['media']) -- null (default)
     *   walks every selected SCAN_CONFIG dir, same as before this param
     *   existed. Pass [] to skip the directory walk entirely while still
     *   running the webroot/core-entry checks below, if $includeWebrootCore.
     * @param bool $includeWebrootCore Whether to run the shallow webroot
     *   scan and core-entry-point checks in this call. Defaults true (full
     *   scan, unchanged behaviour); a per-directory chunk call passes false
     *   so those cheap-but-redundant checks only run once per chunked scan,
     *   not once per chunk.
     * @param ?float $deadline Wall-clock microtime(true) cutoff. When set,
     *   a directory walk that's still running past it is cut short (see
     *   MuruguardScanChunkTimeout) instead of letting one huge folder blow
     *   through an entire chunked-scan HTTP request's time budget.
     */
    public function scanFilesystem(?array $onlyDirs = null, bool $includeWebrootCore = true, ?float $deadline = null): void
    {
        // Extends CONTENT_SIGNATURES with any externally-published
        // signatures (see mergeSignatureFeedInto()'s own docblock) --
        // done here, once, rather than inside getSignatures() itself, so
        // every OTHER caller of getSignatures() in this codebase stays
        // completely unaffected.
        $sig = MuruguardHelper::mergeSignatureFeedInto(MuruguardHelper::getSignatures());
        $params = ComponentHelper::getParams('com_muruguard');
        $maxSize = (int) ($params->get('max_file_scan_size', 2 * 1024 * 1024));
        // Empty string (the default) makes every checkContentUrlsAgainst
        // SafeBrowsing() call inside scanFileContent() a pure no-op --
        // this is entirely inert until an admin configures a key.
        $safeBrowsingApiKey = trim((string) $params->get('safe_browsing_api_key', ''));

        $extraRootDirs = array_filter(array_map('trim', explode(',', (string) $params->get('extra_root_dirs', ''))));
        $sig['KNOWN_ROOT_DIRS'] = array_merge($sig['KNOWN_ROOT_DIRS'], $extraRootDirs);

        $ignoredPaths = array_filter(array_map('trim', explode("\n", (string) $params->get('ignored_paths', ''))));
        $isIgnored = function (string $relPath) use ($ignoredPaths): bool {
            foreach ($ignoredPaths as $pattern) {
                if ($pattern === '') continue;
                if (fnmatch($pattern, $relPath, FNM_PATHNAME)) return true;

                // A trailing "/*" is documented (COM_MURUGUARD_CONFIG_IGNORED_
                // PATHS_DESC) as ignoring an entire extension, e.g.
                // "plugins/mcp/*" -- but FNM_PATHNAME makes "*" stop at the
                // first "/", so that pattern only ever matched files placed
                // directly inside plugins/mcp/, never anything one level
                // deeper like plugins/mcp/mcpadminlogin/foo.php. Treat a
                // trailing "/*" as "this whole subtree" via a plain prefix
                // check instead, without loosening any other pattern shape
                // (a bare "*.php" still only matches within one directory,
                // as documented/expected).
                if (substr($pattern, -2) === '/*') {
                    $prefix = substr($pattern, 0, -1); // keep the trailing slash
                    if ($prefix !== '/' && strncmp($relPath, $prefix, strlen($prefix)) === 0) {
                        return true;
                    }
                }
            }
            return false;
        };

        $selfLogPattern  = '/^\.muruguard-[a-f0-9]{16}\.(log|lock)$/i';
        $googleVerifyPattern = '/^google[a-f0-9]{16,}\.html$/i';
        // Safety-backup copies this scanner's own "Clean code" action
        // writes before overwriting an infected file -- deliberately kept
        // on disk for manual review/rollback, so they shouldn't re-appear
        // as a "new" finding on the next scan (they still contain the
        // original malicious content by design, that's the whole point).
        $selfBackupPattern = '/\.muruguard-\d{8}-\d{6}\.bak$/i';
        $registeredTemplates = $this->getRegisteredTemplates();
        $registeredPlugins = $this->getRegisteredPlugins();
        $registeredComponents = $this->getRegisteredComponents();
        $falsePositives = MuruguardHelper::getFalsePositiveLookup();
        // Loaded once per scan, not per file -- same reasoning as every
        // other lookup table above. Empty on a fresh install (this
        // scanner ships with no bundled hashes, see the list's own
        // docblock), so the check below is a cheap no-op until an admin
        // actually adds one.
        $customHashes = MuruguardHelper::getCustomMalwareHashes();

        foreach ($sig['SCAN_CONFIG'] as $relDir => $mode) {
            if ($onlyDirs !== null && !in_array($relDir, $onlyDirs, true)) continue;
            if (!$this->isAreaSelected($relDir)) continue;
            if ($deadline !== null && microtime(true) > $deadline) {
                // Budget already spent before even starting this area (only
                // reachable when $onlyDirs covers more than one area) --
                // leave it for the next chunk rather than starting it.
                $this->truncatedAreas[$relDir] = true;
                break;
            }
            $dir = $this->root . '/' . $relDir;
            if (!is_dir($dir)) continue;

            try {
                MuruguardHelper::walkDir($dir, function (string $path, bool $isDir) use ($sig, $mode, $maxSize, $isIgnored, $selfBackupPattern, $registeredTemplates, $registeredPlugins, $registeredComponents, $falsePositives, $deadline, $customHashes, $safeBrowsingApiKey) {
                if ($deadline !== null && microtime(true) > $deadline) {
                    throw new MuruguardScanChunkTimeout();
                }
                foreach ($sig['SAFE_COMPONENT_PATHS'] as $safeFrag) {
                    if (stripos($path, $safeFrag) !== false) return;
                }
                if (preg_match('#/tmp/install_[a-z0-9]+(/|$)#i', $path)) {
                    return; // Joomla's own installer extraction folder — transient, not user-uploadable
                }
                if (!$isDir && preg_match($selfBackupPattern, basename($path))) return;
                if (isset($this->seenAbs[$path])) return;

                $basename = basename($path);
                $relCheck = ltrim(str_replace($this->root, '', $path), '/');
                if ($isIgnored($relCheck)) return;
                $isKnownSafeEntry = !$isDir && in_array($relCheck, $sig['KNOWN_SAFE_RELATIVE_FILES'], true);
                $flagged = false;
                $reasons = [];

                // iconfont strict allow-list -- file TYPE is checked at
                // ANY depth inside an iconfont/ tree (icomoon/, css/,
                // fonts/, or any other allowed subfolder), not just its
                // immediate children. A subfolder name being on the
                // allow-list (e.g. "icomoon", IcoMoon's own export/build
                // tool name -- a legitimate, common icon-font vendor
                // folder) only means the FOLDER itself isn't flagged as
                // unrecognized; it is never a free pass for what's placed
                // inside it -- every file there still has its own
                // extension checked against the allow-list below, on top
                // of the depth-independent executable check and the
                // ordinary content-signature scan every file gets
                // regardless of location.
                if (stripos($path, '/iconfont/') !== false) {
                    $parentBase = strtolower(basename(dirname($path)));
                    if ($isDir) {
                        if ($parentBase === 'iconfont' && !in_array(strtolower($basename), $sig['ICONFONT_ALLOWED_DIRNAMES'], true)) {
                            $flagged = true;
                            $reasons[] = 'Unrecognized folder inside icon-font asset directory.';
                        }
                    } else {
                        $extL = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                        if (in_array($extL, $sig['EXEC_EXTS'], true)) {
                            $flagged = true;
                            $reasons[] = 'Executable file inside icon-font asset folder.';
                        } elseif ($basename === '.htaccess') {
                            // Icon-font export tools (IcoMoon, Fontello, ...)
                            // commonly ship a minimal .htaccess here purely
                            // to set the correct MIME type for .woff/.ttf/
                            // .eot -- checked by CONTENT, not trusted by
                            // location alone: only a genuinely permissive
                            // .htaccess is flagged, same criteria the
                            // 'upload' mode structural check below already
                            // uses for every other .htaccess it finds.
                            $htContents = @file_get_contents($path, false, null, 0, 4096);
                            if ($htContents !== false
                                && preg_match('/Allow\s+from\s+all|Require\s+all\s+granted|RewriteEngine\s+Off/i', $htContents)
                                && !preg_match('/FilesMatch.*php/i', $htContents)) {
                                $flagged = true;
                                $reasons[] = 'Suspicious .htaccess inside icon-font asset directory: permissively allows access.';
                            }
                        } else {
                            $baseNoExt = strtolower(pathinfo($basename, PATHINFO_FILENAME));
                            if (!in_array($extL, $sig['ICONFONT_ALLOWED_EXTENSIONS'], true)
                                && !($extL === '' && in_array($baseNoExt, $sig['ICONFONT_ALLOWED_BARE_NAMES'], true))) {
                                $flagged = true;
                                $reasons[] = 'Unrecognized file type inside icon-font asset directory.';
                            }
                        }
                    }
                }

                // JCE upload strict allow-list
                if (!$isDir && !$flagged) {
                    foreach ($sig['JCE_UPLOAD_PATH_FRAGMENTS'] as $frag) {
                        if (stripos($path, $frag) === false) continue;
                        $extL = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                        if (in_array($extL, $sig['EXEC_EXTS'], true)) {
                            $flagged = true;
                            $reasons[] = 'Executable file inside JCE file-browser upload path.';
                        } elseif ($extL !== '' && !in_array($extL, $sig['JCE_UPLOAD_ALLOWED_EXTENSIONS'], true)) {
                            $flagged = true;
                            $reasons[] = 'Unrecognized file type inside JCE file-browser upload path.';
                        }
                        break;
                    }
                }

                // 'upload' mode strict structural checks
                if ($mode === 'upload') {
                    if ($isDir) {
                        if (preg_match('/^\d+$/', $basename) && !MuruguardHelper::isDateLikeNumericFolderName($basename)) {
                            $flagged = true;
                            $reasons[] = "Folder name is purely numeric (\"{$basename}\") and isn't a normal date/ID component — a common automated-malware-drop pattern.";
                        }
                    } else {
                        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                        $isBlankStub = false;
                        if ($ext === 'php' && strcasecmp($basename, 'index.php') === 0) {
                            $stubContents = @file_get_contents($path, false, null, 0, 4096);
                            if ($stubContents !== false && MuruguardHelper::isStandardJoomlaStub($stubContents)) {
                                $isBlankStub = true;
                            }
                        }
                        $isJoomlaCacheFile = $ext === 'php'
                            && strpos($relCheck, 'cache/') === 0
                            && (bool) preg_match($sig['JOOMLA_CACHE_FILE_RE'], $basename);
                        $isRegisteredExtensionSnapshot = $ext === 'php'
                            && strpos($relCheck, 'tmp/joomtower_snapshots/') === 0
                            && MuruguardHelper::isRegisteredExtensionSnapshotPath($relCheck, $registeredPlugins, $registeredComponents, $registeredTemplates);
                        $isJedCheckerOwnZipSnapshot = $ext === 'php'
                            && strpos($relCheck, 'tmp/jed_checker/unzipped/') === 0
                            && MuruguardHelper::isJedCheckerOwnZipSnapshotPath($relCheck);
                        $isHikashopMailTemplate = $ext === 'php'
                            && strpos($relCheck, 'media/com_hikashop/mail/') === 0
                            && MuruguardHelper::isHikashopMailTemplatePath($relCheck, $registeredComponents);
                        if (!$isKnownSafeEntry && !$isBlankStub && !$isJoomlaCacheFile && !$isRegisteredExtensionSnapshot && !$isJedCheckerOwnZipSnapshot && !$isHikashopMailTemplate && in_array($ext, $sig['EXEC_EXTS'], true)) {
                            $flagged = true;
                            $reasons[] = "Executable file (.$ext) inside an upload directory — these should never contain runnable code.";
                        }
                        if ($basename === '.htaccess') {
                            $contents = @file_get_contents($path, false, null, 0, 4096);
                            if ($contents !== false
                                && preg_match('/Allow\s+from\s+all|Require\s+all\s+granted|RewriteEngine\s+Off/i', $contents)
                                && !preg_match('/FilesMatch.*php/i', $contents)) {
                                $flagged = true;
                                $reasons[] = 'Suspicious .htaccess: permissively allows access in an upload folder.';
                            }
                        }
                    }
                }

                // content signature scan runs in both modes, files only
                if (!$isDir) {
                    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                    if (MuruguardHelper::scanFileContent($path, $ext, $sig, $maxSize, $reasons, $safeBrowsingApiKey)) {
                        // Strip only this scanner's own narrow, known,
                        // per-file self-matches (see
                        // SELF_CONTENT_SIGNATURE_EXEMPTIONS) -- never a
                        // blanket skip, so an actually-injected backdoor
                        // in this scanner's own files is still caught.
                        $reasons = MuruguardHelper::filterSelfSignatureExemptions($relCheck, $sig, $reasons);
                        // Narrow, per-file, per-signature exemption for
                        // known-legitimate third-party libraries (see
                        // KNOWN_LIBRARY_SIGNATURE_EXEMPTIONS) -- same
                        // "never blanket-skip a path" reasoning as above.
                        $reasons = MuruguardHelper::filterKnownLibrarySignatureExemptions($relCheck, $sig, $reasons);
                        // Full content-signature exemption for exactly
                        // one file (scan-progress.php) -- see
                        // filterStubProtectedDataCacheExemptions()'s own
                        // docblock for why this one is structurally
                        // different from the two narrower filters above.
                        $reasons = MuruguardHelper::filterStubProtectedDataCacheExemptions($relCheck, $reasons);
                        if (!empty($reasons)) {
                            $flagged = true;
                        }
                    }
                }

                // known-malicious filename pattern (location-independent, runs both modes --
                // malware doesn't respect the upload-vs-code folder distinction)
                if (!$isDir && !$isKnownSafeEntry) {
                    // Joomla's own legacy MVC convention names a view's
                    // per-format render file view.<format>.php --
                    // view.html.php, view.xml.php, view.json.php,
                    // view.rss.php, view.atom.php, ... -- ubiquitous
                    // across virtually every real component that outputs
                    // more than plain HTML (sitemaps, feeds, JSON APIs),
                    // this scanner's own admin/views/scanner/view.html.php
                    // included. The .xml.php entry in
                    // SUSPICIOUS_FILENAME_REGEXES exists for a webshell/
                    // dropper disguised as an XML file, not this
                    // well-known naming convention -- confirmed false
                    // positive on com_osmap's views/xml/view.xml.php.
                    $isStandardMvcFormatView = (bool) preg_match('/^view\.[a-z0-9]+\.php$/i', $basename);
                    foreach ($sig['SUSPICIOUS_FILENAME_REGEXES'] as $re) {
                        if ($re === '/\.xml\.php$/i' && $isStandardMvcFormatView) continue;
                        if (preg_match($re, $basename)) { $flagged = true; $reasons[] = 'Filename matches known malicious pattern.'; break; }
                    }
                }

                // .htaccess rewriting a non-PHP extension to execute as PHP
                // (location-independent, runs both modes) -- confirmed real
                // backdoor technique: pairs with a *.php.json-style dropped
                // file (see SUSPICIOUS_FILENAME_REGEXES above) to defeat any
                // filter that only blocks the .php extension itself.
                if (!$isDir && !$isKnownSafeEntry && $basename === '.htaccess') {
                    $htaccessContents = @file_get_contents($path, false, null, 0, 8192);
                    if ($htaccessContents !== false) {
                        $handlerHijack = MuruguardHelper::checkMaliciousHtaccessHandler($htaccessContents);
                        if ($handlerHijack !== null) { $flagged = true; $reasons[] = $handlerHijack; }
                    }
                }

                // World-writable file permission audit (location-
                // independent, runs both modes, FILES only -- deliberately
                // never checked against directories: cache/logs/tmp/
                // images are routinely forced to 777 by real shared-
                // hosting environments as the only way Joomla can write to
                // them at all, and flagging every such directory on a
                // completely ordinary, non-compromised install would be
                // pure noise. An individual world-writable FILE is a much
                // rarer and much more directly actionable signal -- ANY
                // other tenant's process on that same host can modify it.
                if (!$isDir && !$isKnownSafeEntry) {
                    $worldWritable = MuruguardHelper::checkWorldWritablePermission($path, false);
                    if ($worldWritable !== null) { $flagged = true; $reasons[] = $worldWritable; }
                }

                // Exact-hash malware database (location-independent, runs
                // BOTH modes, unconditionally -- deliberately NOT gated on
                // $isKnownSafeEntry, same "never suppress an unconditional
                // signature check" principle as the content-signature scan
                // itself: an exact byte-for-byte match against a hash the
                // admin has personally confirmed malicious is unambiguous
                // evidence regardless of where the file happens to sit.
                if (!$isDir && !empty($customHashes)) {
                    $hashMatch = MuruguardHelper::checkAgainstCustomMalwareHashes($path, $customHashes);
                    if ($hashMatch !== null) { $flagged = true; $reasons[] = $hashMatch; }
                }

                // core-path masquerade check (location-based, runs both modes)
                $masq = MuruguardHelper::checkCoreMasquerade($relCheck, $isDir, $sig, $path);
                if ($masq !== null) { $flagged = true; $reasons[] = $masq; }

                // junk auto-generated template folder check (location-based, runs both modes)
                $junkTpl = MuruguardHelper::checkJunkTemplateFolder($relCheck, $sig, $path, $registeredTemplates);
                if ($junkTpl !== null) { $flagged = true; $reasons[] = $junkTpl; }

                // junk module/plugin/component folder check (location-based, runs both modes)
                $junkExt = MuruguardHelper::checkJunkExtensionFolder($relCheck, $sig, $registeredPlugins, $registeredComponents, $path);
                if ($junkExt !== null) { $flagged = true; $reasons[] = $junkExt; }

                // stray index.php structural check (location-based, runs both modes)
                if (!$isDir && !$isKnownSafeEntry) {
                    $strayIdx = MuruguardHelper::checkStrayIndexPhp($relCheck, $path, $sig);
                    if ($strayIdx !== null) { $flagged = true; $reasons[] = $strayIdx; }
                }

                if ($flagged) {
                    $this->seenAbs[$path] = true;
                    // Admin-dismissed false positives (see the "Mark as
                    // Safe" button on each finding row) are keyed on the
                    // exact reasons text, not just the path -- if this
                    // exact same file later matches something DIFFERENT
                    // (e.g. an attacker overwrites a previously-dismissed
                    // path with a real backdoor, which trips a different/
                    // additional signature), the fingerprint no longer
                    // matches and it reappears as a fresh finding rather
                    // than staying silently suppressed forever.
                    $fingerprint = MuruguardHelper::fingerprintReasons($reasons);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $relCheck, $fingerprint)) {
                        MuruguardHelper::recordFinding($this->fileFindings, $path, $this->root, $reasons, $isDir);
                    }
                }
                });
            } catch (MuruguardScanChunkTimeout $e) {
                // Whatever this area's walk found before hitting the
                // deadline is already recorded in $this->fileFindings above
                // -- kept as a partial result rather than discarded, with
                // the area marked truncated so runScanChunk() can report it
                // honestly instead of implying a complete scan.
                $this->truncatedAreas[$relDir] = true;
                break;
            }
        }

        // Shallow webroot scan
        $rootItems = ($includeWebrootCore && $this->isAreaSelected('webroot')) ? (@scandir($this->root) ?: []) : [];
        foreach ($rootItems as $it) {
            if ($it === '.' || $it === '..') continue;
            $p = $this->root . '/' . $it;
            if (isset($this->seenAbs[$p])) continue;
            if (preg_match($selfLogPattern, $it)) continue;
            if (preg_match($selfBackupPattern, $it)) continue;
            if (preg_match($googleVerifyPattern, $it)) continue;
            if ($isIgnored($it)) continue;

            if (is_dir($p)) {
                if (in_array(strtolower($it), array_map('strtolower', $sig['KNOWN_ROOT_DIRS']), true)) {
                    continue;
                }

                if (MuruguardHelper::isKnownExtensionDataFolder($it, $sig, $registeredComponents)
                    || MuruguardHelper::isComposerVendorFolder($it, $this->root)) {
                    // Recognized companion data folder of an installed
                    // extension (e.g. ConvertForms' own convertforms_<alias>
                    // custom-code folders) or Composer's own vendor/
                    // dependency tree -- not itself suspicious, but still
                    // content-scanned file by file so malware planted here
                    // later doesn't get a free pass just because the
                    // folder name matches a known convention.
                    $this->seenAbs[$p] = true;
                    MuruguardHelper::walkDir($p, function (string $innerPath, bool $innerIsDir) use ($sig, $maxSize, $falsePositives, $safeBrowsingApiKey) {
                        if ($innerIsDir || isset($this->seenAbs[$innerPath])) return;
                        $this->seenAbs[$innerPath] = true;
                        $innerExt = strtolower(pathinfo($innerPath, PATHINFO_EXTENSION));
                        $innerReasons = [];
                        MuruguardHelper::scanFileContent($innerPath, $innerExt, $sig, $maxSize, $innerReasons, $safeBrowsingApiKey);
                        if (!empty($innerReasons)) {
                            $innerRel = ltrim(str_replace($this->root, '', $innerPath), '/');
                            $innerFp = MuruguardHelper::fingerprintReasons($innerReasons);
                            if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $innerRel, $innerFp)) {
                                MuruguardHelper::recordFinding($this->fileFindings, $innerPath, $this->root, $innerReasons, false);
                            }
                        }
                    });
                    continue;
                }

                // Unrecognized directory -- flagged ONCE, at the folder
                // itself, unless it's made up ENTIRELY of static assets
                // (fonts/images/css/...), a common, legitimate custom
                // template/page-builder asset folder, not a malware
                // staging area (no directory-level flag at all in that
                // case). Confirmed real false positive, twice: first a
                // top-level /fonts folder was flagged High identically to
                // a dropped-shell folder purely because the reason text
                // contained the word "unrecognized"; downgrading it to
                // Medium instead of removing the flag entirely was STILL
                // reported back as a false positive needing individual
                // per-file dismissal.
                //
                // Files inside are never ALSO individually flagged with a
                // blanket "inside an unrecognized folder" structural
                // reason, regardless of which case above applies -- only
                // content-signature scanning decides whether an inner file
                // gets its own finding, same as a known extension's data
                // folder just above. Confirmed real case: a legitimate
                // ~200MB unrelated application (a separate forum/hotspot
                // tool, nothing to do with Joomla) installed in its own
                // top-level folder produced 16,000+ duplicate High-
                // confidence findings, one per file, every single one
                // just repeating the same fact the ONE folder-level
                // finding already states. An actual payload hiding
                // anywhere in the tree is still caught on its own merits
                // by the unconditional content scan below.
                $this->seenAbs[$p] = true;
                $innerFiles = [];
                $hasNonAssetContent = false;
                MuruguardHelper::walkDir($p, function (string $innerPath, bool $innerIsDir) use (&$innerFiles, &$hasNonAssetContent, $sig) {
                    if ($innerIsDir) return;
                    $innerFiles[] = $innerPath;
                    $innerExt = strtolower(pathinfo($innerPath, PATHINFO_EXTENSION));
                    if (!in_array($innerExt, $sig['ICONFONT_ALLOWED_EXTENSIONS'], true)) $hasNonAssetContent = true;
                });

                if ($hasNonAssetContent) {
                    $dirReason = 'Unrecognized directory directly in the Joomla webroot — not part of a standard install.';
                    $dirFp = MuruguardHelper::fingerprintReasons([$dirReason]);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $it, $dirFp)) {
                        MuruguardHelper::recordFinding($this->fileFindings, $p, $this->root, $dirReason, true);
                    }
                }

                foreach ($innerFiles as $innerPath) {
                    if (isset($this->seenAbs[$innerPath])) continue;
                    $this->seenAbs[$innerPath] = true;
                    $innerExt = strtolower(pathinfo($innerPath, PATHINFO_EXTENSION));
                    $innerReasons = [];
                    MuruguardHelper::scanFileContent($innerPath, $innerExt, $sig, $maxSize, $innerReasons, $safeBrowsingApiKey);
                    if (!empty($innerReasons)) {
                        $innerRel = ltrim(str_replace($this->root, '', $innerPath), '/');
                        $innerFp = MuruguardHelper::fingerprintReasons($innerReasons);
                        if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $innerRel, $innerFp)) {
                            MuruguardHelper::recordFinding($this->fileFindings, $innerPath, $this->root, $innerReasons, false);
                        }
                    }
                }
                continue;
            }

            if (!is_file($p)) continue;
            if (in_array(strtolower($it), array_map('strtolower', $sig['KNOWN_ROOT_FILES']), true)) continue;
            if (preg_match($sig['MYJOOMLA_CHECKSUM_FILE_RE'], $it)) continue;
            $relCheck = ltrim(str_replace($this->root, '', $p), '/');
            if (in_array($relCheck, $sig['KNOWN_SAFE_RELATIVE_FILES'], true)) continue;

            $flaggedRoot = false;
            $reasonsRoot = [];
            foreach ($sig['SUSPICIOUS_FILENAME_REGEXES'] as $re) {
                if (preg_match($re, $it)) { $flaggedRoot = true; $reasonsRoot[] = 'Filename matches known malicious pattern.'; break; }
            }
            foreach ($sig['ROOT_SUSPICIOUS_FILENAME_REGEXES'] as $re) {
                if (preg_match($re, $it)) { $flaggedRoot = true; $reasonsRoot[] = 'Filename resembles a known dropped-shell naming pattern.'; break; }
            }
            foreach ($sig['CONFIG_BACKUP_PATTERNS'] as $re) {
                if (preg_match($re, $it)) { $flaggedRoot = true; $reasonsRoot[] = 'Backup/duplicate configuration file — leaks the same credentials as configuration.php.'; break; }
            }

            $masqRoot = MuruguardHelper::checkCoreMasquerade($relCheck, false, $sig, $p);
            if ($masqRoot !== null) { $flaggedRoot = true; $reasonsRoot[] = $masqRoot; }

            $dotfileRoot = MuruguardHelper::checkRootLevelDotfile($it);
            if ($dotfileRoot !== null) { $flaggedRoot = true; $reasonsRoot[] = $dotfileRoot; }

            $extR = strtolower(pathinfo($p, PATHINFO_EXTENSION));
            MuruguardHelper::scanFileContent($p, $extR, $sig, $maxSize, $reasonsRoot, $safeBrowsingApiKey);
            if (count($reasonsRoot) > ($flaggedRoot ? 1 : 0)) $flaggedRoot = true;

            $benignStaticExts = ['css', 'jpg', 'jpeg', 'png', 'gif', 'svg', 'ico', 'webp', 'woff', 'woff2', 'ttf', 'eot', 'map'];
            $benignRootLogFile = in_array(strtolower($it), $sig['BENIGN_ROOT_LOG_FILES'], true);
            $benignSitemapVariant = (bool) preg_match($sig['SITEMAP_VARIANT_RE'], $it);
            if (!$flaggedRoot && !$benignRootLogFile && !$benignSitemapVariant && !in_array($extR, $benignStaticExts, true)) {
                $flaggedRoot = true;
                $reasonsRoot[] = 'Unrecognized file directly in the Joomla webroot — not part of a standard install.';
            }

            if ($flaggedRoot) {
                $this->seenAbs[$p] = true;
                $rootFp = MuruguardHelper::fingerprintReasons($reasonsRoot);
                if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $relCheck, $rootFp)) {
                    MuruguardHelper::recordFinding($this->fileFindings, $p, $this->root, $reasonsRoot, false);
                }
            }
        }

        // Core entry-point integrity + content-signature scan, plus (when
        // the site's exact Joomla version is covered by the bundled
        // manifest) a byte-for-byte checksum comparison against the
        // official release -- unambiguous proof of tampering, independent
        // of and stronger than every heuristic check here.
        $joomlaVersion = MuruguardHelper::getInstalledJoomlaVersion($this->root);
        $checksumManifest = MuruguardHelper::getCoreChecksumManifest();

        $coreEntries = ($includeWebrootCore && $this->isAreaSelected('core_entry')) ? $sig['CORE_ENTRY_POINTS'] : [];
        foreach ($coreEntries as $relEntry) {
            $absEntry = $this->root . '/' . $relEntry;
            if (!is_file($absEntry)) continue;
            $size = @filesize($absEntry);
            if ($size === false || $size > $maxSize) continue;
            $contents = @file_get_contents($absEntry);
            if ($contents === false) continue;

            $reasonsEntry = [];
            $issue = MuruguardHelper::checkCoreIndexIntegrity($contents);
            if ($issue !== null) $reasonsEntry[] = $issue;

            $ext = strtolower(pathinfo($absEntry, PATHINFO_EXTENSION));
            MuruguardHelper::scanFileContent($absEntry, $ext, $sig, $maxSize, $reasonsEntry, $safeBrowsingApiKey);

            $checksumIssue = MuruguardHelper::checkCoreFileChecksum($relEntry, $absEntry, $joomlaVersion, $checksumManifest);
            if ($checksumIssue !== null) $reasonsEntry[] = $checksumIssue;

            if (!empty($reasonsEntry)) {
                $this->seenAbs[$absEntry] = true;
                MuruguardHelper::recordFinding($this->fileFindings, $absEntry, $this->root, $reasonsEntry, false);
            }
        }

        // Checksum-only pass for the remaining manifest-covered static
        // files (includes/framework.php, robots.txt.dist, htaccess.txt,
        // web.config.txt) -- none of these paths are reached by any other
        // scan pass above, so there's no risk of a second recordFinding()
        // call on the same file silently overwriting an earlier finding.
        if ($includeWebrootCore && $this->isAreaSelected('core_entry') && $joomlaVersion !== null && isset($checksumManifest[$joomlaVersion])) {
            $staticCoreFiles = ['includes/framework.php', 'robots.txt.dist', 'htaccess.txt', 'web.config.txt'];
            foreach ($staticCoreFiles as $relEntry) {
                $absEntry = $this->root . '/' . $relEntry;
                if (isset($this->seenAbs[$absEntry]) || !is_file($absEntry)) continue;

                $checksumIssue = MuruguardHelper::checkCoreFileChecksum($relEntry, $absEntry, $joomlaVersion, $checksumManifest);
                if ($checksumIssue !== null) {
                    $this->seenAbs[$absEntry] = true;
                    MuruguardHelper::recordFinding($this->fileFindings, $absEntry, $this->root, [$checksumIssue], false);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Database scan
    // ------------------------------------------------------------------

    public function scanDatabase(): void
    {
        if (!$this->isAreaSelected('database')) return;

        $db  = $this->getDatabase();
        $sig = MuruguardHelper::getSignatures();
        $falsePositives = MuruguardHelper::getFalsePositiveLookup();

        try {
            $query = $db->getQuery(true)
                ->select('u.id, u.name, u.username, u.email, u.registerDate, u.lastvisitDate')
                ->from($db->quoteName('#__users', 'u'))
                ->join('INNER', $db->quoteName('#__user_usergroup_map', 'm') . ' ON ' . $db->quoteName('m.user_id') . ' = ' . $db->quoteName('u.id'))
                ->where($db->quoteName('m.group_id') . ' IN (SELECT id FROM ' . $db->quoteName('#__usergroups') . ' WHERE title IN (' . $db->quote('Super Users') . ',' . $db->quote('Super User') . '))')
                ->order($db->quoteName('u.registerDate') . ' DESC');
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
            foreach ($rows as $row) {
                $suspicious = false;
                $why = [];
                if (stripos($row['email'], 'secure.local') !== false) { $suspicious = true; $why[] = 'email domain: secure.local (known attacker marker)'; }
                if (preg_match('/webmanager\d+|codex|sppb/i', $row['username'])) { $suspicious = true; $why[] = 'username matches known attacker pattern'; }
                // A widespread automated attack wave injects a rogue Super
                // User account using exactly this email address on hijacked
                // sites (regardless of username/display name, which vary).
                // Exact match only -- this is a known literal marker, not a
                // pattern, so no false positives on legitimate similar-looking
                // addresses.
                if (strcasecmp(trim((string) $row['email']), 'joomla@test.com') === 0) { $suspicious = true; $why[] = 'known mass-attack marker: injected admin account using joomla@test.com'; }
                // Only a "suspicious" row is ever a candidate for dismissal
                // -- an already-normal row has nothing to suppress.
                if ($suspicious) {
                    $fingerprint = MuruguardHelper::fingerprintReasons($why);
                    if (MuruguardHelper::isFalsePositive($falsePositives, 'superusers', (string) $row['id'], $fingerprint)) {
                        $suspicious = false;
                        $why = [];
                    }
                }
                $this->dbFindings['superusers'][] = [
                    'id' => $row['id'], 'name' => $row['name'], 'username' => $row['username'],
                    'email' => $row['email'], 'registered' => $row['registerDate'], 'lastvisit' => $row['lastvisitDate'],
                    'suspicious' => $suspicious, 'why' => implode('; ', $why), 'why_list' => $why,
                ];
            }
        } catch (\Throwable $e) { /* table missing or query failed -- non-fatal */ }

        try {
            $query = $db->getQuery(true)->select('id, title, link, params')->from($db->quoteName('#__menu'));
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
            foreach ($rows as $row) {
                $params = (string) ($row['params'] ?? '');
                $matches = [];
                foreach ($sig['MENU_XSS_PATTERNS'] as $label => $re) {
                    if (preg_match($re, $params)) $matches[] = $label;
                }
                if (!empty($matches)) {
                    $fingerprint = MuruguardHelper::fingerprintReasons($matches);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'menu_xss', (string) $row['id'], $fingerprint)) {
                        $this->dbFindings['menu_xss'][] = [
                            'id' => $row['id'], 'title' => $row['title'], 'link' => $row['link'], 'matches' => $matches,
                        ];
                    }
                }
            }
        } catch (\Throwable $e) { /* non-fatal */ }

        // A template style's own params blob is where Helix Ultimate/
        // Helix 3 (and similar frameworks) store the "Custom JavaScript"/
        // "Custom CSS" fields from the template's Options screen -- just
        // as attacker-controllable, and just as capable of running on
        // every single page load, as a #__menu item's params above. Same
        // MENU_XSS_PATTERNS (see that constant's docblock), same false-
        // positive dismissal flow, deliberately a separate finding
        // category ('template_style_xss') so cleaning one never touches
        // the other.
        try {
            $query = $db->getQuery(true)->select('id, template, title, params')->from($db->quoteName('#__template_styles'));
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
            foreach ($rows as $row) {
                $params = (string) ($row['params'] ?? '');
                $matches = [];
                foreach ($sig['MENU_XSS_PATTERNS'] as $label => $re) {
                    if (preg_match($re, $params)) $matches[] = $label;
                }
                if (!empty($matches)) {
                    $fingerprint = MuruguardHelper::fingerprintReasons($matches);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'template_style_xss', (string) $row['id'], $fingerprint)) {
                        $this->dbFindings['template_style_xss'][] = [
                            'id' => $row['id'], 'title' => $row['title'], 'template' => $row['template'], 'matches' => $matches,
                        ];
                    }
                }
            }
        } catch (\Throwable $e) { /* non-fatal */ }

       try {

    $this->dbFindings['sppb_assets'] = [];
    $this->dbFindings['rogue_iconfont'] = [];

    // Load all SP Page Builder assets
    $query = $db->getQuery(true)
        ->select('*')
        ->from($db->quoteName('#__sppagebuilder_assets'))
        ->order($db->quoteName('id') . ' DESC');

    $db->setQuery($query);
    $rows = $db->loadAssocList() ?: [];


    foreach ($rows as $row) {

        $reasons = [];

        // The real #__sppagebuilder_assets column is "assets" (a JSON/text
        // blob of the actual icon-font/asset definition) -- NOT
        // "asset_value", which doesn't exist in this table at all and was
        // silently always empty, meaning every payload check below matched
        // against '' on every real install regardless of what this row
        // actually contained. css_path is checked too: it's the other
        // attacker-controllable text field here, and should only ever
        // reference a real .css file -- never inline code, never a PHP path.
        $assetValue = (string) ($row['assets'] ?? '');
        $cssPath    = (string) ($row['css_path'] ?? '');
        $type       = strtolower((string) ($row['type'] ?? ''));
        $name       = strtolower((string) ($row['name'] ?? ''));
        $createdBy  = (int) ($row['created_by'] ?? 0);


        /*
         * Payload detection -- runs against every row regardless of type or
         * name. A "known good" iconfont name (icofont, icomoon, ...) is
         * only ever a name -- it is never a substitute for actually
         * checking what this row's content contains, since nothing stops
         * an attacker from naming a malicious row "icofont" too.
         */
        foreach ([$assetValue, $cssPath] as $content) {
            if (stripos($content, 'xss.report') !== false) {
                $reasons[] = 'Contains xss.report';
            }

            if (stripos($content, 'base64_decode') !== false) {
                $reasons[] = 'Contains base64_decode()';
            }

            if (stripos($content, 'eval(') !== false) {
                $reasons[] = 'Contains eval()';
            }

            if (stripos($content, '<script') !== false) {
                $reasons[] = 'Contains script tag';
            }

            if (preg_match('/on(load|error|click|mouseover)\s*=/i', $content)) {
                $reasons[] = 'Contains JavaScript event handler';
            }

            if (preg_match('/<\?php|<\?=\s*[\$A-Za-z_(]/i', $content)) {
                $reasons[] = 'Contains a PHP open tag';
            }
        }

        // css_path should only ever point at a real stylesheet -- a path
        // ending in .php/.phtml/etc. (or any other executable extension)
        // is a direct way to smuggle a runnable file reference through a
        // field nobody expects to hold one.
        if ($cssPath !== '') {
            $cssExt = strtolower(pathinfo(parse_url($cssPath, PHP_URL_PATH) ?: $cssPath, PATHINFO_EXTENSION));
            if (in_array($cssExt, $sig['EXEC_EXTS'], true)) {
                $reasons[] = "css_path references an executable file (.{$cssExt}), not a stylesheet";
            }
        }


        /*
         * Iconfont detection -- a secondary, name-based signal ON TOP OF
         * the content checks above, not a replacement for them. A row
         * named exactly "icofont" (SP Page Builder's own bundled default)
         * still goes through every content check above; this block only
         * adds an extra reason when the name itself doesn't match that
         * one known-legitimate default.
         */
        if ($type === 'iconfont') {

            // Ignore known-legitimate iconfont names (see
            // KNOWN_GOOD_ICONFONT_NAMES's docblock for why this is only
            // a secondary signal, not a substitute for the content checks
            // above).
            if (!in_array($name, $sig['KNOWN_GOOD_ICONFONT_NAMES'], true)) {

                $iconfontReasons = ['Non-default iconfont'];
                if ($createdBy === 0) {
                    $iconfontReasons[] = 'Created by Guest/System';
                }
                $reasons = array_merge($reasons, $iconfontReasons);

                $rogueFingerprint = MuruguardHelper::fingerprintReasons($iconfontReasons);
                if (!MuruguardHelper::isFalsePositive($falsePositives, 'rogue_iconfont', (string) $row['id'], $rogueFingerprint)) {
                    $rogueRow = $row;
                    $rogueRow['scan_reasons'] = $iconfontReasons;
                    $this->dbFindings['rogue_iconfont'][] = $rogueRow;
                }
            }
        }


        /*
         * Only store suspicious rows
         */
        if (!empty($reasons)) {

            $row['scan_reasons'] = array_values(array_unique($reasons));

            $sppbFingerprint = MuruguardHelper::fingerprintReasons($row['scan_reasons']);
            if (!MuruguardHelper::isFalsePositive($falsePositives, 'sppb_assets', (string) $row['id'], $sppbFingerprint)) {
                $this->dbFindings['sppb_assets'][] = $row;
            }
        }
    }


} catch (\Throwable $e) {

    // table missing or query failed
    $this->dbFindings['sppb_assets'] = [];
    $this->dbFindings['rogue_iconfont'] = [];

}

        try {
            $query = $db->getQuery(true)->select('id, template, title, params, client_id')->from($db->quoteName('#__template_styles'));
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
            $registeredTemplates = $this->getRegisteredTemplates();
            foreach ($rows as $row) {
                $matches = [];
                foreach ($sig['DEFACEMENT_PATTERNS'] as $pattern) {
                    if (preg_match($pattern, (string) $row['params'], $m)) $matches[] = $m[0];
                }

                $templateName = (string) $row['template'];
                $clientId     = (int) $row['client_id'];
                $isSystemTemplate = in_array(strtolower($templateName), $sig['TEMPLATE_SYSTEM_FOLDER_NAMES'], true);

                if ($templateName !== '' && !$isSystemTemplate) {
                    // Strongest, hardest-to-fake signal first: cross-reference
                    // Joomla's own #__extensions registry -- see
                    // getRegisteredTemplates()/checkJunkTemplateFolder() for
                    // why this is checked ahead of the on-disk manifest
                    // check below. A real attack faked the folder AND its
                    // templateDetails.xml AND even a matching #__extensions
                    // row, but every faked #__extensions row was left
                    // disabled -- unlike every genuinely-installed template.
                    if ($registeredTemplates !== null) {
                        $key = $clientId . '|' . strtolower($templateName);
                        if (!array_key_exists($key, $registeredTemplates)) {
                            $matches[] = "No matching #__extensions row of type \"template\" exists for \"{$templateName}\" -- Joomla never actually installed this as a real template";
                        } elseif (!$registeredTemplates[$key]) {
                            $matches[] = "Matching #__extensions row for \"{$templateName}\" exists but is disabled (enabled = 0) -- a strong sign of an injected row rather than a real, active template";
                        }
                    }

                    // Independent, on-disk corroborating signals -- still
                    // checked even when the registry already flagged the
                    // row above, and still useful on their own when the
                    // registry itself is unavailable (see getRegisteredTemplates()).
                    $templateDir = $clientId === 1
                        ? JPATH_ADMINISTRATOR . '/templates/' . $templateName
                        : $this->root . '/templates/' . $templateName;
                    $noManifest = !is_file($templateDir . '/templateDetails.xml');
                    $junkName   = (bool) preg_match($sig['TEMPLATE_STYLE_JUNK_NAME_RE'], $templateName);

                    if ($noManifest) {
                        $matches[] = is_dir($templateDir)
                            ? "Template folder \"{$templateName}\" exists but has no templateDetails.xml manifest -- was never actually installed as a real template, orphaned or injected row"
                            : "Template folder not found on disk ({$templateName}) -- orphaned or injected row";
                    }
                    if ($junkName) {
                        $matches[] = 'Auto-generated junk name pattern (tmpl_xxxxxx)';
                    }
                }

                if (!empty($matches)) {
                    $fingerprint = MuruguardHelper::fingerprintReasons($matches);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'template_defacement', (string) $row['id'], $fingerprint)) {
                        $this->dbFindings['template_defacement'][] = [
                            'id' => $row['id'], 'template' => $row['template'], 'title' => $row['title'], 'matches' => $matches,
                        ];
                    }
                }
            }
        } catch (\Throwable $e) { /* non-fatal */ }

        // Known-vulnerability cross-check -- cheap (one #__extensions
        // query + comparing against the already-cached feed, no file I/O),
        // so it runs as part of every scan alongside everything else here.
        $this->dbFindings['vulnerable_extensions'] = $this->getVulnerableExtensions();
    }

    // ------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------

    /** Files a recursive folder delete may snapshot before refusing the whole delete rather than partially protecting it -- same cap the bulk mark-safe/bulk AI-check actions already use (v3.5.7). */
    private const TM_MAX_SNAPSHOTS_PER_FOLDER_DELETE = 500;

    public function deleteTargets(array $targets): array
    {
        $this->fileFindings = $this->getFileFindings();
        $sig = MuruguardHelper::getSignatures();
        $rootReal = realpath($this->root);
        $protectedAbs = array_map(fn($d) => $rootReal . DIRECTORY_SEPARATOR . $d, $sig['PROTECTED_TOP_DIRS']);
        $registeredTemplates = $this->getRegisteredTemplates();
        $flash = [];

        // One TimeMachine transaction per bulk-delete submission -- every
        // file this call actually removes (across possibly several
        // targets, folders included) rolls back together as one unit.
        $transactionId = 'tm_' . bin2hex(random_bytes(8));
        $user = MuruguardHelper::currentUsername();

        foreach ($targets as $relPath) {
            $relPath = (string) $relPath;
            if (!isset($this->fileFindings[$relPath])) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NOT_FLAGGED', $relPath); continue; }
            $abs = realpath($this->root . '/' . $relPath);
            if ($abs === false) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_VANISHED', $relPath); continue; }
            if (strpos($abs, $rootReal . DIRECTORY_SEPARATOR) !== 0) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_OUTSIDE_ROOT', $relPath); continue; }
            if (basename($abs) === 'configuration.php') { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_PROTECTED', $relPath); continue; }
            if (in_array($abs, $protectedAbs, true) || $abs === $rootReal) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_PROTECTED_DIR', $relPath); continue; }

            if (MuruguardHelper::isProtectedEntryPath($relPath, $sig, $abs, $registeredTemplates)) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_REQUIRED_ENTRY', $relPath);
                continue;
            }

            if (is_dir($abs)) {
                // Every file under this folder must be snapshotted BEFORE
                // deleteRecursive() runs -- it deletes bottom-up and
                // leaves nothing to read afterward.
                $filesUnder = [];
                MuruguardHelper::walkDir($abs, function (string $p, bool $isDir) use (&$filesUnder) {
                    if (!$isDir) $filesUnder[] = $p;
                });
                if (count($filesUnder) > self::TM_MAX_SNAPSHOTS_PER_FOLDER_DELETE) {
                    $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_TOO_MANY_TO_SNAPSHOT', $relPath);
                    continue;
                }

                $snapshotIds = [];
                $snapshotFailed = false;
                foreach ($filesUnder as $fileAbs) {
                    $fileRel = ltrim(str_replace($rootReal, '', $fileAbs), '/');
                    $content = @file_get_contents($fileAbs);
                    if ($content === false) { $snapshotFailed = true; break; }
                    $sid = MuruguardTimeMachineHelper::recordSnapshot([
                        'transaction_id' => $transactionId, 'user' => $user, 'kind' => 'file', 'origin' => 'cleanup', 'tool' => 'delete',
                        'rel_path' => $fileRel, 'before_existed' => true, 'before_content' => $content, 'after_existed' => false,
                    ]);
                    if ($sid === null) { $snapshotFailed = true; break; }
                    $snapshotIds[] = $sid;
                }
                if ($snapshotFailed) {
                    foreach ($snapshotIds as $sid) MuruguardTimeMachineHelper::discardSnapshot($sid);
                    $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_SNAPSHOT_FAILED', $relPath);
                    continue;
                }

                $flash[] = MuruguardHelper::deleteRecursive($abs) ? Text::sprintf('COM_MURUGUARD_FLASH_DELETED_FOLDER', $relPath) : Text::sprintf('COM_MURUGUARD_FLASH_FAILED_PERMISSIONS', $relPath);
            } elseif (is_file($abs)) {
                $content = @file_get_contents($abs);
                if ($content === false) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_UNREADABLE', $relPath); continue; }

                $sid = MuruguardTimeMachineHelper::recordSnapshot([
                    'transaction_id' => $transactionId, 'user' => $user, 'kind' => 'file', 'origin' => 'cleanup', 'tool' => 'delete',
                    'rel_path' => $relPath, 'before_existed' => true, 'before_content' => $content, 'after_existed' => false,
                ]);
                if ($sid === null) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_SNAPSHOT_FAILED', $relPath); continue; }

                if (@unlink($abs)) {
                    $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_DELETED', $relPath);
                } else {
                    MuruguardTimeMachineHelper::discardSnapshot($sid);
                    $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_FAILED_PERMISSIONS', $relPath);
                }
            }
        }

        Factory::getApplication()->getSession()->set('muruguard.filefindings', null);
        return $flash;
    }

    /**
     * Surgically repairs selected files instead of deleting them -- for
     * the well-bounded injection patterns this scanner can safely fix
     * (a payload prepended before Joomla's bootstrap/access guard, or a
     * <script> block injected right after <head>) the exact malicious
     * region is known, so it can be stripped while leaving the rest of
     * the file -- a genuinely legitimate Joomla core/template file --
     * completely untouched. A TimeMachine snapshot of the original is
     * always taken first (replacing this method's previous bespoke
     * "copy to a .muruguard-<timestamp>.bak file" step) so the change is
     * restorable through the same rollback UI/retention lifecycle every
     * other repair uses, instead of an unmanaged file nobody cleans up.
     */
    public function cleanCodeFiles(array $targets): array
    {
        $this->fileFindings = $this->getFileFindings();
        $rootReal = realpath($this->root);
        $cleanableExts = ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'pht', 'html', 'htm'];
        $flash = [];
        $user = MuruguardHelper::currentUsername();

        foreach ($targets as $relPath) {
            $relPath = (string) $relPath;
            if (!isset($this->fileFindings[$relPath])) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NOT_FLAGGED', $relPath); continue; }

            $abs = realpath($this->root . '/' . $relPath);
            if ($abs === false || !is_file($abs)) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_VANISHED', $relPath); continue; }
            if (strpos($abs, $rootReal . DIRECTORY_SEPARATOR) !== 0) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_OUTSIDE_ROOT', $relPath); continue; }

            $ext = strtolower(pathinfo($abs, PATHINFO_EXTENSION));
            if (!in_array($ext, $cleanableExts, true)) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NOT_CLEANABLE_TYPE', $relPath);
                continue;
            }

            // Checked explicitly (rather than only relying on
            // file_put_contents()'s return value) so a permissions
            // problem -- the single most common real-world reason a
            // "successful" clean silently doesn't stick on shared
            // hosting -- gets its own clear, actionable message.
            if (!is_writable($abs)) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NOT_WRITABLE', $relPath);
                continue;
            }

            $contents = @file_get_contents($abs);
            if ($contents === false) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_UNREADABLE', $relPath); continue; }

            $result = MuruguardHelper::cleanPrependedPayload($contents);
            if (!$result['changed']) {
                $result = MuruguardHelper::cleanHeadTagInjection($contents);
            }
            if (!$result['changed']) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NO_PATTERN', $relPath);
                continue;
            }

            // One transaction per file here (unlike deleteTargets()'s
            // one-per-submission) -- each Clean Code click on this file
            // is its own independently rollback-able repair.
            $transactionId = 'tm_' . bin2hex(random_bytes(8));
            $snapshotId = MuruguardTimeMachineHelper::recordSnapshot([
                'transaction_id' => $transactionId, 'user' => $user, 'kind' => 'file', 'origin' => 'cleanup', 'tool' => 'clean_code',
                'rel_path' => $relPath, 'before_existed' => true, 'before_content' => $contents,
                'after_existed' => true, 'after_content' => $result['cleaned'],
            ]);
            if ($snapshotId === null) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_SNAPSHOT_FAILED', $relPath);
                continue;
            }

            if (@file_put_contents($abs, $result['cleaned']) === false) {
                MuruguardTimeMachineHelper::discardSnapshot($snapshotId);
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_FAILED_WRITE', $relPath);
                continue;
            }

            // Verify the write actually stuck by re-reading the file from
            // disk and confirming the same issue no longer matches --
            // catches caching layers, race conditions, or any other way a
            // "successful" write could fail to actually take effect,
            // instead of just trusting file_put_contents()'s return value.
            clearstatcache(true, $abs);
            $verifyContents = @file_get_contents($abs);
            $stillInfected = $verifyContents !== false && (
                MuruguardHelper::cleanPrependedPayload($verifyContents)['changed']
                || MuruguardHelper::cleanHeadTagInjection($verifyContents)['changed']
            );
            if ($stillInfected) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_WARNING_REVERTED', $relPath);
                continue;
            }

            MuruguardHelper::recordAttackLogEntry([
                'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
                'rule' => 'cleanup_clean_code', 'severity' => 'low',
                'why' => 'Clean Code repaired a file (TimeMachine snapshot taken, restorable).',
                'matched' => $relPath,
            ]);
            $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_CLEANED', $result['removed_preview'], $relPath);
        }

        Factory::getApplication()->getSession()->set('muruguard.filefindings', null);
        return $flash;
    }

    public function cleanMenuXss(array $ids): array
    {
        $db = $this->getDatabase();
        $sig = MuruguardHelper::getSignatures();
        $flash = [];
        $user = MuruguardHelper::currentUsername();

        foreach ($ids as $id) {
            $id = (int) $id;
            $query = $db->getQuery(true)->select('params')->from($db->quoteName('#__menu'))->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($query);
            $paramsJson = $db->loadResult();
            if ($paramsJson === null) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_ROW_NOT_FOUND', $id); continue; }

            $result = MuruguardHelper::cleanMenuParamsXss((string) $paramsJson, array_values($sig['MENU_XSS_PATTERNS']));
            if (!$result['changed']) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_UNPARSEABLE', $id); continue; }

            $snapshotId = MuruguardTimeMachineHelper::recordSnapshot([
                'transaction_id' => 'tm_' . bin2hex(random_bytes(8)), 'user' => $user, 'kind' => 'db_row', 'origin' => 'cleanup', 'tool' => 'clean_menu_xss',
                'table' => '#__menu', 'pk_column' => 'id', 'pk_value' => $id,
                'before_row' => ['params' => (string) $paramsJson], 'after_row' => ['params' => $result['cleaned']], 'restore_type' => 'update',
            ]);
            if ($snapshotId === null) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_SNAPSHOT_FAILED', $id); continue; }

            $update = $db->getQuery(true)->update($db->quoteName('#__menu'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($result['cleaned']))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($update);
            $db->execute();
            MuruguardHelper::recordAttackLogEntry([
                'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
                'rule' => 'cleanup_clean_menu_xss', 'severity' => 'low',
                'why' => 'Clean Menu XSS repaired a #__menu row (TimeMachine snapshot taken, restorable).', 'matched' => (string) $id,
            ]);
            $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_CLEANED_MENU', $id);
        }
        return $flash;
    }

    /** Same surgical XSS-stripping approach as cleanMenuXss(), targeting #__template_styles.params instead (a template's "Custom JavaScript"/"Custom CSS" fields). */
    public function cleanTemplateStyleXss(array $ids): array
    {
        $db = $this->getDatabase();
        $sig = MuruguardHelper::getSignatures();
        $flash = [];
        $user = MuruguardHelper::currentUsername();

        foreach ($ids as $id) {
            $id = (int) $id;
            $query = $db->getQuery(true)->select('params')->from($db->quoteName('#__template_styles'))->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($query);
            $paramsJson = $db->loadResult();
            if ($paramsJson === null) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_ROW_NOT_FOUND', $id); continue; }

            $result = MuruguardHelper::cleanMenuParamsXss((string) $paramsJson, array_values($sig['MENU_XSS_PATTERNS']));
            if (!$result['changed']) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_UNPARSEABLE', $id); continue; }

            $snapshotId = MuruguardTimeMachineHelper::recordSnapshot([
                'transaction_id' => 'tm_' . bin2hex(random_bytes(8)), 'user' => $user, 'kind' => 'db_row', 'origin' => 'cleanup', 'tool' => 'clean_template_style_xss',
                'table' => '#__template_styles', 'pk_column' => 'id', 'pk_value' => $id,
                'before_row' => ['params' => (string) $paramsJson], 'after_row' => ['params' => $result['cleaned']], 'restore_type' => 'update',
            ]);
            if ($snapshotId === null) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_SNAPSHOT_FAILED', $id); continue; }

            $update = $db->getQuery(true)->update($db->quoteName('#__template_styles'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($result['cleaned']))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($update);
            $db->execute();
            MuruguardHelper::recordAttackLogEntry([
                'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
                'rule' => 'cleanup_clean_template_style_xss', 'severity' => 'low',
                'why' => 'Clean Template Style XSS repaired a #__template_styles row (TimeMachine snapshot taken, restorable).', 'matched' => (string) $id,
            ]);
            $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_CLEANED_TEMPLATE_STYLE', $id);
        }
        return $flash;
    }

    /** Deletes selected rogue SP Page Builder asset rows -- each row is read and snapshotted BEFORE the bulk DELETE so it can be re-inserted later, same fetch-then-mutate shape the other db_row-snapshotting actions use. */
    public function deleteRogueAssets(array $ids): void
    {
        if (empty($ids)) return;
        $db = $this->getDatabase();
        $ids = array_map('intval', $ids);
        $user = MuruguardHelper::currentUsername();
        $transactionId = 'tm_' . bin2hex(random_bytes(8));

        $query = $db->getQuery(true)->select('*')->from($db->quoteName('#__sppagebuilder_assets'))
            ->where($db->quoteName('id') . ' IN (' . implode(',', $ids) . ')');
        $db->setQuery($query);
        $rows = $db->loadAssocList() ?: [];

        $survivingIds = [];
        foreach ($rows as $row) {
            $snapshotId = MuruguardTimeMachineHelper::recordSnapshot([
                'transaction_id' => $transactionId, 'user' => $user, 'kind' => 'db_row', 'origin' => 'cleanup', 'tool' => 'delete_rogue_asset',
                'table' => '#__sppagebuilder_assets', 'pk_column' => 'id', 'pk_value' => (int) $row['id'],
                'before_row' => $row, 'after_existed' => false, 'restore_type' => 'insert',
            ]);
            // A row whose snapshot failed is skipped entirely (fail-
            // closed) rather than deleted unprotected -- it simply stays
            // in the DB for the admin to retry.
            if ($snapshotId !== null) $survivingIds[] = (int) $row['id'];
        }
        if (empty($survivingIds)) return;

        $query = $db->getQuery(true)->delete($db->quoteName('#__sppagebuilder_assets'))
            ->where($db->quoteName('id') . ' IN (' . implode(',', $survivingIds) . ')');
        $db->setQuery($query);
        $db->execute();
        MuruguardHelper::recordAttackLogEntry([
            'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
            'rule' => 'cleanup_delete_rogue_asset', 'severity' => 'low',
            'why' => 'Deleted ' . count($survivingIds) . ' rogue SP Page Builder asset row(s) (TimeMachine snapshots taken, restorable).',
            'matched' => implode(',', $survivingIds),
        ]);
    }

    /**
     * Deletes selected #__template_styles rows, but only the ones
     * independently confirmed as junk/injected -- an orphaned template
     * reference (folder not found on disk) or an auto-generated
     * tmpl_xxxxxx name. Rows flagged only for classic defacement TEXT are
     * left alone and reported as skipped: a text match alone isn't a
     * reliable enough signal to safely auto-delete a row that might
     * otherwise be a legitimate style (false positives are more likely
     * there than for the junk-name/orphaned-folder checks). Re-derives
     * each row's flags fresh from the DB rather than trusting the cached
     * scan result, same as cleanMenuXss() above.
     */
    public function cleanTemplateDefacement(array $ids): array
    {
        $db  = $this->getDatabase();
        $sig = MuruguardHelper::getSignatures();
        $flash = [];
        $user = MuruguardHelper::currentUsername();

        // Same registry cross-reference scanDatabase() already reports
        // against (see getRegisteredTemplates()) -- without this, a row
        // flagged ONLY because its #__extensions record is missing/
        // disabled (manifest present, name not junk-patterned) would show
        // up as a template_defacement finding but then get skipped here
        // every time, since neither $noManifest nor $junkName alone would
        // be true for it.
        $registeredTemplates = $this->getRegisteredTemplates();

        foreach ($ids as $id) {
            $id = (int) $id;
            $query = $db->getQuery(true)->select('id, template, client_id')
                ->from($db->quoteName('#__template_styles'))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($query);
            $row = $db->loadAssoc();
            if ($row === null) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_ROW_NOT_FOUND', $id);
                continue;
            }

            $templateDir = ((int) $row['client_id']) === 1
                ? JPATH_ADMINISTRATOR . '/templates/' . $row['template']
                : $this->root . '/templates/' . $row['template'];
            $isSystemTemplate = in_array(strtolower((string) $row['template']), $sig['TEMPLATE_SYSTEM_FOLDER_NAMES'], true);
            $noManifest = !$isSystemTemplate && $row['template'] !== '' && !is_file($templateDir . '/templateDetails.xml');
            $junkName   = (bool) preg_match($sig['TEMPLATE_STYLE_JUNK_NAME_RE'], (string) $row['template']);

            $registryProblem = false;
            if (!$isSystemTemplate && $row['template'] !== '' && $registeredTemplates !== null) {
                $key = ((int) $row['client_id']) . '|' . strtolower((string) $row['template']);
                $registryProblem = !array_key_exists($key, $registeredTemplates) || !$registeredTemplates[$key];
            }

            if (!$noManifest && !$junkName && !$registryProblem) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_REVIEW_DEFACEMENT', $id);
                continue;
            }

            // Full row (not just the id/template/client_id columns
            // selected above for detection) is what a re-INSERT rollback
            // needs to reconstruct the row exactly.
            $fullRowQuery = $db->getQuery(true)->select('*')->from($db->quoteName('#__template_styles'))->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($fullRowQuery);
            $fullRow = $db->loadAssoc();
            if ($fullRow === null) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_ROW_NOT_FOUND', $id); continue; }

            $snapshotId = MuruguardTimeMachineHelper::recordSnapshot([
                'transaction_id' => 'tm_' . bin2hex(random_bytes(8)), 'user' => $user, 'kind' => 'db_row', 'origin' => 'cleanup', 'tool' => 'clean_template_defacement',
                'table' => '#__template_styles', 'pk_column' => 'id', 'pk_value' => $id,
                'before_row' => $fullRow, 'after_existed' => false, 'restore_type' => 'insert',
            ]);
            if ($snapshotId === null) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_SNAPSHOT_FAILED', $id); continue; }

            $delete = $db->getQuery(true)->delete($db->quoteName('#__template_styles'))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($delete);
            $db->execute();
            MuruguardHelper::recordAttackLogEntry([
                'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
                'rule' => 'cleanup_clean_template_defacement', 'severity' => 'low',
                'why' => 'Deleted a junk/injected #__template_styles row (TimeMachine snapshot taken, restorable).', 'matched' => (string) $id,
            ]);
            $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_DELETED_DEFACEMENT', $id);
        }

        return $flash;
    }

    /**
     * TimeMachine -- restores a db_row-kind snapshot. Deliberately a
     * narrow, explicit allow-list of exactly the four table+restore_type
     * combinations the cleanup actions above can create -- never a
     * generic "replay stored SQL" rollback, which the feature's own
     * design constraints (reversible-only database snapshots) rule out.
     * Conflict detection compares the row's CURRENT state to what the
     * repair itself left behind (after_row), not the pre-repair state,
     * same "don't silently clobber a later change" rule
     * MuruguardAiHelper::rollbackSnapshot() applies to files. Unlike a
     * file conflict, an 'insert' restore's conflict (a row now occupies
     * that primary key again) is never force-overridable -- overwriting
     * or displacing an unrelated row that happens to reuse the same id
     * was never asked for and isn't a case $force is meant to cover.
     */
    public function rollbackDbRowSnapshot(array $snap, bool $force = false): array
    {
        $snapshotId = (string) ($snap['id'] ?? '');
        if (!empty($snap['rolled_back_at'])) {
            return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'already_rolled_back'];
        }

        $table = (string) ($snap['table'] ?? '');
        $pkColumn = (string) ($snap['pk_column'] ?? '');
        $pkValue = $snap['pk_value'] ?? null;
        $restoreType = (string) ($snap['restore_type'] ?? '');
        $beforeRow = is_array($snap['before_row'] ?? null) ? $snap['before_row'] : null;

        $allowed = ['#__menu|update', '#__template_styles|update', '#__template_styles|insert', '#__sppagebuilder_assets|insert'];
        if ($beforeRow === null || $pkColumn === '' || $pkValue === null || !in_array($table . '|' . $restoreType, $allowed, true)) {
            return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'not_found'];
        }

        $db = $this->getDatabase();

        if ($restoreType === 'update') {
            $query = $db->getQuery(true)->select($db->quoteName('params'))->from($db->quoteName($table))
                ->where($db->quoteName($pkColumn) . ' = ' . (int) $pkValue);
            $db->setQuery($query);
            $currentParams = $db->loadResult();
            if ($currentParams === null) {
                // The row itself is gone entirely -- an update can't
                // restore a row that no longer exists to update.
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'conflict'];
            }

            $afterParams = is_array($snap['after_row'] ?? null) ? (string) ($snap['after_row']['params'] ?? '') : '';
            if (!$force && $afterParams !== '' && (string) $currentParams !== $afterParams) {
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'conflict'];
            }

            $update = $db->getQuery(true)->update($db->quoteName($table))
                ->set($db->quoteName('params') . ' = ' . $db->quote((string) ($beforeRow['params'] ?? '')))
                ->where($db->quoteName($pkColumn) . ' = ' . (int) $pkValue);
            $db->setQuery($update);
            $db->execute();
        } else { // restore_type === 'insert' -- undoing a row DELETE
            $existsQuery = $db->getQuery(true)->select('COUNT(*)')->from($db->quoteName($table))
                ->where($db->quoteName($pkColumn) . ' = ' . (int) $pkValue);
            $db->setQuery($existsQuery);
            if ((int) $db->loadResult() > 0) {
                // Never force-overridable -- see docblock above.
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'conflict'];
            }

            $columns = array_keys($beforeRow);
            $values = array_map(fn($v) => $v === null ? 'NULL' : $db->quote((string) $v), array_values($beforeRow));
            $insert = $db->getQuery(true)->insert($db->quoteName($table))
                ->columns(array_map(fn($c) => $db->quoteName($c), $columns))
                ->values(implode(',', $values));
            $db->setQuery($insert);
            $db->execute();
        }

        MuruguardTimeMachineHelper::markRolledBack($snapshotId);
        MuruguardHelper::recordAttackLogEntry([
            'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
            'rule' => 'rollback', 'severity' => 'low',
            'why' => 'TimeMachine rollback restored a database row to its pre-repair state.',
            'matched' => $table . '#' . $pkValue,
        ]);
        return ['ok' => true, 'snapshotId' => $snapshotId];
    }

    /**
     * Checks the installed SP Page Builder version from #__extensions and
     * returns a warning array if it is a vulnerable build.
     */
    public function getSppbVersionWarning(): ?array
    {
        try {
            $db    = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['manifest_cache', 'enabled']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_sppagebuilder'))
                ->where($db->quoteName('type')    . ' = ' . $db->quote('component'));
            $db->setQuery($query);
            $row = $db->loadAssoc();
        } catch (\Throwable $e) {
            return null;
        }

        if (empty($row)) return null;

        $manifest = json_decode($row['manifest_cache'] ?? '{}', true);
        $version  = trim($manifest['version'] ?? '');

        if ($version === '') {
            return ['safe' => null, 'version' => 'unknown', 'major' => 0, 'enabled' => (bool) $row['enabled']];
        }

        $parts = array_map('intval', explode('.', $version));
        $major = $parts[0] ?? 0;
        $minor = $parts[1] ?? 0;
        $patch = $parts[2] ?? 0;

        $isSafe = ($major > 6)
            || ($major === 6 && $minor > 6)
            || ($major === 6 && $minor === 6 && $patch >= 2);

        return [
            'safe'    => $isSafe,
            'version' => $version,
            'major'   => $major,
            'enabled' => (bool) $row['enabled'],
        ];
    }


    /**
     * Checks whether Joomla's own update-checking mechanism is actually
     * working -- not whether an update exists, but whether Joomla is even
     * capable of finding out. A real, reported failure mode: a site gets
     * compromised through an unpatched extension because Joomla's "Check
     * for Updates" screen never showed an update was available, not
     * because none existed, but because the plumbing that tells Joomla
     * WHERE to look was broken -- #__update_sites.enabled = 0 (Joomla
     * itself calls this out with a one-line warning on the Find Updates
     * screen, see com_installer's UpdateController::find(), but that's
     * easy to never see -- most admins only ever look at the Update list
     * itself, which just silently omits anything whose update site is
     * broken instead of explaining why), or no #__update_sites_extensions
     * link row at all.
     *
     * Deliberately narrow: only the extensions this scanner already has
     * dedicated, name-specific knowledge of elsewhere (SPPB's own version
     * check above, JCE's upload-path signature in getSignatures()) are
     * checked for a totally MISSING update site, since third-party
     * extensions vary too much in normal update-server behaviour to flag
     * that reliably without noise. A DISABLED update site, in contrast,
     * is checked for every installed extension -- Joomla having once
     * registered one and then stopped checking it is unambiguous
     * regardless of which extension it is.
     *
     * Returns null when nothing is wrong -- this is an "only show if
     * there's a real problem" banner, not a status line.
     */
    public function getUpdateSiteHealthWarning(): ?array
    {
        try {
            $db    = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['e.extension_id', 'e.name', 'e.element', 'us.update_site_id', 'us.enabled']))
                ->from($db->quoteName('#__extensions', 'e'))
                ->join('LEFT', $db->quoteName('#__update_sites_extensions', 'use') . ' ON ' . $db->quoteName('use.extension_id') . ' = ' . $db->quoteName('e.extension_id'))
                ->join('LEFT', $db->quoteName('#__update_sites', 'us') . ' ON ' . $db->quoteName('us.update_site_id') . ' = ' . $db->quoteName('use.update_site_id'))
                ->where($db->quoteName('e.state') . ' = 0')
                ->where($db->quoteName('e.enabled') . ' = 1');
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
        } catch (\Throwable $e) {
            return null;
        }

        $knownNames = [
            'com_sppagebuilder' => 'SP Page Builder',
            'com_jce'           => 'JCE Editor',
        ];

        $byExtension = [];
        foreach ($rows as $row) {
            $extId = (int) $row['extension_id'];
            $byExtension[$extId]['element'] = $byExtension[$extId]['element'] ?? (string) $row['element'];
            $byExtension[$extId]['name']    = $byExtension[$extId]['name']    ?? (string) $row['name'];
            $byExtension[$extId]['sites'][]   = ['has' => $row['update_site_id'] !== null, 'enabled' => (int) ($row['enabled'] ?? 0) === 1];
        }

        $disabled = [];
        $missing  = [];
        foreach ($byExtension as $info) {
            $label         = $knownNames[$info['element']] ?? $info['name'];
            $hasAnySite     = false;
            $hasEnabledSite = false;
            foreach ($info['sites'] as $site) {
                if ($site['has']) {
                    $hasAnySite = true;
                    if ($site['enabled']) $hasEnabledSite = true;
                }
            }
            if ($hasAnySite && !$hasEnabledSite) {
                $disabled[] = $label;
            } elseif (!$hasAnySite && isset($knownNames[$info['element']])) {
                $missing[] = $label;
            }
        }

        if (empty($disabled) && empty($missing)) {
            return null;
        }

        return ['disabled' => $disabled, 'missing' => $missing];
    }

    /**
     * Every installed extension with a parsed version number, keyed by
     * lowercase element -- ['element' => ..., 'type' => ..., 'name' =>
     * ..., 'version' => ...]. Version comes out of manifest_cache the
     * same way getSppbVersionWarning() already parses it for SPPB
     * specifically; here it's done generically for every row so it can
     * be cross-referenced against the known-vulnerability feed. A row
     * with no parseable version is skipped -- nothing to compare it
     * against anyway.
     */
    protected function getInstalledExtensionsWithVersions(): array
    {
        try {
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['element', 'type', 'name', 'manifest_cache']))
                ->from($db->quoteName('#__extensions'));
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
        } catch (\Throwable $e) {
            return [];
        }

        $extensions = [];
        foreach ($rows as $row) {
            $element = strtolower(trim((string) $row['element']));
            if ($element === '') continue;

            $manifest = json_decode((string) ($row['manifest_cache'] ?? ''), true);
            $version = is_array($manifest) ? trim((string) ($manifest['version'] ?? '')) : '';
            if ($version === '' || !preg_match('/^\d+(\.\d+)*/', $version)) continue;

            $extensions[] = [
                'element' => $element,
                'type'    => (string) $row['type'],
                'name'    => (string) $row['name'],
                'version' => $version,
            ];
        }

        return $extensions;
    }

    /**
     * Cross-references installed extensions (see
     * getInstalledExtensionsWithVersions()) against the cached
     * known-vulnerability feed (MuruguardHelper::fetchVulnerabilityFeed(),
     * admin-curated on the dashboard -- see that method's docblock), using
     * plain version_compare() against each advisory's affectedFrom/
     * affectedTo. Both bounds are inclusive; a blank bound means
     * "unbounded on that side" (e.g. no affectedTo -- still unpatched as
     * of publish). Returns one row per match: the advisory plus the
     * actually-installed version, so the UI can show "you have 4.1.0,
     * this affects up to 4.2.1, update to 4.2.3". Independent of whether
     * a full scan has been run -- safe to call any time (e.g. for the
     * top-of-report banner), same as getUpdateSiteHealthWarning(). Free
     * on Pro too -- this is awareness, not a licensed feature.
     */
    public function getVulnerableExtensions(): array
    {
        $advisories = MuruguardHelper::fetchVulnerabilityFeed();
        if (empty($advisories)) return [];

        $installed = $this->getInstalledExtensionsWithVersions();
        if (empty($installed)) return [];

        // Index installed extensions by element for O(1) lookup per advisory
        // rather than a nested loop over every installed row per advisory.
        $byElement = [];
        foreach ($installed as $ext) {
            $byElement[$ext['element']] = $ext;
        }

        $matches = [];
        foreach ($advisories as $advisory) {
            $element = strtolower(trim((string) ($advisory['extensionElement'] ?? '')));
            if ($element === '' || !isset($byElement[$element])) continue;

            $ext = $byElement[$element];
            $version = $ext['version'];
            $from = trim((string) ($advisory['affectedFrom'] ?? ''));
            $to   = trim((string) ($advisory['affectedTo'] ?? ''));

            if ($from !== '' && version_compare($version, $from, '<')) continue;
            if ($to !== '' && version_compare($version, $to, '>')) continue;

            // A fixed version already installed is never a match, even if
            // it technically still falls inside an affectedTo bound the
            // admin hasn't tightened yet (fixedVersion is the more
            // trustworthy, more specific signal when both are present).
            $fixedVersion = trim((string) ($advisory['fixedVersion'] ?? ''));
            if ($fixedVersion !== '' && version_compare($version, $fixedVersion, '>=')) continue;

            $matches[] = [
                'element'        => $element,
                'installedName'  => $ext['name'],
                'installedType'  => $ext['type'],
                'installedVersion' => $version,
                'extensionName'  => (string) ($advisory['extensionName'] ?? $ext['name']),
                'title'          => (string) ($advisory['title'] ?? ''),
                'severity'       => strtoupper((string) ($advisory['severity'] ?? 'MEDIUM')),
                'fixedVersion'   => $fixedVersion !== '' ? $fixedVersion : null,
                'cveId'          => $advisory['cveId'] ?? null,
                'advisoryUrl'    => $advisory['advisoryUrl'] ?? null,
                'description'    => $advisory['description'] ?? null,
            ];
        }

        return $matches;
    }
}