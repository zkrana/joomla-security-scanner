<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     MIT
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Component\ComponentHelper;

require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/muruguard.php';
require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/aiassistant.php';
require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/timemachine.php';

class MuruguardViewScanner extends HtmlView
{
    public $fileFindings = [];
    public $dbFindings = [];
    public $highCount = 0;
    public $medCount = 0;
    public $scanned = false;
    public $scanStartedAt = 0;
    public $sppbWarning = null;
    public $updateSiteHealthWarning = null;
    public $vulnerableExtensions = [];
    public $scanAreas = [];
    public $selectedAreas = [];
    public $cronEnabled = false;
    public $cronToken = '';
    public $alertEmail = '';
    public $lastScheduledRun = null;
    public int $itemsPerPage = 50;
    public $canDelete = false;
    public $canEdit = false;
    public $canAdmin = false;
    public $shieldEnabled = false;
    public $shieldBlockPatterns = false;
    public $shieldBlockBruteForce = false;
    public $shieldThreshold = 5;
    public $shieldWindow = 15;
    public $shieldPluginActive = false;
    public $attackLog = [];
    public ?array $registeredTemplates = null;
    public array $htaccess = [];
    public array $serverLimits = [];
    public $shieldBlockUserAgents = false;
    public $shieldBlockCountries = false;
    public $shieldBlockedCountries = '';
    public bool $wafEnabled = false;
    public array $ipList = [];
    public array $knownHashes = [];
    public string $currentClientIp = '';
    public bool $backendAuthEnabled = false;
    public string $backendAuthUsername = '';
    public int $backendAuthActivated = 0;
    public bool $emergencyModeEnabled = false;
    public int $emergencyModeActivated = 0;
    public array $falsePositives = [];
    public int $attackLogArchiveCount = 0;
    public string $componentVersion = '';
    public string $helpUserName = '';
    public string $helpUserEmail = '';
    public string $helpSystemInfo = '';
    public string $activePanel = 'dashboard';
    public array $licenseStatus = ['status' => 'none', 'expiresAt' => null, 'lastChecked' => null, 'product' => null];
    public string $licenseKey = '';
    public string $licenseKeyMasked = '';
    public bool $aiProActive = false;
    /** @var array{exists:bool,fileCount:int,createdAt:?int} */
    public array $fimBaselineStatus = ['exists' => false, 'fileCount' => 0, 'createdAt' => null];
    public array $aiAuditLog = [];
    /** Snapshot id => snapshot record, only loaded for an active Pro license -- feeds the "Protected Repairs" list's Restore/pin buttons alongside $aiAuditLog. */
    public array $timeMachineSnapshots = [];
    /** Unified, newest-first list merging AI-origin entries ($aiAuditLog, richer human-readable action/detail text) with cleanup-origin TimeMachine snapshots (which have no separate audit-log entry of their own) -- see the loading logic below for why one list, one rendering loop. */
    public array $protectedRepairs = [];
    public int $timemachineRetentionDays = 14;
    public int $timemachineRetentionMaxSnapshots = 500;
    public string $aiFormToken = '';
    public string $activeSettingsTab = 'general';
    public bool $fleetReportingEnabled = false;
    public bool $autopilotEnabled = false;
    public bool $alertSlackEnabled = false;
    public string $alertSlackWebhook = '';
    public bool $alertDiscordEnabled = false;
    public string $alertDiscordWebhook = '';
    public bool $alertTelegramEnabled = false;
    public string $alertTelegramBotToken = '';
    public string $alertTelegramChatId = '';
    public bool $shieldBlockReferrers = false;
    public bool $shieldBlockPbl = false;
    public bool $shieldBlockUploadExts = false;
    public bool $shieldAutoblockRepeatOffenders = false;
    public int $shieldAutoblockThreshold = 3;
    public int $shieldAutoblockWindow = 60;
    public bool $hardenRemoveGenerator = false;
    public bool $hardenTmpCleanupEnabled = false;
    public bool $homepageWatchEnabled = false;
    public string $safeBrowsingApiKeyMasked = '';
    public string $geminiApiKeyMasked = '';
    /** True when "Ask AI" actually has somewhere to go: an active Pro license (dashboard multi-provider), or a locally-saved Gemini key on any edition. Drives whether the row-level/bulk Ask AI buttons render at all. */
    public bool $aiAvailable = false;
    /** @var array{score:int,label:string,issues:list<string>} */
    public array $securityScore = ['score' => 0, 'label' => '', 'issues' => []];

    public function display($tpl = null)
    {
        MuruguardHelper::requireManageAccess();

        // Read straight from the manifest on disk rather than the DB's
        // manifest_cache -- accurate even if files were ever overwritten
        // outside Joomla's own installer/updater flow (manifest_cache
        // only refreshes on an actual install/update through Joomla).
        $manifestPath = JPATH_ADMINISTRATOR . '/components/com_muruguard/muruguard.xml';
        if (is_file($manifestPath)) {
            $manifestXml = @simplexml_load_file($manifestPath);
            if ($manifestXml !== false) {
                $this->componentVersion = (string) $manifestXml->version;
            }
        }

        $app     = Factory::getApplication();
        $session = $app->getSession();

        // What this specific user is authorised to DO, not just view -- the
        // template uses these to hide/disable Delete, Clean, and Settings
        // actions a user's ACL group doesn't grant, rather than showing a
        // button that would just 403 on click.
        $this->canDelete = MuruguardHelper::canDelete();
        $this->canEdit   = MuruguardHelper::canEdit();
        $this->canAdmin  = MuruguardHelper::canAdmin();

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        // Show SPPB version warning
        $this->sppbWarning = $model->getSppbVersionWarning();

        // Is Joomla's own update-checking mechanism actually working?
        // Only ever set to a non-null value when there's a real problem --
        // see getUpdateSiteHealthWarning()'s docblock.
        $this->updateSiteHealthWarning = $model->getUpdateSiteHealthWarning();

        // Known-vulnerability cross-check against installed extension
        // versions -- independent of whether a scan has run, same as the
        // update-site-health check above, so the banner shows immediately.
        $this->vulnerableExtensions = $model->getVulnerableExtensions();

        // .htaccess hardening advisor -- read-only, cheap (one file read +
        // a handful of regexes), so it's always available regardless of
        // whether a scan has been run yet.
        $this->htaccess = MuruguardHelper::getHtaccessSuggestions(JPATH_ROOT);
        // Cheap (a couple ini_get/ini_set calls, no I/O) -- always computed
        // rather than gated on scan state, so it's available regardless.
        $this->serverLimits = MuruguardHelper::getServerLimitsInfo();

        // Directory-picker definitions + the user's last selection.
        $this->scanAreas     = MuruguardHelper::getScanAreas();
        $this->selectedAreas = (array) $session->get('muruguard.scan_areas', []);

        // Scheduled-scanning settings, for the in-page Settings panel --
        // the exact same storage System > Global Configuration reads/
        // writes, so both stay in sync with each other automatically.
        $cfgParams = ComponentHelper::getParams('com_muruguard');
        $this->cronEnabled = (bool) $cfgParams->get('cron_enabled', 0);
        $this->cronToken   = (string) $cfgParams->get('cron_token', '');
        $this->itemsPerPage = (int) $cfgParams->get('items_per_page', 50);
        if (!in_array($this->itemsPerPage, [25, 50, 100, 250, 500], true)) {
            $this->itemsPerPage = 50;
        }
        $this->timemachineRetentionDays = (int) $cfgParams->get('timemachine_retention_days', 14);
        if ($this->timemachineRetentionDays < 1) $this->timemachineRetentionDays = 14;
        $this->timemachineRetentionMaxSnapshots = (int) $cfgParams->get('timemachine_retention_max_snapshots', 500);
        if ($this->timemachineRetentionMaxSnapshots < 10) $this->timemachineRetentionMaxSnapshots = 500;
        $this->alertEmail  = (string) $cfgParams->get('alert_email', '');
        $this->lastScheduledRun = $model->getLastScheduledRunTime();

        // Protection Mode settings + audit log, for the in-page Settings
        // panel and the new Protection Log tab -- same params blob the
        // plg_system_muruguardshield plugin reads on every request.
        $this->shieldEnabled         = (bool) $cfgParams->get('shield_enabled', 0);
        $this->shieldBlockPatterns   = (bool) $cfgParams->get('shield_block_patterns', 0);
        $this->shieldBlockBruteForce = (bool) $cfgParams->get('shield_block_bruteforce', 0);
        $this->shieldThreshold       = (int) $cfgParams->get('shield_bruteforce_threshold', 5);
        $this->shieldWindow          = (int) $cfgParams->get('shield_bruteforce_window', 15);
        $this->shieldPluginActive    = $model->isShieldPluginActive();

        // License status -- cheap on every page load: getLicenseStatus()
        // only makes an actual network call when the cache is stale
        // (or there's a key but no cached result yet), never when no key
        // is set at all. Checked regardless of which panel is being
        // viewed so a license doesn't silently go stale just because the
        // admin never happens to open Settings.
        $this->licenseKey       = (string) $cfgParams->get('license_key', '');
        $this->licenseKeyMasked = MuruguardHelper::maskLicenseKey($this->licenseKey);
        $this->licenseStatus    = $model->getLicenseStatus();

        // Smart AI Assistant -- Pro-only (see MuruguardAiHelper::
        // isProLicenseActive()'s docblock for what "Pro" means here).
        // aiProActive/aiFormToken are cheap and needed regardless of
        // panel (the sidebar badge + every AJAX call's CSRF token); the
        // audit log itself is only loaded once $requestedPanel is known,
        // further down, so a normal Dashboard/Settings page load never
        // pays for it.
        //
        // Deliberately NOT calling MuruguardAiHelper::isProLicenseActive()
        // here -- it re-reads ComponentHelper::getParams('com_muruguard'),
        // which Joomla caches in a per-REQUEST static (ComponentHelper::
        // $components), populated by the FIRST getParams() call above
        // ($cfgParams). When getLicenseStatus() just above did a live
        // recheck (cache was stale) and persisted a fresh status to the
        // DB, that static cache is NOT invalidated, so a second
        // getParams() call in the same request -- which is exactly what
        // isProLicenseActive() does -- would still see the PRE-recheck
        // value. That's what made a freshly-activated (or freshly
        // corrected) license require a second/hard page reload before
        // the AI Integrations and Pro Features tabs unlocked: the very
        // request that fixed the DB row rendered itself off the stale
        // in-memory copy. $this->licenseStatus above is the live result
        // returned directly from getLicenseStatus(), so deriving from it
        // is always correct for the current request.
        $this->aiProActive = ($this->licenseStatus['status'] ?? '') === 'active';
        $this->aiFormToken = \Joomla\CMS\Session\Session::getFormToken();
        // Cheap (reads one small JSON data file) -- only meaningful for
        // an active Pro license, so skip it entirely otherwise rather
        // than reading a file that'll never be shown.
        if ($this->aiProActive) {
            $this->fimBaselineStatus = $model->getFimBaselineStatus();
        }

        $this->attackLog             = MuruguardHelper::getAttackLog();
        $this->attackLogArchiveCount = MuruguardHelper::getAttackLogArchiveCount();
        $this->shieldBlockUserAgents = (bool) $cfgParams->get('shield_block_useragents', 0);
        $this->shieldBlockCountries  = (bool) $cfgParams->get('shield_block_countries', 0);
        $this->shieldBlockedCountries = (string) $cfgParams->get('shield_blocked_countries', '');
        $this->wafEnabled             = (bool) $cfgParams->get('waf_enabled', 0);
        $this->shieldBlockReferrers            = (bool) $cfgParams->get('shield_block_referrers', 0);
        $this->shieldBlockPbl                  = (bool) $cfgParams->get('shield_block_pbl', 0);
        $this->shieldBlockUploadExts            = (bool) $cfgParams->get('shield_block_upload_extensions', 0);
        $this->shieldAutoblockRepeatOffenders  = (bool) $cfgParams->get('shield_autoblock_repeat_offenders', 0);
        $this->shieldAutoblockThreshold        = (int) $cfgParams->get('shield_autoblock_threshold', 3);
        $this->shieldAutoblockWindow           = (int) $cfgParams->get('shield_autoblock_window', 60);
        $this->hardenRemoveGenerator    = (bool) $cfgParams->get('harden_remove_generator', 0);
        $this->hardenTmpCleanupEnabled  = (bool) $cfgParams->get('harden_tmp_cleanup_enabled', 0);
        $this->homepageWatchEnabled     = (bool) $cfgParams->get('homepage_watch_enabled', 0);
        $this->safeBrowsingApiKeyMasked = MuruguardHelper::maskLicenseKey((string) $cfgParams->get('safe_browsing_api_key', ''));
        $geminiApiKey = trim((string) $cfgParams->get('gemini_api_key', ''));
        $this->geminiApiKeyMasked = MuruguardHelper::maskLicenseKey($geminiApiKey);
        $this->aiAvailable = $this->aiProActive || $geminiApiKey !== '';
        $this->ipList                = MuruguardHelper::getIpList();
        $this->knownHashes           = MuruguardHelper::getCustomMalwareHashes();
        // Same resolution the shield plugin actually keys blocking on
        // (see resolveClientIp()'s docblock) -- showing the admin their
        // raw REMOTE_ADDR would be actively misleading behind a
        // configured proxy/CDN trusted header, and showing it here next
        // to the IP Access List saves a trip to an external "what's my
        // IP" site when adding an always-allow entry for themselves.
        $this->currentClientIp = \MuruguardHelper::resolveClientIp(
            Factory::getApplication()->input->server,
            (string) $cfgParams->get('shield_trusted_proxy_header', '')
        );
        // MuRu Shield Hardening (server-level .htaccess protection,
        // distinct from Protection Mode above which is PHP-layer) --
        // read-only status display, the actual activate/deactivate
        // actions live in the controller since they touch the
        // filesystem, not just params.
        $this->backendAuthEnabled   = (bool) $cfgParams->get('backend_auth_enabled', 0);
        $this->backendAuthUsername  = (string) $cfgParams->get('backend_auth_username', '');
        $this->backendAuthActivated = (int) $cfgParams->get('backend_auth_activated', 0);
        $this->emergencyModeEnabled   = (bool) $cfgParams->get('emergency_mode_enabled', 0);
        $this->emergencyModeActivated = (int) $cfgParams->get('emergency_mode_activated', 0);
        $this->falsePositives        = MuruguardHelper::getFalsePositives();

        // Pro Features (Fleet Dashboard reporting + Alert Channels) --
        // same storage as every other setting here; the panel itself
        // gates on aiProActive (computed above) to decide whether to
        // show the real form or the locked/upgrade card.
        $this->fleetReportingEnabled  = (bool) $cfgParams->get('fleet_reporting_enabled', 0);
        $this->autopilotEnabled       = (bool) $cfgParams->get('autopilot_enabled', 0);
        $this->alertSlackEnabled      = (bool) $cfgParams->get('alert_slack_enabled', 0);
        $this->alertSlackWebhook      = (string) $cfgParams->get('alert_slack_webhook', '');
        $this->alertDiscordEnabled    = (bool) $cfgParams->get('alert_discord_enabled', 0);
        $this->alertDiscordWebhook    = (string) $cfgParams->get('alert_discord_webhook', '');
        $this->alertTelegramEnabled   = (bool) $cfgParams->get('alert_telegram_enabled', 0);
        $this->alertTelegramBotToken  = (string) $cfgParams->get('alert_telegram_bot_token', '');
        $this->alertTelegramChatId    = (string) $cfgParams->get('alert_telegram_chat_id', '');

        // Restore cached scan results. Deliberately NOT gated on the same
        // 300-second freshness window getFileFindings() uses internally
        // to decide "reuse the cache vs. do a fresh rescan" -- that's a
        // read-time optimisation concern, not a "should results even be
        // shown at all" concern. This used to conflate the two: any bulk
        // action (delete, mark safe, clean code, any DB-row action --
        // Super Users/Menu XSS/SPPB Assets/Defacement included, since ALL
        // of them are gated behind this same file-findings check) taken
        // more than 5 minutes after the original scan -- entirely
        // plausible while reviewing dozens of flagged items one at a
        // time -- redirected back to the "no scan yet, run one" landing
        // screen instead of showing the just-updated results, even
        // though the action itself succeeded. Now "has a scan ever
        // completed this session" (any real timestamp) is enough to show
        // results; getFileFindings() below still transparently re-scans
        // on its own if the underlying cache actually is stale.
        $cachedAt = (int) $session->get('muruguard.filefindings_time', 0);
        $hasCache = $cachedAt > 0;

        if ($hasCache) {
            $this->fileFindings = $model->getFileFindings();
            $this->dbFindings   = $model->getDbFindings();

            // Same #__extensions registry cross-check scanFilesystem()/
            // deleteTargets() already use server-side (see
            // getRegisteredTemplates()) -- the template needs it too so
            // the Suspicious-vs-Cleanable tab routing for a template-root
            // index.php finding uses the strongest available signal, not
            // just the weaker on-disk manifest check.
            $this->registeredTemplates = $model->getRegisteredTemplates();

            $this->highCount = count(array_filter(
                $this->fileFindings,
                function ($f) {
                    return isset($f['confidence']) && $f['confidence'] === 'high';
                }
            ));

            $this->medCount      = count($this->fileFindings) - $this->highCount;
            $this->scanned       = true;
            $this->scanStartedAt = $cachedAt;

            // Single-glance security score -- only computed once a scan
            // is actually cached, same as everything else in this block:
            // getSecurityScore() reads getFileFindings()/getDbFindings()
            // on the model, which transparently re-scan when their own
            // cache is stale, so calling it unconditionally on every page
            // load (including the very first, pre-scan visit) would risk
            // triggering a full scan just to render a Dashboard widget.
            $this->securityScore = $model->getSecurityScore();
        }

        // Which panel the left sidebar submenu (see addSubmenu()) should
        // land on -- a plain custom query param rather than Joomla's
        // reserved &layout=, since there's deliberately no separate
        // tmpl/settings.php / tmpl/support.php file: this component is
        // still one page with everything on it, the submenu just jumps
        // straight to the right part of it (auto-opening the existing
        // Settings panel / Support section client-side) rather than a
        // full page reload into isolated views, which would mean
        // duplicating the scan-results header/stats across three
        // separate templates for no real benefit.
        $requestedPanel = $app->input->getCmd('view_panel', 'dashboard');
        // 'support' deliberately no longer routes anywhere -- removed
        // from the primary nav now that the built-in purchasing/
        // licensing system (Settings > License, the dashboard's own My
        // Products/checkout) covers what that panel used to be the main
        // way to reach. A stale bookmark/link just falls back to Dashboard.
        $this->activePanel = in_array($requestedPanel, ['dashboard', 'settings', 'ai_assistant', 'help'], true) ? $requestedPanel : 'dashboard';

        // Which Settings sub-tab to land on -- see
        // MuruguardControllerScanner::settingsRedirectUrl() for how this
        // gets set on every settings-saving action's redirect, and the
        // generic form-submit listener in default.php for how the
        // client-side hidden field it reads gets filled in.
        // Settings tabs were consolidated from 9 down to 6 (general/
        // site_protection/license/automation/backup/guide) -- 'general'
        // is Display/Pagination + Scheduled Scanning + False Positives;
        // 'site_protection' is Site Protection + File Integrity
        // Monitoring (both read-at-a-glance status cards, open by
        // default) + Protection Log (also open) plus IP Access List +
        // MuRu Shield Hardening (collapsed <details> -- opened on demand
        // so the tab isn't overwhelming); 'automation' is Automations
        // (Fleet Dashboard + Alerts) + AI Integrations; 'backup' is
        // Backup & Restore (formerly "TimeMachine", renamed for
        // clarity), always-open. A bookmarked/stale link carrying an old
        // tab id (e.g. ?settings_tab=ai, ?settings_tab=timemachine,
        // ?settings_tab=integrity, or even ?settings_tab=protection from
        // before Site Protection existed as its own tab) still lands
        // somewhere sensible via the fallback below rather than a blank/
        // unrecognized tab.
        $requestedSettingsTab = $app->input->getCmd('settings_tab', 'general');
        $legacySettingsTabMap = [
            'protection' => 'site_protection', 'iplist' => 'site_protection',
            'scheduled' => 'general',
            'ai' => 'automation', 'pro' => 'automation',
            'timemachine' => 'backup', 'integrity' => 'site_protection',
        ];
        $requestedSettingsTab = $legacySettingsTabMap[$requestedSettingsTab] ?? $requestedSettingsTab;
        $this->activeSettingsTab = in_array($requestedSettingsTab, ['general', 'site_protection', 'license', 'automation', 'backup', 'guide'], true)
            ? $requestedSettingsTab
            : 'general';

        if ($this->activePanel === 'ai_assistant') {
            $this->aiAuditLog = MuruguardAiHelper::getAuditLog();
            // TimeMachine snapshots feed the Restore/pin controls on the
            // "Protected Repairs" list -- Pro-gated like everything else
            // on this panel, so a Free/expired-license admin (who could
            // still land on this panel via a stale bookmark) never pays
            // for reading a file that only Pro ever writes to. The panel
            // template only ever renders this section when aiProActive
            // is true (see default.php's locked-card branch), so it's
            // safe to build $protectedRepairs only in this branch too.
            if ($this->aiProActive) {
                $this->timeMachineSnapshots = MuruguardTimeMachineHelper::listSnapshotsById();

                // One merged, newest-first list rather than two separate
                // rendering loops: AI-origin repairs already have a
                // richer human-readable entry in $aiAuditLog (action +
                // detail text written at the point of mutation); cleanup-
                // origin repairs (bulk delete, Clean Code, Clean Menu
                // XSS, ...) have no such audit-log entry of their own
                // (see MuruguardModelScanner's six cleanup actions --
                // they write to MuruguardHelper::recordAttackLogEntry()
                // for the cross-cutting security log, not this AI-
                // specific one), so they're synthesized here directly
                // from their own TimeMachine snapshot record instead.
                $repairs = [];
                foreach ($this->aiAuditLog as $entry) {
                    $repairs[] = [
                        'time'          => (int) ($entry['time'] ?? 0),
                        'user'          => (string) ($entry['user'] ?? ''),
                        'label'         => trim((string) ($entry['action'] ?? '') . ': ' . (string) ($entry['detail'] ?? '')),
                        'snapshotId'    => $entry['snapshotId'] ?? null,
                        'transactionId' => $entry['transactionId'] ?? null,
                    ];
                }
                foreach ($this->timeMachineSnapshots as $snap) {
                    if (($snap['origin'] ?? '') !== 'cleanup') continue; // AI-origin already covered via $aiAuditLog above
                    $target = ($snap['kind'] ?? '') === 'db_row'
                        ? (string) ($snap['table'] ?? '') . ' #' . (string) ($snap['pk_value'] ?? '')
                        : (string) ($snap['rel_path'] ?? '');
                    $repairs[] = [
                        'time'          => (int) ($snap['time'] ?? 0),
                        'user'          => (string) ($snap['user'] ?? ''),
                        'label'         => trim((string) ($snap['tool'] ?? '') . ': ' . $target),
                        'snapshotId'    => (string) ($snap['id'] ?? ''),
                        'transactionId' => (string) ($snap['transaction_id'] ?? ''),
                    ];
                }
                usort($repairs, fn($a, $b) => $b['time'] <=> $a['time']);
                $this->protectedRepairs = array_slice($repairs, 0, 30);
            }
        }

        if ($this->activePanel === 'help') {
            $user = Factory::getApplication()->getIdentity();
            $this->helpUserName  = (string) ($user->name ?? '');
            $this->helpUserEmail = (string) ($user->email ?? '');
            // Purely informational context for whoever answers the
            // message -- deliberately no passwords, no file paths, no
            // scan findings, nothing about the site's actual content.
            // Optional (see the "Send system info too" checkbox in the
            // template) and shown to the admin before it's ever sent.
            $this->helpSystemInfo = implode("\n", [
                'MuRu Guard version: ' . ($this->componentVersion !== '' ? $this->componentVersion : 'unknown'),
                'Joomla version: ' . (defined('JVERSION') ? JVERSION : 'unknown'),
                'PHP version: ' . PHP_VERSION,
                'Server software: ' . (string) ($_SERVER['SERVER_SOFTWARE'] ?? 'unknown'),
                'License status: ' . (string) ($this->licenseStatus['status'] ?? 'none'),
                'Protection Mode: ' . ($this->shieldEnabled ? 'enabled' : 'disabled') . ($this->shieldPluginActive ? '' : ' (plugin not active)'),
                'Backend access hardening: ' . ($this->backendAuthEnabled ? 'active' : 'inactive'),
            ]);
        }

        $this->addToolbar();
        $this->addSubmenu();

        parent::display($tpl);
    }

    protected function addToolbar()
    {
        ToolbarHelper::title(Text::_('COM_MURUGUARD_TITLE'), 'shield');

        // Show Preferences only if the helper supports it
        if (method_exists('ToolbarHelper', 'preferences')) {
            ToolbarHelper::preferences('com_muruguard');
        }

        // Help button intentionally omitted for Joomla 3/4/5/6 compatibility.
    }

    /**
     * Left-sidebar submenu (Dashboard / Settings / Smart AI Assistant),
     * the same mechanism com_content/com_banners/... and third-party
     * components like SP Page Builder use for their own multi-page
     * navigation. Secondary to script.php's real #__menu rows (the
     * actual left-nav dropdown items) -- kept in sync anyway since this
     * populates a second, in-page panel Joomla also renders.
     */
    protected function addSubmenu(): void
    {
        \Joomla\CMS\HTML\HTMLHelper::_(
            'sidebar.addEntry',
            Text::_('COM_MURUGUARD_SUBMENU_DASHBOARD'),
            'index.php?option=com_muruguard&view_panel=dashboard',
            $this->activePanel === 'dashboard'
        );
        \Joomla\CMS\HTML\HTMLHelper::_(
            'sidebar.addEntry',
            Text::_('COM_MURUGUARD_SUBMENU_SETTINGS'),
            'index.php?option=com_muruguard&view_panel=settings',
            $this->activePanel === 'settings'
        );
        \Joomla\CMS\HTML\HTMLHelper::_(
            'sidebar.addEntry',
            Text::_('COM_MURUGUARD_SUBMENU_AI_ASSISTANT'),
            'index.php?option=com_muruguard&view_panel=ai_assistant',
            $this->activePanel === 'ai_assistant'
        );
        \Joomla\CMS\HTML\HTMLHelper::_(
            'sidebar.addEntry',
            Text::_('COM_MURUGUARD_SUBMENU_HELP'),
            'index.php?option=com_muruguard&view_panel=help',
            $this->activePanel === 'help'
        );
    }
}