<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     MIT
 */

defined('_JEXEC') or die;

require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/muruguard.php';
require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/timemachine.php';

/**
 * File-tool primitives for the Smart AI Assistant (Pro-only feature). The
 * actual multi-turn reasoning loop lives in the controller
 * (MuruguardControllerScanner::aichat()), which calls the dashboard's
 * stateless /api/ai/step endpoint once per turn and executes whatever
 * tool call it requests by calling straight into this class -- files
 * never leave this server, only tool NAMES/ARGS and RESULTS cross the
 * network to the dashboard, which only ever sees file content the
 * assistant explicitly reads or writes as part of a conversation the
 * customer initiated.
 */
class MuruguardAiHelper
{
    /**
     * Deliberately NOT the same list MuruguardHelper::PROTECTED_TOP_DIRS
     * uses for the scanner's bulk-delete guard -- that blocks entire
     * top-level directories (components/, templates/, plugins/, modules/,
     * ...) which would leave the assistant unable to touch almost
     * anything a developer would actually want it to edit. This is
     * deliberately narrower: only Joomla's own core framework code (which
     * any core update overwrites anyway, so hand-editing it is pointless
     * and risky) and this extension's own files (editing the security
     * scanner's own code, or the Shield plugin actively protecting the
     * site, is a self-tampering risk distinct from ordinary project
     * files -- same reasoning as SELF_CONTENT_SIGNATURE_EXEMPTIONS
     * elsewhere in this codebase).
     */
    private const DENY_DIRS = [
        'libraries', 'includes', 'api', 'cli',
        'administrator/includes', 'administrator/language', 'language',
        'administrator/manifests',
        'administrator/components/com_muruguard',
        'components/com_muruguard',
        'plugins/system/muruguardshield',
    ];

    /** Core bootstrap entry points -- corrupting these breaks the whole site with no easy recovery path through the assistant itself. */
    private const DENY_FILES = [
        'configuration.php',
        'index.php', 'administrator/index.php', 'api/index.php',
        'includes/app.php', 'includes/framework.php',
    ];

    private const MAX_READ_BYTES     = 262144; // 256KB
    private const MAX_WRITE_BYTES    = 262144;
    private const MAX_SEARCH_RESULTS = 100;
    private const MAX_LIST_ENTRIES   = 500;
    private const MAX_AUDIT_ENTRIES  = 1000;

    /**
     * "Pro" for the Smart AI Assistant means exactly what it means
     * everywhere else in this system: a currently valid (non-expired,
     * non-revoked, cache-fresh-or-not) license -- there is no separate
     * paid tier in the product catalog to gate on instead. Reads the same
     * cached status Settings > License already shows, no network call.
     */
    public static function isProLicenseActive(): bool
    {
        $cfgParams = \Joomla\CMS\Component\ComponentHelper::getParams('com_muruguard');
        $status = \MuruguardHelper::readCachedLicenseStatus($cfgParams);
        return $status['status'] === 'active';
    }

    /**
     * Normalises and validates a browser/LLM-supplied relative path.
     * Returns the absolute path on disk, or null if it's unsafe (escapes
     * JPATH_ROOT via traversal or a symlink) or denied. $mustExist=false
     * is for a not-yet-created target (new file / rename destination) --
     * validates the PARENT directory instead, since the target itself
     * can't be realpath()'d before it exists.
     */
    private static function resolvePath(string $relPath, bool $mustExist = true): ?string
    {
        $relPath = str_replace('\\', '/', trim($relPath));
        $relPath = ltrim($relPath, '/');
        if ($relPath === '' || strpos($relPath, '..') !== false) {
            return null;
        }

        $root = realpath(JPATH_ROOT);
        if ($root === false) return null;
        $abs = $root . '/' . $relPath;

        if ($mustExist) {
            $real = realpath($abs);
            if ($real === false) return null;
            $abs = $real;
        } else {
            // Walk upward to the deepest ANCESTOR directory that
            // actually exists -- not just the immediate parent. A brand
            // new file can legitimately need brand new PARENT
            // directories too (e.g. creating a whole new SP Page
            // Builder addon folder), and the immediate parent alone
            // failing realpath() used to reject that entirely, even
            // though every existing ancestor above it was perfectly
            // safe. Only the existing portion of the path can actually
            // be realpath()'d/symlink-checked -- there's nothing on
            // disk yet for the rest of it to resolve against -- so the
            // safety property this preserves is: every directory that
            // DOES exist along the way is verified to stay inside
            // $root, exactly as strictly as the single-level version
            // did for the one directory it used to check.
            $ancestor = self::findDeepestExistingAncestor($root, $relPath);
            if ($ancestor === null) return null;
            $abs = $root . '/' . $relPath;
        }

        // realpath() resolves symlinks too, so this also catches a
        // symlink planted inside the webroot that points somewhere else
        // on disk -- not just literal ../ traversal in the input string.
        if (strpos($abs, $root . DIRECTORY_SEPARATOR) !== 0 && $abs !== $root) {
            return null;
        }

        $rel = ltrim(str_replace($root, '', $abs), '/');
        if (self::isDenied($rel)) return null;

        return $abs;
    }

    /**
     * Walks upward from $root/$relPath's PARENT directories (not the
     * target file itself) until it finds one that actually exists on
     * disk, verifying that directory's realpath() stays inside $root --
     * catching a symlink escape planted at any EXISTING point in the
     * chain. Everything below that point doesn't exist yet, so there's
     * nothing for realpath()/symlink resolution to act on for it; the
     * caller's own textual containment check on the full path (which
     * already excludes literal ".." earlier in resolvePath()) is what
     * covers the not-yet-existing remainder. Returns the existing
     * ancestor's real path, or null if some existing directory along
     * the way escapes $root via a symlink.
     */
    private static function findDeepestExistingAncestor(string $root, string $relPath): ?string
    {
        $segments = explode('/', $relPath);
        array_pop($segments); // the file's own basename doesn't need to exist
        $probe = $root;
        $verified = $root;
        foreach ($segments as $seg) {
            if ($seg === '') continue;
            $probe .= '/' . $seg;
            $real = realpath($probe);
            if ($real === false) break; // this level, and everything below it, doesn't exist yet
            if (strpos($real, $root . DIRECTORY_SEPARATOR) !== 0 && $real !== $root) {
                return null;
            }
            $verified = $real;
        }
        return $verified;
    }

    private static function isDenied(string $relPath): bool
    {
        $relLower = strtolower($relPath);
        foreach (self::DENY_FILES as $f) {
            if ($relLower === strtolower($f)) return true;
        }
        foreach (self::DENY_DIRS as $d) {
            $dLower = strtolower($d);
            if ($relLower === $dLower || strpos($relLower, $dLower . '/') === 0) return true;
        }
        return false;
    }

    /** Shallow directory listing (one level) -- denied entries are excluded entirely rather than shown as locked, so the assistant never even learns they exist. */
    public static function listFiles(string $relDir = ''): array
    {
        $root = realpath(JPATH_ROOT);
        $abs = $relDir === '' ? $root : self::resolvePath($relDir);
        if ($abs === null || !is_dir($abs)) {
            return ['ok' => false, 'error' => 'Directory not found or not allowed'];
        }

        $entries = [];
        $items = @scandir($abs) ?: [];
        sort($items);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $itemAbs = $abs . '/' . $item;
            $itemRel = ltrim(str_replace($root, '', $itemAbs), '/');
            if (self::isDenied($itemRel)) continue;
            $entries[] = ['name' => $item, 'path' => $itemRel, 'type' => is_dir($itemAbs) ? 'dir' : 'file'];
            if (count($entries) >= self::MAX_LIST_ENTRIES) break;
        }
        return ['ok' => true, 'entries' => $entries];
    }

    public static function readFile(string $relPath): array
    {
        $abs = self::resolvePath($relPath);
        if ($abs === null || !is_file($abs)) {
            return ['ok' => false, 'error' => 'File not found or not allowed'];
        }

        $size = filesize($abs) ?: 0;
        $content = @file_get_contents($abs, false, null, 0, self::MAX_READ_BYTES);
        if ($content === false) {
            return ['ok' => false, 'error' => 'Failed to read file'];
        }

        return ['ok' => true, 'content' => $content, 'truncated' => $size > self::MAX_READ_BYTES, 'size' => $size];
    }

    /** Filename + first-line-content search across the project, skipping denied paths, binary/oversized files, and non-text extensions. */
    public static function searchProject(string $query): array
    {
        $query = trim($query);
        if (strlen($query) < 2) {
            return ['ok' => false, 'error' => 'Search query too short'];
        }

        $root = realpath(JPATH_ROOT);
        $results = [];
        $textExts = ['php', 'js', 'jsx', 'ts', 'tsx', 'css', 'scss', 'html', 'xml', 'ini', 'json', 'md', 'txt'];

        \MuruguardHelper::walkDir($root, function (string $path, bool $isDir) use (&$results, $root, $query, $textExts) {
            if ($isDir || count($results) >= self::MAX_SEARCH_RESULTS) return;
            $rel = ltrim(str_replace($root, '', $path), '/');
            if (self::isDenied($rel)) return;
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            $matchedByName = stripos(basename($path), $query) !== false;
            if (!in_array($ext, $textExts, true) && !$matchedByName) return;
            if ((filesize($path) ?: 0) > self::MAX_READ_BYTES) {
                if ($matchedByName) $results[] = ['path' => $rel, 'match' => null];
                return;
            }

            $lineMatch = null;
            if (in_array($ext, $textExts, true)) {
                $contents = @file_get_contents($path, false, null, 0, self::MAX_READ_BYTES);
                if ($contents !== false && stripos($contents, $query) !== false) {
                    foreach (explode("\n", $contents) as $i => $line) {
                        if (stripos($line, $query) !== false) {
                            $lineMatch = ['line' => $i + 1, 'text' => trim($line)];
                            break;
                        }
                    }
                }
            }
            if ($matchedByName || $lineMatch !== null) {
                $results[] = ['path' => $rel, 'match' => $lineMatch];
            }
        });

        return ['ok' => true, 'results' => $results];
    }

    /** A missing/blank transaction id degrades to its own single-mutation transaction rather than blocking anything -- see MuruguardControllerScanner::aiexecutetool()'s docblock for why this is a UI-grouping label, not a security boundary. */
    private static function normalizeTransactionId(string $transactionId): string
    {
        $transactionId = substr(trim($transactionId), 0, 64);
        return $transactionId !== '' ? $transactionId : ('tm_' . bin2hex(random_bytes(8)));
    }

    /**
     * Creates or overwrites a file. The controller is responsible for
     * requiring an explicit user confirmation before ever calling this
     * for a destructive-feeling action -- this function itself has no
     * concept of "pending", it executes immediately once called.
     *
     * TimeMachine safety net: a snapshot of whatever was at $relPath
     * BEFORE this write is taken between resolvePath() succeeding and
     * the actual file_put_contents() below -- this is the one and only
     * place a write_file tool call reaches disk (see executeAiTool()'s
     * docblock), so hooking here means no future refactor or prompt
     * trick can reach the disk without a snapshot existing first.
     * Fail-closed: if the snapshot itself can't be durably stored, the
     * write is refused entirely rather than proceeding unprotected.
     */
    public static function writeFile(string $relPath, string $content, string $transactionId = ''): array
    {
        if (strlen($content) > self::MAX_WRITE_BYTES) {
            return ['ok' => false, 'error' => 'Content too large (' . self::MAX_WRITE_BYTES . ' byte limit)'];
        }
        $abs = self::resolvePath($relPath, false);
        if ($abs === null) {
            return ['ok' => false, 'error' => 'Path not allowed'];
        }

        $existed = is_file($abs);
        $beforeContent = null;
        if ($existed) {
            $beforeContent = @file_get_contents($abs);
            if ($beforeContent === false) {
                // Existed but couldn't be read -- refuse rather than
                // snapshot a file we can't actually prove we captured.
                return ['ok' => false, 'error' => 'Failed to read existing file before write'];
            }
        }

        $transactionId = self::normalizeTransactionId($transactionId);
        $snapshotId = \MuruguardTimeMachineHelper::recordSnapshot([
            'transaction_id' => $transactionId,
            'user'           => \MuruguardHelper::currentUsername(),
            'kind'           => 'file',
            'origin'         => 'ai',
            'tool'           => 'write_file',
            'rel_path'       => $relPath,
            'before_existed' => $existed,
            'before_content' => $beforeContent,
            'after_existed'  => true,
            'after_content'  => $content,
        ]);
        if ($snapshotId === null) {
            return ['ok' => false, 'error' => 'Failed to create safety snapshot; write aborted'];
        }

        // resolvePath() above already validated the FULL path (including
        // any not-yet-existing parent directories) as safe -- creating a
        // brand new file can legitimately need brand new parent
        // directories too (e.g. a whole new SP Page Builder addon
        // folder), not just a new file inside an already-existing one.
        // Directory creation itself isn't individually snapshotted/
        // rollback-able -- undoing a "create" just unlink()s the file
        // (see rollbackSnapshot() below), which can leave a harmless
        // empty directory behind; that's an accepted, documented
        // tradeoff rather than tracking directory lifecycle too.
        $dir = dirname($abs);
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            \MuruguardTimeMachineHelper::discardSnapshot($snapshotId);
            return ['ok' => false, 'error' => 'Failed to create directory'];
        }

        if (@file_put_contents($abs, $content) === false) {
            \MuruguardTimeMachineHelper::discardSnapshot($snapshotId);
            return ['ok' => false, 'error' => 'Failed to write file'];
        }
        self::recordAudit($existed ? 'edit_file' : 'create_file', $relPath, $snapshotId, $transactionId);
        \MuruguardHelper::recordAttackLogEntry([
            'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
            'rule' => 'ai_' . ($existed ? 'edit' : 'create') . '_file', 'severity' => 'low',
            'why' => 'AI assistant ' . ($existed ? 'edited' : 'created') . ' a file (TimeMachine snapshot taken, restorable).',
            'matched' => $relPath,
        ]);
        return ['ok' => true, 'snapshotId' => $snapshotId, 'transactionId' => $transactionId];
    }

    /**
     * Renames/moves a file. No blob is captured (content isn't destroyed
     * by a rename, only its path changes) -- rollback of a rename is a
     * plain rename() back, see rollbackSnapshot() below. Same
     * fail-closed shape as writeFile()/deleteFile() otherwise.
     */
    public static function renameFile(string $relFrom, string $relTo, string $transactionId = ''): array
    {
        $absFrom = self::resolvePath($relFrom);
        if ($absFrom === null) {
            return ['ok' => false, 'error' => 'Source not found or not allowed'];
        }
        $absTo = self::resolvePath($relTo, false);
        if ($absTo === null) {
            return ['ok' => false, 'error' => 'Destination not allowed'];
        }
        if (file_exists($absTo)) {
            return ['ok' => false, 'error' => 'Destination already exists'];
        }

        $transactionId = self::normalizeTransactionId($transactionId);
        $snapshotId = \MuruguardTimeMachineHelper::recordSnapshot([
            'transaction_id' => $transactionId,
            'user'           => \MuruguardHelper::currentUsername(),
            'kind'           => 'file',
            'origin'         => 'ai',
            'tool'           => 'rename_file',
            'rel_path'       => $relTo,
            'rel_path_from'  => $relFrom,
            'before_existed' => true,
            'after_existed'  => true,
        ]);
        if ($snapshotId === null) {
            return ['ok' => false, 'error' => 'Failed to create safety snapshot; rename aborted'];
        }

        // Same reasoning as writeFile()'s mkdir step -- a rename/move
        // into a not-yet-existing nested destination folder is a
        // legitimate request, not just a rename within an already-
        // existing directory.
        $destDir = dirname($absTo);
        if (!is_dir($destDir) && !@mkdir($destDir, 0755, true) && !is_dir($destDir)) {
            \MuruguardTimeMachineHelper::discardSnapshot($snapshotId);
            return ['ok' => false, 'error' => 'Failed to create destination directory'];
        }

        if (!@rename($absFrom, $absTo)) {
            \MuruguardTimeMachineHelper::discardSnapshot($snapshotId);
            return ['ok' => false, 'error' => 'Failed to rename'];
        }
        self::recordAudit('rename_file', $relFrom . ' -> ' . $relTo, $snapshotId, $transactionId);
        \MuruguardHelper::recordAttackLogEntry([
            'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
            'rule' => 'ai_rename_file', 'severity' => 'low',
            'why' => 'AI assistant renamed a file (TimeMachine snapshot taken, restorable).',
            'matched' => $relFrom . ' -> ' . $relTo,
        ]);
        return ['ok' => true, 'snapshotId' => $snapshotId, 'transactionId' => $transactionId];
    }

    public static function deleteFile(string $relPath, string $transactionId = ''): array
    {
        $abs = self::resolvePath($relPath);
        if ($abs === null || !is_file($abs)) {
            return ['ok' => false, 'error' => 'File not found or not allowed'];
        }

        $beforeContent = @file_get_contents($abs);
        if ($beforeContent === false) {
            return ['ok' => false, 'error' => 'Failed to read file before delete'];
        }

        $transactionId = self::normalizeTransactionId($transactionId);
        $snapshotId = \MuruguardTimeMachineHelper::recordSnapshot([
            'transaction_id' => $transactionId,
            'user'           => \MuruguardHelper::currentUsername(),
            'kind'           => 'file',
            'origin'         => 'ai',
            'tool'           => 'delete_file',
            'rel_path'       => $relPath,
            'before_existed' => true,
            'before_content' => $beforeContent,
            'after_existed'  => false,
        ]);
        if ($snapshotId === null) {
            return ['ok' => false, 'error' => 'Failed to create safety snapshot; delete aborted'];
        }

        if (!@unlink($abs)) {
            \MuruguardTimeMachineHelper::discardSnapshot($snapshotId);
            return ['ok' => false, 'error' => 'Failed to delete'];
        }
        self::recordAudit('delete_file', $relPath, $snapshotId, $transactionId);
        \MuruguardHelper::recordAttackLogEntry([
            'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
            'rule' => 'ai_delete_file', 'severity' => 'low',
            'why' => 'AI assistant deleted a file (TimeMachine snapshot taken, restorable).',
            'matched' => $relPath,
        ]);
        return ['ok' => true, 'snapshotId' => $snapshotId, 'transactionId' => $transactionId];
    }

    // ------------------------------------------------------------------
    // TimeMachine -- repair preview + rollback. Lives here (not a
    // separate class reaching into this one) so resolvePath()/isDenied()
    // can stay private: there remains exactly one class that knows how
    // to safely touch an AI-managed path, with one deny-list, which is
    // what makes "can't be prompt-engineered around" true by
    // construction rather than by convention. See the class docblock on
    // MuruguardTimeMachineHelper for the storage side of this feature.
    // ------------------------------------------------------------------

    /**
     * Read-only preview of what a pending mutating tool call would
     * change, shown in the confirmation card BEFORE the user approves --
     * reuses resolvePath() so preview can never expose a denied file's
     * contents either. Returns a diff for text content, a hash/size
     * comparison for binary content (never sent externally either way),
     * or {mode:'denied'} if the target itself isn't allowed (the real
     * write would fail too, but this avoids a pointless confirm click).
     */
    public static function previewMutation(string $tool, array $input): array
    {
        if ($tool === 'rename_file') {
            $absFrom = self::resolvePath((string) ($input['from'] ?? ''));
            $absTo   = self::resolvePath((string) ($input['to'] ?? ''), false);
            if ($absFrom === null || $absTo === null) return ['mode' => 'denied'];
            return ['mode' => 'none'];
        }

        if ($tool === 'write_file') {
            $abs = self::resolvePath((string) ($input['path'] ?? ''), false);
            if ($abs === null) return ['mode' => 'denied'];
            $newContent = (string) ($input['content'] ?? '');
            $oldContent = is_file($abs) ? @file_get_contents($abs) : '';
            if ($oldContent === false) $oldContent = '';
            return self::buildPreview($oldContent, $newContent);
        }

        if ($tool === 'delete_file') {
            $abs = self::resolvePath((string) ($input['path'] ?? ''));
            if ($abs === null || !is_file($abs)) return ['mode' => 'denied'];
            $oldContent = @file_get_contents($abs);
            if ($oldContent === false) return ['mode' => 'denied'];
            return self::buildPreview($oldContent, '');
        }

        return ['mode' => 'none'];
    }

    private static function buildPreview(string $oldContent, string $newContent): array
    {
        if (\MuruguardHelper::looksBinary($oldContent) || \MuruguardHelper::looksBinary($newContent)) {
            return [
                'mode'   => 'binary',
                'before' => ['size' => strlen($oldContent), 'sha256' => hash('sha256', $oldContent)],
                'after'  => ['size' => strlen($newContent), 'sha256' => hash('sha256', $newContent)],
            ];
        }
        $diff = \MuruguardHelper::diffLines($oldContent, $newContent);
        if (!$diff['ok']) {
            return [
                'mode'   => 'binary',
                'before' => ['size' => strlen($oldContent), 'sha256' => hash('sha256', $oldContent)],
                'after'  => ['size' => strlen($newContent), 'sha256' => hash('sha256', $newContent)],
                'reason' => 'too_large',
            ];
        }
        return ['mode' => 'text', 'ops' => $diff['ops']];
    }

    /**
     * Rolls back a single snapshot. Every target path involved --
     * including, for a rename rollback, the DESTINATION of the rollback
     * write (the original $relFrom) -- goes through the exact same
     * resolvePath()+deny-list check a fresh write_file would, so a path
     * that became newly-denied since the snapshot was taken (e.g. a
     * future DENY_DIRS addition, or the file being absorbed into this
     * component's own tree by something else) cannot be rolled back
     * into. This is deliberate, not an oversight: "it was safe to write
     * here once" does not imply "it's still safe to write here now".
     *
     * @return array{ok:bool, error?:string}
     */
    public static function rollbackSnapshot(string $snapshotId, bool $force = false): array
    {
        $snap = \MuruguardTimeMachineHelper::getSnapshot($snapshotId);
        if ($snap === null) return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'not_found'];
        if (!empty($snap['rolled_back_at'])) return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'already_rolled_back'];
        if (($snap['kind'] ?? '') !== 'file') return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'not_found'];

        $tool = (string) ($snap['tool'] ?? '');

        if ($tool === 'rename_file') {
            // Undo: rename the current (post-repair) path back to the
            // original. Both ends re-validated fresh, exactly as a new
            // write_file/rename_file call would be.
            $currentAbs = self::resolvePath((string) $snap['rel_path']);
            $originalAbs = self::resolvePath((string) $snap['rel_path_from'], false);
            if ($currentAbs === null || $originalAbs === null) {
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'denied'];
            }
            if (file_exists($originalAbs) && !$force) {
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'conflict'];
            }
            if (!@rename($currentAbs, $originalAbs)) {
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'rollback_failed'];
            }
            \MuruguardTimeMachineHelper::markRolledBack($snapshotId);
            self::recordAudit('rollback', (string) $snap['rel_path'] . ' -> ' . (string) $snap['rel_path_from'], $snapshotId, (string) $snap['transaction_id']);
            \MuruguardHelper::recordAttackLogEntry([
                'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
                'rule' => 'rollback', 'severity' => 'low', 'why' => 'TimeMachine rollback restored a renamed file.',
                'matched' => (string) $snap['rel_path'],
            ]);
            return ['ok' => true, 'snapshotId' => $snapshotId];
        }

        // write_file / delete_file: the target is always $snap['rel_path'].
        $abs = self::resolvePath((string) $snap['rel_path'], false);
        if ($abs === null) return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'denied'];

        // Conflict check: current on-disk state vs. what the repair
        // itself left behind (after_*), NOT the pre-repair state -- a
        // file that changed again since the repair (someone hand-edited
        // it, or a later action touched it) is exactly what this refuses
        // to silently clobber.
        $currentContent = is_file($abs) ? @file_get_contents($abs) : null;
        $currentExists = $currentContent !== null && $currentContent !== false;
        $afterExisted = (bool) ($snap['after_existed'] ?? false);
        $conflict = false;
        if ($afterExisted !== $currentExists) {
            $conflict = true;
        } elseif ($currentExists && $snap['after_sha256'] !== null && hash('sha256', $currentContent) !== $snap['after_sha256']) {
            $conflict = true;
        }
        if ($conflict && !$force) {
            return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'conflict'];
        }

        if (empty($snap['before_existed'])) {
            // Undoing a create: the target shouldn't exist afterward.
            if (is_file($abs) && !@unlink($abs)) {
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'rollback_failed'];
            }
        } else {
            // Undoing an edit or a delete: restore the verified blob.
            $verified = \MuruguardTimeMachineHelper::readBlobVerified($snapshotId);
            if (!$verified['ok']) {
                // Integrity failure is never overridable by $force --
                // force only overrides the conflict check above, never
                // "we can't prove this is really what was there before".
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'corrupted'];
            }
            if (@file_put_contents($abs, $verified['content']) === false) {
                return ['ok' => false, 'snapshotId' => $snapshotId, 'error' => 'rollback_failed'];
            }
        }

        \MuruguardTimeMachineHelper::markRolledBack($snapshotId);
        self::recordAudit('rollback', (string) $snap['rel_path'], $snapshotId, (string) $snap['transaction_id']);
        \MuruguardHelper::recordAttackLogEntry([
            'type' => 'timemachine', 'time' => time(), 'ip' => '', 'blocked' => false,
            'rule' => 'rollback', 'severity' => 'low', 'why' => 'TimeMachine rollback restored a file to its pre-repair state.',
            'matched' => (string) $snap['rel_path'],
        ]);
        return ['ok' => true, 'snapshotId' => $snapshotId];
    }

    /** Rolls back every not-yet-rolled-back snapshot in one AI transaction, aggregating per-snapshot results rather than an opaque all-or-nothing failure -- a transaction can partially succeed, with the caller (the controller) reporting exactly which entries still need $force. */
    public static function rollbackTransaction(string $transactionId, bool $force = false): array
    {
        $results = [];
        $hasConflicts = false;
        foreach (\MuruguardTimeMachineHelper::getSnapshotsForTransaction($transactionId) as $snap) {
            if (($snap['kind'] ?? '') !== 'file') continue; // db_row entries are rolled back via the model, not here
            if (!empty($snap['rolled_back_at'])) continue;
            $result = self::rollbackSnapshot((string) $snap['id'], $force);
            if (!$result['ok'] && ($result['error'] ?? '') === 'conflict') $hasConflicts = true;
            $results[] = $result;
        }
        return ['results' => $results, 'hasConflicts' => $hasConflicts];
    }

    // ------------------------------------------------------------------
    // Audit log -- same stub-protected, capped-ring-buffer pattern as
    // MuruguardHelper::recordAttackLogEntry(), so every file the
    // assistant ever creates/edits/renames/deletes is traceable after
    // the fact even though the confirmation happened in a chat UI, not
    // a form submission.
    // ------------------------------------------------------------------

    private static function auditLogFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/ai-audit-log.php';
    }

    /** $snapshotId/$transactionId are optional and new (TimeMachine) -- older entries simply lack them, and getAuditLog() consumers must treat both as possibly absent. */
    private static function recordAudit(string $action, string $detail, ?string $snapshotId = null, ?string $transactionId = null): void
    {
        $entry = [
            'time' => time(), 'action' => $action, 'detail' => $detail,
            'user' => \MuruguardHelper::currentUsername(),
        ];
        if ($snapshotId !== null) $entry['snapshotId'] = $snapshotId;
        if ($transactionId !== null) $entry['transactionId'] = $transactionId;

        $path = self::auditLogFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return;

        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? \MuruguardHelper::stripDataFileStub(fread($fh, $size)) : '';
            $log = json_decode($contents, true);
            if (!is_array($log)) $log = [];

            array_unshift($log, $entry);
            if (count($log) > self::MAX_AUDIT_ENTRIES) {
                $log = array_slice($log, 0, self::MAX_AUDIT_ENTRIES);
            }

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, \MuruguardHelper::dataFileStubPrefix() . json_encode($log));
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    /** Newest first, for the Smart AI Assistant panel's audit tab. */
    public static function getAuditLog(): array
    {
        $path = self::auditLogFilePath();
        if (!is_file($path)) return [];
        $contents = @file_get_contents($path);
        if ($contents === false) return [];
        $decoded = json_decode(\MuruguardHelper::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : [];
    }

    // ------------------------------------------------------------------
    // Custom "Skill" -- free-text project-specific instructions the
    // customer writes (or uploads a .md/.txt file for) once, always
    // appended to the assistant's system prompt on every chat turn (see
    // MuruguardControllerScanner::aiSystemPrompt()). Stored locally, not
    // on the dashboard -- this is specific to THIS Joomla install's own
    // codebase/conventions, not an account-level setting like the AI
    // provider credentials, so there's no reason for it to round-trip
    // through the license-authenticated dashboard API at all.
    // ------------------------------------------------------------------

    private const MAX_SKILL_BYTES = 65536; // 64KB -- generous for hand-written project instructions, cheap insurance against an accidental multi-MB paste bloating every single chat turn's prompt.

    private static function skillFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/ai-skill.php';
    }

    public static function getCustomSkill(): string
    {
        $path = self::skillFilePath();
        if (!is_file($path)) return '';
        $contents = @file_get_contents($path);
        if ($contents === false) return '';
        return \MuruguardHelper::stripDataFileStub($contents);
    }

    public static function saveCustomSkill(string $content): void
    {
        if (strlen($content) > self::MAX_SKILL_BYTES) {
            $content = substr($content, 0, self::MAX_SKILL_BYTES);
        }
        @file_put_contents(self::skillFilePath(), \MuruguardHelper::dataFileStubPrefix() . $content);
    }
}
