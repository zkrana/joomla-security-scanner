<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     MIT
 */

defined('_JEXEC') or die;

require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/muruguard.php';

/**
 * TimeMachine Safe Repair Engine (Pro-only) -- storage/lifecycle layer.
 *
 * This class is deliberately dumb about WHAT it's protecting: it knows
 * nothing about JPATH_ROOT, resolvePath(), deny-lists, or database
 * tables. It only knows how to durably record a "before" state (a file's
 * bytes, or a database row) alongside a transaction id, verify it later,
 * and expire it on schedule. Every method that actually TOUCHES an
 * AI-managed file or a scan-cleanup target lives in MuruguardAiHelper
 * (file/AI-origin rollback) or MuruguardModelScanner (cleanup-origin
 * snapshot calls, DB-row rollback) instead -- keeping this class free of
 * that logic means it can never become a second privileged writer into
 * a path the AI assistant's own deny-list would otherwise refuse.
 *
 * Storage is the same flock()-guarded, stub-protected flat-file JSON
 * pattern already used throughout this codebase (see
 * MuruguardHelper::recordAttackLogEntry() for the canonical version of
 * this idiom) rather than a new database table -- this extension has
 * never shipped a custom table, and nothing here needs SQL.
 */
class MuruguardTimeMachineHelper
{
    private const DEFAULT_RETENTION_DAYS = 14;
    private const DEFAULT_RETENTION_MAX_SNAPSHOTS = 500;

    // ------------------------------------------------------------------
    // Paths
    // ------------------------------------------------------------------

    private static function indexFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/timemachine-index.php';
    }

    private static function blobsDirPath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/timemachine-blobs';
    }

    private static function blobFilePath(string $blobId): string
    {
        return self::blobsDirPath() . '/' . $blobId . '.php';
    }

    /** Creates the blobs subdirectory (plus an index.html placeholder, matching every other data/ subfolder in this component) the first time it's actually needed -- never at install time, so a Pro customer who never uses the AI assistant or cleanup actions never gets an empty directory they didn't ask for. */
    private static function ensureBlobsDir(): bool
    {
        $dir = self::blobsDirPath();
        if (is_dir($dir)) return true;
        if (!@mkdir($dir, 0755, true) && !is_dir($dir)) return false;
        @file_put_contents($dir . '/index.html', '<html><body bgcolor="#FFFFFF"></body></html>');
        return true;
    }

    // ------------------------------------------------------------------
    // Index read/write -- same open-c+/flock/truncate/rewrite idiom as
    // MuruguardHelper::recordAttackLogEntry(), generalized here into a
    // single locked-mutate helper since TimeMachine has several distinct
    // write operations (append snapshot, mark rolled back, toggle keep)
    // that all need the same read-modify-write-under-lock shape.
    // ------------------------------------------------------------------

    /** @return array{transactions:array,snapshots:array} */
    private static function emptyIndex(): array
    {
        return ['transactions' => [], 'snapshots' => []];
    }

    /** @return array{transactions:array,snapshots:array} */
    public static function loadIndex(): array
    {
        $path = self::indexFilePath();
        if (!is_file($path)) return self::emptyIndex();
        $contents = @file_get_contents($path);
        if ($contents === false) return self::emptyIndex();
        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        if (!is_array($decoded) || !isset($decoded['transactions'], $decoded['snapshots'])) {
            return self::emptyIndex();
        }
        return ['transactions' => (array) $decoded['transactions'], 'snapshots' => (array) $decoded['snapshots']];
    }

    /**
     * Runs $mutator(array $index): ?array under an exclusive lock on the
     * index file, writing back whatever it returns (or leaving the file
     * untouched if it returns null, e.g. "not found"). Returns whether a
     * write actually happened, so callers with a fail-closed requirement
     * (recordSnapshot) can distinguish "nothing to do" from "the lock/
     * write itself failed".
     */
    private static function withLockedIndex(callable $mutator): bool
    {
        $path = self::indexFilePath();
        $fh = @fopen($path, 'c+');
        if ($fh === false) return false;

        $wrote = false;
        if (@flock($fh, LOCK_EX)) {
            $size = filesize($path) ?: 0;
            $contents = $size > 0 ? MuruguardHelper::stripDataFileStub(fread($fh, $size)) : '';
            $decoded = json_decode($contents, true);
            $index = (is_array($decoded) && isset($decoded['transactions'], $decoded['snapshots']))
                ? ['transactions' => (array) $decoded['transactions'], 'snapshots' => (array) $decoded['snapshots']]
                : self::emptyIndex();

            $next = $mutator($index);
            if (is_array($next)) {
                ftruncate($fh, 0);
                rewind($fh);
                fwrite($fh, MuruguardHelper::dataFileStubPrefix() . json_encode($next));
                fflush($fh);
                $wrote = true;
            }
            flock($fh, LOCK_UN);
        }
        fclose($fh);
        return $wrote;
    }

    // ------------------------------------------------------------------
    // Transactions
    // ------------------------------------------------------------------

    private static function ensureTransaction(array $transactions, string $transactionId, string $user): array
    {
        foreach ($transactions as $t) {
            if (($t['id'] ?? null) === $transactionId) return $transactions;
        }
        $transactions[] = ['id' => $transactionId, 'created_at' => time(), 'user' => $user, 'keep' => false];
        return $transactions;
    }

    // ------------------------------------------------------------------
    // Snapshot creation
    // ------------------------------------------------------------------

    /**
     * Records one "before" state and returns its snapshot id, or null if
     * the snapshot could not be durably stored -- callers MUST treat
     * null as "abort the mutation" (fail-closed), never as "proceed
     * unprotected". Accepts either a file-content snapshot ($kind=
     * 'file': before_existed/before_content/after_existed/after_content,
     * rel_path[/rel_path_from]) or a database-row snapshot ($kind=
     * 'db_row': table/pk_column/pk_value/before_row/restore_type) --
     * see the class docblock on why this class doesn't distinguish
     * AI-origin from cleanup-origin beyond the plain $origin label.
     *
     * @param array{
     *   transaction_id:string, user:string, kind:string, origin:string,
     *   tool?:string, rel_path?:string, rel_path_from?:?string,
     *   before_existed?:bool, before_content?:?string,
     *   after_existed?:bool, after_content?:?string,
     *   table?:string, pk_column?:string, pk_value?:int|string,
     *   before_row?:array, restore_type?:string
     * } $p
     */
    public static function recordSnapshot(array $p): ?string
    {
        $kind = (string) ($p['kind'] ?? '');
        if (!in_array($kind, ['file', 'db_row'], true)) return null;

        $id = bin2hex(random_bytes(16));
        $blobId = null;
        $beforeSha256 = null;
        $beforeSize = null;
        $afterSha256 = null;
        $afterSize = null;

        if ($kind === 'file') {
            $beforeExisted = !empty($p['before_existed']);
            // A blob is only captured when the caller explicitly passes a
            // 'before_content' key -- write_file/delete_file always do
            // (even a failed read is passed through as null/false, see
            // below), so a file that existed but whose content couldn't
            // be captured correctly refuses the whole snapshot rather
            // than silently recording "no blob", which would make a
            // later rollback delete a file it should have restored.
            // rename_file deliberately OMITS the key: content isn't
            // destroyed by a rename, it's still on disk at the new path,
            // so no blob is needed at all -- rollback is a plain
            // rename() back (see MuruguardAiHelper::rollbackSnapshot()).
            if ($beforeExisted && array_key_exists('before_content', $p)) {
                $beforeContent = $p['before_content'];
                if (!is_string($beforeContent)) return null;
                $beforeSha256 = hash('sha256', $beforeContent);
                $beforeSize = strlen($beforeContent);
                if (!self::ensureBlobsDir()) return null;
                $blobId = $id;
                $written = @file_put_contents(
                    self::blobFilePath($blobId),
                    MuruguardHelper::dataFileStubPrefix() . $beforeContent,
                    LOCK_EX
                );
                if ($written === false) return null;
            }
            if (array_key_exists('after_content', $p) && is_string($p['after_content'])) {
                $afterSha256 = hash('sha256', $p['after_content']);
                $afterSize = strlen($p['after_content']);
            }
        }

        $record = [
            'id'             => $id,
            'transaction_id' => (string) $p['transaction_id'],
            'time'           => time(),
            'user'           => (string) $p['user'],
            'kind'           => $kind,
            'origin'         => (string) ($p['origin'] ?? ''),
            'tool'           => (string) ($p['tool'] ?? ''),
            'rel_path'       => (string) ($p['rel_path'] ?? ''),
            'rel_path_from'  => $p['rel_path_from'] ?? null,
            'before_existed' => array_key_exists('before_existed', $p) ? (bool) $p['before_existed'] : null,
            'before_sha256'  => $beforeSha256,
            'before_size'    => $beforeSize,
            'blob_id'        => $blobId,
            'after_existed'  => array_key_exists('after_existed', $p) ? (bool) $p['after_existed'] : null,
            'after_sha256'   => $afterSha256,
            'after_size'     => $afterSize,
            'table'          => $p['table'] ?? null,
            'pk_column'      => $p['pk_column'] ?? null,
            'pk_value'       => $p['pk_value'] ?? null,
            'before_row'     => $p['before_row'] ?? null,
            // The db_row equivalent of after_content/after_sha256 above --
            // known up front because the cleanup action already computes
            // its "cleaned" replacement value before executing the
            // UPDATE/DELETE, same as write_file's $content is known
            // before the write. Used at rollback time to detect whether
            // the row changed again since the repair (see
            // MuruguardModelScanner::rollbackDbRowSnapshot()).
            'after_row'      => $p['after_row'] ?? null,
            'restore_type'   => $p['restore_type'] ?? null,
            'keep'           => false,
            'rolled_back_at' => null,
        ];

        [$retentionDays, $retentionMax] = self::retentionSettings();

        $evictedBlobIds = [];
        $wrote = self::withLockedIndex(function (array $index) use ($record, $p, $retentionDays, $retentionMax, &$evictedBlobIds) {
            $index['transactions'] = self::ensureTransaction($index['transactions'], (string) $p['transaction_id'], (string) $p['user']);
            $index['snapshots'][] = $record;
            $next = self::sweepIndex($index, $retentionDays, $retentionMax);
            $evictedBlobIds = $next['_evicted_blob_ids'] ?? [];
            unset($next['_evicted_blob_ids']);
            return $next;
        });

        if (!$wrote) {
            // Orphaned blob (written above, but the index append that
            // would reference it failed) -- clean it up rather than
            // leaving a dangling, unreferenced file behind.
            if ($blobId !== null) @unlink(self::blobFilePath($blobId));
            return null;
        }

        foreach ($evictedBlobIds as $evictedBlobId) {
            @unlink(self::blobFilePath($evictedBlobId));
        }

        return $id;
    }

    /**
     * Undoes a just-created snapshot when the mutation it was meant to
     * protect turned out to fail anyway (e.g. recordSnapshot() succeeded
     * but the subsequent file_put_contents()/rename()/unlink()/DB write
     * failed) -- an orphaned snapshot for a repair that never actually
     * happened would be actively misleading in the rollback history.
     */
    public static function discardSnapshot(string $snapshotId): void
    {
        $blobIdToDelete = null;
        self::withLockedIndex(function (array $index) use ($snapshotId, &$blobIdToDelete) {
            $found = false;
            $index['snapshots'] = array_values(array_filter($index['snapshots'], function ($s) use ($snapshotId, &$found, &$blobIdToDelete) {
                if (($s['id'] ?? null) === $snapshotId) {
                    $found = true;
                    $blobIdToDelete = $s['blob_id'] ?? null;
                    return false;
                }
                return true;
            }));
            return $found ? $index : null;
        });
        if ($blobIdToDelete !== null) @unlink(self::blobFilePath($blobIdToDelete));
    }

    // ------------------------------------------------------------------
    // Reads
    // ------------------------------------------------------------------

    public static function getSnapshot(string $snapshotId): ?array
    {
        foreach (self::loadIndex()['snapshots'] as $s) {
            if (($s['id'] ?? null) === $snapshotId) return $s;
        }
        return null;
    }

    public static function getTransaction(string $transactionId): ?array
    {
        foreach (self::loadIndex()['transactions'] as $t) {
            if (($t['id'] ?? null) === $transactionId) return $t;
        }
        return null;
    }

    public static function getSnapshotsForTransaction(string $transactionId): array
    {
        return array_values(array_filter(self::loadIndex()['snapshots'], fn($s) => ($s['transaction_id'] ?? null) === $transactionId));
    }

    /** Keyed by snapshot id, for O(1) lookup while rendering the "Protected Repairs" list against the audit log / cleanup flash entries. */
    public static function listSnapshotsById(): array
    {
        $byId = [];
        foreach (self::loadIndex()['snapshots'] as $s) {
            $byId[(string) ($s['id'] ?? '')] = $s;
        }
        return $byId;
    }

    /** Newest-first snapshots for the Protected Repairs panel, capped at $limit. */
    public static function listRecent(int $limit = 50): array
    {
        $snapshots = self::loadIndex()['snapshots'];
        usort($snapshots, fn($a, $b) => ($b['time'] ?? 0) <=> ($a['time'] ?? 0));
        return array_slice($snapshots, 0, $limit);
    }

    /**
     * Reads a file-kind snapshot's stored "before" content and verifies
     * its SHA-256 still matches what was recorded at snapshot time --
     * the "SHA-256 verification of a snapshot before it's trusted"
     * requirement. A mismatch means the blob was corrupted or tampered
     * with since it was written, and is refused unconditionally by every
     * caller (never overridable by force, unlike a plain conflict).
     */
    public static function readBlobVerified(string $snapshotId): array
    {
        $snap = self::getSnapshot($snapshotId);
        if ($snap === null) return ['ok' => false, 'error' => 'not_found'];
        if (($snap['blob_id'] ?? null) === null) return ['ok' => false, 'error' => 'no_blob'];

        $path = self::blobFilePath((string) $snap['blob_id']);
        if (!is_file($path)) return ['ok' => false, 'error' => 'missing_blob'];

        $raw = @file_get_contents($path);
        if ($raw === false) return ['ok' => false, 'error' => 'read_failed'];

        $content = MuruguardHelper::stripDataFileStub($raw);
        if (!hash_equals((string) $snap['before_sha256'], hash('sha256', $content))) {
            return ['ok' => false, 'error' => 'corrupted'];
        }

        return ['ok' => true, 'content' => $content];
    }

    // ------------------------------------------------------------------
    // Mutations on existing records
    // ------------------------------------------------------------------

    public static function markRolledBack(string $snapshotId): bool
    {
        return self::withLockedIndex(function (array $index) use ($snapshotId) {
            $found = false;
            foreach ($index['snapshots'] as &$s) {
                if (($s['id'] ?? null) === $snapshotId) {
                    $s['rolled_back_at'] = time();
                    $found = true;
                    break;
                }
            }
            unset($s);
            return $found ? $index : null;
        });
    }

    public static function setKeep(string $snapshotId, bool $keep): bool
    {
        return self::withLockedIndex(function (array $index) use ($snapshotId, $keep) {
            $found = false;
            foreach ($index['snapshots'] as &$s) {
                if (($s['id'] ?? null) === $snapshotId) {
                    $s['keep'] = $keep;
                    $found = true;
                    break;
                }
            }
            unset($s);
            return $found ? $index : null;
        });
    }

    public static function setKeepTransaction(string $transactionId, bool $keep): bool
    {
        return self::withLockedIndex(function (array $index) use ($transactionId, $keep) {
            $found = false;
            foreach ($index['transactions'] as &$t) {
                if (($t['id'] ?? null) === $transactionId) {
                    $t['keep'] = $keep;
                    $found = true;
                    break;
                }
            }
            unset($t);
            return $found ? $index : null;
        });
    }

    // ------------------------------------------------------------------
    // Retention / expiration
    // ------------------------------------------------------------------

    /** @return array{0:int,1:int} [retentionDays, retentionMaxSnapshots] */
    private static function retentionSettings(): array
    {
        $days = self::DEFAULT_RETENTION_DAYS;
        $max = self::DEFAULT_RETENTION_MAX_SNAPSHOTS;
        try {
            $cfgParams = \Joomla\CMS\Component\ComponentHelper::getParams('com_muruguard');
            $days = (int) $cfgParams->get('timemachine_retention_days', $days);
            $max = (int) $cfgParams->get('timemachine_retention_max_snapshots', $max);
        } catch (\Throwable $e) {
            // non-fatal -- fall back to the defaults above
        }
        if ($days < 1) $days = self::DEFAULT_RETENTION_DAYS;
        if ($max < 10) $max = self::DEFAULT_RETENTION_MAX_SNAPSHOTS;
        return [$days, $max];
    }

    /**
     * Evicts snapshots (and their blobs) past the retention window or
     * beyond the count cap -- oldest-first, and never a snapshot that's
     * pinned itself OR belongs to a pinned transaction. Unlike the
     * attack log's evicted-entries-are-archived precedent, eviction here
     * is a HARD delete: an unbounded archive of raw former file/row
     * contents (potentially sensitive source code, DB rows) would defeat
     * the entire point of a retention policy. Runs inside the SAME lock
     * recordSnapshot() already holds (called from within its
     * withLockedIndex() mutator) so a snapshot-triggered sweep never
     * takes a second lock, and is also exposed publicly via
     * sweepExpired() for the scheduled-scan cron path to call when idle
     * (no new snapshots being taken to trigger this as a side effect).
     */
    private static function sweepIndex(array $index, int $retentionDays, int $retentionMax): array
    {
        $keptTransactionIds = [];
        foreach ($index['transactions'] as $t) {
            if (!empty($t['keep'])) $keptTransactionIds[(string) ($t['id'] ?? '')] = true;
        }

        $cutoff = time() - ($retentionDays * 86400);
        $snapshots = $index['snapshots'];
        usort($snapshots, fn($a, $b) => ($a['time'] ?? 0) <=> ($b['time'] ?? 0)); // oldest first

        $evictedBlobIds = [];
        $pinned = [];
        $ageSurvivors = []; // non-pinned, within the retention window, oldest first

        foreach ($snapshots as $s) {
            $isPinned = !empty($s['keep']) || !empty($keptTransactionIds[(string) ($s['transaction_id'] ?? '')]);
            if ($isPinned) {
                $pinned[] = $s;
                continue;
            }
            if (($s['time'] ?? 0) < $cutoff) {
                if (!empty($s['blob_id'])) $evictedBlobIds[] = (string) $s['blob_id'];
                continue;
            }
            $ageSurvivors[] = $s;
        }

        // Count cap applies AFTER age eviction -- it only needs to trim
        // whatever's left down to the max, oldest of the survivors first,
        // not evict a fixed count independent of what age already removed.
        $overCount = max(0, count($ageSurvivors) - $retentionMax);
        if ($overCount > 0) {
            for ($i = 0; $i < $overCount; $i++) {
                if (!empty($ageSurvivors[$i]['blob_id'])) $evictedBlobIds[] = (string) $ageSurvivors[$i]['blob_id'];
            }
            $ageSurvivors = array_slice($ageSurvivors, $overCount);
        }

        $index['snapshots'] = array_merge($pinned, $ageSurvivors);

        // Blob deletion happens here, still logically "inside" the
        // sweep, but the actual unlink()s are deferred to just after
        // this returns (see recordSnapshot()/sweepExpired()) so a
        // slow filesystem operation never extends how long the index
        // lock is held.
        $index['_evicted_blob_ids'] = $evictedBlobIds;
        return $index;
    }

    /** Public entry point for the scheduled-scan cron path (see MuruguardControllerScanner::scheduledcheck()) -- catches storage that's gone idle with no new snapshots to trigger sweepIndex() as a side effect. */
    public static function sweepExpired(): void
    {
        [$days, $max] = self::retentionSettings();
        $evictedBlobIds = [];
        self::withLockedIndex(function (array $index) use ($days, $max, &$evictedBlobIds) {
            $next = self::sweepIndex($index, $days, $max);
            $evictedBlobIds = $next['_evicted_blob_ids'] ?? [];
            unset($next['_evicted_blob_ids']);
            return $next;
        });
        foreach ($evictedBlobIds as $blobId) {
            @unlink(self::blobFilePath($blobId));
        }
    }
}
