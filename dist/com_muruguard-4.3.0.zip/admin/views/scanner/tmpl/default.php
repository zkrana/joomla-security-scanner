<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     MIT
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Toolbar\ToolbarInterface;
use Joomla\CMS\Uri\Uri;

/**
 * Client-side pagination controls (Prev/Next + "Showing X-Y of Z") for a
 * table body identified by $tbodyId -- the actual paging logic lives in
 * JS (muruPaginateTable() in the script block below), which toggles
 * .muru-paginated-row visibility by data-row-index. Deliberately
 * client-side, not a server-side re-render per page: every row (and its
 * checkbox) stays in the DOM regardless of which page is showing, so
 * "select all" / "select high only" keep working across the WHOLE result
 * set exactly as they already did before pagination existed, not just
 * the currently-visible page.
 *
 * Declared here, at the very top of the file, rather than down near
 * where it's mostly used -- the Protection Log section (much earlier in
 * this template than the Suspicious/Cleanable Files tables) also calls
 * this, and a declaration positioned after its own first call site threw
 * "Call to undefined function" on a real Joomla 6.1.2 install despite
 * being valid, hoistable top-level PHP. Declaring it unconditionally
 * before ANY use removes the dependency on that behavior entirely,
 * regardless of what in that environment (opcache, a template override,
 * or something else) was actually causing it.
 */
function muru_pagination_controls(string $tbodyId, int $totalCount): void {
    if ($totalCount === 0) return;
    ?>
    <div class="muru-pagination flex items-center justify-between gap-3 mb-4 text-xs text-gray-500" data-paginate-for="<?= htmlspecialchars($tbodyId) ?>">
        <span class="muru-pagination-status"></span>
        <div class="flex items-center gap-2">
            <button type="button" class="muru-pagination-prev px-2.5 py-1 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 shadow-sm disabled:opacity-40 disabled:cursor-not-allowed" disabled>← <?= Text::_('COM_MURUGUARD_PAGINATION_PREV') ?></button>
            <button type="button" class="muru-pagination-next px-2.5 py-1 rounded-lg border border-gray-300 bg-white hover:bg-gray-50 shadow-sm disabled:opacity-40 disabled:cursor-not-allowed" disabled><?= Text::_('COM_MURUGUARD_PAGINATION_NEXT') ?> →</button>
        </div>
    </div>
    <?php
}

/**
 * One "Protected Repairs" row -- shared between the AI Assistant panel's
 * short preview (2 most recent) and the Backup & Restore tab's full
 * list, so the two never drift apart on markup or the Restore/pin
 * button wiring. Declared here (same top-of-file reasoning as
 * muru_pagination_controls() above) since the AI Assistant panel is
 * rendered before the Backup & Restore tab further down the file.
 */
function muru_render_protected_repair_row(array $repair, array $timeMachineSnapshots): void {
    $snapshotId = $repair['snapshotId'] ?? null;
    $snap = $snapshotId !== null ? ($timeMachineSnapshots[$snapshotId] ?? null) : null;
    $canRestore = $snap !== null && empty($snap['rolled_back_at']);
    $isRolledBack = $snap !== null && !empty($snap['rolled_back_at']);
    ?>
    <div class="px-1 py-1.5 border-b border-gray-100 last:border-0" data-tm-row<?php if ($snapshotId): ?> data-snapshot-id="<?= htmlspecialchars((string) $snapshotId) ?>" data-transaction-id="<?= htmlspecialchars((string) ($repair['transactionId'] ?? '')) ?>"<?php endif; ?>>
        <div class="font-mono text-[10px] text-gray-500"><?= date('Y-m-d H:i', $repair['time']) ?> · <?= htmlspecialchars($repair['user']) ?></div>
        <div class="flex items-start justify-between gap-2">
            <div class="text-gray-700 font-mono break-all"><?= htmlspecialchars($repair['label']) ?></div>
            <div class="shrink-0 flex items-center gap-2">
                <?php if ($canRestore): ?>
                <button type="button" class="muru-tm-pin-btn text-[10px] font-medium <?= !empty($snap['keep']) ? 'text-amber-600' : 'text-gray-400 hover:text-gray-600' ?>" data-keep="<?= !empty($snap['keep']) ? '1' : '0' ?>"><?= !empty($snap['keep']) ? Text::_('COM_MURUGUARD_TM_UNPIN_BTN') : Text::_('COM_MURUGUARD_TM_PIN_BTN') ?></button>
                <button type="button" class="muru-tm-restore-btn text-[10px] font-bold text-indigo-600 hover:text-indigo-800"><?= Text::_('COM_MURUGUARD_TM_RESTORE_BTN') ?></button>
                <?php elseif ($isRolledBack): ?>
                <span class="text-[10px] font-medium text-gray-400"><?= Text::_('COM_MURUGUARD_TM_ROLLED_BACK_BADGE') ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}

/** @var MuruguardViewScanner $this */
$fileFindings = $this->fileFindings ?? [];
$dbFindings   = $this->dbFindings   ?? [];
$suspiciousSU = !empty($dbFindings['superusers'])
    ? array_filter($dbFindings['superusers'], fn($u) => $u['suspicious'])
    : [];

$scanUrl    = 'index.php?option=com_muruguard&task=scanner.scan';
$rescanUrl  = 'index.php?option=com_muruguard&task=scanner.scan&rescan=1';
?>

<script src="https://cdn.tailwindcss.com"></script>
<script>
  // Scope every Tailwind utility class to elements inside #muruguard-root,
  // and disable Tailwind's global reset (preflight). Without this, the
  // CDN build resets margin/box-sizing/line-height on EVERY element on
  // the admin page (not just ours), and several of its utility class
  // names collide 1:1 with Joomla's own Bootstrap admin classes
  // (.shadow-sm, .gap-2, .rounded, .border, ...) -- which is what was
  // breaking the sidebar, post-install messages, and other admin chrome
  // sitting outside this component.
  tailwind.config = {
    important: '#muruguard-root',
    corePlugins: { preflight: false },
  };
</script>
<style>
  @keyframes muruguard-spin { to { transform: rotate(360deg); } }
  @keyframes muruguard-fade-up { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
  @keyframes muruguard-pulse-ring { 0%,100%{opacity:.4;transform:scale(1)} 50%{opacity:.8;transform:scale(1.08)} }
  .spinner { animation: muruguard-spin 0.8s linear infinite; }
  .anim-in { animation: muruguard-fade-up 0.4s ease both; }
  .shield-pulse { animation: muruguard-pulse-ring 2.5s ease-in-out infinite; }

  /* Base resets scoped to our component only, replacing what Tailwind's
     preflight would normally do globally (now disabled above). */
  #muruguard-root, #muruguard-root * { box-sizing: border-box; }
  #muruguard-root { line-height: 1.55; -webkit-font-smoothing: antialiased; }
  #muruguard-root h1, #muruguard-root h2, #muruguard-root h3, #muruguard-root h4, #muruguard-root p { margin: 0; }
  #muruguard-root a { color: inherit; text-decoration: none; }
  #muruguard-root button { font: inherit; cursor: pointer; background: none; border: 0; padding: 0; -webkit-appearance: none; appearance: none; }
  #muruguard-root table { border-collapse: collapse; width: 100%; }
  #muruguard-root pre  { white-space: pre-wrap; word-break: break-all; }
  #muruguard-root code { font-family: ui-monospace, monospace; }

  /* scrollable table wrapper */
  .tbl-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }

  /* tabs */
  .muru-tab { color:#4b5563; background:transparent; border:1px solid transparent; cursor:pointer; }
  .muru-tab:hover { background:#fff; color:#111827; }
  .muru-tab.active { background:#fff; color:#4338ca; border:1px solid #e5e7eb !important; box-shadow:0 1px 2px rgba(0,0,0,.05); }
  .muru-panel.active { display:block; }

  /* settings sub-tabs (Scheduled Scanning / Setup Guide) */
  /* !important on color -- Joomla's own admin template CSS (or Tailwind's
     CDN-injected stylesheet, which loads after this static <style> block)
     can otherwise win this at equal specificity depending on cascade
     order, which is exactly what made this text render invisible
     (white-on-white) despite this rule existing. */
  .muru-settings-tab { color:#374151 !important; background:#fff; border:1px solid #e5e7eb; cursor:pointer; box-shadow:0 1px 2px rgba(0,0,0,.04); }
  .muru-settings-tab:hover { background:#f9fafb; color:#111827 !important; box-shadow:0 1px 3px rgba(0,0,0,.08); }
  .muru-settings-tab.active { background:#4338ca; color:#000000 !important; border-color:#4338ca; box-shadow:0 2px 6px rgba(67,56,202,.35); }

  /* ── Site Protection tab: collapsed-by-default sections (IP Access
     List, MuRu Shield Hardening) -- same white-card chrome every other
     settings card uses, just as a native <details> disclosure instead
     of always-open, so the tab isn't overwhelming while Site Protection
     and Protection Log (what's checked most often) stay open. */
  .muru-settings-collapse { background:#fff; border:1px solid #e5e7eb; border-radius:12px; box-shadow:0 1px 2px rgba(0,0,0,.04); margin-bottom:20px; overflow:hidden; }
  .muru-settings-collapse > summary { cursor:pointer; padding:20px 24px; display:flex; align-items:center; justify-content:space-between; gap:16px; list-style:none; }
  .muru-settings-collapse > summary::-webkit-details-marker { display:none; }
  .muru-settings-collapse > summary:hover { background:#f9fafb; }
  .muru-settings-collapse > summary:focus-visible { outline:2px solid #4338ca; outline-offset:-2px; }
  /* Explicit chevron badge (not a bare ::after glyph, which rendered too
     small/faint to read as "click to expand") -- a real circular button
     look with its own background, so the affordance is obvious at a
     glance rather than a barely-visible character. */
  .muru-settings-collapse-chevron { flex-shrink:0; width:32px; height:32px; border-radius:9999px; background:#f3f4f6; color:#6b7280; display:flex; align-items:center; justify-content:center; font-size:32px; line-height:1; transition:transform .15s ease, background .15s ease; }
  .muru-settings-collapse > summary:hover .muru-settings-collapse-chevron { background:#e5e7eb; color:#374151; }
  .muru-settings-collapse[open] .muru-settings-collapse-chevron { transform:rotate(90deg); }
  .muru-settings-collapse-hint { font-size: 11px; color: #fbfbfb; font-weight: 700; text-transform: uppercase; letter-spacing: .03em; margin-top: 16px !important; background: #4f47e6; padding: 4px 10px; border-radius: 4px; display: inline-block; }
  .muru-settings-collapse-body { padding:0 24px 24px; }

  /* A settings tab id can be split across several sibling top-level
     .muru-settings-tabpanel divs (e.g. "automation" = Automations, AI
     Integrations, Backup & Restore, Integrity, each its own div) --
     without this they stack directly on top of each other with zero
     gap between (the last card's Save button touching the next card's
     heading). Harmless on a hidden panel since margin on a
     display:none element has no layout effect. */
  .muru-settings-tabpanel { margin-bottom:20px; }
  .muru-settings-tabpanel:last-child { margin-bottom:0; }

  /* copy-path button feedback */
  .muru-copy-btn.muru-copied { color:#16a34a !important; background:#f0fdf4 !important; }

  /* settings toggle switch */
  .muru-switch { display:inline-flex; cursor:pointer; }
  .muru-switch input { position:absolute; opacity:0; width:0; height:0; }
  .muru-switch-track { width:44px; height:24px; border-radius:9999px; background:#d1d5db; position:relative; transition:background .2s; flex-shrink:0; }
  .muru-switch-thumb { position:absolute; top:2px; left:2px; width:20px; height:20px; border-radius:9999px; background:#fff; box-shadow:0 1px 2px rgba(0,0,0,.15); transition:transform .2s; }
  .muru-switch input:checked + .muru-switch-track { background:#4338ca; }
  .muru-switch input:checked + .muru-switch-track .muru-switch-thumb { transform:translateX(20px); }
  .muru-switch input:focus-visible + .muru-switch-track { box-shadow:0 0 0 3px rgba(67,56,202,.3); }

  /* ── Loading overlay & floating header-actions widget ────────────
     Deliberately PLAIN CSS (no Tailwind utility classes). Both the
     overlay and the header-actions wrapper (Settings + Support) get
     re-parented to <body> at runtime via JS: Joomla's admin template
     applies a CSS transform to the content wrapper while animating the
     collapsible sidebar, and a transformed ancestor breaks
     `position: fixed` (it gets confined to that ancestor's box instead
     of the real viewport -- which is why the overlay was appearing
     pinned near the sidebar instead of centered). Re-parenting to <body>
     escapes that, but also takes these elements outside #muruguard-root,
     so they can no longer rely on the Tailwind scoping above. */
  #muruguard-overlay {
    position: fixed; inset: 0; z-index: 999999; display: none;
    align-items: center; justify-content: center;
    background: rgba(15,23,42,.86);
    backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  }
  #muruguard-overlay.muruguard-show { display: flex; }
  .muruguard-overlay-card { display:flex; flex-direction:column; align-items:center; text-align:center; max-width:320px; padding:0 16px; }
  .muruguard-overlay-icon-wrap { position:relative; width:64px; height:64px; margin-bottom:20px; display:flex; align-items:center; justify-content:center; font-size:30px; }
  .muruguard-overlay-spinner { position:absolute; inset:0; border-radius:9999px; border:4px solid rgba(255,255,255,.12); border-top-color:#3b82f6; animation: muruguard-spin .8s linear infinite; }
  .muruguard-overlay-icon { animation: muruguard-icon-pulse 1.6s ease-in-out infinite; }
  @keyframes muruguard-icon-pulse { 0%,100%{opacity:1} 50%{opacity:.5} }
  .muruguard-overlay-title { color:#fff; font-weight:700; font-size:16px; margin:0 0 8px; }
  .muruguard-overlay-status { color:#94a3b8; font-size:14px; margin:0 0 20px; min-height:18px; transition:opacity .3s; }
  .muruguard-overlay-track { width:224px; height:6px; border-radius:9999px; background:rgba(255,255,255,.1); overflow:hidden; margin-bottom:16px; }
  .muruguard-overlay-bar { height:100%; border-radius:9999px; background:linear-gradient(90deg,#3b82f6,#60a5fa); width:30%; animation: muruguard-bar-slide 1.8s ease-in-out infinite; }
  @keyframes muruguard-bar-slide { 0%{width:15%;margin-left:0} 50%{width:55%;margin-left:20%} 100%{width:15%;margin-left:100%} }
  .muruguard-overlay-note { color:#64748b; font-size:11px; line-height:1.6; margin:0; }


  /* ── Code-analysis modal ──────────────────────────────────────
     Same plain-CSS + re-parent-to-<body> treatment as the overlay and
     support widget above, for the same reason: Joomla's admin template
     transforms the content wrapper, which breaks `position: fixed`. */
  #muru-modal { display:none; position:fixed; inset:0; z-index:999997; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif; }
  #muru-modal.muru-show { display:block; }
  #muru-modal-backdrop { position:absolute; inset:0; background:rgba(15,23,42,.6); backdrop-filter:blur(2px); -webkit-backdrop-filter:blur(2px); }
  #muru-modal-dialog { position:relative; max-width:720px; width:calc(100% - 32px); max-height:calc(100% - 64px); margin:32px auto; background:#fff; border-radius:16px; box-shadow:0 20px 50px rgba(0,0,0,.3); display:flex; flex-direction:column; overflow:hidden; }
  #muru-modal-header { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; padding:18px 20px; border-bottom:1px solid #f1f5f9; }
  #muru-modal-badge { display:inline-block; font-size:11px; font-weight:700; padding:2px 8px; border-radius:9999px; margin-bottom:6px; }
  #muru-modal-badge.high { background:#fee2e2; color:#b91c1c; }
  #muru-modal-badge.medium { background:#fef3c7; color:#92400e; }
  #muru-modal-path { font-family:ui-monospace,monospace; font-size:12.5px; color:#374151; word-break:break-all; }
  #muru-modal-close { flex-shrink:0; width:28px; height:28px; border-radius:9999px; background:#f3f4f6; color:#6b7280; font-size:14px; line-height:1; cursor:pointer; border:0; }
  #muru-modal-close:hover { background:#e5e7eb; color:#111827; }
  #muru-modal-body { padding:16px 20px 20px; overflow-y:auto; }
  #muru-modal-ai-result.muru-ai-error { background:#fef2f2; border-color:#fecaca; color:#b91c1c; }
  .muru-reason-block { padding:12px 0; border-bottom:1px solid #f1f5f9; }
  .muru-reason-block:last-child { border-bottom:0; }
  .muru-reason-block p { font-size:13px; color:#374151; line-height:1.55; margin:0 0 8px; }
  .muru-reason-code-label { font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; color:#9ca3af; margin-bottom:4px; }
  .muru-reason-code { font-family:ui-monospace,monospace; font-size:12px; line-height:1.6; color:#b91c1c; background:#fef2f2; border:1px solid #fee2e2; border-radius:8px; padding:10px 12px; white-space:pre-wrap; word-break:break-all; margin:0; }
  .muru-diff-block { padding:12px 0; border-top:2px dashed #e5e7eb; margin-top:4px; }
  .muru-diff-label { font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; margin-bottom:4px; }
  .muru-diff-label-before { color:#b91c1c; }
  .muru-diff-label-after { color:#15803d; margin-top:10px; }
  .muru-diff-removed { font-family:ui-monospace,monospace; font-size:12px; line-height:1.6; color:#b91c1c; background:#fef2f2; border:1px solid #fee2e2; border-radius:8px; padding:10px 12px; white-space:pre-wrap; word-break:break-all; margin:0; text-decoration:line-through; text-decoration-color:#fca5a5; }
  .muru-diff-added { font-family:ui-monospace,monospace; font-size:12px; line-height:1.6; color:#15803d; background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; padding:10px 12px; white-space:pre-wrap; word-break:break-all; margin:0; }

  /* ── TimeMachine repair preview -- per-line diff shown inside the AI
     chat's existing #muru-ai-confirm-box, reusing the same red/green
     removed/added color language as .muru-diff-removed/.muru-diff-added
     above (the one existing diff affordance in the product) but as a
     scrolling per-line list instead of two whole-block <pre> dumps,
     since a real line diff can interleave adds/removes/unchanged
     context lines rather than a single before/after replacement. */
  .muru-tm-diff { font-family:ui-monospace,monospace; font-size:11px; line-height:1.5; background:#fff; border:1px solid #fde68a; border-radius:8px; padding:6px 0; max-height:220px; overflow:auto; margin-bottom:8px; }
  .muru-tm-diff-line { padding:0 10px; white-space:pre-wrap; word-break:break-all; }
  .muru-tm-diff-add { background:#f0fdf4; color:#15803d; }
  .muru-tm-diff-remove { background:#fef2f2; color:#b91c1c; text-decoration:line-through; text-decoration-color:#fca5a5; }
  .muru-tm-diff-equal { color:#9ca3af; }
  .muru-tm-binary { font-family:ui-monospace,monospace; font-size:11px; color:#78716c; background:#fff; border:1px solid #fde68a; border-radius:8px; padding:8px 10px; margin-bottom:8px; }

  /* ── .htaccess hardening modal -- same fixed/re-parent-to-<body>
     treatment as the modals above, for the same reason. Content here is
     hand-styled with dedicated classes rather than Tailwind utilities,
     since a re-parented element sits outside #muruguard-root and loses
     access to Tailwind's JIT-scoped CSS entirely. */
  #muru-htaccess-modal { display:none; position:fixed; inset:0; z-index:999997; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif; }
  #muru-htaccess-modal.muru-show { display:flex; align-items:center; justify-content:center; padding:24px; }
  #muru-htaccess-modal-backdrop { position:absolute; inset:0; background:rgba(15,23,42,.65); backdrop-filter:blur(3px); -webkit-backdrop-filter:blur(3px); }
  #muru-htaccess-modal-dialog { position:relative; max-width:760px; width:100%; max-height:calc(100vh - 48px); background:#fff; border-radius:20px; box-shadow:0 25px 60px rgba(15,23,42,.35); display:flex; flex-direction:column; overflow:hidden; }
  #muru-htaccess-modal-header { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:20px 24px; background:linear-gradient(135deg,#eef2ff 0%,#f5f3ff 55%,#fdf2f8 100%); border-bottom:1px solid #eef0f4; flex-shrink:0; }
  #muru-htaccess-modal-header-title { display:flex; align-items:flex-start; gap:12px; }
  #muru-htaccess-modal-header-icon { flex-shrink:0; display:flex; align-items:center; justify-content:center; width:40px; height:40px; border-radius:12px; background:rgba(255,255,255,.7); font-size:19px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
  #muru-htaccess-modal-header h3 { font-size:15px; font-weight:800; color:#1f2937; margin:0; }
  #muru-htaccess-modal-header p { font-size:12px; color:#6b7280; margin:4px 0 0; line-height:1.5; }
  #muru-htaccess-modal-close { flex-shrink:0; width:30px; height:30px; border-radius:9999px; background:rgba(255,255,255,.8); color:#6b7280; font-size:14px; line-height:1; cursor:pointer; border:0; transition:background .15s, color .15s; }
  #muru-htaccess-modal-close:hover { background:#fff; color:#111827; }
  #muru-htaccess-modal-body { padding:20px 24px; overflow-y:auto; background:#fafbfc; }
  #muru-htaccess-modal-missing-file { display:flex; align-items:center; gap:10px; color:#b45309; background:#fffbeb; border:1px solid #fde68a; border-radius:12px; padding:12px 14px; margin-bottom:16px; font-size:13px; font-weight:600; }
  .muru-hc-category { font-size:13px; font-weight:800; color:#374151; margin:18px 0 10px; }
  .muru-hc-category:first-child { margin-top:0; }
  .muru-hc-item { border:1px solid #e5e7eb; border-radius:12px; margin-bottom:8px; overflow:hidden; }
  .muru-hc-item.present { background:#f0fdf4; border-color:#bbf7d0; }
  .muru-hc-item.missing { background:#fffbeb; border-color:#fde68a; }
  .muru-hc-item summary { cursor:pointer; padding:12px 14px; display:flex; align-items:center; justify-content:space-between; gap:12px; font-size:13px; font-weight:700; color:#1f2937; list-style:none; }
  .muru-hc-item summary::-webkit-details-marker { display:none; }
  .muru-hc-status { font-size:11px; font-weight:800; flex-shrink:0; }
  .muru-hc-status.present { color:#15803d; }
  .muru-hc-status.missing { color:#b45309; }
  .muru-hc-body { border-top:1px solid rgba(0,0,0,.06); padding:12px 14px; }
  .muru-hc-explain { font-size:12px; color:#4b5563; line-height:1.6; margin:0 0 10px; }
  .muru-hc-rule-label { font-size:11px; font-weight:700; color:#6b7280; margin:0 0 4px; }
  .muru-hc-rule { font-size:11.5px; line-height:1.6; background:#111827; color:#e5e7eb; border-radius:8px; padding:10px 12px; overflow-x:auto; white-space:pre; font-family:ui-monospace,monospace; margin:0; }
  .muru-hc-actions { display:flex; align-items:center; gap:10px; margin-top:10px; }
  .muru-hc-apply-btn { flex-shrink:0; display:inline-flex; align-items:center; gap:5px; padding:6px 12px; border-radius:8px; font-size:12px; font-weight:700; color:#fff; background:#4338ca; border:0; cursor:pointer; transition:background-color .15s; }
  .muru-hc-apply-btn:hover:not(:disabled) { background:#3730a3; }
  .muru-hc-apply-btn:disabled { opacity:.55; cursor:default; }
  .muru-hc-apply-result { font-size:11.5px; font-weight:700; }
  .muru-hc-apply-result.ok { color:#15803d; }
  .muru-hc-apply-result.err { color:#b91c1c; }
  .muru-hc-apply-note { font-size:10.5px; color:#9ca3af; margin:8px 0 0; line-height:1.5; }
  #muru-htaccess-modal-footer { padding:12px 24px 18px; font-size:11px; color:#9ca3af; flex-shrink:0; }

  /* ── Scan-area picker modal -- same fixed/re-parent-to-<body> treatment
     as the code-analysis modal above, for the same reason (Joomla's
     admin template transforms the content wrapper, which breaks
     `position: fixed`). */
  #muru-scan-modal { display:none; position:fixed; inset:0; z-index:999997; align-items:center; justify-content:center; padding:24px; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif; }
  #muru-scan-modal.muru-show { display:flex; }
  #muru-scan-modal-backdrop { position:absolute; inset:0; background:rgba(15,23,42,.65); backdrop-filter:blur(3px); -webkit-backdrop-filter:blur(3px); animation:muruguard-fade-up .25s ease both; }
  #muru-scan-modal-dialog { position:relative; max-width:840px; width:100%; max-height:calc(100vh - 48px); background:#fff; border-radius:20px; box-shadow:0 25px 60px rgba(15,23,42,.35); display:flex; flex-direction:column; overflow:hidden; animation:muruguard-fade-up .3s ease both; }
  #muru-scan-modal-header { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:20px 24px; background:linear-gradient(135deg,#eef2ff 0%,#f5f3ff 55%,#fdf2f8 100%); border-bottom:1px solid #eef0f4; flex-shrink:0; }
  #muru-scan-modal-header-title { display:flex; align-items:center; gap:12px; }
  #muru-scan-modal-header-icon { flex-shrink:0; display:flex; align-items:center; justify-content:center; width:40px; height:40px; border-radius:12px; background:rgba(255,255,255,.7); font-size:19px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
  #muru-scan-modal-header h3 { font-size:15px; font-weight:800; color:#1f2937; margin:0; }
  #muru-scan-modal-header p { font-size:12px; color:#6b7280; margin:2px 0 0; }
  #muru-scan-modal-close { flex-shrink:0; width:30px; height:30px; border-radius:9999px; background:rgba(255,255,255,.8); color:#6b7280; font-size:14px; line-height:1; cursor:pointer; border:0; transition:background .15s, color .15s; }
  #muru-scan-modal-close:hover { background:#fff; color:#111827; }
  #muru-scan-modal-body { padding:20px 24px; overflow-y:auto; background:#fafbfc; }
  #muru-scan-modal-selectall { display:flex; align-items:center; justify-content:flex-end; gap:8px; margin-bottom:16px; }
  #muru-scan-modal-selectall label { display:inline-flex; align-items:center; gap:7px; font-size:12.5px; font-weight:700; color:#4338ca; background:#eef2ff; border:1px solid #e0e7ff; border-radius:9999px; padding:6px 14px; cursor:pointer; user-select:none; transition:background .15s, box-shadow .15s; }
  #muru-scan-modal-selectall label:hover { background:#e0e7ff; }
  .muru-scan-group { background:#fff; border:1px solid #eef0f4; border-radius:14px; padding:16px; transition:box-shadow .15s, border-color .15s; }
  .muru-scan-group:hover { box-shadow:0 2px 10px rgba(15,23,42,.05); border-color:#e5e7eb; }
  .muru-area-chk { accent-color:#4338ca; }
  #muru-scan-modal-footer { display:flex; align-items:center; justify-content:space-between; gap:16px; padding:16px 24px; border-top:1px solid #eef0f4; background:#fff; flex-shrink:0; }

  /* The chrome above (dialog/header/footer/backdrop) already gets plain CSS
     because this whole modal is re-parented to <body> at runtime, outside
     #muruguard-root's Tailwind scope (see comment further up). The modal's
     INNER content (area grid, checkboxes, labels, Run Scan button) was added
     later and relies on Tailwind utility classes too, so it needs the same
     treatment -- scoped under #muru-scan-modal specifically (its own id,
     rather than #muruguard-root) so this can't leak into the rest of the
     Joomla admin page regardless of where in the document this modal lives. */
  #muru-scan-modal .flex { display:flex; }
  #muru-scan-modal .inline-flex { display:inline-flex; }
  #muru-scan-modal .grid { display:grid; }
  #muru-scan-modal .items-center { align-items:center; }
  #muru-scan-modal .items-start { align-items:flex-start; }
  #muru-scan-modal .justify-center { justify-content:center; }
  #muru-scan-modal .gap-2 { gap:8px; }
  #muru-scan-modal .gap-4 { gap:16px; }
  #muru-scan-modal .mb-2\.5 { margin-bottom:10px; }
  #muru-scan-modal .mt-0\.5 { margin-top:2px; }
  #muru-scan-modal .-mx-2 { margin-left:-8px; margin-right:-8px; }
  #muru-scan-modal .space-y-0\.5 > * + * { margin-top:2px; }
  #muru-scan-modal .w-3\.5 { width:14px; }
  #muru-scan-modal .h-3\.5 { height:14px; }
  #muru-scan-modal .w-4 { width:16px; }
  #muru-scan-modal .h-4 { height:16px; }
  #muru-scan-modal .w-7 { width:28px; }
  #muru-scan-modal .h-7 { height:28px; }
  #muru-scan-modal .flex-shrink-0 { flex-shrink:0; }
  #muru-scan-modal .rounded { border-radius:4px; }
  #muru-scan-modal .rounded-lg { border-radius:8px; }
  #muru-scan-modal .rounded-xl { border-radius:12px; }
  #muru-scan-modal .border-gray-300 { border:1px solid #d1d5db; }
  #muru-scan-modal .border-indigo-300 { border:1px solid #a5b4fc; }
  #muru-scan-modal .bg-gray-100 { background:#f3f4f6; }
  #muru-scan-modal .text-gray-400 { color:#9ca3af; }
  #muru-scan-modal .text-gray-500 { color:#6b7280; }
  #muru-scan-modal .text-gray-700 { color:#374151; }
  #muru-scan-modal .text-sm { font-size:14px; line-height:1.43; }
  #muru-scan-modal .text-xs { font-size:12px; line-height:1.5; }
  #muru-scan-modal .text-\[11px\] { font-size:11px; line-height:1.4; }
  #muru-scan-modal .font-bold { font-weight:700; }
  #muru-scan-modal .uppercase { text-transform:uppercase; }
  #muru-scan-modal .tracking-wider { letter-spacing:.05em; }
  #muru-scan-modal .leading-snug { line-height:1.375; }
  #muru-scan-modal .cursor-pointer { cursor:pointer; }
  #muru-scan-modal .px-2 { padding-left:8px; padding-right:8px; }
  #muru-scan-modal .px-6 { padding-left:24px; padding-right:24px; }
  #muru-scan-modal .py-1\.5 { padding-top:6px; padding-bottom:6px; }
  #muru-scan-modal .py-2\.5 { padding-top:10px; padding-bottom:10px; }
  #muru-scan-modal .transition-colors { transition:background-color .15s ease, color .15s ease, border-color .15s ease; }
  #muru-scan-modal .transition-all { transition:all .2s ease; }
  #muru-scan-modal .duration-200 { transition-duration:.2s; }
  #muru-scan-modal .hover\:bg-gray-50:hover { background:#f9fafb; }
  #muru-scan-modal .hover\:-translate-y-0\.5:hover { transform:translateY(-2px); }
  #muru-scan-modal #muru-scan-modal-run {
    color:#fff; background:#4f46e5; box-shadow:0 10px 15px -3px rgba(79,70,229,.25), 0 4px 6px -4px rgba(79,70,229,.25);
  }
  #muru-scan-modal #muru-scan-modal-run:hover {
    background:#4338ca; box-shadow:0 20px 25px -5px rgba(67,56,202,.3), 0 8px 10px -6px rgba(67,56,202,.3);
  }
  @media (min-width: 640px) {
    #muru-scan-modal .sm\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  }
</style>

<div id="muruguard-root" class="font-sans text-gray-800 relative">

<?php
/* ── SPPB version warning banner ───────────────────────────────── */
$w = $this->sppbWarning ?? null;
if ($w !== null && $w['safe'] !== true):
    $version = htmlspecialchars($w['version']);
    $major   = (int)($w['major'] ?? 0);
    if ($w['safe'] === false && $major === 5):
        $borderColor = '#dc2626'; $bgColor = '#fef2f2'; $textColor = '#991b1b';
        $icon = '🚨'; $badgeClass = 'bg-red-600';
        $headline = "SP Page Builder {$version} is installed — this major version is vulnerable and has no patch.";
        $detail   = 'SPPB 5.x has its own separate known vulnerabilities. <strong>Update to SPPB 6.8.0+ immediately</strong>, or remove the component if you no longer use it.';
        $btnClass = 'bg-red-600 hover:bg-red-700';
    elseif ($w['safe'] === false):
        $borderColor = '#dc2626'; $bgColor = '#fef2f2'; $textColor = '#991b1b';
        $icon = '🚨'; $badgeClass = 'bg-red-600';
        $headline = "SP Page Builder {$version} is installed — vulnerable to the uploadCustomIcon RCE.";
        $detail   = 'Unauthenticated attackers can upload PHP webshells via Custom Icons in SPPB 6.x &lt; 6.6.2. <strong>Update to 6.8.0 immediately</strong> before doing anything else.';
        $btnClass = 'bg-red-600 hover:bg-red-700';
    else:
        $borderColor = '#d97706'; $bgColor = '#fffbeb'; $textColor = '#78350f';
        $icon = '⚠️'; $badgeClass = 'bg-amber-500';
        $headline = "SP Page Builder is installed but its version could not be determined.";
        $detail   = 'Check manually under <strong>Extensions → Manage → Manage</strong> and confirm it is 6.8.0 or newer.';
        $btnClass = 'bg-amber-500 hover:bg-amber-600';
    endif;
?>
<div class="anim-in flex gap-4 items-start rounded-xl border-l-4 p-4 mb-5 shadow-sm"
     style="background:<?= $bgColor ?>; border-color:<?= $borderColor ?>; color:<?= $textColor ?>">
    <div class="text-3xl flex-shrink-0 mt-0.5"><?= $icon ?></div>
    <div class="flex-1 min-w-0">
        <p class="font-bold text-sm leading-snug mb-1"><?= $headline ?></p>
        <p class="text-xs leading-relaxed opacity-90"><?= $detail ?></p>
        <a href="index.php?option=com_installer&view=update"
           class="inline-flex items-center gap-1.5 mt-3 px-4 py-1.5 rounded-lg text-white text-xs font-semibold shadow <?= $btnClass ?> transition-colors">
            🔧 Go to Extension Manager → Update
        </a>
    </div>
</div>
<?php endif; ?>

<?php
/* ── Update-site health banner ─────────────────────────────────
   Not "an update exists" -- "Joomla can't even find out whether one
   exists." Only rendered when there's an actual problem; see
   getUpdateSiteHealthWarning()'s docblock for why this happens and why
   it's easy for an admin to never notice on their own. */
$uh = $this->updateSiteHealthWarning ?? null;
if ($uh !== null && (!empty($uh['disabled']) || !empty($uh['missing']))):
?>
<div class="anim-in flex gap-4 items-start rounded-xl border-l-4 p-4 mb-5 shadow-sm"
     style="background:#fef2f2; border-color:#dc2626; color:#991b1b">
    <div class="text-3xl flex-shrink-0 mt-0.5">🚨</div>
    <div class="flex-1 min-w-0">
        <p class="font-bold text-sm leading-snug mb-1">Joomla can't check for updates on <?= count($uh['disabled']) + count($uh['missing']) ?> installed extension<?= (count($uh['disabled']) + count($uh['missing'])) === 1 ? '' : 's' ?> -- this is how sites get hacked by a patched vulnerability.</p>
        <p class="text-xs leading-relaxed opacity-90 mb-2">A security fix can be released and your Extensions → Update screen will still show nothing, because the record that tells Joomla <em>where to check</em> is broken -- not because nothing needs updating.</p>
        <?php if (!empty($uh['disabled'])): ?>
        <p class="text-xs leading-relaxed mb-1">
            <strong>Update checking is turned off</strong> for: <?= htmlspecialchars(implode(', ', $uh['disabled'])) ?>.
            Re-enable under Extensions → Manage → <strong>Update Sites</strong>.
        </p>
        <?php endif; ?>
        <?php if (!empty($uh['missing'])): ?>
        <p class="text-xs leading-relaxed mb-1">
            <strong>No update site is registered at all</strong> for: <?= htmlspecialchars(implode(', ', $uh['missing'])) ?> --
            Joomla has no record of where to look, often left over from a manual reinstall or a site migration/restore.
            Re-uploading the extension's latest zip via Extensions → Manage → Install usually restores it.
        </p>
        <?php endif; ?>
        <a href="index.php?option=com_installer&view=updatesites"
           class="inline-flex items-center gap-1.5 mt-3 px-4 py-1.5 rounded-lg text-white text-xs font-semibold shadow bg-red-600 hover:bg-red-700 transition-colors">
            🔧 Go to Update Sites
        </a>
    </div>
</div>
<?php endif; ?>

<?php
/* ── Known-vulnerability banner ────────────────────────────────
   Not "this got hacked" -- "this COULD get hacked": installed
   extension versions cross-referenced against an admin-curated feed
   of published advisories. Independent of whether a scan has run --
   see MuruguardModelScanner::getVulnerableExtensions()'s docblock.
   Only rendered when at least one CRITICAL/HIGH match exists; MEDIUM/
   LOW matches still appear in the Vulnerable Extensions tab below,
   just without demanding attention at the top of the page. */
$vulns = $this->vulnerableExtensions ?? [];
$criticalVulns = array_filter($vulns, fn($v) => in_array($v['severity'], ['CRITICAL', 'HIGH'], true));
if (!empty($criticalVulns)):
?>
<div class="anim-in flex gap-4 items-start rounded-xl border-l-4 p-4 mb-5 shadow-sm"
     style="background:#fef2f2; border-color:#dc2626; color:#991b1b">
    <div class="text-3xl flex-shrink-0 mt-0.5">🛑</div>
    <div class="flex-1 min-w-0">
        <p class="font-bold text-sm leading-snug mb-1">
            <?= count($criticalVulns) ?> known vulnerabilit<?= count($criticalVulns) === 1 ? 'y' : 'ies' ?> found in installed extension<?= count($criticalVulns) === 1 ? '' : 's' ?> -- not a compromise yet, but a published way in.
        </p>
        <ul class="text-xs leading-relaxed space-y-0.5 mb-2">
            <?php foreach ($criticalVulns as $v): ?>
                <li>
                    <strong><?= htmlspecialchars($v['extensionName']) ?></strong> (<?= htmlspecialchars($v['installedVersion']) ?>) --
                    <?= htmlspecialchars($v['title']) ?><?php if (!empty($v['fixedVersion'])): ?>, fixed in <?= htmlspecialchars($v['fixedVersion']) ?><?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <p class="text-xs opacity-90">Run a scan to see the full Vulnerable Extensions tab, including any lower-severity matches.</p>
    </div>
</div>
<?php endif; ?>

<!-- ── Loading overlay (re-parented to <body> at runtime, see script) ── -->
<div id="muruguard-overlay">
    <div class="muruguard-overlay-card">
        <div class="muruguard-overlay-icon-wrap">
            <div class="muruguard-overlay-spinner"></div>
            <span class="muruguard-overlay-icon">🛡️</span>
        </div>
        <h3 class="muruguard-overlay-title"><?= Text::_('COM_MURUGUARD_OVERLAY_TITLE') ?></h3>
        <p id="muruguard-loading-status" class="muruguard-overlay-status"><?= Text::_('COM_MURUGUARD_OVERLAY_STARTING') ?></p>
        <div class="muruguard-overlay-track"><div class="muruguard-overlay-bar"></div></div>
        <p class="muruguard-overlay-note"><?= Text::_('COM_MURUGUARD_OVERLAY_NOTE') ?></p>
    </div>
</div>


<!-- ── Code-analysis modal (re-parented to <body> at runtime, see script) ── -->
<div id="muru-modal">
    <div id="muru-modal-backdrop"></div>
    <div id="muru-modal-dialog" role="dialog" aria-modal="true">
        <div id="muru-modal-header">
            <div>
                <div id="muru-modal-badge"></div>
                <code id="muru-modal-path"></code>
            </div>
            <button type="button" id="muru-modal-close" aria-label="<?= Text::_('COM_MURUGUARD_MODAL_CLOSE') ?>">✕</button>
        </div>
        <div id="muru-modal-body"></div>
        <div id="muru-modal-ai-section" class="mx-5 mb-5 rounded-xl border border-gray-300 bg-gray-50 overflow-hidden">
            <?php if ($this->aiProActive): ?>
                <div class="flex items-center gap-3 px-4 py-3">
                    <span class="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center text-sm shrink-0" aria-hidden="true">🤖</span>
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-semibold text-black"><?= Text::_('COM_MURUGUARD_AI_REVIEW_HEADING') ?></p>
                        <p class="text-[11px] text-gray-700 leading-snug"><?= Text::_('COM_MURUGUARD_AI_REVIEW_DISCLAIMER') ?></p>
                    </div>
                    <button type="button" id="muru-modal-ai-btn" class="shrink-0 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold text-black bg-white hover:bg-gray-100 border border-gray-400 transition-colors disabled:opacity-50 whitespace-nowrap">
                        <?= Text::_('COM_MURUGUARD_AI_REVIEW_BTN') ?>
                    </button>
                </div>
                <div id="muru-modal-ai-result-wrap" class="hidden px-4 pb-4">
                    <div id="muru-modal-ai-result" class="bg-white border border-gray-300 rounded-lg p-3 text-sm text-black leading-relaxed whitespace-pre-wrap"></div>
                </div>
            <?php else: ?>
                <div class="flex items-center gap-3 px-4 py-3">
                    <span class="w-8 h-8 rounded-full bg-gray-300 text-black flex items-center justify-center text-sm shrink-0" aria-hidden="true">🤖</span>
                    <p class="flex-1 min-w-0 text-sm font-medium text-black"><?= Text::_('COM_MURUGUARD_AI_REVIEW_UPGRADE') ?></p>
                    <span class="shrink-0 text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded-full">PRO</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ── Bulk AI Check results (multi-select toolbar's "Check via AI") ── -->
<div id="muru-bulk-ai-modal" class="hidden fixed inset-0 z-[9999] flex items-center justify-center p-4" style="background: rgba(0,0,0,0.5);">
    <div class="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] flex flex-col overflow-hidden">
        <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100 shrink-0">
            <h3 class="font-bold text-gray-800 flex items-center gap-2">🤖 <?= Text::_('COM_MURUGUARD_BULK_AI_RESULTS_TITLE') ?></h3>
            <button type="button" id="muru-bulk-ai-modal-close" class="text-gray-400 hover:text-gray-700 text-xl leading-none" aria-label="<?= Text::_('COM_MURUGUARD_MODAL_CLOSE') ?>">✕</button>
        </div>
        <div id="muru-bulk-ai-modal-status" class="px-5 py-2 text-xs text-gray-500 border-b border-gray-100 shrink-0"></div>
        <div id="muru-bulk-ai-modal-body" class="flex-1 overflow-y-auto px-5 py-4 space-y-3"></div>
    </div>
</div>

<!-- ══════════════════════════════════════════════════════════════
     SETTINGS PANEL -- hidden by default, toggled by #muru-settings-btn.
     Lives outside #muru-main-content (see below) so it works regardless
     of scan state, and is never shown at the same time as the results/
     scan-gate content.
     ══════════════════════════════════════════════════════════════ -->
<div id="muru-settings-panel" class="hidden">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-lg font-bold text-gray-800 flex items-center gap-2">⚙️ <?= Text::_('COM_MURUGUARD_SETTINGS_HEADING') ?></h2>
        <button type="button" id="muru-settings-back" class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors shadow-sm">
            ← <?= Text::_('COM_MURUGUARD_SETTINGS_BACK') ?>
        </button>
    </div>

    <div class="flex flex-wrap gap-1 p-1.5 bg-gray-50 border border-gray-200 rounded-xl mb-5 w-fit">
        <button type="button" class="muru-settings-tab active flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors" data-settings-tab="general">
            🛠️ <?= Text::_('COM_MURUGUARD_SETTINGS_TAB_GENERAL') ?>
        </button>
        <button type="button" class="muru-settings-tab flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors" data-settings-tab="site_protection">
            🛡️ <?= Text::_('COM_MURUGUARD_SETTINGS_TAB_SITE_PROTECTION') ?>
            <?php if ($this->shieldEnabled || $this->fimBaselineStatus['exists']): ?>
                <span class="inline-flex items-center justify-center w-2 h-2 rounded-full bg-emerald-500"></span>
            <?php endif; ?>
            <?php if (!empty($this->ipList)): ?>
                <span class="inline-flex items-center justify-center min-w-4 h-4 px-1 bg-gray-200 text-gray-600 text-[10px] font-bold rounded-full"><?= count($this->ipList) ?></span>
            <?php endif; ?>
        </button>
        <button type="button" class="muru-settings-tab flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors" data-settings-tab="license">
            🔑 <?= Text::_('COM_MURUGUARD_LICENSE_HEADING') ?>
            <?php if ($this->licenseStatus['status'] === 'active'): ?>
                <span class="inline-flex items-center justify-center w-2 h-2 rounded-full bg-emerald-500"></span>
            <?php elseif ($this->licenseKey !== ''): ?>
                <span class="inline-flex items-center justify-center w-2 h-2 rounded-full bg-amber-500"></span>
            <?php endif; ?>
        </button>
        <button type="button" class="muru-settings-tab flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors" data-settings-tab="automation">
            🤖 <?= Text::_('COM_MURUGUARD_SETTINGS_TAB_AUTOMATION') ?>
        </button>
        <button type="button" class="muru-settings-tab flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors" data-settings-tab="backup">
            🕐 <?= Text::_('COM_MURUGUARD_SETTINGS_TAB_BACKUP') ?>
        </button>
        <button type="button" class="muru-settings-tab flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors" data-settings-tab="guide">
            📖 <?= Text::_('COM_MURUGUARD_SETTINGS_TAB_GUIDE') ?>
        </button>
    </div>

    <div class="muru-settings-tabpanel hidden" data-settings-panel="automation">
        <?php if (!$this->canAdmin): ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 flex items-center gap-2 text-xs text-gray-500">
            <span class="text-base">🔒</span>
            <span><?= Text::_('COM_MURUGUARD_LICENSE_LOCKED_EDIT') ?></span>
        </div>
        <?php elseif (!$this->aiProActive): ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-10 text-center">
            <div class="text-4xl mb-3">🔒</div>
            <h3 class="text-base font-bold text-gray-800 mb-2"><?= Text::_('COM_MURUGUARD_AI_AUTOMATION_LOCKED_TITLE') ?></h3>
            <p class="text-sm text-gray-500 max-w-md mx-auto mb-5"><?= Text::_('COM_MURUGUARD_AI_AUTOMATION_LOCKED_DESC') ?></p>
            <a href="<?= htmlspecialchars(\MuruguardHelper::DASHBOARD_LOGIN_URL) ?>" target="_blank" rel="noopener"
               class="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                ⭐ <?= Text::_('COM_MURUGUARD_AI_UPGRADE_BTN') ?>
            </a>
        </div>
        <?php else: ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1">🤖 <?= Text::_('COM_MURUGUARD_AI_SETTINGS_HEADING') ?></h3>
            <p class="text-xs text-gray-500 mb-4 max-w-xl"><?= Text::_('COM_MURUGUARD_AI_SETTINGS_DESC') ?></p>

            <div id="muru-ai-providers-list" class="space-y-4">
                <p class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_AI_PROVIDER_TESTING_MSG') ?></p>
            </div>
        </div>

        <details class="muru-settings-collapse">
            <summary>
                <div>
                    <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2"><span class="text-lg leading-none">📋</span> <?= Text::_('COM_MURUGUARD_AI_SKILL_HEADING') ?></h3>
                    <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_AI_SKILL_DESC') ?></p>
                    <p class="muru-settings-collapse-hint" data-expand-text="<?= Text::_('COM_MURUGUARD_COLLAPSE_HINT') ?>" data-collapse-text="<?= Text::_('COM_MURUGUARD_COLLAPSE_HINT_COLLAPSE') ?>"><?= Text::_('COM_MURUGUARD_COLLAPSE_HINT') ?></p>
                </div>
                <span class="muru-settings-collapse-chevron" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 6 15 12 9 18"></polyline></svg></span>
            </summary>
            <div class="muru-settings-collapse-body">
            <textarea id="muru-ai-skill-content" rows="10" placeholder="<?= Text::_('COM_MURUGUARD_AI_SKILL_PLACEHOLDER') ?>"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 mb-3" style="resize:vertical;"></textarea>
            <div class="flex items-center gap-2">
                <label class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm cursor-pointer">
                    📁 <?= Text::_('COM_MURUGUARD_AI_SKILL_UPLOAD_BTN') ?>
                    <input type="file" id="muru-ai-skill-file" accept=".md,.txt" class="hidden">
                </label>
                <button type="button" id="muru-ai-skill-save" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-colors">
                    💾 <?= Text::_('COM_MURUGUARD_AI_PROVIDER_SAVE_BTN') ?>
                </button>
                <span id="muru-ai-skill-status" class="text-xs"></span>
            </div>
            </div>
        </details>

        <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.saveprofeatures') ?>" method="post">
            <?= HTMLHelper::_('form.token') ?>

            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
                <div class="flex items-start justify-between gap-4">
                    <div>
                        <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2">🚩 <?= Text::_('COM_MURUGUARD_FLEET_HEADING') ?></h3>
                        <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_FLEET_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0" title="<?= $this->fleetReportingEnabled ? Text::_('COM_MURUGUARD_STATUS_ENABLED') : Text::_('COM_MURUGUARD_STATUS_DISABLED') ?>">
                        <input type="checkbox" name="fleet_reporting_enabled" value="1" <?= $this->fleetReportingEnabled ? 'checked' : '' ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
            </div>

            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
                <div class="flex items-start justify-between gap-4">
                    <div class="min-w-0">
                        <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2">
                            🤖 <?= Text::_('COM_MURUGUARD_AUTOPILOT_HEADING') ?>
                            <span class="inline-flex items-center justify-center w-4 h-4 rounded-full bg-gray-200 text-gray-600 text-[10px] font-bold cursor-help flex-shrink-0"
                                  title="<?= Text::_('COM_MURUGUARD_AUTOPILOT_TOOLTIP') ?>">i</span>
                        </h3>
                        <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_AUTOPILOT_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0" title="<?= $this->autopilotEnabled ? Text::_('COM_MURUGUARD_STATUS_ENABLED') : Text::_('COM_MURUGUARD_STATUS_DISABLED') ?>">
                        <input type="checkbox" name="autopilot_enabled" value="1" <?= $this->autopilotEnabled ? 'checked' : '' ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
                <?php if ($this->autopilotEnabled): ?>
                <p class="text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2 mt-3 flex items-start gap-1.5">
                    ⚠️ <span><?= Text::_('COM_MURUGUARD_AUTOPILOT_ACTIVE_NOTE') ?></span>
                </p>
                <?php endif; ?>
            </div>

            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
                <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1">🔔 <?= Text::_('COM_MURUGUARD_ALERTS_HEADING') ?></h3>
                <p class="text-xs text-gray-500 mb-4 max-w-xl"><?= Text::_('COM_MURUGUARD_ALERTS_DESC') ?></p>

                <div class="space-y-4">
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex items-start justify-between gap-4 mb-3">
                            <h4 class="text-xs font-bold text-gray-700 flex items-center gap-1.5">💬 Slack</h4>
                            <label class="muru-switch flex-shrink-0">
                                <input type="checkbox" name="alert_slack_enabled" value="1" <?= $this->alertSlackEnabled ? 'checked' : '' ?>>
                                <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                            </label>
                        </div>
                        <label class="block text-[11px] font-bold text-gray-500 mb-1" for="muru-alert-slack-webhook"><?= Text::_('COM_MURUGUARD_ALERT_WEBHOOK_URL_LABEL') ?></label>
                        <div class="flex items-center gap-2">
                            <input type="text" id="muru-alert-slack-webhook" name="alert_slack_webhook" value="<?= htmlspecialchars($this->alertSlackWebhook) ?>"
                                   placeholder="https://hooks.slack.com/services/..."
                                   class="flex-1 min-w-0 px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                            <button type="button" class="muru-test-alert-btn flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm" data-channel="slack">
                                <?= Text::_('COM_MURUGUARD_ALERT_TEST_BTN') ?>
                            </button>
                        </div>
                        <span class="muru-test-alert-status text-xs"></span>
                    </div>

                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex items-start justify-between gap-4 mb-3">
                            <h4 class="text-xs font-bold text-gray-700 flex items-center gap-1.5">🎮 Discord</h4>
                            <label class="muru-switch flex-shrink-0">
                                <input type="checkbox" name="alert_discord_enabled" value="1" <?= $this->alertDiscordEnabled ? 'checked' : '' ?>>
                                <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                            </label>
                        </div>
                        <label class="block text-[11px] font-bold text-gray-500 mb-1" for="muru-alert-discord-webhook"><?= Text::_('COM_MURUGUARD_ALERT_WEBHOOK_URL_LABEL') ?></label>
                        <div class="flex items-center gap-2">
                            <input type="text" id="muru-alert-discord-webhook" name="alert_discord_webhook" value="<?= htmlspecialchars($this->alertDiscordWebhook) ?>"
                                   placeholder="https://discord.com/api/webhooks/..."
                                   class="flex-1 min-w-0 px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                            <button type="button" class="muru-test-alert-btn flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm" data-channel="discord">
                                <?= Text::_('COM_MURUGUARD_ALERT_TEST_BTN') ?>
                            </button>
                        </div>
                        <span class="muru-test-alert-status text-xs"></span>
                    </div>

                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex items-start justify-between gap-4 mb-3">
                            <h4 class="text-xs font-bold text-gray-700 flex items-center gap-1.5">✈️ Telegram</h4>
                            <label class="muru-switch flex-shrink-0">
                                <input type="checkbox" name="alert_telegram_enabled" value="1" <?= $this->alertTelegramEnabled ? 'checked' : '' ?>>
                                <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                            </label>
                        </div>
                        <div class="grid sm:grid-cols-2 gap-3 mb-2">
                            <div>
                                <label class="block text-[11px] font-bold text-gray-500 mb-1" for="muru-alert-telegram-token"><?= Text::_('COM_MURUGUARD_ALERT_TELEGRAM_TOKEN_LABEL') ?></label>
                                <input type="text" id="muru-alert-telegram-token" name="alert_telegram_bot_token" value="<?= htmlspecialchars($this->alertTelegramBotToken) ?>"
                                       placeholder="123456:ABC-DEF..."
                                       class="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-gray-500 mb-1" for="muru-alert-telegram-chatid"><?= Text::_('COM_MURUGUARD_ALERT_TELEGRAM_CHATID_LABEL') ?></label>
                                <input type="text" id="muru-alert-telegram-chatid" name="alert_telegram_chat_id" value="<?= htmlspecialchars($this->alertTelegramChatId) ?>"
                                       placeholder="-1001234567890"
                                       class="w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                            </div>
                        </div>
                        <button type="button" class="muru-test-alert-btn px-3 py-1.5 rounded-lg text-xs font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm" data-channel="telegram">
                            <?= Text::_('COM_MURUGUARD_ALERT_TEST_BTN') ?>
                        </button>
                        <span class="muru-test-alert-status text-xs"></span>
                    </div>
                </div>
            </div>

            <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                💾 <?= Text::_('COM_MURUGUARD_SAVE_SETTINGS_BTN') ?>
            </button>
        </form>
        <?php endif; ?>
    </div>

    <!-- IP Access List -- pulled out of Site Protection into its own tab:
         a manual allow/block list is general access-control configuration,
         not part of the active pattern/bruteforce/country blocking that
         tab now focuses on exclusively. -->
    <div class="muru-settings-tabpanel active" data-settings-panel="general">
        <?php if (!$this->canAdmin): ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-3">⏰ <?= Text::_('COM_MURUGUARD_SCHEDULED_TITLE') ?></h3>
            <div class="flex items-center gap-2 text-xs text-gray-500 mb-4">
                <span class="text-base">🔒</span>
                <span><?= Text::_('COM_MURUGUARD_SCHEDULED_READONLY') ?></span>
            </div>
            <div class="text-xs text-gray-600 space-y-1.5">
                <div><?= Text::_('COM_MURUGUARD_STATUS_LABEL') ?>: <span class="font-semibold text-gray-800"><?= $this->cronEnabled ? Text::_('COM_MURUGUARD_STATUS_ENABLED') : Text::_('COM_MURUGUARD_STATUS_DISABLED') ?></span></div>
                <div><?= Text::_('COM_MURUGUARD_ALERT_EMAIL_STATUS_LABEL') ?>: <span class="font-semibold text-gray-800"><?= $this->alertEmail !== '' ? htmlspecialchars($this->alertEmail) : Text::_('COM_MURUGUARD_NOT_SET') ?></span></div>
                <?php if ($this->lastScheduledRun): ?>
                    <div><?= Text::_('COM_MURUGUARD_LAST_RUN_LABEL') ?>: <span class="font-semibold text-gray-800"><?= date('Y-m-d H:i:s', $this->lastScheduledRun) ?></span></div>
                <?php else: ?>
                    <div><?= Text::_('COM_MURUGUARD_LAST_RUN_LABEL') ?>: <span class="font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_NEVER') ?></span></div>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
        <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.savedisplaysettings') ?>" method="post" class="mb-5">
            <?= HTMLHelper::_('form.token') ?>
            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6">
                <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1">📄 <?= Text::_('COM_MURUGUARD_DISPLAY_TITLE') ?></h3>
                <p class="text-xs text-gray-500 mb-3 max-w-xl"><?= Text::_('COM_MURUGUARD_DISPLAY_DESC') ?></p>
                <div class="flex items-end gap-3">
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-items-per-page"><?= Text::_('COM_MURUGUARD_ITEMS_PER_PAGE_LABEL') ?></label>
                        <select id="muru-items-per-page" name="items_per_page" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                            <?php foreach ([25, 50, 100, 250, 500] as $opt): ?>
                            <option value="<?= $opt ?>" <?= $this->itemsPerPage === $opt ? 'selected' : '' ?>><?= $opt ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                        💾 <?= Text::_('COM_MURUGUARD_LICENSE_SAVE_BTN') ?>
                    </button>
                </div>
            </div>
        </form>

        <!-- Free-tier "Ask AI" -- Gemini only, bring-your-own key. Lives
             here in General (not the Pro-gated Automation tab) since this
             is the one AI capability every edition actually has access
             to. -->
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1">✨ <?= Text::_('COM_MURUGUARD_GEMINI_TITLE') ?></h3>
            <p class="text-xs text-gray-500 mb-3 max-w-xl"><?= Text::_('COM_MURUGUARD_GEMINI_DESC') ?></p>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.savegeminikey') ?>" method="post" class="flex flex-wrap items-center gap-2">
                <?= HTMLHelper::_('form.token') ?>
                <input type="text" name="gemini_api_key" placeholder="<?= $this->geminiApiKeyMasked !== '' ? htmlspecialchars($this->geminiApiKeyMasked) : Text::_('COM_MURUGUARD_GEMINI_PLACEHOLDER') ?>"
                       class="flex-1 min-w-[220px] px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                    💾 <?= Text::_('COM_MURUGUARD_SAVE_SETTINGS_BTN') ?>
                </button>
            </form>
            <?php if ($this->geminiApiKeyMasked !== ''): ?>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.cleargeminikey') ?>" method="post" class="mt-2"
                  onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_GEMINI_CLEAR_CONFIRM') ?>');">
                <?= HTMLHelper::_('form.token') ?>
                <button type="submit" class="text-xs text-red-600 hover:text-red-700 font-semibold"><?= Text::_('COM_MURUGUARD_GEMINI_CLEAR_BTN') ?></button>
            </form>
            <?php endif; ?>
        </div>

        <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.savesettings') ?>" method="post">
            <?= HTMLHelper::_('form.token') ?>

            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
                <div class="flex items-start justify-between gap-4 mb-1">
                    <div>
                        <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2">⏰ <?= Text::_('COM_MURUGUARD_SCHEDULED_TITLE') ?></h3>
                        <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_SCHEDULED_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0" title="<?= $this->cronEnabled ? Text::_('COM_MURUGUARD_STATUS_ENABLED') : Text::_('COM_MURUGUARD_STATUS_DISABLED') ?>">
                        <input type="checkbox" id="muru-cron-enabled" name="cron_enabled" value="1" <?= $this->cronEnabled ? 'checked' : '' ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <?php if ($this->lastScheduledRun): ?>
                    <div class="text-xs text-gray-500 mb-4">
                        🕐 <?= Text::_('COM_MURUGUARD_LAST_RUN_LABEL') ?>: <span class="font-semibold text-gray-700"><?= date('Y-m-d H:i:s', $this->lastScheduledRun) ?></span>
                    </div>
                <?php else: ?>
                    <div class="text-xs text-gray-400 mb-4"><?= Text::_('COM_MURUGUARD_SCHEDULED_NEVER_RUN') ?></div>
                <?php endif; ?>

                <div class="grid sm:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-cron-token"><?= Text::_('COM_MURUGUARD_TOKEN_LABEL') ?></label>
                        <div class="flex gap-2">
                            <input type="text" id="muru-cron-token" name="cron_token" value="<?= htmlspecialchars($this->cronToken) ?>"
                                   placeholder="<?= Text::_('COM_MURUGUARD_TOKEN_PLACEHOLDER') ?>"
                                   class="flex-1 min-w-0 px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                            <button type="button" id="muru-cron-generate" class="flex-shrink-0 px-3 py-2 border border-gray-300 rounded-lg text-xs font-semibold text-gray-600 bg-gray-50 hover:bg-gray-100 transition-colors shadow-sm">🎲 <?= Text::_('COM_MURUGUARD_GENERATE_BTN') ?></button>
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-alert-email"><?= Text::_('COM_MURUGUARD_ALERT_EMAIL_FIELD_LABEL') ?></label>
                        <input type="email" id="muru-alert-email" name="alert_email" value="<?= htmlspecialchars($this->alertEmail) ?>"
                               placeholder="<?= Text::_('COM_MURUGUARD_EMAIL_PLACEHOLDER') ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                    </div>
                </div>

                <?php
                // Routed through com_ajax (plg_muruguardshield's
                // onAjaxMuruguardshield() bridge), NOT a direct
                // option=com_muruguard hit -- Joomla core's
                // AdministratorApplication::findOption() only lets a
                // GUEST request reach option=com_login or option=com_ajax,
                // silently redirecting anything else (including
                // com_muruguard itself) to the login page before a real,
                // unauthenticated external cron caller ever reaches
                // scheduledcheck()'s own token check. See
                // onAjaxMuruguardshield()'s own docblock for the full
                // explanation.
                $webcronUrl = Uri::root() . 'administrator/index.php?option=com_ajax&plugin=muruguardshield&group=system&format=raw&token=' . $this->cronToken;
                ?>
                <div class="mb-5">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5"><?= Text::_('COM_MURUGUARD_WEBCRON_URL_LABEL') ?> <span class="font-normal text-gray-400"><?= Text::_('COM_MURUGUARD_WEBCRON_URL_HINT') ?></span></label>
                    <div class="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2">
                        <code id="muru-webcron-url" class="flex-1 min-w-0 text-xs text-gray-600 break-all"><?= htmlspecialchars($webcronUrl) ?></code>
                        <button type="button" class="muru-copy-btn flex-shrink-0 w-7 h-7 inline-flex items-center justify-center rounded-lg text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                                data-copy="<?= htmlspecialchars($webcronUrl) ?>" title="<?= Text::_('COM_MURUGUARD_COPY_URL') ?>" aria-label="<?= Text::_('COM_MURUGUARD_COPY_URL') ?>">
                            <span class="muru-copy-icon">📋</span>
                        </button>
                    </div>
                </div>

                <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                    💾 <?= Text::_('COM_MURUGUARD_SAVE_SETTINGS_BTN') ?>
                </button>
            </div>
        </form>
        <?php endif; ?>

        <!-- False Positives -->
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <div class="mb-4">
                <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2">✅ <?= Text::_('COM_MURUGUARD_FP_TITLE') ?></h3>
                <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_FP_DESC') ?></p>
            </div>

            <?php if (empty($this->falsePositives)): ?>
                <div class="flex items-center gap-3 text-gray-500 bg-gray-50 rounded-xl p-[10px] text-xs">
                    <span class="text-lg">ℹ️</span>
                    <span><?= Text::_('COM_MURUGUARD_FP_EMPTY') ?></span>
                </div>
            <?php else: ?>
                <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="bg-gray-50 border-b border-gray-100">
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_FP_COL_CATEGORY') ?></th>
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_FP_COL_IDENTIFIER') ?></th>
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_FP_COL_ADDED') ?></th>
                                <th class="w-10 px-4 py-2.5"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                        <?php foreach ($this->falsePositives as $entry): ?>
                            <tr class="hover:bg-gray-50/60 transition-colors">
                                <td class="px-4 py-2.5 text-xs text-gray-600"><?= htmlspecialchars($entry['category'] ?? '') ?></td>
                                <td class="px-4 py-2.5 font-mono text-xs text-gray-700 break-all"><?= htmlspecialchars($entry['identifier'] ?? '') ?></td>
                                <td class="px-4 py-2.5 text-xs text-gray-400"><?= isset($entry['addedAt']) ? date('Y-m-d H:i', (int) $entry['addedAt']) : '' ?></td>
                                <td class="px-4 py-2.5">
                                    <?php if ($this->canEdit): ?>
                                    <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.unmarkfalsepositive') ?>" method="post"
                                          onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_FP_REMOVE_CONFIRM') ?>');">
                                        <?= HTMLHelper::_('form.token') ?>
                                        <input type="hidden" name="fp_id" value="<?= htmlspecialchars($entry['id'] ?? '') ?>">
                                        <button type="submit" class="text-gray-400 hover:text-indigo-600 transition-colors" title="<?= Text::_('COM_MURUGUARD_FP_REMOVE_BTN') ?>">↩️</button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="muru-settings-tabpanel hidden" data-settings-panel="backup">
        <?php if (!$this->canAdmin): ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 flex items-center gap-2 text-xs text-gray-500">
            <span class="text-base">🔒</span>
            <span><?= Text::_('COM_MURUGUARD_LICENSE_LOCKED_EDIT') ?></span>
        </div>
        <?php elseif (!$this->aiProActive): ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-10 text-center">
            <div class="text-4xl mb-3">🔒</div>
            <h3 class="text-base font-bold text-gray-800 mb-2"><?= Text::_('COM_MURUGUARD_TM_LOCKED_TITLE') ?></h3>
            <p class="text-sm text-gray-500 max-w-md mx-auto mb-5"><?= Text::_('COM_MURUGUARD_TM_LOCKED_DESC') ?></p>
            <a href="<?= htmlspecialchars(\MuruguardHelper::DASHBOARD_LOGIN_URL) ?>" target="_blank" rel="noopener"
               class="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                ⭐ <?= Text::_('COM_MURUGUARD_AI_UPGRADE_BTN') ?>
            </a>
        </div>
        <?php else: ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1"><span class="text-lg leading-none">🕐</span> <?= Text::_('COM_MURUGUARD_TM_HEADING') ?></h3>
            <p class="text-xs text-gray-500 max-w-xl"><?= Text::_('COM_MURUGUARD_TM_INTRO_DESC') ?></p>
        </div>

        <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.savetimemachinesettings') ?>" method="post" class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <?= HTMLHelper::_('form.token') ?>
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1"><span class="text-lg leading-none">🗓️</span> <?= Text::_('COM_MURUGUARD_TM_SETTINGS_HEADING') ?></h3>
            <p class="text-xs text-gray-500 mb-4 max-w-xl"><?= Text::_('COM_MURUGUARD_TM_SETTINGS_DESC') ?></p>
            <div class="flex flex-wrap items-end gap-4 mb-2">
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1"><?= Text::_('COM_MURUGUARD_TM_RETENTION_DAYS_LABEL') ?></label>
                    <input type="number" name="timemachine_retention_days" min="1" max="365" value="<?= (int) $this->timemachineRetentionDays ?>"
                        class="w-28 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1"><?= Text::_('COM_MURUGUARD_TM_RETENTION_MAX_LABEL') ?></label>
                    <input type="number" name="timemachine_retention_max_snapshots" min="10" max="10000" value="<?= (int) $this->timemachineRetentionMaxSnapshots ?>"
                        class="w-28 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-colors">
                    💾 <?= Text::_('COM_MURUGUARD_LICENSE_SAVE_BTN') ?>
                </button>
            </div>
            <p class="text-[11px] text-gray-400 max-w-xl"><?= Text::_('COM_MURUGUARD_TM_SETTINGS_KEEP_HINT') ?></p>
        </form>

        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1"><span class="text-lg leading-none">📋</span> <?= Text::_('COM_MURUGUARD_TM_MANAGE_HEADING') ?></h3>
            <p class="text-xs text-gray-500 max-w-xl mb-3"><?= Text::_('COM_MURUGUARD_TM_MANAGE_DESC') ?></p>
            <?php if (empty($this->protectedRepairs)): ?>
            <p class="text-gray-400 text-xs px-1 py-1"><?= Text::_('COM_MURUGUARD_AI_AUDIT_EMPTY') ?></p>
            <?php else: ?>
            <div class="text-xs border border-gray-100 rounded-xl overflow-hidden">
                <?php foreach ($this->protectedRepairs as $repair): muru_render_protected_repair_row($repair, $this->timeMachineSnapshots); endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="muru-settings-tabpanel hidden" data-settings-panel="guide">
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <div class="flex items-start justify-between gap-4 mb-4">
                <div>
                    <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2">📖 <?= Text::_('COM_MURUGUARD_SETUP_GUIDE_TITLE') ?></h3>
                    <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_SETUP_GUIDE_DESC') ?></p>
                </div>
                <a href="index.php?option=com_config&view=component&component=com_muruguard"
                   class="flex-shrink-0 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm whitespace-nowrap">
                    🔧 <?= Text::_('COM_MURUGUARD_OPEN_GLOBAL_CONFIG') ?>
                </a>
            </div>

            <div class="text-xs text-gray-600 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 mb-5">
                <?= Text::_('COM_MURUGUARD_GLOBAL_CONFIG_PATH_NOTE') ?>
            </div>

            <div class="space-y-4">
                <div class="border-l-2 border-indigo-200 pl-3">
                    <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_GUIDE_MAXSIZE_TITLE') ?></div>
                    <p class="text-xs text-gray-500 mt-0.5"><?= Text::_('COM_MURUGUARD_GUIDE_MAXSIZE_DESC') ?></p>
                </div>
                <div class="border-l-2 border-indigo-200 pl-3">
                    <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_GUIDE_EXTRAROOT_TITLE') ?></div>
                    <p class="text-xs text-gray-500 mt-0.5"><?= Text::_('COM_MURUGUARD_GUIDE_EXTRAROOT_DESC') ?></p>
                </div>
                <div class="border-l-2 border-indigo-200 pl-3">
                    <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_GUIDE_IGNOREDPATHS_TITLE') ?></div>
                    <p class="text-xs text-gray-500 mt-0.5"><?= Text::_('COM_MURUGUARD_GUIDE_IGNOREDPATHS_DESC') ?></p>
                </div>
                <div class="border-l-2 border-indigo-200 pl-3">
                    <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_GUIDE_SCHEDULED_TITLE') ?></div>
                    <p class="text-xs text-gray-500 mt-0.5"><?= Text::_('COM_MURUGUARD_GUIDE_SCHEDULED_DESC') ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-4">🔐 <?= Text::_('COM_MURUGUARD_GUIDE_ACL_HEADING') ?></h3>
            <div class="space-y-4">
                <div class="border-l-2 border-emerald-200 pl-3">
                    <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_GUIDE_ACL_TITLE') ?></div>
                    <p class="text-xs text-gray-500 mt-0.5"><?= Text::_('COM_MURUGUARD_GUIDE_ACL_DESC') ?></p>
                    <ul class="text-xs text-gray-500 mt-2 space-y-1 list-disc pl-4">
                        <li><strong class="text-gray-700"><?= Text::_('COM_MURUGUARD_GUIDE_ACL_MANAGE_LABEL') ?></strong> (core.manage) — <?= Text::_('COM_MURUGUARD_GUIDE_ACL_MANAGE_DESC') ?></li>
                        <li><strong class="text-gray-700"><?= Text::_('COM_MURUGUARD_GUIDE_ACL_EDIT_LABEL') ?></strong> (core.edit) — <?= Text::_('COM_MURUGUARD_GUIDE_ACL_EDIT_DESC') ?></li>
                        <li><strong class="text-gray-700"><?= Text::_('COM_MURUGUARD_GUIDE_ACL_DELETE_LABEL') ?></strong> (core.delete) — <?= Text::_('COM_MURUGUARD_GUIDE_ACL_DELETE_DESC') ?></li>
                        <li><strong class="text-gray-700"><?= Text::_('COM_MURUGUARD_GUIDE_ACL_ADMIN_LABEL') ?></strong> (core.admin) — <?= Text::_('COM_MURUGUARD_GUIDE_ACL_ADMIN_DESC') ?></li>
                    </ul>
                </div>
                <div class="border-l-2 border-emerald-200 pl-3">
                    <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_GUIDE_LANG_TITLE') ?></div>
                    <p class="text-xs text-gray-500 mt-0.5"><?= Text::_('COM_MURUGUARD_GUIDE_LANG_DESC') ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="muru-settings-tabpanel hidden" data-settings-panel="license">
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-3">🔑 <?= Text::_('COM_MURUGUARD_LICENSE_HEADING') ?></h3>

            <?php
            $licenseStatusLabels = [
                'none'               => ['label' => Text::_('COM_MURUGUARD_LICENSE_STATUS_NONE'),               'color' => 'gray'],
                'active'             => ['label' => Text::_('COM_MURUGUARD_LICENSE_STATUS_ACTIVE'),             'color' => 'green'],
                'expired'            => ['label' => Text::_('COM_MURUGUARD_LICENSE_STATUS_EXPIRED'),            'color' => 'amber'],
                'revoked'            => ['label' => Text::_('COM_MURUGUARD_LICENSE_STATUS_REVOKED'),            'color' => 'red'],
                'not_found'          => ['label' => Text::_('COM_MURUGUARD_LICENSE_STATUS_NOT_FOUND'),          'color' => 'red'],
                'site_limit_reached' => ['label' => Text::_('COM_MURUGUARD_LICENSE_STATUS_SITE_LIMIT_REACHED'), 'color' => 'amber'],
                'unreachable'        => ['label' => Text::_('COM_MURUGUARD_LICENSE_STATUS_UNREACHABLE'),        'color' => 'gray'],
            ];
            $curStatus = $licenseStatusLabels[$this->licenseStatus['status']] ?? $licenseStatusLabels['none'];
            $colorClasses = [
                'green' => 'bg-green-100 text-green-700',
                'amber' => 'bg-amber-100 text-amber-700',
                'red'   => 'bg-red-100 text-red-700',
                'gray'  => 'bg-gray-100 text-gray-500',
            ];
            ?>

            <div class="flex items-center gap-3 mb-4">
                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold <?= $colorClasses[$curStatus['color']] ?>">
                    <?= htmlspecialchars($curStatus['label']) ?>
                </span>
                <?php if ($this->licenseStatus['product'] !== null): ?>
                    <span class="text-xs text-gray-500"><?= htmlspecialchars($this->licenseStatus['product']) ?></span>
                <?php endif; ?>
            </div>

            <?php if ($this->licenseKey !== ''): ?>
            <div class="text-xs text-gray-500 space-y-1 mb-4">
                <div><?= Text::_('COM_MURUGUARD_LICENSE_EXPIRES_LABEL') ?>: <span class="font-semibold text-gray-700"><?= $this->licenseStatus['expiresAt'] !== null ? date('Y-m-d', $this->licenseStatus['expiresAt']) : Text::_('COM_MURUGUARD_LICENSE_LIFETIME') ?></span></div>
                <div><?= Text::_('COM_MURUGUARD_LICENSE_LAST_CHECKED_LABEL') ?>: <span class="font-semibold text-gray-700"><?= $this->licenseStatus['lastChecked'] !== null ? date('Y-m-d H:i:s', $this->licenseStatus['lastChecked']) : Text::_('COM_MURUGUARD_LICENSE_NEVER') ?></span></div>
            </div>
            <?php endif; ?>

            <?php if ($this->canAdmin): ?>
            <?php if ($this->licenseKeyMasked !== ''): ?>
            <p class="text-xs text-gray-500 mb-2">
                <?= Text::_('COM_MURUGUARD_LICENSE_CURRENT_KEY_LABEL') ?>:
                <span class="font-mono text-gray-700"><?= htmlspecialchars($this->licenseKeyMasked) ?></span>
            </p>
            <?php endif; ?>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.savelicense') ?>" method="post" class="flex flex-wrap items-end gap-3 mb-3">
                <?= HTMLHelper::_('form.token') ?>
                <div class="flex-1 min-w-[240px]">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-license-key"><?= Text::_('COM_MURUGUARD_CONFIG_LICENSE_KEY_LABEL') ?></label>
                    <!-- Deliberately never pre-filled with the saved key --
                         see MuruguardHelper::maskLicenseKey() -- so the
                         plaintext value is never echoed into the page.
                         Left blank, this field means "no change"; only a
                         typed value replaces the saved key. -->
                    <input type="text" id="muru-license-key" name="license_key" value="" autocomplete="off"
                           placeholder="<?= $this->licenseKeyMasked !== '' ? Text::_('COM_MURUGUARD_LICENSE_KEY_REPLACE_PLACEHOLDER') : Text::_('COM_MURUGUARD_LICENSE_KEY_PLACEHOLDER') ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                    💾 <?= Text::_('COM_MURUGUARD_LICENSE_SAVE_BTN') ?>
                </button>
            </form>
            <?php if ($this->licenseKey !== ''): ?>
            <div class="flex flex-wrap items-center gap-2">
                <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.rechecklicense') ?>" method="post" style="margin:0">
                    <?= HTMLHelper::_('form.token') ?>
                    <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-gray-300 rounded-lg text-xs font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors shadow-sm">
                        🔄 <?= Text::_('COM_MURUGUARD_LICENSE_RECHECK_BTN') ?>
                    </button>
                </form>
                <?php if ($this->licenseStatus['status'] === 'expired'): ?>
                <a href="<?= htmlspecialchars(\MuruguardHelper::DASHBOARD_LOGIN_URL) ?>" target="_blank" rel="noopener"
                   class="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 transition-colors shadow-sm">
                    ⏰ <?= Text::_('COM_MURUGUARD_LICENSE_RENEW_BTN') ?>
                </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php if ($this->licenseStatus['status'] === 'site_limit_reached'): ?>
            <p class="text-xs text-amber-700 mt-3"><?= Text::_('COM_MURUGUARD_LICENSE_SITE_LIMIT_DETAIL') ?></p>
            <?php endif; ?>
            <?php if ($this->licenseStatus['status'] === 'not_found'): ?>
            <p class="text-xs text-red-700 mt-3"><?= Text::_('COM_MURUGUARD_LICENSE_NOT_FOUND_DETAIL') ?></p>
            <?php endif; ?>
            <?php if ($this->licenseStatus['status'] === 'revoked'): ?>
            <p class="text-xs text-red-700 mt-3"><?= Text::_('COM_MURUGUARD_LICENSE_REVOKED_DETAIL') ?></p>
            <?php endif; ?>
            <?php else: ?>
            <div class="flex items-center gap-2 text-xs text-gray-500">
                <span class="text-base">🔒</span>
                <span><?= Text::_('COM_MURUGUARD_LICENSE_LOCKED_EDIT') ?></span>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="muru-settings-tabpanel hidden" data-settings-panel="site_protection">
        <?php if (!$this->shieldPluginActive): ?>
        <div class="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 mb-5 text-xs text-amber-800">
            <span class="text-base leading-none">⚠️</span>
            <span><?= Text::_('COM_MURUGUARD_SHIELD_PLUGIN_MISSING') ?></span>
        </div>
        <?php endif; ?>

        <?php if (!$this->canAdmin): ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-3">🛡️ <?= Text::_('COM_MURUGUARD_SHIELD_TITLE') ?></h3>
            <div class="flex items-center gap-2 text-xs text-gray-500 mb-4">
                <span class="text-base">🔒</span>
                <span><?= Text::_('COM_MURUGUARD_SCHEDULED_READONLY') ?></span>
            </div>
            <div class="text-xs text-gray-600 space-y-1.5">
                <div><?= Text::_('COM_MURUGUARD_SHIELD_ENABLED_STATUS_LABEL') ?>: <span class="font-semibold text-gray-800"><?= $this->shieldEnabled ? Text::_('COM_MURUGUARD_STATUS_ENABLED') : Text::_('COM_MURUGUARD_STATUS_DISABLED') ?></span></div>
                <div><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_PATTERNS_STATUS_LABEL') ?>: <span class="font-semibold text-gray-800"><?= $this->shieldBlockPatterns ? Text::_('COM_MURUGUARD_STATUS_ENABLED') : Text::_('COM_MURUGUARD_STATUS_DISABLED') ?></span></div>
                <div><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_BRUTEFORCE_STATUS_LABEL') ?>: <span class="font-semibold text-gray-800"><?= $this->shieldBlockBruteForce ? Text::_('COM_MURUGUARD_STATUS_ENABLED') : Text::_('COM_MURUGUARD_STATUS_DISABLED') ?></span></div>
            </div>
        </div>
        <?php else: ?>
        <?php
        // Every toggle below does nothing without plg_system_muruguardshield
        // actually installed and enabled -- the warning banner above said
        // so, but until now the form itself stayed fully interactive and
        // savable anyway, which reads as "this is configured" when it
        // silently isn't. $shieldDisabled disables every input and the
        // Save button; saveshieldsettings() also refuses the save
        // server-side (see the controller) so a direct POST can't bypass
        // this either.
        $shieldDisabled = !$this->shieldPluginActive;
        $shieldDisabledAttr = $shieldDisabled ? 'disabled' : '';
        ?>
        <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.saveshieldsettings') ?>" method="post" class="<?= $shieldDisabled ? 'opacity-60' : '' ?>">
            <?= HTMLHelper::_('form.token') ?>

            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
                <div class="flex items-start justify-between gap-4 mb-4">
                    <div>
                        <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2">🛡️ <?= Text::_('COM_MURUGUARD_SHIELD_TITLE') ?></h3>
                        <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0" title="<?= $this->shieldEnabled ? Text::_('COM_MURUGUARD_STATUS_ENABLED') : Text::_('COM_MURUGUARD_STATUS_DISABLED') ?>">
                        <input type="checkbox" name="shield_enabled" value="1" <?= $this->shieldEnabled ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_PATTERNS_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_PATTERNS_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="shield_block_patterns" value="1" <?= $this->shieldBlockPatterns ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_BRUTEFORCE_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_BRUTEFORCE_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="shield_block_bruteforce" value="1" <?= $this->shieldBlockBruteForce ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <div class="grid sm:grid-cols-2 gap-4 mt-4 pt-4 border-t border-gray-100">
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-shield-threshold"><?= Text::_('COM_MURUGUARD_SHIELD_THRESHOLD_LABEL') ?></label>
                        <input type="number" id="muru-shield-threshold" name="shield_bruteforce_threshold" min="2" max="50" value="<?= (int) $this->shieldThreshold ?>" <?= $shieldDisabledAttr ?>
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 disabled:bg-gray-50 disabled:text-gray-400">
                        <p class="text-xs text-gray-400 mt-1"><?= Text::_('COM_MURUGUARD_SHIELD_THRESHOLD_DESC') ?></p>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-shield-window"><?= Text::_('COM_MURUGUARD_SHIELD_WINDOW_LABEL') ?></label>
                        <input type="number" id="muru-shield-window" name="shield_bruteforce_window" min="1" max="1440" value="<?= (int) $this->shieldWindow ?>" <?= $shieldDisabledAttr ?>
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 disabled:bg-gray-50 disabled:text-gray-400">
                        <p class="text-xs text-gray-400 mt-1"><?= Text::_('COM_MURUGUARD_SHIELD_WINDOW_DESC') ?></p>
                    </div>
                </div>

                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100 mt-4">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_UA_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_UA_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="shield_block_useragents" value="1" <?= $this->shieldBlockUserAgents ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_COUNTRIES_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_COUNTRIES_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="shield_block_countries" value="1" <?= $this->shieldBlockCountries ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
                <div class="pt-3">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-shield-countries"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCKED_COUNTRIES_LABEL') ?></label>
                    <input type="text" id="muru-shield-countries" name="shield_blocked_countries" value="<?= htmlspecialchars($this->shieldBlockedCountries) ?>"
                           placeholder="CN,RU,KP" <?= $shieldDisabledAttr ?>
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 disabled:bg-gray-50 disabled:text-gray-400">
                    <p class="text-xs text-gray-400 mt-1"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCKED_COUNTRIES_DESC') ?></p>
                </div>

                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_REFERRERS_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_REFERRERS_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="shield_block_referrers" value="1" <?= $this->shieldBlockReferrers ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_UPLOAD_EXT_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_UPLOAD_EXT_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="shield_block_upload_extensions" value="1" <?= $this->shieldBlockUploadExts ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_PBL_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_BLOCK_PBL_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="shield_block_pbl" value="1" <?= $this->shieldBlockPbl ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SHIELD_AUTOBLOCK_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_SHIELD_AUTOBLOCK_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="shield_autoblock_repeat_offenders" value="1" <?= $this->shieldAutoblockRepeatOffenders ? 'checked' : '' ?> <?= $shieldDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
                <div class="grid sm:grid-cols-2 gap-4 pb-1">
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-autoblock-threshold"><?= Text::_('COM_MURUGUARD_SHIELD_AUTOBLOCK_THRESHOLD_LABEL') ?></label>
                        <input type="number" id="muru-autoblock-threshold" name="shield_autoblock_threshold" min="2" max="50" value="<?= (int) $this->shieldAutoblockThreshold ?>" <?= $shieldDisabledAttr ?>
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 disabled:bg-gray-50 disabled:text-gray-400">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-autoblock-window"><?= Text::_('COM_MURUGUARD_SHIELD_AUTOBLOCK_WINDOW_LABEL') ?></label>
                        <input type="number" id="muru-autoblock-window" name="shield_autoblock_window" min="5" max="1440" value="<?= (int) $this->shieldAutoblockWindow ?>" <?= $shieldDisabledAttr ?>
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 disabled:bg-gray-50 disabled:text-gray-400">
                    </div>
                </div>

                <?php
                // Independent gate on top of $shieldDisabled -- needs
                // BOTH the plugin installed AND an active Pro license.
                $wafDisabled = $shieldDisabled || !$this->aiProActive;
                $wafDisabledAttr = $wafDisabled ? 'disabled' : '';
                ?>
                <div class="flex items-center justify-between gap-4 py-3 border-t border-gray-100 mt-4">
                    <div>
                        <div class="text-sm font-semibold text-gray-800 flex items-center gap-2">
                            <?= Text::_('COM_MURUGUARD_WAF_LABEL') ?>
                            <?php if (!$this->aiProActive): ?>
                                <span class="inline-flex items-center px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold">PRO</span>
                            <?php endif; ?>
                        </div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_WAF_DESC') ?></p>
                        <?php if (!$this->aiProActive): ?>
                            <a href="<?= htmlspecialchars(\MuruguardHelper::DASHBOARD_LOGIN_URL) ?>" target="_blank" rel="noopener"
                               class="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 mt-1.5">
                                ⭐ <?= Text::_('COM_MURUGUARD_AI_UPGRADE_BTN') ?>
                            </a>
                        <?php endif; ?>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="waf_enabled" value="1" <?= $this->wafEnabled ? 'checked' : '' ?> <?= $wafDisabledAttr ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>

                <button type="submit" <?= $shieldDisabledAttr ?> title="<?= $shieldDisabled ? Text::_('COM_MURUGUARD_SHIELD_PLUGIN_MISSING') : '' ?>"
                        class="inline-flex items-center gap-1.5 px-5 py-2 mt-5 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-indigo-600">
                    💾 <?= Text::_('COM_MURUGUARD_SAVE_SETTINGS_BTN') ?>
                </button>
            </div>
        </form>

        <!-- Test a request -- previews what the checks above WOULD do
             with a given URL/IP/User-Agent/Referer, without any of it
             being real traffic: no attack-log entry, no block, no stored
             state touched. Independent of every toggle's own on/off
             state -- lets an admin see what a check WOULD flag before
             deciding whether to turn its blocking switch on at all. -->
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1">🧪 <?= Text::_('COM_MURUGUARD_TEST_REQUEST_TITLE') ?></h3>
            <p class="text-xs text-gray-500 mb-4 max-w-xl"><?= Text::_('COM_MURUGUARD_TEST_REQUEST_DESC') ?></p>

            <div class="grid sm:grid-cols-2 gap-4">
                <div class="sm:col-span-2">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-test-url"><?= Text::_('COM_MURUGUARD_TEST_REQUEST_URL_LABEL') ?></label>
                    <input type="text" id="muru-test-url" placeholder="/index.php?option=com_users&task=user.save"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-test-ip"><?= Text::_('COM_MURUGUARD_TEST_REQUEST_IP_LABEL') ?></label>
                    <input type="text" id="muru-test-ip" placeholder="203.0.113.7"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                    <p class="text-[11px] text-gray-400 mt-1"><?= Text::_('COM_MURUGUARD_TEST_REQUEST_IP_HINT') ?></p>
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-test-ua"><?= Text::_('COM_MURUGUARD_TEST_REQUEST_UA_LABEL') ?></label>
                    <input type="text" id="muru-test-ua" placeholder="sqlmap/1.7"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <div class="sm:col-span-2">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-test-referrer"><?= Text::_('COM_MURUGUARD_TEST_REQUEST_REFERRER_LABEL') ?></label>
                    <input type="text" id="muru-test-referrer" placeholder="https://some-spam-domain.example/"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
            </div>

            <button type="button" id="muru-test-request-btn"
                    class="inline-flex items-center gap-1.5 px-5 py-2 mt-4 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50">
                🧪 <?= Text::_('COM_MURUGUARD_TEST_REQUEST_BTN') ?>
            </button>

            <div id="muru-test-request-results" class="mt-4 space-y-2"></div>
        </div>

        <!-- Small, independent hardening toggles + a one-shot maintenance
             action -- kept in their own compact card rather than folded
             into the Shield form above since neither depends on
             plg_system_muruguardshield being installed at all. -->
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-4">🧹 <?= Text::_('COM_MURUGUARD_MISC_HARDENING_TITLE') ?></h3>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.savemischardening') ?>" method="post">
                <?= HTMLHelper::_('form.token') ?>
                <div class="flex items-center justify-between gap-4 py-2">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_REMOVE_GENERATOR_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_REMOVE_GENERATOR_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="harden_remove_generator" value="1" <?= $this->hardenRemoveGenerator ? 'checked' : '' ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
                <div class="flex items-center justify-between gap-4 py-2 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_TMP_CLEANUP_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_TMP_CLEANUP_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="harden_tmp_cleanup_enabled" value="1" <?= $this->hardenTmpCleanupEnabled ? 'checked' : '' ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
                <div class="flex items-center justify-between gap-4 py-2 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_HOMEPAGE_WATCH_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_HOMEPAGE_WATCH_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="homepage_watch_enabled" value="1" <?= $this->homepageWatchEnabled ? 'checked' : '' ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
                <div class="flex items-center justify-between gap-4 py-2 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_ADMIN_LOCKDOWN_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_ADMIN_LOCKDOWN_DESC') ?></p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="harden_lock_admin_actions" value="1" <?= $this->hardenLockAdminActions ? 'checked' : '' ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
                <div class="flex items-center justify-between gap-4 py-2 border-t border-gray-100">
                    <div>
                        <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_PROTECTED_USERS_LABEL') ?></div>
                        <p class="text-xs text-gray-500 mt-0.5 max-w-xl"><?= Text::_('COM_MURUGUARD_PROTECTED_USERS_DESC') ?></p>
                        <p class="text-xs text-gray-400 mt-1">
                            <?= $this->protectedUsersStatus['hasSnapshot']
                                ? Text::sprintf('COM_MURUGUARD_PROTECTED_USERS_STATUS_SNAPSHOT', $this->protectedUsersStatus['count'], HTMLHelper::_('date', (int) $this->protectedUsersStatus['takenAt'], Text::_('DATE_FORMAT_LC5')))
                                : Text::_('COM_MURUGUARD_PROTECTED_USERS_STATUS_NONE') ?>
                        </p>
                    </div>
                    <label class="muru-switch flex-shrink-0">
                        <input type="checkbox" name="protected_users_enabled" value="1" <?= $this->protectedUsersEnabled ? 'checked' : '' ?>>
                        <span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>
                    </label>
                </div>
                <button type="submit"
                        class="inline-flex items-center gap-1.5 px-5 py-2 mt-4 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                    💾 <?= Text::_('COM_MURUGUARD_SAVE_SETTINGS_BTN') ?>
                </button>
            </form>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.cleanuptmp') ?>" method="post" class="mt-3 pt-3 border-t border-gray-100">
                <?= HTMLHelper::_('form.token') ?>
                <button type="submit"
                        class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 bg-white hover:bg-gray-50 transition-colors shadow-sm">
                    🧹 <?= Text::_('COM_MURUGUARD_TMP_CLEANUP_NOW_BTN') ?>
                </button>
                <span class="text-xs text-gray-400 ml-2"><?= Text::_('COM_MURUGUARD_TMP_CLEANUP_NOW_DESC') ?></span>
            </form>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.snapshotprotectedusers') ?>" method="post" class="mt-3 pt-3 border-t border-gray-100">
                <?= HTMLHelper::_('form.token') ?>
                <button type="submit"
                        class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 bg-white hover:bg-gray-50 transition-colors shadow-sm">
                    📸 <?= Text::_('COM_MURUGUARD_PROTECTED_USERS_SNAPSHOT_BTN') ?>
                </button>
                <span class="text-xs text-gray-400 ml-2"><?= Text::_('COM_MURUGUARD_PROTECTED_USERS_SNAPSHOT_DESC') ?></span>
            </form>

            <div class="mt-4 pt-4 border-t border-gray-100">
                <div class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_SAFE_BROWSING_LABEL') ?></div>
                <p class="text-xs text-gray-500 mt-0.5 mb-2 max-w-xl"><?= Text::_('COM_MURUGUARD_SAFE_BROWSING_DESC') ?></p>
                <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.savesafebrowsingkey') ?>" method="post" class="flex flex-wrap items-center gap-2">
                    <?= HTMLHelper::_('form.token') ?>
                    <input type="text" name="safe_browsing_api_key" placeholder="<?= $this->safeBrowsingApiKeyMasked !== '' ? htmlspecialchars($this->safeBrowsingApiKeyMasked) : Text::_('COM_MURUGUARD_SAFE_BROWSING_PLACEHOLDER') ?>"
                           class="flex-1 min-w-[220px] px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                    <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                        💾 <?= Text::_('COM_MURUGUARD_SAVE_SETTINGS_BTN') ?>
                    </button>
                </form>
                <?php if ($this->safeBrowsingApiKeyMasked !== ''): ?>
                <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.clearsafebrowsingkey') ?>" method="post" class="mt-2"
                      onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_SAFE_BROWSING_CLEAR_CONFIRM') ?>');">
                    <?= HTMLHelper::_('form.token') ?>
                    <button type="submit" class="text-xs text-red-600 hover:text-red-700 font-semibold"><?= Text::_('COM_MURUGUARD_SAFE_BROWSING_CLEAR_BTN') ?></button>
                </form>
                <?php endif; ?>
            </div>
        </div>

        <!-- Configuration import/export -- deliberately a narrow allowlist
             of feature toggles, never a blanket dump; see
             MuruguardHelper::EXPORTABLE_CONFIG_KEYS' own docblock. No
             secret this extension stores is ever included, so this file
             is safe to keep as a backup or hand to another admin. -->
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1">🗂️ <?= Text::_('COM_MURUGUARD_CONFIG_BACKUP_TITLE') ?></h3>
            <p class="text-xs text-gray-500 mb-4 max-w-xl"><?= Text::_('COM_MURUGUARD_CONFIG_BACKUP_DESC') ?></p>
            <div class="flex flex-wrap items-center gap-3">
                <a href="<?= Route::_('index.php?option=com_muruguard&task=scanner.exportconfig&' . urlencode(\Joomla\CMS\Session\Session::getFormToken()) . '=1') ?>"
                   class="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 rounded-lg text-sm font-semibold text-gray-700 bg-white hover:bg-gray-50 transition-colors shadow-sm">
                    ⬇️ <?= Text::_('COM_MURUGUARD_CONFIG_EXPORT_BTN') ?>
                </a>
                <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.importconfig') ?>" method="post" enctype="multipart/form-data" class="flex items-center gap-2">
                    <?= HTMLHelper::_('form.token') ?>
                    <input type="file" name="config_file" accept="application/json,.json" required
                           class="text-xs text-gray-600 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200">
                    <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                        ⬆️ <?= Text::_('COM_MURUGUARD_CONFIG_IMPORT_BTN') ?>
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($this->canAdmin && $this->aiProActive): ?>
        <!-- File Integrity Monitoring -- one-shot actions (build/check),
             not a toggle to save, so this has no <form>/Save button of
             its own. See MuruguardModelScanner's FIM section for what
             "baseline" actually means here. Kept right after Site
             Protection since both are read-at-a-glance status cards an
             admin checks routinely, not configuration you set once. -->
        <div id="muru-fim-card" class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1"><span class="text-lg leading-none">🧬</span> <?= Text::_('COM_MURUGUARD_FIM_HEADING') ?></h3>
            <p class="text-xs text-gray-500 mb-4 max-w-xl"><?= Text::_('COM_MURUGUARD_FIM_DESC') ?></p>

            <div class="flex flex-wrap items-center justify-between gap-3 border border-gray-200 rounded-lg p-4">
                <div>
                    <?php if ($this->fimBaselineStatus['exists']): ?>
                        <p class="text-sm font-semibold text-gray-800">
                            <?= Text::sprintf('COM_MURUGUARD_FIM_BASELINE_STATUS', number_format($this->fimBaselineStatus['fileCount']), date('M j, Y', (int) $this->fimBaselineStatus['createdAt'])) ?>
                        </p>
                    <?php else: ?>
                        <p class="text-sm font-semibold text-gray-800"><?= Text::_('COM_MURUGUARD_FIM_NO_BASELINE') ?></p>
                    <?php endif; ?>
                    <p id="muru-fim-status" class="text-xs text-gray-500 mt-1"></p>
                </div>
                <div class="flex items-center gap-2 flex-shrink-0">
                    <?php if ($this->fimBaselineStatus['exists']): ?>
                        <button type="button" id="muru-fim-check-btn"
                                class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                            🔍 <?= Text::_('COM_MURUGUARD_FIM_CHECK_BTN') ?>
                        </button>
                    <?php endif; ?>
                    <button type="button" id="muru-fim-build-btn"
                            class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 transition-colors shadow-sm">
                        🧬 <?= $this->fimBaselineStatus['exists'] ? Text::_('COM_MURUGUARD_FIM_REBUILD_BTN') : Text::_('COM_MURUGUARD_FIM_BUILD_BTN') ?>
                    </button>
                </div>
            </div>
        </div>
        <?php elseif (!$this->canAdmin): ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5 flex items-center gap-2 text-xs text-gray-500">
            <span class="text-base">🔒</span>
            <span><?= Text::_('COM_MURUGUARD_LICENSE_LOCKED_EDIT') ?></span>
        </div>
        <?php else: ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-10 text-center mb-5">
            <div class="text-4xl mb-3">🔒</div>
            <h3 class="text-base font-bold text-gray-800 mb-2"><?= Text::_('COM_MURUGUARD_FIM_LOCKED_TITLE') ?></h3>
            <p class="text-sm text-gray-500 max-w-md mx-auto mb-5"><?= Text::_('COM_MURUGUARD_FIM_LOCKED_DESC') ?></p>
            <a href="<?= htmlspecialchars(\MuruguardHelper::DASHBOARD_LOGIN_URL) ?>" target="_blank" rel="noopener"
               class="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                ⭐ <?= Text::_('COM_MURUGUARD_AI_UPGRADE_BTN') ?>
            </a>
        </div>
        <?php endif; ?>

        <!-- IP Access List -- collapsed by default (Site Protection above and Protection Log below stay open since they're what's checked most often; this and Hardening below are opened on demand). -->
        <details class="muru-settings-collapse">
            <summary>
                <div>
                    <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2"><span class="text-lg leading-none">🚧</span> <?= Text::_('COM_MURUGUARD_IPLIST_TITLE') ?></h3>
                    <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_IPLIST_DESC') ?></p>
                    <p class="muru-settings-collapse-hint" data-expand-text="<?= Text::_('COM_MURUGUARD_COLLAPSE_HINT') ?>" data-collapse-text="<?= Text::_('COM_MURUGUARD_COLLAPSE_HINT_COLLAPSE') ?>"><?= Text::_('COM_MURUGUARD_COLLAPSE_HINT') ?></p>
                </div>
                <span class="muru-settings-collapse-chevron" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 6 15 12 9 18"></polyline></svg></span>
            </summary>
            <div class="muru-settings-collapse-body">
            <div class="flex items-center gap-2 text-xs text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-xl px-3 py-2 mb-4">
                <span class="text-base">📍</span>
                <span><?= Text::sprintf('COM_MURUGUARD_IPLIST_YOUR_IP', '<code class="font-mono font-bold">' . htmlspecialchars($this->currentClientIp) . '</code>') ?></span>
                <button type="button" class="muru-copy-btn ml-auto flex-shrink-0 w-6 h-6 inline-flex items-center justify-center rounded-lg text-indigo-400 hover:text-indigo-700 hover:bg-indigo-100 transition-colors"
                        data-copy="<?= htmlspecialchars($this->currentClientIp) ?>" title="<?= Text::_('COM_MURUGUARD_COPY_URL') ?>" aria-label="<?= Text::_('COM_MURUGUARD_COPY_URL') ?>">
                    <span class="muru-copy-icon">📋</span>
                </button>
            </div>

            <?php if (empty($this->ipList)): ?>
                <div class="flex items-center gap-3 text-gray-500 bg-gray-50 rounded-xl p-[10px] mb-4 text-xs">
                    <span class="text-lg">ℹ️</span>
                    <span><?= Text::_('COM_MURUGUARD_IPLIST_EMPTY') ?></span>
                </div>
            <?php else: ?>
                <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-4">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="bg-gray-50 border-b border-gray-100">
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_IPLIST_COL_VALUE') ?></th>
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_IPLIST_COL_MODE') ?></th>
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_IPLIST_COL_NOTE') ?></th>
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_IPLIST_COL_ADDED') ?></th>
                                <th class="w-10 px-4 py-2.5"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                        <?php foreach ($this->ipList as $entry): ?>
                            <tr class="hover:bg-gray-50/60 transition-colors">
                                <td class="px-4 py-2.5 font-mono text-xs text-gray-700"><?= htmlspecialchars($entry['value'] ?? '') ?></td>
                                <td class="px-4 py-2.5">
                                    <?php if (($entry['mode'] ?? '') === 'allow'): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-bold">✓ <?= Text::_('COM_MURUGUARD_IPLIST_MODE_ALLOW') ?></span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-bold">🚫 <?= Text::_('COM_MURUGUARD_IPLIST_MODE_BLOCK') ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-2.5 text-xs text-gray-500"><?= htmlspecialchars($entry['note'] ?? '') ?></td>
                                <td class="px-4 py-2.5 text-xs text-gray-400"><?= isset($entry['addedAt']) ? date('Y-m-d H:i', (int) $entry['addedAt']) : '' ?></td>
                                <td class="px-4 py-2.5">
                                    <?php if ($this->canAdmin): ?>
                                    <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.removeipentry') ?>" method="post"
                                          onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_IPLIST_REMOVE_CONFIRM') ?>');">
                                        <?= HTMLHelper::_('form.token') ?>
                                        <input type="hidden" name="ip_id" value="<?= htmlspecialchars($entry['id'] ?? '') ?>">
                                        <button type="submit" class="text-gray-400 hover:text-red-600 transition-colors" title="<?= Text::_('COM_MURUGUARD_IPLIST_REMOVE_BTN') ?>">🗑</button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <?php if ($this->canAdmin): ?>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.addipentry') ?>" method="post" class="flex flex-wrap items-end gap-3">
                <?= HTMLHelper::_('form.token') ?>
                <div class="flex-1 min-w-[180px]">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-ip-value"><?= Text::_('COM_MURUGUARD_IPLIST_ADD_VALUE_LABEL') ?></label>
                    <input type="text" id="muru-ip-value" name="ip_value" placeholder="203.0.113.5 or 203.0.113.0/24" required
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-ip-mode"><?= Text::_('COM_MURUGUARD_IPLIST_ADD_MODE_LABEL') ?></label>
                    <select id="muru-ip-mode" name="ip_mode" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                        <option value="block"><?= Text::_('COM_MURUGUARD_IPLIST_MODE_BLOCK') ?></option>
                        <option value="allow"><?= Text::_('COM_MURUGUARD_IPLIST_MODE_ALLOW') ?></option>
                    </select>
                </div>
                <div class="flex-1 min-w-[160px]">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-ip-note"><?= Text::_('COM_MURUGUARD_IPLIST_ADD_NOTE_LABEL') ?></label>
                    <input type="text" id="muru-ip-note" name="ip_note" maxlength="200"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                    ➕ <?= Text::_('COM_MURUGUARD_IPLIST_ADD_BTN') ?>
                </button>
            </form>
            <?php endif; ?>
            </div>
        </details>

        <!-- Known-Bad Hashes -- exact-hash malware database, admin-
             maintained (ships empty on purpose, see the list's own PHP
             docblock). Same collapsed-by-default treatment as IP Access
             List above. -->
        <details class="muru-settings-collapse">
            <summary>
                <div>
                    <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2"><span class="text-lg leading-none">🧬</span> <?= Text::_('COM_MURUGUARD_KNOWNHASH_TITLE') ?></h3>
                    <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_KNOWNHASH_DESC') ?></p>
                    <p class="muru-settings-collapse-hint" data-expand-text="<?= Text::_('COM_MURUGUARD_COLLAPSE_HINT') ?>" data-collapse-text="<?= Text::_('COM_MURUGUARD_COLLAPSE_HINT_COLLAPSE') ?>"><?= Text::_('COM_MURUGUARD_COLLAPSE_HINT') ?></p>
                </div>
                <span class="muru-settings-collapse-chevron" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 6 15 12 9 18"></polyline></svg></span>
            </summary>
            <div class="muru-settings-collapse-body">
            <?php if (empty($this->knownHashes)): ?>
                <div class="flex items-center gap-3 text-gray-500 bg-gray-50 rounded-xl p-[10px] mb-4 text-xs">
                    <span class="text-lg">ℹ️</span>
                    <span><?= Text::_('COM_MURUGUARD_KNOWNHASH_EMPTY') ?></span>
                </div>
            <?php else: ?>
                <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-4">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="bg-gray-50 border-b border-gray-100">
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_KNOWNHASH_COL_MD5') ?></th>
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_IPLIST_COL_NOTE') ?></th>
                                <th class="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_IPLIST_COL_ADDED') ?></th>
                                <th class="w-10 px-4 py-2.5"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                        <?php foreach ($this->knownHashes as $entry): ?>
                            <tr class="hover:bg-gray-50/60 transition-colors">
                                <td class="px-4 py-2.5 font-mono text-xs text-gray-700"><?= htmlspecialchars($entry['md5'] ?? '') ?></td>
                                <td class="px-4 py-2.5 text-xs text-gray-500"><?= htmlspecialchars($entry['note'] ?? '') ?></td>
                                <td class="px-4 py-2.5 text-xs text-gray-400"><?= isset($entry['addedAt']) ? date('Y-m-d H:i', (int) $entry['addedAt']) : '' ?></td>
                                <td class="px-4 py-2.5">
                                    <?php if ($this->canAdmin): ?>
                                    <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.removeknownhash') ?>" method="post"
                                          onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_IPLIST_REMOVE_CONFIRM') ?>');">
                                        <?= HTMLHelper::_('form.token') ?>
                                        <input type="hidden" name="hash_id" value="<?= htmlspecialchars($entry['id'] ?? '') ?>">
                                        <button type="submit" class="text-gray-400 hover:text-red-600 transition-colors" title="<?= Text::_('COM_MURUGUARD_IPLIST_REMOVE_BTN') ?>">🗑</button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <?php if ($this->canAdmin): ?>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.addknownhash') ?>" method="post" class="flex flex-wrap items-end gap-3">
                <?= HTMLHelper::_('form.token') ?>
                <div class="flex-1 min-w-[220px]">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-hash-value"><?= Text::_('COM_MURUGUARD_KNOWNHASH_ADD_VALUE_LABEL') ?></label>
                    <input type="text" id="muru-hash-value" name="hash_md5" placeholder="d41d8cd98f00b204e9800998ecf8427e" required pattern="[a-fA-F0-9]{32}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <div class="flex-1 min-w-[160px]">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-hash-note"><?= Text::_('COM_MURUGUARD_IPLIST_ADD_NOTE_LABEL') ?></label>
                    <input type="text" id="muru-hash-note" name="hash_note" maxlength="200"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                    ➕ <?= Text::_('COM_MURUGUARD_KNOWNHASH_ADD_BTN') ?>
                </button>
            </form>
            <?php endif; ?>
            </div>
        </details>

        <!-- MuRu Shield Hardening: Backend Access (server-level .htaccess
             HTTP Basic Auth in front of /administrator) + Emergency Mode.
             Distinct from Protection Mode above -- this operates at the
             web-server layer, before Joomla even bootstraps, not PHP.
             Collapsed by default -- see the IP Access List note above. -->
        <details class="muru-settings-collapse">
            <summary>
                <div>
                    <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2"><span class="text-lg leading-none">🔒</span> <?= Text::_('COM_MURUGUARD_HARDENING_TITLE') ?></h3>
                    <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_HARDENING_DESC') ?></p>
                    <p class="muru-settings-collapse-hint" data-expand-text="<?= Text::_('COM_MURUGUARD_COLLAPSE_HINT') ?>" data-collapse-text="<?= Text::_('COM_MURUGUARD_COLLAPSE_HINT_COLLAPSE') ?>"><?= Text::_('COM_MURUGUARD_COLLAPSE_HINT') ?></p>
                </div>
                <span class="muru-settings-collapse-chevron" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 6 15 12 9 18"></polyline></svg></span>
            </summary>
            <div class="muru-settings-collapse-body">

            <?php if (!$this->canAdmin): ?>
            <div class="flex items-center gap-2 text-xs text-gray-500">
                <span class="text-base">🔒</span>
                <span><?= Text::_('COM_MURUGUARD_LOCKED_EDIT_MENU') ?></span>
            </div>
            <?php else: ?>

            <?php if ($this->backendAuthEnabled): ?>
            <div class="flex items-center gap-3 bg-emerald-50 border border-emerald-100 rounded-xl p-3 mb-4">
                <span class="text-2xl">✅</span>
                <div class="text-xs text-emerald-800">
                    <div class="font-bold"><?= Text::_('COM_MURUGUARD_HARDENING_ACTIVE_LABEL') ?></div>
                    <div><?= Text::sprintf('COM_MURUGUARD_HARDENING_ACTIVE_DETAIL', htmlspecialchars($this->backendAuthUsername), $this->backendAuthActivated > 0 ? date('Y-m-d H:i:s', $this->backendAuthActivated) : '—') ?></div>
                </div>
            </div>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.deactivatebackendauth') ?>" method="post"
                  onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_HARDENING_DEACTIVATE_CONFIRM') ?>');" class="mb-5">
                <?= HTMLHelper::_('form.token') ?>
                <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 border border-red-200 rounded-lg text-sm font-semibold text-red-700 bg-red-50 hover:bg-red-100 transition-colors">
                    🚫 <?= Text::_('COM_MURUGUARD_HARDENING_DEACTIVATE_BTN') ?>
                </button>
            </form>
            <?php else: ?>
            <div class="flex items-center gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-xl px-3 py-2 mb-4">
                <span class="text-base">⚠️</span>
                <span><?= Text::_('COM_MURUGUARD_HARDENING_WRITABLE_WARNING') ?></span>
            </div>
            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.activatebackendauth') ?>" method="post" id="muru-backendauth-form"
                  onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_HARDENING_ACTIVATE_CONFIRM') ?>');">
                <?= HTMLHelper::_('form.token') ?>
                <div class="grid sm:grid-cols-2 gap-4 mb-3">
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-ba-username"><?= Text::_('COM_MURUGUARD_HARDENING_USERNAME_LABEL') ?></label>
                        <input type="text" id="muru-ba-username" name="backend_auth_username" autocomplete="off" required
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                    </div>
                    <div></div>
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-ba-password"><?= Text::_('COM_MURUGUARD_HARDENING_PASSWORD_LABEL') ?></label>
                        <input type="text" id="muru-ba-password" name="backend_auth_password" autocomplete="off" required minlength="8"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-ba-password-repeat"><?= Text::_('COM_MURUGUARD_HARDENING_PASSWORD_REPEAT_LABEL') ?></label>
                        <input type="text" id="muru-ba-password-repeat" name="backend_auth_password_repeat" autocomplete="off" required minlength="8"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                    </div>
                </div>
                <div class="flex items-center gap-2 mb-4">
                    <button type="button" id="muru-ba-generate" class="inline-flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 rounded-lg text-xs font-semibold text-gray-600 bg-gray-50 hover:bg-gray-100 transition-colors">
                        🎲 <?= Text::_('COM_MURUGUARD_HARDENING_GENERATE_BTN') ?>
                    </button>
                    <span class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_HARDENING_GENERATE_HINT') ?></span>
                </div>
                <p class="text-xs text-gray-500 mb-4"><?= Text::_('COM_MURUGUARD_HARDENING_TIP') ?></p>
                <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                    🔒 <?= Text::_('COM_MURUGUARD_HARDENING_ACTIVATE_BTN') ?>
                </button>
            </form>
            <?php endif; ?>

            <!-- Emergency Mode -->
            <div class="mt-6 pt-5 border-t border-gray-100">
                <h4 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1">🚨 <?= Text::_('COM_MURUGUARD_EMERGENCY_TITLE') ?></h4>
                <p class="text-xs text-gray-500 mb-3 max-w-xl"><?= Text::_('COM_MURUGUARD_EMERGENCY_DESC') ?></p>

                <?php if (!$this->backendAuthEnabled): ?>
                <div class="flex items-center gap-2 text-xs text-gray-500 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2">
                    <span class="text-base">ℹ️</span>
                    <span><?= Text::_('COM_MURUGUARD_EMERGENCY_NEEDS_BACKEND_MSG') ?></span>
                </div>
                <?php elseif ($this->emergencyModeEnabled): ?>
                <div class="flex items-center gap-3 bg-red-50 border border-red-200 rounded-xl p-3 mb-4">
                    <span class="text-2xl">🚨</span>
                    <div class="text-xs text-red-800">
                        <div class="font-bold"><?= Text::_('COM_MURUGUARD_EMERGENCY_ACTIVE_LABEL') ?></div>
                        <div><?= Text::sprintf('COM_MURUGUARD_EMERGENCY_ACTIVE_DETAIL', $this->emergencyModeActivated > 0 ? date('Y-m-d H:i:s', $this->emergencyModeActivated) : '—') ?></div>
                    </div>
                </div>
                <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.deactivateemergencymode') ?>" method="post"
                      onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_EMERGENCY_DEACTIVATE_CONFIRM') ?>');">
                    <?= HTMLHelper::_('form.token') ?>
                    <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-sm">
                        ✅ <?= Text::_('COM_MURUGUARD_EMERGENCY_DEACTIVATE_BTN') ?>
                    </button>
                </form>
                <?php else: ?>
                <div class="flex items-center gap-2 text-xs text-red-700 bg-red-50 border border-red-100 rounded-xl px-3 py-2 mb-3">
                    <span class="text-base">⚠️</span>
                    <span><?= Text::_('COM_MURUGUARD_EMERGENCY_WARNING') ?></span>
                </div>
                <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.activateemergencymode') ?>" method="post"
                      onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_EMERGENCY_ACTIVATE_CONFIRM') ?>');">
                    <?= HTMLHelper::_('form.token') ?>
                    <div class="grid sm:grid-cols-2 gap-4 mb-3 max-w-lg">
                        <div>
                            <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-em-username"><?= Text::_('COM_MURUGUARD_HARDENING_USERNAME_LABEL') ?></label>
                            <input type="text" id="muru-em-username" name="emergency_username" autocomplete="off" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-em-password"><?= Text::_('COM_MURUGUARD_EMERGENCY_PASSWORD_LABEL') ?></label>
                            <input type="password" id="muru-em-password" name="emergency_password" autocomplete="off" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-400">
                        </div>
                    </div>
                    <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-bold text-white bg-red-600 hover:bg-red-700 transition-colors shadow-sm">
                        🚨 <?= Text::_('COM_MURUGUARD_EMERGENCY_ACTIVATE_BTN') ?>
                    </button>
                </form>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            </div>
        </details>

        <?php
        $attackEntries = array_filter($this->attackLog, fn($e) => ($e['type'] ?? '') === 'request');
        $bruteEntries  = array_filter($this->attackLog, fn($e) => ($e['type'] ?? '') === 'bruteforce');
        ?>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-5">
            <div class="flex items-start justify-between gap-4 mb-4">
                <div>
                    <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2">📋 <?= Text::_('COM_MURUGUARD_PROTECTION_LOG_TITLE') ?></h3>
                    <p class="text-xs text-gray-500 mt-1 max-w-xl"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_DESC') ?></p>
                    <?php if ($this->attackLogArchiveCount > 0): ?>
                        <p class="text-xs text-gray-400 mt-1 flex items-center gap-1">🗄 <?= Text::sprintf('COM_MURUGUARD_PROTECTION_LOG_ARCHIVE_NOTE', number_format($this->attackLogArchiveCount)) ?></p>
                    <?php endif; ?>
                </div>
                <?php if ($this->canAdmin && !empty($this->attackLog)): ?>
                <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.clearattacklog') ?>" method="post" onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_PROTECTION_LOG_CLEAR_CONFIRM') ?>');">
                    <?= HTMLHelper::_('form.token') ?>
                    <button type="submit" class="flex-shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 rounded-lg text-xs font-semibold text-gray-600 bg-white hover:bg-gray-50 transition-colors shadow-sm">
                        🗑 <?= Text::_('COM_MURUGUARD_PROTECTION_LOG_CLEAR_BTN') ?>
                    </button>
                </form>
                <?php endif; ?>
            </div>

            <?php if (empty($this->attackLog)): ?>
                <div class="text-center py-10 text-gray-400 text-sm">
                    ✅ <?= Text::_('COM_MURUGUARD_PROTECTION_LOG_EMPTY') ?>
                </div>
            <?php else: ?>

                <h4 class="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2 mt-2"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_SECTION_REQUESTS') ?></h4>
                <?php if (empty($attackEntries)): ?>
                    <div class="text-xs text-gray-400 mb-5">— <?= Text::_('COM_MURUGUARD_PROTECTION_LOG_NONE') ?></div>
                <?php else: ?>
                <?php muru_pagination_controls('muru-attacklog-tbody', count($attackEntries)); ?>
                <div class="overflow-x-auto mb-5 border border-gray-200 rounded-lg">
                    <table class="w-full text-xs">
                        <thead class="bg-gray-50 text-gray-500 uppercase tracking-wider">
                            <tr>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_TIME') ?></th>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_IP') ?></th>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_SEVERITY') ?></th>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_REASON') ?></th>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_URI') ?></th>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_STATUS') ?></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100" id="muru-attacklog-tbody">
                            <?php $attackRowIndex = 0; foreach ($attackEntries as $e): ?>
                            <tr class="muru-paginated-row hover:bg-gray-50/60" data-row-index="<?= $attackRowIndex++ ?>">
                                <td class="px-3 py-2 text-gray-500 whitespace-nowrap"><?= date('Y-m-d H:i:s', (int) ($e['time'] ?? 0)) ?></td>
                                <td class="px-3 py-2 font-mono text-gray-700"><?= htmlspecialchars((string) ($e['ip'] ?? '')) ?></td>
                                <td class="px-3 py-2">
                                    <?php if (($e['severity'] ?? '') === 'high'): ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-700">🔴 <?= Text::_('COM_MURUGUARD_CONFIDENCE_HIGH') ?></span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-700">🟡 <?= Text::_('COM_MURUGUARD_CONFIDENCE_MEDIUM') ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-3 py-2 text-gray-600 max-w-xs"><?= htmlspecialchars((string) ($e['why'] ?? '')) ?></td>
                                <td class="px-3 py-2 text-gray-500 max-w-[220px] truncate font-mono" title="<?= htmlspecialchars((string) ($e['uri'] ?? '')) ?>"><?= htmlspecialchars(mb_strimwidth((string) ($e['uri'] ?? ''), 0, 60, '…')) ?></td>
                                <td class="px-3 py-2">
                                    <?php if (!empty($e['blocked'])): ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-red-600 text-white">🚫 <?= Text::_('COM_MURUGUARD_PROTECTION_LOG_BLOCKED') ?></span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-gray-100 text-gray-600"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_LOGGED_ONLY') ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>

                <h4 class="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_SECTION_BRUTEFORCE') ?></h4>
                <?php if (empty($bruteEntries)): ?>
                    <div class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_NONE') ?></div>
                <?php else: ?>
                <?php muru_pagination_controls('muru-bruteforce-tbody', count($bruteEntries)); ?>
                <div class="overflow-x-auto border border-gray-200 rounded-lg">
                    <table class="w-full text-xs">
                        <thead class="bg-gray-50 text-gray-500 uppercase tracking-wider">
                            <tr>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_TIME') ?></th>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_IP') ?></th>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_USERNAME') ?></th>
                                <th class="text-left px-3 py-2 font-bold"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_COL_STATUS') ?></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100" id="muru-bruteforce-tbody">
                            <?php $bruteRowIndex = 0; foreach ($bruteEntries as $e): ?>
                            <tr class="muru-paginated-row hover:bg-gray-50/60" data-row-index="<?= $bruteRowIndex++ ?>">
                                <td class="px-3 py-2 text-gray-500 whitespace-nowrap"><?= date('Y-m-d H:i:s', (int) ($e['time'] ?? 0)) ?></td>
                                <td class="px-3 py-2 font-mono text-gray-700"><?= htmlspecialchars((string) ($e['ip'] ?? '')) ?></td>
                                <td class="px-3 py-2 text-gray-600"><?= htmlspecialchars((string) preg_replace('/^username:\s*/', '', (string) ($e['matched'] ?? '')) ?: '—') ?></td>
                                <td class="px-3 py-2">
                                    <?php if (!empty($e['blocked'])): ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-red-600 text-white">🚫 <?= Text::_('COM_MURUGUARD_PROTECTION_LOG_BLOCKED') ?></span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-gray-100 text-gray-600"><?= Text::_('COM_MURUGUARD_PROTECTION_LOG_LOGGED_ONLY') ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════════════════════════════
     SMART AI ASSISTANT PANEL -- Pro-only. hidden by default, toggled
     by the sidebar's Smart AI Assistant entry. Same show/hide-vs-
     #muru-main-content mechanism as the Settings panel above.
     ══════════════════════════════════════════════════════════════ -->
<div id="muru-ai-panel" class="hidden">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-lg font-bold text-gray-800 flex items-center gap-2">🤖 <?= Text::_('COM_MURUGUARD_AI_HEADING') ?></h2>
        <button type="button" id="muru-ai-back" class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors shadow-sm">
            ← <?= Text::_('COM_MURUGUARD_SETTINGS_BACK') ?>
        </button>
    </div>

    <?php if (!$this->canAdmin): ?>
    <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 flex items-center gap-2 text-sm text-gray-500">
        <span class="text-base">🔒</span>
        <span><?= Text::_('COM_MURUGUARD_LICENSE_LOCKED_EDIT') ?></span>
    </div>
    <?php elseif (!$this->aiProActive): ?>
    <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-10 text-center">
        <div class="text-4xl mb-3">🔒</div>
        <h3 class="text-base font-bold text-gray-800 mb-2"><?= Text::_('COM_MURUGUARD_AI_LOCKED_TITLE') ?></h3>
        <p class="text-sm text-gray-500 max-w-md mx-auto mb-5"><?= Text::_('COM_MURUGUARD_AI_LOCKED_DESC') ?></p>
        <a href="<?= htmlspecialchars(\MuruguardHelper::DASHBOARD_LOGIN_URL) ?>" target="_blank" rel="noopener"
           class="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
            ⭐ <?= Text::_('COM_MURUGUARD_AI_UPGRADE_BTN') ?>
        </a>
    </div>
    <?php else: ?>
    <div class="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4">
        <!-- Quick actions + file browser -->
        <div class="space-y-4">
            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-3">
                <div class="text-[11px] font-bold text-gray-500 uppercase tracking-wider px-1 mb-2"><?= Text::_('COM_MURUGUARD_AI_QUICK_ACTIONS') ?></div>
                <div class="flex flex-col gap-1" id="muru-ai-quick-actions">
                    <button type="button" class="muru-ai-quick-btn text-left px-2.5 py-1.5 rounded-lg text-xs text-gray-700 hover:bg-gray-100" data-prompt="Scan the project for coding issues, bugs, and potential errors. Summarize what you find.">🔍 <?= Text::_('COM_MURUGUARD_AI_ACTION_SCAN') ?></button>
                    <button type="button" class="muru-ai-quick-btn text-left px-2.5 py-1.5 rounded-lg text-xs text-gray-700 hover:bg-gray-100" data-prompt="Suggest fixes for the issues you find, and explain each one before applying anything.">🛠️ <?= Text::_('COM_MURUGUARD_AI_ACTION_FIX') ?></button>
                    <button type="button" class="muru-ai-quick-btn text-left px-2.5 py-1.5 rounded-lg text-xs text-gray-700 hover:bg-gray-100" data-prompt="Explain what a file I'll specify does. Ask me which file if I haven't said yet.">📖 <?= Text::_('COM_MURUGUARD_AI_ACTION_EXPLAIN') ?></button>
                    <button type="button" class="muru-ai-quick-btn text-left px-2.5 py-1.5 rounded-lg text-xs text-gray-700 hover:bg-gray-100" data-prompt="Refactor a file I'll specify for clarity and maintainability, without changing its behavior. Ask me which file if I haven't said yet.">♻️ <?= Text::_('COM_MURUGUARD_AI_ACTION_REFACTOR') ?></button>
                    <button type="button" class="muru-ai-quick-btn text-left px-2.5 py-1.5 rounded-lg text-xs text-gray-700 hover:bg-gray-100" data-prompt="Write unit tests for a file I'll specify. Ask me which file if I haven't said yet.">🧪 <?= Text::_('COM_MURUGUARD_AI_ACTION_TESTS') ?></button>
                    <button type="button" class="muru-ai-quick-btn text-left px-2.5 py-1.5 rounded-lg text-xs text-gray-700 hover:bg-gray-100" data-prompt="Generate documentation for a file or component I'll specify. Ask me which one if I haven't said yet.">📝 <?= Text::_('COM_MURUGUARD_AI_ACTION_DOCS') ?></button>
                    <button type="button" class="muru-ai-quick-btn text-left px-2.5 py-1.5 rounded-lg text-xs text-gray-700 hover:bg-gray-100" data-prompt="Review the project for security recommendations and performance improvements.">🛡️ <?= Text::_('COM_MURUGUARD_AI_ACTION_SECURITY') ?></button>
                </div>
            </div>
            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-3">
                <div class="text-[11px] font-bold text-gray-500 uppercase tracking-wider px-1 mb-2"><?= Text::_('COM_MURUGUARD_AI_AUDIT_LOG') ?></div>
                <div class="text-xs" id="muru-ai-audit-list">
                    <?php if (empty($this->protectedRepairs)): ?>
                    <p class="text-gray-400 px-1 py-1"><?= Text::_('COM_MURUGUARD_AI_AUDIT_EMPTY') ?></p>
                    <?php else: foreach (array_slice($this->protectedRepairs, 0, 2) as $repair): muru_render_protected_repair_row($repair, $this->timeMachineSnapshots); endforeach; ?>
                    <?php endif; ?>
                </div>
                <?php if (count($this->protectedRepairs) > 2): ?>
                <a href="index.php?option=com_muruguard&view_panel=settings&settings_tab=backup" class="block text-center mt-2 pt-2 border-t border-gray-100 text-[11px] font-bold text-indigo-600 hover:text-indigo-800"><?= Text::_('COM_MURUGUARD_TM_SEE_ALL_BTN') ?></a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Chat -->
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col" style="height: 640px;">
            <div id="muru-ai-messages" class="flex-1 overflow-y-auto p-4 space-y-3">
                <div class="text-sm text-gray-500 bg-gray-50 border border-gray-200 rounded-xl p-3">
                    <?= Text::_('COM_MURUGUARD_AI_WELCOME') ?>
                </div>
            </div>
            <div id="muru-ai-confirm-box" class="hidden border-t border-amber-200 bg-amber-50 p-4"></div>
            <div class="border-t border-gray-200 p-3">
                <form id="muru-ai-form" class="flex items-end gap-2">
                    <textarea id="muru-ai-input" rows="2" placeholder="<?= Text::_('COM_MURUGUARD_AI_INPUT_PLACEHOLDER') ?>"
                        class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 resize-none"></textarea>
                    <button type="submit" id="muru-ai-send" class="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-sm">
                        <?= Text::_('COM_MURUGUARD_AI_SEND_BTN') ?>
                    </button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<div id="muru-help-panel" class="hidden">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-lg font-bold text-gray-800 flex items-center gap-2">💬 <?= Text::_('COM_MURUGUARD_HELP_HEADING') ?></h2>
        <button type="button" id="muru-help-back" class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors shadow-sm">
            ← <?= Text::_('COM_MURUGUARD_SETTINGS_BACK') ?>
        </button>
    </div>

    <div class="grid lg:grid-cols-[1fr_320px] gap-5 items-start">
        <div>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-6">
            <p class="text-sm text-gray-500 mb-5"><?= Text::_('COM_MURUGUARD_HELP_DESC') ?></p>

            <form action="<?= Route::_('index.php?option=com_muruguard&task=scanner.sendhelprequest') ?>" method="post">
                <?= HTMLHelper::_('form.token') ?>
                <div class="grid sm:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-help-name"><?= Text::_('COM_MURUGUARD_HELP_NAME_LABEL') ?></label>
                        <input type="text" id="muru-help-name" name="help_name" value="<?= htmlspecialchars($this->helpUserName) ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-help-email"><?= Text::_('COM_MURUGUARD_HELP_EMAIL_LABEL') ?></label>
                        <input type="email" id="muru-help-email" name="help_email" value="<?= htmlspecialchars($this->helpUserEmail) ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                    </div>
                </div>
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-help-subject"><?= Text::_('COM_MURUGUARD_HELP_SUBJECT_LABEL') ?></label>
                    <input type="text" id="muru-help-subject" name="help_subject" required
                           placeholder="<?= Text::_('COM_MURUGUARD_HELP_SUBJECT_PLACEHOLDER') ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400">
                </div>
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-600 mb-1.5" for="muru-help-message"><?= Text::_('COM_MURUGUARD_HELP_MESSAGE_LABEL') ?></label>
                    <textarea id="muru-help-message" name="help_message" rows="7" required
                              placeholder="<?= Text::_('COM_MURUGUARD_HELP_MESSAGE_PLACEHOLDER') ?>"
                              class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400" style="resize:vertical;"></textarea>
                </div>
                <div class="mb-4">
                    <label class="flex items-start gap-2 text-xs text-gray-600 cursor-pointer">
                        <input type="checkbox" id="muru-help-sysinfo-toggle" name="help_send_system_info" value="1" class="mt-0.5 w-4 h-4 rounded border-gray-300">
                        <span><?= Text::_('COM_MURUGUARD_HELP_SYSINFO_LABEL') ?></span>
                    </label>
                    <input type="hidden" name="help_system_info" value="<?= htmlspecialchars($this->helpSystemInfo) ?>">
                    <pre id="muru-help-sysinfo-preview" class="hidden mt-2 text-[11px] font-mono text-gray-500 bg-gray-50 border border-gray-200 rounded-lg p-3 whitespace-pre-wrap"><?= htmlspecialchars($this->helpSystemInfo) ?></pre>
                </div>
                <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                    ✉️ <?= Text::_('COM_MURUGUARD_HELP_SEND_BTN') ?>
                </button>
            </form>
        </div>

        <p class="text-xs text-gray-400 mt-4"><?= Text::sprintf('COM_MURUGUARD_HELP_DIRECT_EMAIL', 'zkranao@gmail.com') ?></p>
        </div>

        <!-- Alternative channel for licensed customers: a tracked support
             ticket on the Lyzerslab dashboard (order/license history
             visible to whoever answers it), rather than this site's own
             one-off contact email. Purely informational + a link -- no
             ticket data flows through com_muruguard itself. -->
        <div class="bg-indigo-50/60 border border-indigo-100 rounded-xl p-5">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-2 mb-1">🎫 <?= Text::_('COM_MURUGUARD_HELP_TICKET_HEADING') ?></h3>
            <p class="text-xs text-gray-500 mb-4"><?= Text::_('COM_MURUGUARD_HELP_TICKET_DESC') ?></p>
            <ol class="text-xs text-gray-600 space-y-2.5 mb-4 list-decimal list-inside">
                <li><?= Text::_('COM_MURUGUARD_HELP_TICKET_STEP1') ?></li>
                <li><?= Text::_('COM_MURUGUARD_HELP_TICKET_STEP2') ?></li>
                <li><?= Text::_('COM_MURUGUARD_HELP_TICKET_STEP3') ?></li>
                <li><?= Text::_('COM_MURUGUARD_HELP_TICKET_STEP4') ?></li>
            </ol>
            <a href="<?= htmlspecialchars(\MuruguardHelper::DASHBOARD_LOGIN_URL) ?>" target="_blank" rel="noopener"
               class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                🔑 <?= Text::_('COM_MURUGUARD_HELP_TICKET_LOGIN_BTN') ?>
            </a>
        </div>
    </div>
</div>

<!-- Wrapper toggled off when the Settings panel is open -- see the
     #muru-settings-btn handler further down. Wraps BOTH the pre-scan
     gate and the post-scan results below, so Settings works regardless
     of scan state. Pure outer wrap, no internal logic changed. -->
<div id="muru-main-content">
<?php if (!$this->scanned): ?>
<!-- ══════════════════════════════════════════════════════════════
     SCAN GATE
     ══════════════════════════════════════════════════════════════ -->
<?php
$scanAreas = $this->scanAreas ?? [];
$selAreas  = $this->selectedAreas ?? [];
// Empty previous selection = first visit -> default everything on.
$isAreaChecked = function (string $key) use ($selAreas): bool {
    return empty($selAreas) || in_array($key, $selAreas, true);
};
?>
<?php
$groupIcons = [
    'upload_media'   => ['icon' => '🖼', 'chip' => 'bg-sky-100 text-sky-600'],
    'extension_code' => ['icon' => '🧩', 'chip' => 'bg-violet-100 text-violet-600'],
    'core_webroot'   => ['icon' => '🏛', 'chip' => 'bg-amber-100 text-amber-600'],
    'database'       => ['icon' => '🗄', 'chip' => 'bg-emerald-100 text-emerald-600'],
];
$totalAreaCount = array_sum(array_map(fn($g) => count($g['areas']), $scanAreas));
?>
<div class="anim-in flex flex-col items-center gap-6 py-6">
    <!-- Hero -->
    <div class="w-full max-w-3xl text-center relative overflow-hidden rounded-2xl px-6 py-9"
         style="background:linear-gradient(135deg,#eef2ff 0%,#f5f3ff 55%,#fdf2f8 100%);">
        <div class="relative flex items-center justify-center mb-4">
            <div class="absolute w-24 h-24 rounded-full bg-indigo-200/50 shield-pulse"></div>
            <div class="relative text-5xl">🛡️</div>
        </div>
        <h2 class="text-2xl font-extrabold text-gray-900 mb-2"><?= Text::_('COM_MURUGUARD_TITLE') ?></h2>
        <p class="text-gray-500 text-sm leading-relaxed max-w-lg mx-auto mb-2">
            <?= Text::_('COM_MURUGUARD_HERO_DESC') ?>
        </p>
        <?php if ($this->componentVersion !== ''): ?>
        <div class="flex items-center justify-center">
            <a href="index.php?option=com_installer&view=update"
               class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-600 text-white text-[11px] font-bold hover:bg-red-700 transition-colors"
               title="<?= Text::_('COM_MURUGUARD_CHECK_UPDATES_TITLE') ?>">
                🛡️ v<?= htmlspecialchars($this->componentVersion) ?>
                <span class="opacity-50">|</span>
                <?= Text::_('COM_MURUGUARD_CHECK_UPDATES_LINK') ?>
            </a>
        </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($this->serverLimits) && !$this->serverLimits['allGood']): ?>
    <!-- Server limits advisory -- shown BEFORE a scan is attempted so a
         large site on a host that won't raise execution-time/memory
         limits gets actionable instructions instead of only finding out
         after the scan dies partway through with a generic 500 error. -->
    <div class="w-full max-w-3xl bg-amber-50 border border-amber-200 rounded-xl p-5 text-left">
        <p class="text-sm font-bold text-amber-800 flex items-center gap-2 mb-1">
            ⚠️ <?= Text::_('COM_MURUGUARD_SERVER_LIMITS_TITLE') ?>
        </p>
        <p class="text-xs text-amber-700 leading-relaxed mb-3"><?= Text::_('COM_MURUGUARD_SERVER_LIMITS_DESC') ?></p>
        <div class="flex flex-wrap gap-3 mb-3">
            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold <?= $this->serverLimits['execRaisable'] ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-200 text-amber-800' ?>">
                <?= Text::_('COM_MURUGUARD_SERVER_LIMITS_EXEC_LABEL') ?>:
                <?= Text::sprintf('COM_MURUGUARD_SERVER_LIMITS_CURRENT', htmlspecialchars($this->serverLimits['execTimeAfter']) . 's') ?>
                <?= $this->serverLimits['execRaisable'] ? '· ' . Text::_('COM_MURUGUARD_SERVER_LIMITS_OK_BADGE') : '· ' . Text::_('COM_MURUGUARD_SERVER_LIMITS_LOCKED_BADGE') ?>
            </span>
            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold <?= $this->serverLimits['memRaisable'] ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-200 text-amber-800' ?>">
                <?= Text::_('COM_MURUGUARD_SERVER_LIMITS_MEMORY_LABEL') ?>:
                <?= Text::sprintf('COM_MURUGUARD_SERVER_LIMITS_CURRENT', htmlspecialchars($this->serverLimits['memoryAfter'])) ?>
                <?= $this->serverLimits['memRaisable'] ? '· ' . Text::_('COM_MURUGUARD_SERVER_LIMITS_OK_BADGE') : '· ' . Text::_('COM_MURUGUARD_SERVER_LIMITS_LOCKED_BADGE') ?>
            </span>
        </div>
        <p class="text-xs font-bold text-amber-800 mb-1"><?= Text::_('COM_MURUGUARD_SERVER_LIMITS_FIX_TITLE') ?></p>
        <p class="text-xs text-amber-700 leading-relaxed mb-2"><?= Text::_('COM_MURUGUARD_SERVER_LIMITS_FIX_HOST') ?></p>
        <p class="text-xs text-amber-700 leading-relaxed mb-1"><?= Text::_('COM_MURUGUARD_SERVER_LIMITS_FIX_USERINI') ?></p>
        <pre class="text-xs bg-white border border-amber-200 rounded-lg p-3 overflow-x-auto text-gray-700">max_execution_time = 300
memory_limit = 512M</pre>
    </div>
    <?php endif; ?>

    <form action="<?= Route::_($scanUrl) ?>" method="post" id="muruguard-form" class="w-full max-w-3xl flex flex-col items-center gap-3">
        <?= HTMLHelper::_('form.token') ?>
        <input type="hidden" name="areas_submitted" value="1">

        <button type="button" id="muru-open-scan-modal"
                class="inline-flex items-center gap-2 px-8 py-3.5 bg-indigo-600 hover:bg-indigo-700
                       text-white font-bold rounded-xl shadow-lg hover:shadow-xl
                       transition-all duration-200 hover:-translate-y-0.5 text-base">
            🔍 <?= Text::_('COM_MURUGUARD_RUN_SCAN_BTN') ?>
        </button>
        <div class="flex items-center gap-2 text-xs text-gray-400 bg-gray-50 border border-gray-100 rounded-lg px-4 py-2">
            <span>⏱</span>
            <span><?= Text::_('COM_MURUGUARD_SCAN_TIME_NOTE') ?></span>
        </div>
    </form>
</div>

<!-- ══════════════════════════════════════════════════════════════
     SCAN-AREA PICKER MODAL -- opened by #muru-open-scan-modal above.
     Every field inside carries form="muruguard-form" because this
     whole div gets re-parented to <body> at runtime (see script), which
     physically moves it out of that <form>'s DOM subtree; the form=""
     attribute is what keeps these inputs submitting with it regardless
     of where in the document they actually live.
     ══════════════════════════════════════════════════════════════ -->
<div id="muru-scan-modal">
    <div id="muru-scan-modal-backdrop"></div>
    <div id="muru-scan-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="muru-scan-modal-title">
        <div id="muru-scan-modal-header">
            <div id="muru-scan-modal-header-title">
                <span id="muru-scan-modal-header-icon">🗂</span>
                <div>
                    <h3 id="muru-scan-modal-title"><?= Text::_('COM_MURUGUARD_AREAS_HEADER') ?></h3>
                    <p><?= Text::_('COM_MURUGUARD_AREAS_SUBHEADER') ?></p>
                </div>
            </div>
            <button type="button" id="muru-scan-modal-close" aria-label="<?= Text::_('COM_MURUGUARD_MODAL_CLOSE') ?>">✕</button>
        </div>
        <div id="muru-scan-modal-body">
            <div id="muru-scan-modal-selectall">
                <label>
                    <input type="checkbox" id="muru-area-all"
                           class="w-3.5 h-3.5 rounded border-indigo-300 muru-area-chk-all"
                           onclick="document.querySelectorAll('.muru-area-chk').forEach(c=>c.checked=this.checked); muruUpdateAreaCount();">
                    <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
                </label>
            </div>

            <div class="grid gap-4 sm:grid-cols-2">
                <?php foreach ($scanAreas as $groupKey => $group):
                    $meta = $groupIcons[$groupKey] ?? ['icon' => '📦', 'chip' => 'bg-gray-100 text-gray-500'];
                ?>
                    <div class="muru-scan-group">
                        <div class="flex items-center gap-2 mb-2.5">
                            <span class="inline-flex items-center justify-center w-7 h-7 rounded-lg text-sm flex-shrink-0 <?= $meta['chip'] ?>"><?= $meta['icon'] ?></span>
                            <span class="text-[11px] font-bold uppercase tracking-wider text-gray-400"><?= $group['label'] ?></span>
                        </div>
                        <div class="space-y-0.5">
                            <?php foreach ($group['areas'] as $key => $label): ?>
                                <label class="flex items-start gap-2 text-sm text-gray-700 cursor-pointer hover:bg-gray-50 rounded-lg px-2 py-1.5 -mx-2 transition-colors">
                                    <input type="checkbox" name="scan_areas[]" form="muruguard-form"
                                           value="<?= htmlspecialchars($key) ?>"
                                           class="muru-area-chk mt-0.5 w-4 h-4 rounded border-gray-300 flex-shrink-0"
                                           onchange="muruUpdateAreaCount()"
                                           <?= $isAreaChecked($key) ? 'checked' : '' ?>>
                                    <span class="leading-snug"><?= $label ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div id="muru-scan-modal-footer">
            <span class="text-xs text-gray-400">
                <?= Text::sprintf('COM_MURUGUARD_AREA_COUNT_TEXT', '<span id="muru-area-count">' . $totalAreaCount . '</span>', $totalAreaCount) ?>
            </span>
            <button type="submit" form="muruguard-form" id="muru-scan-modal-run"
                    class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg hover:shadow-xl transition-all duration-200 hover:-translate-y-0.5">
                🔍 <?= Text::_('COM_MURUGUARD_RUN_SCAN_BTN') ?>
            </button>
        </div>
    </div>
</div>

<?php else: ?>
<!-- ══════════════════════════════════════════════════════════════
     RESULTS
     ══════════════════════════════════════════════════════════════ -->

<?php
$htaccessChecks = $this->htaccess['checks'] ?? [];
$htaccessCriticalMissing = count(array_filter($htaccessChecks, fn($c) => $c['category'] === 'critical' && !$c['present']));
$htaccessCategoryLabels = [
    'critical' => Text::_('COM_MURUGUARD_HTACCESS_CATEGORY_CRITICAL'),
    'header'   => Text::_('COM_MURUGUARD_HTACCESS_CATEGORY_HEADER'),
];
$htaccessByCategory = ['critical' => [], 'header' => []];
foreach ($htaccessChecks as $c) { $htaccessByCategory[$c['category']][] = $c; }
?>

<!-- Re-scan bar -->
<div class="anim-in flex flex-nowrap items-center justify-between gap-3
            bg-white border border-gray-200 rounded-xl px-5 py-3 mb-6 shadow-sm overflow-x-auto">
    <div class="flex items-center gap-2 text-sm text-gray-600 min-w-0 flex-shrink truncate">
        <span class="text-lg flex-shrink-0">🕐</span>
        <span class="truncate"><?= Text::_('COM_MURUGUARD_LAST_SCANNED_LABEL') ?>
        <span class="font-bold text-gray-900"><?= date('Y-m-d H:i:s', $this->scanStartedAt) ?></span>
        <span class="text-gray-300">·</span>
        <span class="text-gray-400"><?= Text::_('COM_MURUGUARD_CACHED_5MIN') ?></span></span>
        <?php if ($this->cronEnabled): ?>
            <span class="text-gray-300 flex-shrink-0">·</span>
            <button type="button" id="muru-cron-status-badge" class="flex-shrink-0 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-colors" title="<?= Text::_('COM_MURUGUARD_CRON_BADGE_TITLE') ?>">
                ⏰ <?= Text::_('COM_MURUGUARD_CRON_ON_BADGE') ?>
            </button>
        <?php endif; ?>
        <?php if ($this->componentVersion !== ''): ?>
            <span class="text-gray-300 flex-shrink-0">·</span>
            <a href="index.php?option=com_installer&view=update"
               class="flex-shrink-0 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-bold bg-red-600 text-white hover:bg-red-700 transition-colors"
               title="<?= Text::_('COM_MURUGUARD_CHECK_UPDATES_TITLE') ?>">
                🛡️ v<?= htmlspecialchars($this->componentVersion) ?>
                <span class="opacity-50">|</span>
                <?= Text::_('COM_MURUGUARD_CHECK_UPDATES_LINK') ?>
            </a>
        <?php endif; ?>
    </div>
    <div class="flex items-center gap-2 flex-shrink-0">
        <form action="<?= Route::_($rescanUrl) ?>" method="post" id="muruguard-rescan-form" style="margin:0">
            <?= HTMLHelper::_('form.token') ?>
            <button type="submit"
                    class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-indigo-200
                           rounded-lg text-sm font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100
                           transition-colors shadow-sm hover:shadow">
                🔄 <?= Text::_('COM_MURUGUARD_RESCAN_NOW') ?>
            </button>
        </form>
        <a href="index.php?option=com_muruguard&view_panel=ai_assistant"
           id="muru-ai-btn"
           title="<?= Text::_('COM_MURUGUARD_AI_INTEGRATION_TITLE') ?>"
           class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-violet-200
                  rounded-lg text-sm font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100
                  transition-colors shadow-sm hover:shadow">
            🤖 <?= Text::_('COM_MURUGUARD_AI_INTEGRATION') ?>
            <?php if ($this->aiProActive): ?>
                <span class="inline-flex items-center justify-center w-2 h-2 rounded-full bg-emerald-500"></span>
            <?php else: ?>
                <span class="inline-flex items-center px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold">PRO</span>
            <?php endif; ?>
        </a>
        <button type="button" id="muru-open-htaccess-modal"
                class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-emerald-200
                       rounded-lg text-sm font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100
                       transition-colors shadow-sm hover:shadow">
            🛡 <?= Text::_('COM_MURUGUARD_TAB_HTACCESS') ?>
            <?php if ($htaccessCriticalMissing > 0): ?>
                <span class="inline-flex items-center justify-center min-w-4 h-4 px-1 bg-amber-500 text-white text-[10px] font-bold rounded-full"><?= $htaccessCriticalMissing ?></span>
            <?php endif; ?>
        </button>
        <a href="index.php?option=com_muruguard&task=scanner.report"
           target="_blank" rel="noopener"
           title="<?= Text::_('COM_MURUGUARD_REPORT_BTN') ?>"
           class="inline-flex items-center gap-1.5 px-4 py-1.5 border border-sky-200
                  rounded-lg text-sm font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100
                  transition-colors shadow-sm hover:shadow">
            📄 <?= Text::_('COM_MURUGUARD_REPORT_BTN') ?>
            <?php if (!$this->aiProActive): ?>
                <span class="inline-flex items-center px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold">PRO</span>
            <?php endif; ?>
        </a>
    </div>
</div>

<!-- ══════════════════════════════════════════════════════════════
     .HTACCESS HARDENING MODAL -- opened by #muru-open-htaccess-modal
     above. Every missing rule except CSP (advisory-only by design, see
     getHtaccessSuggestions()) can be applied for real via the "Apply"
     button -- see MuruguardHelper::applyHtaccessSuggestion(). Admin-only.
     ══════════════════════════════════════════════════════════════ -->
<div id="muru-htaccess-modal">
    <div id="muru-htaccess-modal-backdrop"></div>
    <div id="muru-htaccess-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="muru-htaccess-modal-title">
        <div id="muru-htaccess-modal-header">
            <div id="muru-htaccess-modal-header-title">
                <span id="muru-htaccess-modal-header-icon">🛡</span>
                <div>
                    <h3 id="muru-htaccess-modal-title"><?= Text::_('COM_MURUGUARD_TAB_HTACCESS') ?></h3>
                    <p><?= Text::_('COM_MURUGUARD_HTACCESS_INFO') ?></p>
                </div>
            </div>
            <button type="button" id="muru-htaccess-modal-close" aria-label="<?= Text::_('COM_MURUGUARD_MODAL_CLOSE') ?>">✕</button>
        </div>
        <div id="muru-htaccess-modal-body">
            <?php if (!$this->htaccess['exists']): ?>
                <div id="muru-htaccess-modal-missing-file">⚠️ <?= Text::sprintf('COM_MURUGUARD_HTACCESS_MISSING_FILE', htmlspecialchars($this->htaccess['path'])) ?></div>
            <?php endif; ?>
            <?php
            // Every check except CSP (silently breaks legitimate sites if
            // applied blindly -- see its own docblock in
            // getHtaccessSuggestions()) can be written for real, but HSTS
            // additionally only makes sense once the site is actually on
            // HTTPS -- matches applyHtaccessSuggestion()'s own server-side
            // guard exactly, so the button is never shown for a case the
            // backend would just reject anyway.
            $isHttps = Uri::getInstance()->isSsl();
            $isApplyable = function (array $c) use ($isHttps): bool {
                if ($c['id'] === 'header_csp') return false;
                if ($c['id'] === 'header_hsts' && !$isHttps) return false;
                return true;
            };
            ?>
            <?php foreach ($htaccessByCategory as $cat => $items): if (empty($items)) continue; ?>
                <div class="muru-hc-category"><?= $htaccessCategoryLabels[$cat] ?></div>
                <?php foreach ($items as $c): ?>
                    <details class="muru-hc-item <?= $c['present'] ? 'present' : 'missing' ?>">
                        <summary>
                            <span><?= $c['present'] ? '✅' : '⚠️' ?> <?= htmlspecialchars($c['label']) ?></span>
                            <span class="muru-hc-status <?= $c['present'] ? 'present' : 'missing' ?>" data-htaccess-status="<?= htmlspecialchars($c['id']) ?>">
                                <?= $c['present'] ? Text::_('COM_MURUGUARD_HTACCESS_PRESENT') : Text::_('COM_MURUGUARD_HTACCESS_MISSING') ?>
                            </span>
                        </summary>
                        <div class="muru-hc-body" data-htaccess-item="<?= htmlspecialchars($c['id']) ?>">
                            <p class="muru-hc-explain"><?= htmlspecialchars($c['explanation']) ?></p>
                            <?php if (!$c['present']): ?>
                                <p class="muru-hc-rule-label"><?= Text::_('COM_MURUGUARD_HTACCESS_SUGGESTED_RULE') ?></p>
                                <pre class="muru-hc-rule"><?= htmlspecialchars($c['suggestion']) ?></pre>
                                <?php if ($isApplyable($c) && $this->canAdmin): ?>
                                    <div class="muru-hc-actions">
                                        <button type="button" class="muru-hc-apply-btn" data-check-id="<?= htmlspecialchars($c['id']) ?>">
                                            ⚡ <?= Text::_('COM_MURUGUARD_HTACCESS_APPLY_BTN') ?>
                                        </button>
                                        <span class="muru-hc-apply-result"></span>
                                    </div>
                                    <p class="muru-hc-apply-note"><?= Text::_('COM_MURUGUARD_HTACCESS_APPLY_NOTE') ?></p>
                                <?php elseif ($c['id'] === 'header_csp'): ?>
                                    <p class="muru-hc-apply-note"><?= Text::_('COM_MURUGUARD_HTACCESS_CSP_NO_APPLY') ?></p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </details>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
        <details style="margin: 0 24px 16px;">
            <summary style="cursor:pointer; font-size:12px; font-weight:700; color:#4338ca;"><?= Text::_('COM_MURUGUARD_NGINX_SNIPPET_TOGGLE') ?></summary>
            <p style="font-size:11.5px; color:#6b7280; margin:8px 0;"><?= Text::_('COM_MURUGUARD_NGINX_SNIPPET_DESC') ?></p>
            <pre style="background:#0f172a; color:#e2e8f0; padding:12px; border-radius:8px; font-size:11px; overflow-x:auto; white-space:pre; line-height:1.5;"><?= htmlspecialchars(\MuruguardHelper::getNginxHardeningSnippet()) ?></pre>
        </details>
        <div id="muru-htaccess-modal-footer"><?= Text::sprintf('COM_MURUGUARD_HTACCESS_NOTE', htmlspecialchars($this->htaccess['path'])) ?></div>
    </div>
</div>

<!-- Single-glance security score -->
<?php if (!empty($this->securityScore['label'])):
    $scoreVal = (int) $this->securityScore['score'];
    $scoreLabelKey = $scoreVal >= 85 ? 'COM_MURUGUARD_SECURITY_SCORE_LABEL_GOOD' : ($scoreVal >= 60 ? 'COM_MURUGUARD_SECURITY_SCORE_LABEL_NEEDS_ATTENTION' : 'COM_MURUGUARD_SECURITY_SCORE_LABEL_AT_RISK');
    $scoreColor = $scoreVal >= 85 ? ['bg' => 'bg-emerald-500', 'text' => 'text-emerald-700', 'soft' => 'bg-emerald-50', 'ring' => 'ring-emerald-200']
        : ($scoreVal >= 60 ? ['bg' => 'bg-amber-500', 'text' => 'text-amber-700', 'soft' => 'bg-amber-50', 'ring' => 'ring-amber-200']
        : ['bg' => 'bg-red-500', 'text' => 'text-red-700', 'soft' => 'bg-red-50', 'ring' => 'ring-red-200']);
?>
<div class="bg-white border border-gray-200 rounded-xl shadow-sm p-5 mb-5 flex items-center gap-5 flex-wrap">
    <div class="flex items-center gap-3 shrink-0">
        <span class="inline-flex items-center justify-center w-14 h-14 rounded-full <?= $scoreColor['soft'] ?> ring-4 <?= $scoreColor['ring'] ?>">
            <span class="text-lg font-black <?= $scoreColor['text'] ?>"><?= $scoreVal ?></span>
        </span>
        <div>
            <div class="text-xs font-bold text-gray-400 uppercase tracking-wide"><?= Text::_('COM_MURUGUARD_SECURITY_SCORE_TITLE') ?></div>
            <div class="text-sm font-bold <?= $scoreColor['text'] ?>"><?= Text::_($scoreLabelKey) ?></div>
        </div>
    </div>
    <?php if (!empty($this->securityScore['issues'])): ?>
        <ul class="flex flex-wrap gap-1.5 text-xs text-gray-600">
            <?php foreach ($this->securityScore['issues'] as $issue): ?>
                <li class="inline-flex items-center px-2 py-1 rounded-md bg-gray-50 border border-gray-200"><?= htmlspecialchars($issue) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_SECURITY_SCORE_NO_ISSUES') ?></p>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Stats grid -->
<?php
$fc = count($fileFindings);
$suCount = count($suspiciousSU);
$menuCount = count($dbFindings['menu_xss'] ?? []);
$templateStyleXssCount = count($dbFindings['template_style_xss'] ?? []);
$assetCount = count($dbFindings['sppb_assets'] ?? []) + count($dbFindings['rogue_iconfont'] ?? []);
$deface = count($dbFindings['template_defacement'] ?? []);
$stats = [
    ['icon'=>'📁', 'num'=>$fc,         'label'=>Text::_('COM_MURUGUARD_LABEL_SUSPICIOUS_FILES'),
     'sub'=>$fc>0 ? Text::sprintf('COM_MURUGUARD_STAT_SUB_HIGH_MEDIUM', $this->highCount, $this->medCount) : Text::_('COM_MURUGUARD_STAT_SUB_FS_CLEAN'),
     'danger'=>$fc>0],
    ['icon'=>'👤', 'num'=>$suCount,    'label'=>Text::_('COM_MURUGUARD_LABEL_ROGUE_SUPER_USERS'),
     'sub'=>$suCount>0 ? Text::_('COM_MURUGUARD_STAT_SUB_SU_REVIEW') : Text::_('COM_MURUGUARD_STAT_SUB_SU_NORMAL'),
     'danger'=>$suCount>0],
    ['icon'=>'🔗', 'num'=>$menuCount,  'label'=>Text::_('COM_MURUGUARD_LABEL_MENU_XSS_ROWS'),
     'sub'=>$menuCount>0 ? Text::_('COM_MURUGUARD_STAT_SUB_MENU_FOUND') : Text::_('COM_MURUGUARD_STAT_SUB_MENU_CLEAN'),
     'danger'=>$menuCount>0],
    ['icon'=>'🗄',  'num'=>$assetCount,'label'=>Text::_('COM_MURUGUARD_LABEL_ROGUE_ASSET_ROWS'),
     'sub'=>$assetCount>0 ? Text::_('COM_MURUGUARD_STAT_SUB_ASSET_TAINTED') : Text::_('COM_MURUGUARD_STAT_SUB_ASSET_CLEAN'),
     'danger'=>$assetCount>0],
    ['icon'=>'🖼',  'num'=>$deface,    'label'=>Text::_('COM_MURUGUARD_LABEL_TEMPLATE_DEFACEMENT'),
     'sub'=>$deface>0 ? Text::_('COM_MURUGUARD_STAT_SUB_TEMPLATE_MODIFIED') : Text::_('COM_MURUGUARD_STAT_SUB_TEMPLATE_INTACT'),
     'danger'=>$deface>0],
];
?>
<div class="anim-in grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
    <?php foreach ($stats as $i => $s): ?>
    <div class="bg-white rounded-xl border <?= $s['danger'] ? 'border-red-200 shadow-red-50' : 'border-green-100' ?> shadow-sm p-4"
         style="animation-delay:<?= $i * 60 ?>ms">
        <div class="flex items-start justify-between mb-2">
            <span class="text-2xl"><?= $s['icon'] ?></span>
            <span class="<?= $s['danger'] ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600' ?> text-xs font-bold px-2 py-0.5 rounded-full">
                <?= $s['danger'] ? '⚠ ' . Text::_('COM_MURUGUARD_STAT_ALERT') : '✓ ' . Text::_('COM_MURUGUARD_STAT_OK') ?>
            </span>
        </div>
        <div class="text-3xl font-extrabold <?= $s['danger'] ? 'text-red-600' : 'text-green-600' ?> leading-none mb-1">
            <?= (int)$s['num'] ?>
        </div>
        <div class="text-xs font-semibold text-gray-700 mb-0.5"><?= $s['label'] ?></div>
        <div class="text-[11px] text-gray-400"><?= $s['sub'] ?></div>
    </div>
    <?php endforeach; ?>
</div>

<?php
/* ── Tab navigation ── */
$sig = \MuruguardHelper::getSignatures();
// Not-deletable = an auto-cleanable infection pattern, OR a genuinely
// required core/template entry file that deleteTargets() refuses to
// touch regardless, OR a known code-area file (component/module/plugin/
// library/template source) flagged ONLY by a content-signature match --
// i.e. a legitimate, actively-used file with something malicious injected
// into it, not a foreign dropped file, so deleting it would break real
// site functionality even though this scanner has no auto-clean pattern
// for this particular infection shape yet. Every finding lands in
// exactly one of the two tabs below -- nothing silently disappears, and
// "Suspicious Files" only ever lists things the Delete button can
// actually safely act on.
$registeredTemplates = $this->registeredTemplates;
$notDeletable = function ($f) use ($sig, $registeredTemplates) {
    if (\MuruguardHelper::isCleanablePattern($f['reasons'] ?? [$f['reason']])) return true;

    $protected = \MuruguardHelper::isProtectedEntryPath($f['rel'], $sig, $f['abs'] ?? null, $registeredTemplates);
    if ($protected) return true;

    // A template's own root index.php is a special case isProtectedEntryPath()
    // already makes a precise, positive determination for (via the
    // #__extensions registry and templateDetails.xml manifest checks) --
    // that determination is authoritative and must not be second-guessed
    // by the more general "content-signature-only match in a code area"
    // caution below, which exists for a DIFFERENT scenario (a real,
    // legitimately-installed component/module/plugin/template file with
    // something injected into it). A confirmed-fake template folder's
    // index.php is never that.
    $isTemplateEntryFile = (bool) preg_match(
        '#^(administrator/)?templates/[^/]+/index\.php$#i',
        str_replace('\\', '/', $f['rel'])
    );
    if ($isTemplateEntryFile) return false;

    return \MuruguardHelper::isContentOnlyCodeAreaFinding($f['rel'], $f['reasons'] ?? [$f['reason']], $sig);
};
$cleanableFindings = array_filter($fileFindings, $notDeletable);
$cleanableCount = count($cleanableFindings);
$deletableFindings = array_filter($fileFindings, fn($f) => !$notDeletable($f));
$deletableCount = count($deletableFindings);
$deletableHigh = count(array_filter($deletableFindings, fn($f) => $f['confidence'] === 'high'));
$deletableMed  = $deletableCount - $deletableHigh;
$vulnCount = count($dbFindings['vulnerable_extensions'] ?? []);
$tabs = [
    ['id' => 'files',      'emoji' => '📁', 'title' => Text::_('COM_MURUGUARD_LABEL_SUSPICIOUS_FILES'), 'count' => $deletableCount],
    ['id' => 'cleanable',  'emoji' => '🧹', 'title' => Text::_('COM_MURUGUARD_TAB_CLEANABLE_FILES'),     'count' => $cleanableCount],
    ['id' => 'users',      'emoji' => '👤', 'title' => Text::_('COM_MURUGUARD_TAB_SUPER_USERS'),         'count' => $suCount],
    ['id' => 'menu',       'emoji' => '🔗', 'title' => Text::_('COM_MURUGUARD_TAB_MENU_XSS'),            'count' => $menuCount],
    ['id' => 'assets',     'emoji' => '🗄', 'title' => Text::_('COM_MURUGUARD_TAB_SPPB_ASSETS'),         'count' => $assetCount],
    ['id' => 'template',   'emoji' => '🖼', 'title' => Text::_('COM_MURUGUARD_TAB_DEFACEMENT'),          'count' => $deface],
    ['id' => 'vulns',      'emoji' => '🛑', 'title' => Text::_('COM_MURUGUARD_TAB_VULNERABILITIES'),     'count' => $vulnCount],
];
// Open on the first tab that has findings; otherwise the first tab.
$activeTab = $tabs[0]['id'];
foreach ($tabs as $t) { if ($t['count'] > 0) { $activeTab = $t['id']; break; } }
?>
<div class="anim-in bg-white border border-gray-200 rounded-xl shadow-sm mb-5 overflow-hidden">
    <div class="flex flex-wrap gap-1 p-1.5 bg-gray-50 border-b border-gray-100" role="tablist">
        <?php foreach ($tabs as $t): ?>
            <button type="button"
                    class="muru-tab flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
                    data-tab="<?= $t['id'] ?>" role="tab">
                <span><?= $t['emoji'] ?></span>
                <span><?= $t['title'] ?></span>
                <?php if ($t['count'] > 0): ?>
                    <span class="muru-tab-badge inline-flex items-center justify-center min-w-5 h-5 px-1.5 bg-red-500 text-white text-[10px] font-bold rounded-full"><?= $t['count'] ?></span>
                <?php else: ?>
                    <span class="muru-tab-badge inline-flex items-center justify-center w-5 h-5 bg-green-500 text-white text-[10px] font-bold rounded-full">✓</span>
                <?php endif; ?>
            </button>
        <?php endforeach; ?>
    </div>
</div>

<?php
/* ── Helper: tab panel wrapper (ids match the $tabs 'id' above) ── */
function muru_section_open(string $id, string $emoji, string $title, int $count): void {
    $panel = preg_replace('/^sec-/', '', $id);
    // muru-section-badge is the stable hook the "Mark as Safe" JS uses to
    // decrement this panel's own header count in place -- see
    // muruUpdateSectionBadge() below, which mirrors this exact
    // count>0-vs-zero markup so a live update looks identical to a fresh
    // page render.
    $dot = $count > 0
        ? '<span class="muru-section-badge inline-flex items-center justify-center min-w-5 h-5 px-1.5 bg-red-500 text-white text-[10px] font-bold rounded-full ml-2">' . $count . '</span>'
        : '<span class="muru-section-badge inline-flex items-center justify-center w-5 h-5 bg-green-500 text-white text-[10px] font-bold rounded-full ml-2">✓</span>';
    echo '<section id="' . $id . '" class="muru-panel hidden bg-white border border-gray-200 rounded-xl shadow-sm mb-4 overflow-hidden anim-in" data-panel="' . $panel . '">';
    echo '<div class="flex items-center gap-2 font-bold text-gray-800 p-3 border-b border-gray-100">' . $emoji . ' <span>' . $title . '</span>' . $dot . '</div>';
    echo '<div class="p-3">';
}
function muru_section_close(): void {
    echo '</div></section>';
}

/**
 * "Mark as Safe" button for one finding row -- deliberately a plain
 * <button>, not a nested <form>, since every table this renders inside
 * already sits inside the tab's own bulk-select/delete <form>, and HTML
 * doesn't allow nested forms (it would silently break the outer one).
 * A shared, delegated JS click handler (see the page-bottom script)
 * submits it via fetch() instead. $reasonsList must be the EXACT same
 * list already shown for this finding -- fingerprintReasons() is what
 * ties the dismissal to this specific reviewed content, so it stops
 * applying if the same path/row later matches something different.
 */
function muru_mark_safe_button(string $category, string $identifier, array $reasonsList, bool $canEdit): void {
    if (!$canEdit) return;
    $fingerprint = \MuruguardHelper::fingerprintReasons($reasonsList);
    ?>
    <button type="button" class="muru-mark-safe-btn flex-shrink-0 inline-flex items-center gap-1 h-7 px-2 rounded-lg border border-gray-200 bg-white text-[11px] font-medium text-gray-500 hover:text-emerald-700 hover:bg-emerald-50 hover:border-emerald-200 transition-colors whitespace-nowrap"
            data-fp-category="<?= htmlspecialchars($category) ?>"
            data-fp-identifier="<?= htmlspecialchars($identifier) ?>"
            data-fp-fingerprint="<?= htmlspecialchars($fingerprint) ?>"
            title="<?= Text::_('COM_MURUGUARD_FP_MARK_BTN') ?>" aria-label="<?= Text::_('COM_MURUGUARD_FP_MARK_BTN') ?>">
        <span aria-hidden="true">✅</span><span><?= Text::_('COM_MURUGUARD_FP_MARK_BTN_LABEL') ?></span>
    </button>
    <?php
}

/**
 * Multi-select bulk-action buttons (Mark Selected as Safe, optionally
 * Check via AI) for a results tab's own toolbar, next to its existing
 * Select All / Delete Selected controls. Reads whichever checkboxes in
 * the enclosing .muru-panel carry the shared muru-bulk-chk class -- see
 * the JS below -- regardless of which tab-specific class that same
 * checkbox also carries for its own existing delete/clean form, so this
 * one PHP helper and one JS block covers every tab without per-tab
 * wiring. Caller passes whatever condition already gates that panel's
 * own checkbox column -- there's no new permission model here, bulk
 * actions are only ever offered where a row-level "Mark as Safe" button
 * already would be. AI check is further limited to file-based findings
 * (Suspicious Files / Cleanable Files) since it reads real file content
 * -- a database-row finding has none.
 */
function muru_bulk_toolbar_buttons(bool $show, bool $aiEligible, bool $aiAvailable): void {
    if (!$show) return;
    ?>
    <span class="muru-bulk-count text-xs text-gray-400">0 <?= Text::_('COM_MURUGUARD_BULK_SELECTED') ?></span>
    <button type="button" class="muru-bulk-mark-safe-btn inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 transition-colors disabled:opacity-40 disabled:cursor-not-allowed" disabled>
        ✅ <?= Text::_('COM_MURUGUARD_BULK_MARK_SAFE_BTN') ?>
    </button>
    <?php if ($aiEligible && $aiAvailable): ?>
    <button type="button" class="muru-bulk-ai-check-btn inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-100 transition-colors disabled:opacity-40 disabled:cursor-not-allowed" disabled>
        🤖 <?= Text::_('COM_MURUGUARD_BULK_AI_CHECK_BTN') ?>
    </button>
    <?php endif; ?>
    <?php
}

/**
 * Row-level "🤖 Ask AI" shortcut -- available on every edition now (Pro
 * routes through the dashboard's own provider; a non-Pro site with a
 * saved Gemini key routes directly to Gemini -- see reviewOneFinding() in
 * the controller). Carries the exact same data-path/data-confidence/
 * data-reasons as the 🧬 Code Issues button (see muruOpenCodeModal()'s
 * JS), so clicking it opens the same modal and immediately runs the
 * review, instead of requiring Code Issues -> Ask AI as two separate
 * clicks. File findings only -- a directory has no content for the AI
 * to read. Always rendered even with neither Pro nor a Gemini key
 * configured -- the click handler itself (muruOpenCodeModal()'s JS)
 * shows a "configure a key" prompt on the resulting ai_not_configured
 * error rather than hiding the button and leaving no path to discover
 * the feature exists at all.
 */
function muru_ai_review_shortcut_button(string $relPath, string $confidence, array $blocksHtml): void {
    ?>
    <button type="button" class="muru-ai-review-shortcut flex-shrink-0 inline-flex items-center justify-center w-7 h-7 rounded-lg border border-indigo-200 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-colors"
            data-path="<?= htmlspecialchars($relPath) ?>"
            data-confidence="<?= htmlspecialchars($confidence) ?>"
            data-reasons="<?= htmlspecialchars(json_encode($blocksHtml), ENT_QUOTES) ?>"
            title="<?= Text::_('COM_MURUGUARD_AI_REVIEW_ROW_BTN') ?>" aria-label="<?= Text::_('COM_MURUGUARD_AI_REVIEW_ROW_BTN') ?>">
        <span aria-hidden="true">🤖</span>
    </button>
    <?php
}

/** Shared <tr> markup for a file finding -- used by both the Suspicious
 *  Files and Cleanable Files tabs so the two stay visually identical.
 *  $showCleanPreview is only turned on for the Cleanable Files tab, and
 *  only actually renders a preview when the file's CURRENT on-disk
 *  content still has a pattern this scanner can auto-repair -- it never
 *  shows a preview for something Clean can't actually fix. */
function muru_render_file_row(array $f, bool $showCleanPreview = false, bool $showCheckbox = true, ?array $registeredTemplates = null, bool $canEdit = false, int $rowIndex = 0): void {
    $pathDir  = dirname($f['rel']);
    $pathBase = basename($f['rel']);
    $isProtectedEntry = \MuruguardHelper::isProtectedEntryPath($f['rel'], \MuruguardHelper::getSignatures(), $f['abs'] ?? null, $registeredTemplates);
    $reasonsList = $f['reasons'] ?? [$f['reason']];
    $blocksHtml  = array_map(fn($r) => \MuruguardHelper::formatReasonForDisplay($r), $reasonsList);
    $diffHtml = null;
    if ($showCleanPreview && $f['type'] !== 'dir') {
        $diffHtml = \MuruguardHelper::previewCleanDiff($f['abs']);
        if ($diffHtml !== null) $blocksHtml[] = $diffHtml;
    }
    $reasonsJson = htmlspecialchars(json_encode($blocksHtml), ENT_QUOTES);
    ?>
    <tr class="muru-paginated-row hover:bg-gray-50/60 transition-colors <?= $f['confidence']==='high' ? 'bg-red-50/30' : '' ?>" data-row-index="<?= $rowIndex ?>">
        <td class="px-4 py-3">
            <?php if ($showCheckbox): ?>
            <input type="checkbox" class="muru-file-chk muru-bulk-chk w-4 h-4 rounded border-gray-300"
                   name="targets[]" value="<?= htmlspecialchars($f['rel']) ?>"
                   data-confidence="<?= htmlspecialchars($f['confidence']) ?>">
            <?php endif; ?>
        </td>
        <td class="px-4 py-3">
            <div class="flex items-center gap-1.5 max-w-md">
                <span class="flex-shrink-0 text-sm"><?= $f['type']==='dir' ? '📂' : '📄' ?></span>
                <div class="min-w-0 flex-1 bg-gray-50 border border-gray-100 rounded-lg px-2.5 py-1.5 overflow-hidden">
                    <div class="font-mono text-xs break-all leading-snug" title="<?= htmlspecialchars($f['rel']) ?>">
                        <?php if ($pathDir !== '.'): ?>
                            <span class="text-gray-400"><?= htmlspecialchars($pathDir) ?>/</span>
                        <?php endif; ?>
                        <span class="text-gray-800 font-semibold"><?= htmlspecialchars($pathBase) ?></span>
                    </div>
                    <?php if ($isProtectedEntry): ?>
                        <div class="mt-1 inline-flex items-center gap-1 text-[10px] font-bold text-indigo-600">
                            🛡 <?= Text::_('COM_MURUGUARD_REQUIRED_FILE_BADGE') ?>
                        </div>
                    <?php endif; ?>
                </div>
                <button type="button"
                        class="muru-copy-btn flex-shrink-0 w-7 h-7 inline-flex items-center justify-center rounded-lg text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                        data-copy="<?= htmlspecialchars($f['rel']) ?>" title="<?= Text::_('COM_MURUGUARD_COPY_PATH') ?>" aria-label="<?= Text::_('COM_MURUGUARD_COPY_PATH') ?>">
                    <span class="muru-copy-icon">📋</span>
                </button>
            </div>
        </td>
        <td class="px-4 py-3">
            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-gray-100 text-gray-600">
                <?= $f['type']==='dir' ? '📂 ' . Text::_('COM_MURUGUARD_TYPE_DIR') : '📄 ' . Text::_('COM_MURUGUARD_TYPE_FILE') ?>
            </span>
        </td>
        <td class="px-4 py-3">
            <?php if ($f['confidence']==='high'): ?>
                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-700">🔴 <?= Text::_('COM_MURUGUARD_CONFIDENCE_HIGH') ?></span>
            <?php else: ?>
                <span class="min-w-[80px] text-center inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-700">🟡 <?= Text::_('COM_MURUGUARD_CONFIDENCE_MEDIUM') ?></span>
            <?php endif; ?>
        </td>
        <td class="px-4 py-3 text-xs">
            <div class="text-amber-700 mb-1.5"><?= htmlspecialchars(\MuruguardHelper::shortReasonLabel($reasonsList)) ?></div>
            <button type="button" class="muru-code-issues-btn inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold <?= $diffHtml !== null ? 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?> transition-colors"
                    data-path="<?= htmlspecialchars($f['rel']) ?>"
                    data-confidence="<?= htmlspecialchars($f['confidence']) ?>"
                    data-reasons="<?= $reasonsJson ?>"
                    data-type="<?= htmlspecialchars($f['type']) ?>">
                🧬 <?= Text::_('COM_MURUGUARD_CODE_ISSUES_BTN') ?><?= count($reasonsList) > 1 ? ' (' . count($reasonsList) . ')' : '' ?><?= $diffHtml !== null ? ' + 🔍 ' . Text::_('COM_MURUGUARD_PREVIEW_LABEL') : '' ?>
            </button>
        </td>
        <td class="px-4 py-3 text-xs text-gray-500"><?= \MuruguardHelper::humanSize($f['size']) ?></td>
        <td class="px-4 py-3 text-xs text-gray-400"><?= $f['mtime'] ? date('Y-m-d H:i',$f['mtime']) : '—' ?></td>
        <td class="px-4 py-3">
            <div class="flex items-center gap-1.5">
                <?php if ($f['type'] !== 'dir') muru_ai_review_shortcut_button($f['rel'], $f['confidence'], $blocksHtml); ?>
                <?php
                // Only offered when this exact finding is what put the
                // file here -- checkCoreFileChecksum()'s own reason text
                // always starts this way (see the helper), so matching
                // on that prefix is precise, not a guess at intent.
                $hasChecksumMismatch = false;
                foreach ($reasonsList as $r) {
                    if (is_string($r) && strpos($r, 'Core file checksum mismatch') === 0) { $hasChecksumMismatch = true; break; }
                }
                if ($hasChecksumMismatch && $canEdit && $f['type'] !== 'dir'):
                ?>
                <button type="button" class="muru-restore-core-btn flex-shrink-0 inline-flex items-center justify-center w-7 h-7 rounded-lg border border-emerald-200 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors"
                        data-rel-path="<?= htmlspecialchars($f['rel']) ?>"
                        title="<?= Text::_('COM_MURUGUARD_RESTORE_CORE_BTN') ?>" aria-label="<?= Text::_('COM_MURUGUARD_RESTORE_CORE_BTN') ?>">
                    <span aria-hidden="true">♻️</span>
                </button>
                <?php endif; ?>
                <?php muru_mark_safe_button('file', $f['rel'], $reasonsList, $canEdit); ?>
            </div>
        </td>
    </tr>
    <?php
}
?>

<!-- ── 1. Files ──────────────────────────────────────────────── -->
<?php muru_section_open('sec-files', '📁', Text::_('COM_MURUGUARD_SECTION_SUSPICIOUS_FILES_FOLDERS'), $deletableCount); ?>
<?php if (empty($deletableFindings)): ?>
    <div class="flex items-center gap-3 text-green-700 bg-green-50 rounded-xl p-[10px]">
        <span class="text-2xl">✅</span>
        <span class="font-medium"><?= Text::_('COM_MURUGUARD_NO_DELETABLE_FILES') ?></span>
    </div>
<?php else: ?>
    <?php $tag = $this->canDelete ? 'form' : 'div'; ?>
    <<?= $tag ?><?php if ($this->canDelete): ?> action="index.php?option=com_muruguard&task=scanner.delete" method="post" id="muru-files-form"
          onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_CONFIRM_DELETE_FILES') ?>');"<?php endif; ?>>
        <div class="flex items-center justify-between mb-3">
            <?php if ($this->canDelete): ?>
            <div class="flex items-center gap-3">
                <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                    <input type="checkbox" id="muru-files-select-all" class="w-4 h-4 rounded border-gray-300"
                           onclick="document.querySelectorAll('#muru-files-form .muru-file-chk').forEach(c=>c.checked=this.checked); muruUpdatePanelToolbar(this.closest('.muru-panel'));">
                    <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
                </label>
                <button type="button"
                        class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold text-red-700 bg-red-50 hover:bg-red-100 border border-red-100 transition-colors"
                        onclick="document.querySelectorAll('#muru-files-form .muru-file-chk').forEach(function(c){c.checked = c.getAttribute('data-confidence') === 'high';}); document.getElementById('muru-files-select-all').checked = false; muruUpdatePanelToolbar(this.closest('.muru-panel'));">
                    🔴 <?= Text::_('COM_MURUGUARD_SELECT_HIGH_ONLY') ?>
                </button>
                <button type="submit"
                        class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold text-white bg-red-600 hover:bg-red-700 shadow-sm transition-colors">
                    🗑 <?= Text::_('COM_MURUGUARD_DELETE_SELECTED_BTN') ?>
                </button>
                <?php muru_bulk_toolbar_buttons($this->canEdit, true, $this->aiAvailable); ?>
            </div>
            <?php else: ?>
            <span></span>
            <?php endif; ?>
            <div class="flex items-center gap-2 text-xs text-gray-500">
                <span class="inline-flex items-center gap-1 px-2 py-0.5 bg-red-100 text-red-700 rounded-full font-semibold">🔴 <?= Text::sprintf('COM_MURUGUARD_COUNT_HIGH', $deletableHigh) ?></span>
                <span class="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full font-semibold">🟡 <?= Text::sprintf('COM_MURUGUARD_COUNT_MEDIUM', $deletableMed) ?></span>
            </div>
        </div>
        <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-4">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="w-10 px-4 py-3"></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_PATH') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_TYPE') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_SEVERITY') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_REASON') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_SIZE') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_MODIFIED') ?></th>
                        <th class="w-10 px-4 py-3"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50" id="muru-files-tbody">
                <?php $muruDeletableIdx = 0; foreach ($deletableFindings as $f): muru_render_file_row($f, false, $this->canDelete, $registeredTemplates, $this->canEdit, $muruDeletableIdx++); endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php muru_pagination_controls('muru-files-tbody', $deletableCount); ?>
        <?php if ($this->canDelete): ?>
        <?= HTMLHelper::_('form.token') ?>
        <div class="flex items-center gap-3">
            <button type="submit"
                    class="inline-flex items-center gap-2 px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-bold rounded-xl shadow transition-colors">
                🗑 <?= Text::_('COM_MURUGUARD_BTN_DELETE_SELECTED') ?>
            </button>
            <span class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_DELETE_HINT') ?></span>
        </div>
        <?php else: ?>
        <div class="flex items-center gap-2 text-xs text-gray-500">
            <span class="text-base">🔒</span>
            <span><?= Text::_('COM_MURUGUARD_LOCKED_DELETE') ?></span>
        </div>
        <?php endif; ?>
    </<?= $tag ?>>
<?php endif; ?>
<?php muru_section_close(); ?>

<!-- ── 1b. Cleanable Files ──────────────────────────────────────── -->
<?php muru_section_open('sec-cleanable', '🧹', Text::_('COM_MURUGUARD_TAB_CLEANABLE_FILES'), $cleanableCount); ?>
<?php if (empty($cleanableFindings)): ?>
    <div class="flex items-center gap-3 text-green-700 bg-green-50 rounded-xl p-[10px]">
        <span class="text-2xl">✅</span>
        <span class="font-medium"><?= Text::_('COM_MURUGUARD_NO_CLEANABLE_FILES') ?></span>
    </div>
<?php else: ?>
    <div class="flex items-center gap-3 bg-indigo-50 border border-indigo-100 rounded-xl px-4 py-3 mb-4 text-xs text-indigo-800">
        <span class="text-lg flex-shrink-0">ℹ️</span>
        <span><?= Text::_('COM_MURUGUARD_CLEANABLE_INFO') ?></span>
    </div>
    <?php $tag = $this->canEdit ? 'form' : 'div'; ?>
    <<?= $tag ?><?php if ($this->canEdit): ?> action="index.php?option=com_muruguard&task=scanner.cleancode" method="post" id="muru-cleancode-form"
          onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_CONFIRM_CLEAN_FILES') ?>');"<?php endif; ?>>
        <div class="flex items-center justify-between mb-3">
            <?php if ($this->canEdit): ?>
            <div class="flex items-center gap-3">
                <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                    <input type="checkbox" class="w-4 h-4 rounded border-gray-300"
                           onclick="document.querySelectorAll('#sec-cleanable .muru-file-chk').forEach(c=>c.checked=this.checked); muruUpdatePanelToolbar(this.closest('.muru-panel'));">
                    <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
                </label>
                <button type="submit"
                        class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-colors">
                    🧹 <?= Text::_('COM_MURUGUARD_CLEAN_SELECTED_BTN') ?>
                </button>
                <?php muru_bulk_toolbar_buttons(true, true, $this->aiAvailable); ?>
            </div>
            <?php else: ?>
            <span></span>
            <?php endif; ?>
            <span class="text-xs text-gray-500"><?= $cleanableCount ?> <?= Text::_($cleanableCount === 1 ? 'COM_MURUGUARD_FILES_ELIGIBLE' : 'COM_MURUGUARD_FILES_ELIGIBLE_PLURAL') ?></span>
        </div>
        <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-4">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="w-10 px-4 py-3"></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_PATH') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_TYPE') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_SEVERITY') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_REASON') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_SIZE') ?></th>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_('COM_MURUGUARD_COL_MODIFIED') ?></th>
                        <th class="w-10 px-4 py-3"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50" id="muru-cleanable-tbody">
                <?php $muruCleanableIdx = 0; foreach ($cleanableFindings as $f): muru_render_file_row($f, true, $this->canEdit, $registeredTemplates, $this->canEdit, $muruCleanableIdx++); endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php muru_pagination_controls('muru-cleanable-tbody', $cleanableCount); ?>
        <?php if ($this->canEdit): ?>
        <?= HTMLHelper::_('form.token') ?>
        <div class="flex items-center gap-3">
            <button type="submit"
                    class="inline-flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold rounded-xl shadow transition-colors">
                🧹 <?= Text::_('COM_MURUGUARD_CLEAN_SELECTED_BTN') ?>
            </button>
            <span class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_CLEAN_HINT') ?></span>
        </div>
        <?php else: ?>
        <div class="flex items-center gap-2 text-xs text-gray-500">
            <span class="text-base">🔒</span>
            <span><?= Text::_('COM_MURUGUARD_LOCKED_EDIT_FILES') ?></span>
        </div>
        <?php endif; ?>
    </<?= $tag ?>>
<?php endif; ?>
<?php muru_section_close(); ?>

<!-- ── 2. Super Users ─────────────────────────────────────────── -->
<?php muru_section_open('sec-users', '👤', Text::_('COM_MURUGUARD_SECTION_SUPER_USER_ACCOUNTS'), $suCount); ?>
<?php if (empty($dbFindings['superusers'])): ?>
    <div class="flex items-center gap-3 text-green-700 bg-green-50 rounded-xl p-[10px]">
        <span class="text-2xl">✅</span><span class="font-medium"><?= Text::_('COM_MURUGUARD_NO_SUPERUSERS_FOUND') ?></span>
    </div>
<?php else: ?>
    <?php $suspiciousUserCount = count(array_filter($dbFindings['superusers'], fn($u) => $u['suspicious'])); ?>
    <?php if ($this->canEdit && $suspiciousUserCount > 0): ?>
    <div class="flex items-center gap-3 mb-3">
        <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
            <input type="checkbox" class="w-4 h-4 rounded border-gray-300"
                   onclick="document.querySelectorAll('#sec-users .muru-bulk-chk').forEach(c=>c.checked=this.checked); muruUpdatePanelToolbar(this.closest('.muru-panel'));">
            <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
        </label>
        <?php muru_bulk_toolbar_buttons(true, false, $this->aiAvailable); ?>
    </div>
    <?php endif; ?>
    <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-3">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-100">
                    <th class="w-10 px-4 py-3"></th>
                    <?php foreach (['COM_MURUGUARD_COL_ID','COM_MURUGUARD_COL_NAME','COM_MURUGUARD_COL_USERNAME','COM_MURUGUARD_COL_EMAIL','COM_MURUGUARD_COL_REGISTERED','COM_MURUGUARD_COL_LAST_VISIT','COM_MURUGUARD_COL_STATUS'] as $h): ?>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_($h) ?></th>
                    <?php endforeach; ?>
                        <th class="w-10 px-4 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
            <?php foreach ($dbFindings['superusers'] as $u): ?>
                <tr class="hover:bg-gray-50/60 transition-colors <?= $u['suspicious'] ? 'bg-red-50/40' : '' ?>">
                    <td class="px-4 py-3"><?php if ($this->canEdit && $u['suspicious']): ?><input type="checkbox" class="muru-bulk-chk w-4 h-4 rounded border-gray-300"><?php endif; ?></td>
                    <td class="px-4 py-3 text-xs font-mono text-gray-500"><?= (int)$u['id'] ?></td>
                    <td class="px-4 py-3 font-medium"><?= htmlspecialchars($u['name']) ?></td>
                    <td class="px-4 py-3"><code class="text-xs bg-gray-100 px-1.5 py-0.5 rounded"><?= htmlspecialchars($u['username']) ?></code></td>
                    <td class="px-4 py-3 text-xs text-gray-500"><?= htmlspecialchars($u['email']) ?></td>
                    <td class="px-4 py-3 text-xs text-gray-400"><?= htmlspecialchars($u['registered']) ?></td>
                    <td class="px-4 py-3 text-xs text-gray-400"><?= htmlspecialchars($u['lastvisit']) ?></td>
                    <td class="px-4 py-3">
                        <?php if ($u['suspicious']): ?>
                            <div class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-bold mb-1">⚠ <?= Text::_('COM_MURUGUARD_SUSPICIOUS_BADGE') ?></div>
                            <div class="text-xs text-red-600"><?= htmlspecialchars($u['why']) ?></div>
                        <?php else: ?>
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-bold">✓ <?= Text::_('COM_MURUGUARD_NORMAL_BADGE') ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3">
                        <?php if ($u['suspicious']): ?>
                            <?php muru_mark_safe_button('superusers', (string) $u['id'], $u['why_list'] ?? [$u['why']], $this->canEdit); ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <p class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_REMOVE_ROGUE_NOTE') ?></p>
<?php endif; ?>
<?php muru_section_close(); ?>

<!-- ── 3. Menu XSS ───────────────────────────────────────────── -->
<?php muru_section_open('sec-menu', '🔗', Text::_('COM_MURUGUARD_SECTION_MENU_XSS_INJECTIONS'), $menuCount); ?>
<?php if (empty($dbFindings['menu_xss'])): ?>
    <div class="flex items-center gap-3 text-green-700 bg-green-50 rounded-xl p-[10px]">
        <span class="text-2xl">✅</span><span class="font-medium"><?= Text::_('COM_MURUGUARD_NO_MENU_ITEMS') ?></span>
    </div>
<?php else: ?>
    <?php $tag = $this->canEdit ? 'form' : 'div'; ?>
    <<?= $tag ?><?php if ($this->canEdit): ?> action="index.php?option=com_muruguard&task=scanner.cleanmenu" method="post" id="muru-cleanmenu-form"
          onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_CONFIRM_CLEAN_MENU') ?>');"<?php endif; ?>>
        <?php if ($this->canEdit): ?>
        <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-3">
                <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                    <input type="checkbox" class="w-4 h-4 rounded border-gray-300"
                           onclick="document.querySelectorAll('.muru-menu-chk').forEach(c=>c.checked=this.checked); muruUpdatePanelToolbar(this.closest('.muru-panel'));">
                    <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
                </label>
                <?php muru_bulk_toolbar_buttons(true, false, $this->aiAvailable); ?>
            </div>
        </div>
        <?php endif; ?>
        <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-4">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="w-10 px-4 py-3"></th>
                        <?php foreach (['COM_MURUGUARD_COL_ID','COM_MURUGUARD_COL_TITLE','COM_MURUGUARD_COL_LINK','COM_MURUGUARD_COL_MATCHED_SIGNATURES'] as $h): ?>
                            <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_($h) ?></th>
                        <?php endforeach; ?>
                        <th class="w-10 px-4 py-3"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                <?php foreach ($dbFindings['menu_xss'] as $m): ?>
                    <tr class="hover:bg-red-50/40 bg-red-50/20 transition-colors">
                        <td class="px-4 py-3"><?php if ($this->canEdit): ?><input type="checkbox" class="muru-menu-chk muru-bulk-chk w-4 h-4 rounded border-gray-300" name="menu_xss_ids[]" value="<?= (int)$m['id'] ?>"><?php endif; ?></td>
                        <td class="px-4 py-3 text-xs font-mono text-gray-500"><?= (int)$m['id'] ?></td>
                        <td class="px-4 py-3 font-medium"><?= htmlspecialchars($m['title']) ?></td>
                        <td class="px-4 py-3"><code class="text-xs break-all text-gray-600"><?= htmlspecialchars($m['link']) ?></code></td>
                        <td class="px-4 py-3 text-xs text-amber-700 font-medium"><?= htmlspecialchars(implode(', ', $m['matches'] ?? [])) ?></td>
                        <td class="px-4 py-3"><?php muru_mark_safe_button('menu_xss', (string) $m['id'], $m['matches'] ?? [], $this->canEdit); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php if ($this->canEdit): ?>
        <?= HTMLHelper::_('form.token') ?>
        <div class="flex items-center gap-3">
            <button type="submit"
                    class="inline-flex items-center gap-2 px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-bold rounded-xl shadow transition-colors">
                🧹 <?= Text::_('COM_MURUGUARD_CLEAN_SELECTED_ROWS_BTN') ?>
            </button>
            <span class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_CLEAN_MENU_HINT') ?></span>
        </div>
        <?php else: ?>
        <div class="flex items-center gap-2 text-xs text-gray-500">
            <span class="text-base">🔒</span>
            <span><?= Text::_('COM_MURUGUARD_LOCKED_EDIT_MENU') ?></span>
        </div>
        <?php endif; ?>
    </<?= $tag ?>>
<?php endif; ?>
<?php muru_section_close(); ?>

<!-- ── 3b. Template Style XSS (Helix Custom JS/CSS fields) ─────── -->
<?php muru_section_open('sec-template-style-xss', '🎨', Text::_('COM_MURUGUARD_SECTION_TEMPLATE_STYLE_XSS'), $templateStyleXssCount); ?>
<?php if (empty($dbFindings['template_style_xss'])): ?>
    <div class="flex items-center gap-3 text-green-700 bg-green-50 rounded-xl p-[10px]">
        <span class="text-2xl">✅</span><span class="font-medium"><?= Text::_('COM_MURUGUARD_NO_TEMPLATE_STYLE_XSS') ?></span>
    </div>
<?php else: ?>
    <?php $tag = $this->canEdit ? 'form' : 'div'; ?>
    <<?= $tag ?><?php if ($this->canEdit): ?> action="index.php?option=com_muruguard&task=scanner.cleantemplatestylexss" method="post" id="muru-cleantemplatestylexss-form"
          onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_CONFIRM_CLEAN_TEMPLATE_STYLE') ?>');"<?php endif; ?>>
        <?php if ($this->canEdit): ?>
        <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-3">
                <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                    <input type="checkbox" class="w-4 h-4 rounded border-gray-300"
                           onclick="document.querySelectorAll('.muru-tplstyle-chk').forEach(c=>c.checked=this.checked); muruUpdatePanelToolbar(this.closest('.muru-panel'));">
                    <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
                </label>
                <?php muru_bulk_toolbar_buttons(true, false, $this->aiAvailable); ?>
            </div>
        </div>
        <?php endif; ?>
        <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-4">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="w-10 px-4 py-3"></th>
                        <?php foreach (['COM_MURUGUARD_COL_ID','COM_MURUGUARD_COL_TITLE','COM_MURUGUARD_COL_TEMPLATE','COM_MURUGUARD_COL_MATCHED_SIGNATURES'] as $h): ?>
                            <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_($h) ?></th>
                        <?php endforeach; ?>
                        <th class="w-10 px-4 py-3"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                <?php foreach ($dbFindings['template_style_xss'] as $m): ?>
                    <tr class="hover:bg-red-50/40 bg-red-50/20 transition-colors">
                        <td class="px-4 py-3"><?php if ($this->canEdit): ?><input type="checkbox" class="muru-tplstyle-chk muru-bulk-chk w-4 h-4 rounded border-gray-300" name="template_style_xss_ids[]" value="<?= (int)$m['id'] ?>"><?php endif; ?></td>
                        <td class="px-4 py-3 text-xs font-mono text-gray-500"><?= (int)$m['id'] ?></td>
                        <td class="px-4 py-3 font-medium"><?= htmlspecialchars($m['title']) ?></td>
                        <td class="px-4 py-3"><code class="text-xs break-all text-gray-600"><?= htmlspecialchars($m['template']) ?></code></td>
                        <td class="px-4 py-3 text-xs text-amber-700 font-medium"><?= htmlspecialchars(implode(', ', $m['matches'] ?? [])) ?></td>
                        <td class="px-4 py-3"><?php muru_mark_safe_button('template_style_xss', (string) $m['id'], $m['matches'] ?? [], $this->canEdit); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php if ($this->canEdit): ?>
        <?= HTMLHelper::_('form.token') ?>
        <div class="flex items-center gap-3">
            <button type="submit"
                    class="inline-flex items-center gap-2 px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-bold rounded-xl shadow transition-colors">
                🧹 <?= Text::_('COM_MURUGUARD_CLEAN_SELECTED_ROWS_BTN') ?>
            </button>
            <span class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_CLEAN_TEMPLATE_STYLE_HINT') ?></span>
        </div>
        <?php else: ?>
        <div class="flex items-center gap-2 text-xs text-gray-500">
            <span class="text-base">🔒</span>
            <span><?= Text::_('COM_MURUGUARD_LOCKED_EDIT_MENU') ?></span>
        </div>
        <?php endif; ?>
    </<?= $tag ?>>
<?php endif; ?>
<?php muru_section_close(); ?>

<!-- ── 4. SPPB Assets ────────────────────────────────────────── -->
<?php muru_section_open('sec-assets', '🗄', Text::_('COM_MURUGUARD_SECTION_SPPB_ASSET_TABLE'), $assetCount); ?>
<?php if (empty($dbFindings['sppb_assets']) && empty($dbFindings['rogue_iconfont'])): ?>
    <div class="flex items-center gap-3 text-green-700 bg-green-50 rounded-xl p-[10px]">
        <span class="text-2xl">✅</span><span class="font-medium"><?= Text::_('COM_MURUGUARD_NO_SPPB_ROWS') ?></span>
    </div>
<?php else: ?>
    <?php if (!empty($dbFindings['sppb_assets'])): ?>
        <div class="flex items-center justify-between mb-3">
            <h4 class="font-bold text-gray-700">
                <?= Text::_('COM_MURUGUARD_INJECTED_PAYLOAD_ROWS') ?>
                <span class="ml-1 inline-flex items-center justify-center w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full">
                    <?= count($dbFindings['sppb_assets']) ?>
                </span>
            </h4>
            <?php if ($this->canEdit): ?>
            <div class="flex items-center gap-3">
                <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                    <input type="checkbox" class="w-4 h-4 rounded border-gray-300"
                           onclick="document.querySelectorAll('#sec-assets .muru-sppbasset-chk').forEach(c=>c.checked=this.checked); muruUpdatePanelToolbar(this.closest('.muru-panel'));">
                    <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
                </label>
                <?php muru_bulk_toolbar_buttons(true, false, $this->aiAvailable); ?>
            </div>
            <?php endif; ?>
        </div>

        <div class="space-y-2 mb-5">

            <?php foreach ($dbFindings['sppb_assets'] as $row): ?>
                <details class="bg-red-50 border border-red-100 rounded-xl overflow-hidden">

                    <summary class="cursor-pointer px-4 py-3 flex items-center justify-between hover:bg-red-100/50">
                        <div class="flex items-center gap-3">
                            <?php if ($this->canEdit): ?>
                            <input type="checkbox" class="muru-sppbasset-chk muru-bulk-chk w-4 h-4 rounded border-gray-300 flex-shrink-0"
                                   onclick="event.stopPropagation()" data-fp-category="sppb_assets"
                                   data-fp-identifier="<?= htmlspecialchars((string) $row['id']) ?>"
                                   data-fp-fingerprint="<?= htmlspecialchars(\MuruguardHelper::fingerprintReasons($row['scan_reasons'] ?? [])) ?>">
                            <?php endif; ?>
                            <span class="text-red-600">⚠️</span>

                            <div>
                                <span class="font-bold text-sm text-gray-800">
                                    #<?= (int)$row['id'] ?>
                                    <?= htmlspecialchars($row['name'] ?? '') ?>
                                </span>

                                <span class="text-xs text-gray-500 ml-2">
                                    <?= htmlspecialchars($row['type'] ?? '') ?>
                                </span>
                            </div>
                        </div>

                        <span class="text-xs text-gray-400">
                            <?= htmlspecialchars($row['created'] ?? '') ?>
                        </span>
                    </summary>

                    <div class="border-t border-red-100 p-4">
                        <pre class="text-xs text-red-800 overflow-x-auto"><?= htmlspecialchars(json_encode($row, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre>
                        <?php if ($this->canEdit): ?>
                            <div class="mt-2 flex justify-end">
                                <?php muru_mark_safe_button('sppb_assets', (string) $row['id'], $row['scan_reasons'] ?? [], $this->canEdit); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                </details>
            <?php endforeach; ?>

        </div>
    <?php endif; ?>
    <?php if (!empty($dbFindings['rogue_iconfont'])): ?>
        <?php $tag = $this->canDelete ? 'form' : 'div'; ?>
        <<?= $tag ?><?php if ($this->canDelete): ?> action="index.php?option=com_muruguard&task=scanner.deleteassets" method="post" id="muru-deleteassets-form"
              onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_CONFIRM_DELETE_ASSETS') ?>');"<?php endif; ?>>
            <div class="flex items-center justify-between mb-3">
                <h4 class="font-bold text-gray-700"><?= Text::_('COM_MURUGUARD_ROGUE_ICONFONT_HEADING') ?>
                    <span class="ml-1 inline-flex items-center justify-center w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full">
                        <?= count($dbFindings['rogue_iconfont']) ?>
                    </span>
                </h4>
                <?php if ($this->canDelete): ?>
                <div class="flex items-center gap-3">
                    <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                        <input type="checkbox" class="w-4 h-4 rounded border-gray-300"
                               onclick="document.querySelectorAll('.muru-asset-chk').forEach(c=>c.checked=this.checked); muruUpdatePanelToolbar(this.closest('.muru-panel'));">
                        <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
                    </label>
                    <?php muru_bulk_toolbar_buttons($this->canEdit, false, $this->aiAvailable); ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-4">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-100">
                            <th class="w-10 px-4 py-3"></th>
                            <?php foreach (['COM_MURUGUARD_COL_ID','COM_MURUGUARD_COL_NAME','COM_MURUGUARD_COL_TITLE','COM_MURUGUARD_COL_CREATED','COM_MURUGUARD_COL_BY','COM_MURUGUARD_COL_ASSETS'] as $h): ?>
                                <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_($h) ?></th>
                            <?php endforeach; ?>
                            <th class="w-10 px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50">
                    <?php foreach ($dbFindings['rogue_iconfont'] as $row): ?>
                        <tr class="hover:bg-red-50/40 bg-red-50/20 transition-colors">
                            <td class="px-4 py-3"><?php if ($this->canDelete): ?><input type="checkbox" class="muru-asset-chk muru-bulk-chk w-4 h-4 rounded border-gray-300" name="rogue_asset_ids[]" value="<?= (int)$row['id'] ?>"><?php endif; ?></td>
                            <td class="px-4 py-3 text-xs font-mono text-gray-500"><?= (int)$row['id'] ?></td>
                            <td class="px-4 py-3"><code class="text-xs bg-gray-100 px-1.5 py-0.5 rounded"><?= htmlspecialchars($row['name']) ?></code></td>
                            <td class="px-4 py-3 text-sm"><?= htmlspecialchars($row['title']) ?></td>
                            <td class="px-4 py-3 text-xs text-gray-400"><?= htmlspecialchars($row['created']) ?></td>
                            <td class="px-4 py-3 text-xs text-gray-500"><?= (int)$row['created_by'] ?></td>
                            <td class="px-4 py-3"><code class="text-xs text-red-600 break-all"><?= htmlspecialchars($row['assets']) ?></code></td>
                            <td class="px-4 py-3"><?php muru_mark_safe_button('rogue_iconfont', (string) $row['id'], $row['scan_reasons'] ?? [], $this->canEdit); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($this->canDelete): ?>
            <?= HTMLHelper::_('form.token') ?>
            <button type="submit"
                    class="inline-flex items-center gap-2 px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-bold rounded-xl shadow transition-colors">
                🗑 <?= Text::_('COM_MURUGUARD_BTN_DELETE_SELECTED') ?>
            </button>
            <?php else: ?>
            <div class="flex items-center gap-2 text-xs text-gray-500">
                <span class="text-base">🔒</span>
                <span><?= Text::_('COM_MURUGUARD_LOCKED_DELETE_ASSETS') ?></span>
            </div>
            <?php endif; ?>
        </<?= $tag ?>>
    <?php endif; ?>
<?php endif; ?>
<?php muru_section_close(); ?>

<!-- ── 5. Template defacement ────────────────────────────────── -->
<?php muru_section_open('sec-template', '🖼', Text::_('COM_MURUGUARD_SECTION_TEMPLATE_DEFACEMENT'), $deface); ?>
<?php if (empty($dbFindings['template_defacement'])): ?>
    <div class="flex items-center gap-3 text-green-700 bg-green-50 rounded-xl p-[10px]">
        <span class="text-2xl">✅</span><span class="font-medium"><?= Text::_('COM_MURUGUARD_NO_DEFACEMENT_FOUND') ?></span>
    </div>
<?php else: ?>
    <?php $tag = $this->canDelete ? 'form' : 'div'; ?>
    <<?= $tag ?><?php if ($this->canDelete): ?> action="index.php?option=com_muruguard&task=scanner.cleantemplatedefacement" method="post" id="muru-template-form"
          onsubmit="return confirm('<?= Text::_('COM_MURUGUARD_CONFIRM_CLEAN_DEFACEMENT') ?>');"<?php endif; ?>>
        <?php if ($this->canDelete): ?>
        <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-3">
                <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                    <input type="checkbox" class="w-4 h-4 rounded border-gray-300"
                           onclick="document.querySelectorAll('.muru-template-chk').forEach(c=>c.checked=this.checked); muruUpdatePanelToolbar(this.closest('.muru-panel'));">
                    <?= Text::_('COM_MURUGUARD_SELECT_ALL') ?>
                </label>
                <?php muru_bulk_toolbar_buttons($this->canEdit, false, $this->aiAvailable); ?>
            </div>
        </div>
        <?php endif; ?>
        <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-3">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <?php if ($this->canDelete): ?><th class="w-10 px-4 py-3"></th><?php endif; ?>
                        <?php foreach (['COM_MURUGUARD_COL_ID','COM_MURUGUARD_COL_TEMPLATE','COM_MURUGUARD_COL_TITLE','COM_MURUGUARD_COL_MATCHES'] as $h): ?>
                            <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_($h) ?></th>
                        <?php endforeach; ?>
                        <th class="w-10 px-4 py-3"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                <?php foreach ($dbFindings['template_defacement'] as $row): ?>
                    <tr class="hover:bg-amber-50/40 bg-amber-50/20 transition-colors">
                        <?php if ($this->canDelete): ?><td class="px-4 py-3"><input type="checkbox" class="muru-template-chk muru-bulk-chk w-4 h-4 rounded border-gray-300" name="template_defacement_ids[]" value="<?= (int)$row['id'] ?>"></td><?php endif; ?>
                        <td class="px-4 py-3 text-xs font-mono text-gray-500"><?= (int)$row['id'] ?></td>
                        <td class="px-4 py-3"><code class="text-xs text-gray-600"><?= htmlspecialchars($row['template']) ?></code></td>
                        <td class="px-4 py-3 font-medium"><?= htmlspecialchars($row['title']) ?></td>
                        <td class="px-4 py-3 text-xs text-amber-700 font-medium"><?= htmlspecialchars(implode(', ', $row['matches'])) ?></td>
                        <td class="px-4 py-3"><?php muru_mark_safe_button('template_defacement', (string) $row['id'], $row['matches'], $this->canEdit); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php if ($this->canDelete): ?>
        <?= HTMLHelper::_('form.token') ?>
        <div class="flex items-center gap-3 mb-3">
            <button type="submit"
                    class="inline-flex items-center gap-2 px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-bold rounded-xl shadow transition-colors">
                🗑 <?= Text::_('COM_MURUGUARD_BTN_DELETE_SELECTED') ?>
            </button>
            <span class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_CLEAN_DEFACEMENT_HINT') ?></span>
        </div>
        <?php else: ?>
        <div class="flex items-center gap-2 text-xs text-gray-500 mb-3">
            <span class="text-base">🔒</span>
            <span><?= Text::_('COM_MURUGUARD_LOCKED_DELETE_DEFACEMENT') ?></span>
        </div>
        <?php endif; ?>
    </<?= $tag ?>>
    <p class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_DEFACEMENT_NOTE') ?></p>
<?php endif; ?>
<?php muru_section_close(); ?>

<?php
/* ── Vulnerable Extensions ─────────────────────────────────────
   Awareness, not cleanup -- these rows are installed extensions with a
   known, published vulnerability (see MuruguardModelScanner::
   getVulnerableExtensions()), not something that got compromised. No
   "mark safe"/delete action: the only real fix is updating the
   extension, so each row links out to it instead. */
$severityBadge = [
    'CRITICAL' => 'bg-red-100 text-red-700',
    'HIGH'     => 'bg-orange-100 text-orange-700',
    'MEDIUM'   => 'bg-amber-100 text-amber-700',
    'LOW'      => 'bg-gray-100 text-gray-600',
];
?>
<?php muru_section_open('sec-vulns', '🛑', Text::_('COM_MURUGUARD_SECTION_VULNERABILITIES'), $vulnCount); ?>
<?php if (empty($dbFindings['vulnerable_extensions'])): ?>
    <div class="flex items-center gap-3 text-green-700 bg-green-50 rounded-xl p-[10px]">
        <span class="text-2xl">✅</span><span class="font-medium"><?= Text::_('COM_MURUGUARD_NO_VULNERABILITIES_FOUND') ?></span>
    </div>
<?php else: ?>
    <div class="tbl-wrap rounded-xl border border-gray-100 overflow-hidden mb-3">
        <table class="w-full text-sm">
            <thead>
                <tr class="bg-gray-50 border-b border-gray-100">
                    <?php foreach (['COM_MURUGUARD_COL_EXTENSION','COM_MURUGUARD_COL_VULNERABILITY','COM_MURUGUARD_COL_SEVERITY','COM_MURUGUARD_COL_VERSION','COM_MURUGUARD_COL_FIX'] as $h): ?>
                        <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider"><?= Text::_($h) ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
            <?php foreach ($dbFindings['vulnerable_extensions'] as $v): ?>
                <tr class="hover:bg-red-50/40 bg-red-50/20 transition-colors">
                    <td class="px-4 py-3">
                        <div class="font-medium"><?= htmlspecialchars($v['extensionName']) ?></div>
                        <code class="text-xs text-gray-500"><?= htmlspecialchars($v['element']) ?></code>
                    </td>
                    <td class="px-4 py-3">
                        <div><?= htmlspecialchars($v['title']) ?></div>
                        <?php if (!empty($v['cveId'])): ?><code class="text-xs text-gray-500"><?= htmlspecialchars($v['cveId']) ?></code><?php endif; ?>
                        <?php /* Defense in depth: the dashboard's own API validates advisoryUrl's
                                 scheme before storing it (see isSafeAdvisoryUrl() in
                                 app/api/dashboard/vulnerabilities/route.ts), but this feed crosses
                                 a network boundary into every install's admin session -- only ever
                                 render it as a link if it's still recognisably http(s), never trust
                                 the scheme blindly just because htmlspecialchars() was applied. */ ?>
                        <?php if (!empty($v['advisoryUrl']) && preg_match('#^https?://#i', (string) $v['advisoryUrl'])): ?>
                            <a href="<?= htmlspecialchars($v['advisoryUrl']) ?>" target="_blank" rel="noopener noreferrer" class="block text-xs text-blue-600 hover:text-blue-700">Advisory ↗</a>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold <?= $severityBadge[$v['severity']] ?? $severityBadge['MEDIUM'] ?>"><?= htmlspecialchars($v['severity']) ?></span>
                    </td>
                    <td class="px-4 py-3 text-xs font-mono text-gray-600"><?= htmlspecialchars($v['installedVersion']) ?></td>
                    <td class="px-4 py-3 text-xs">
                        <?php if (!empty($v['fixedVersion'])): ?>
                            <span class="text-emerald-700 font-medium">Update to <?= htmlspecialchars($v['fixedVersion']) ?></span>
                        <?php else: ?>
                            <span class="text-gray-400">No fixed version published yet</span>
                        <?php endif; ?>
                        <a href="index.php?option=com_installer&view=update" class="block text-blue-600 hover:text-blue-700 mt-0.5">Go to Updates →</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <p class="text-xs text-gray-400"><?= Text::_('COM_MURUGUARD_VULNERABILITIES_NOTE') ?></p>
<?php endif; ?>
<?php muru_section_close(); ?>

<?php endif; // end $this->scanned ?>
</div><!-- /#muru-main-content -->

</div><!-- #muruguard-root -->

<script>
(function () {
    // Re-parent fixed-position elements to <body> so they truly cover the
    // viewport / anchor to the real top-right corner. Joomla's admin
    // template applies a CSS transform to the content wrapper while
    // animating the collapsible sidebar, and a transformed ancestor
    // breaks `position: fixed` for any descendant, confining it to that
    // ancestor's box instead of the actual viewport.
    ['muruguard-overlay', 'muru-modal', 'muru-scan-modal', 'muru-htaccess-modal'].forEach(function (id) {
        var el = document.getElementById(id);
        if (el && el.parentNode !== document.body) {
            document.body.appendChild(el);
        }
    });

    muruUpdateAreaCount();

    // Settings disclosure widgets (<details class="muru-settings-collapse">):
    // the hint line under each summary stayed stuck on "Click to expand"
    // even after opening. The chevron already rotates on the native [open]
    // state via CSS -- this just keeps the hint text in sync with it too,
    // reading both strings off data attributes on the hint element itself
    // so its markup/class (and the CSS built around it) doesn't need to
    // change at all, only its text.
    document.querySelectorAll('.muru-settings-collapse').forEach(function (details) {
        var hint = details.querySelector('.muru-settings-collapse-hint');
        if (!hint) return;
        var expandText = hint.getAttribute('data-expand-text');
        var collapseText = hint.getAttribute('data-collapse-text');
        if (!collapseText) return;
        var syncHint = function () {
            hint.textContent = details.open ? collapseText : expandText;
        };
        details.addEventListener('toggle', syncHint);
        syncHint();
    });

    // Chunked scanning: a scan used to be one blocking POST that could
    // outrun a host's execution-time limit on a large site and come back
    // as a bare 500 with no results at all. Instead of submitting the form
    // normally, JS drives a loop of small scanner.scanchunk AJAX calls
    // (each bounded to a fixed wall-clock budget server-side -- see
    // MuruguardModelScanner::CHUNK_TIME_BUDGET_SECONDS) until the scan
    // reports done, then does a plain navigation to show the results --
    // which by then are already sitting in the session exactly as a normal
    // scan() would have left them. If fetch() isn't available at all, the
    // form is left to submit normally so the scan still runs (just as one
    // blocking request, the old behaviour) instead of silently doing
    // nothing.
    var forms = [document.getElementById('muruguard-form'), document.getElementById('muruguard-rescan-form')];
    if (window.fetch && window.FormData) {
        forms.forEach(function (form) {
            if (!form) return;
            form.addEventListener('submit', function (event) {
                event.preventDefault();
                muruRunChunkedScan(form);
            });
        });
    } else {
        forms.forEach(function (form) {
            if (!form) return;
            form.addEventListener('submit', function () {
                closeScanModal();
                muruguardShowOverlay();
            });
        });
    }

    // Bulk delete/clean forms submit one checkbox per row. A large scan
    // result (thousands of flagged files, or hundreds of junk DB rows) can
    // exceed PHP's default max_input_vars (1000) before Joomla even sees
    // the request, silently truncating the POST body -- which can drop the
    // CSRF token field along with it, surfacing as a confusing "invalid
    // security token" error unrelated to the token itself. On submit,
    // every checked box's value is consolidated into one JSON-encoded
    // hidden field (read by MuruguardControllerScanner::getBulkField(),
    // which prefers it over the raw array), and the checkboxes' own `name`
    // attributes are removed so they don't ALSO submit individually --
    // capping the request at a small, constant number of fields regardless
    // of how many rows are selected. If JS is unavailable this listener
    // never runs and the checkboxes submit the old way, still working for
    // reasonable selection sizes.
    function muruConsolidateCheckboxes(formId, checkboxClass, hiddenFieldName) {
        var form = document.getElementById(formId);
        if (!form) return;
        form.addEventListener('submit', function () {
            var boxes = form.querySelectorAll('.' + checkboxClass);
            var checkedValues = [];
            boxes.forEach(function (box) {
                if (box.checked) checkedValues.push(box.value);
                box.removeAttribute('name');
            });
            var hidden = form.querySelector('input[name="' + hiddenFieldName + '"]');
            if (!hidden) {
                hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = hiddenFieldName;
                form.appendChild(hidden);
            }
            hidden.value = JSON.stringify(checkedValues);
        });
    }
    muruConsolidateCheckboxes('muru-files-form', 'muru-file-chk', 'targets_json');
    muruConsolidateCheckboxes('muru-cleancode-form', 'muru-file-chk', 'targets_json');
    muruConsolidateCheckboxes('muru-cleanmenu-form', 'muru-menu-chk', 'menu_xss_ids_json');
    muruConsolidateCheckboxes('muru-cleantemplatestylexss-form', 'muru-tplstyle-chk', 'template_style_xss_ids_json');
    muruConsolidateCheckboxes('muru-deleteassets-form', 'muru-asset-chk', 'rogue_asset_ids_json');
    muruConsolidateCheckboxes('muru-template-form', 'muru-template-chk', 'template_defacement_ids_json');

    // ── "Mark as Safe" (dismiss a finding as a false positive) ──────
    // A plain button, not a <form>, since every table this appears in
    // already sits inside that tab's own bulk-select/delete <form> --
    // HTML doesn't allow nested forms. Submitted via fetch(), using event
    // delegation since these buttons exist inside tab panels that can be
    // re-rendered/hidden by the tab switcher above.
    //
    // Patches the DOM directly (removes the row, decrements the tab and
    // panel-header badges) instead of reloading the whole page. This
    // used to fetch() then do a full window.location.reload() -- a
    // real-world report traced that reload to occasionally firing twice
    // from one click, and more fundamentally, ANY reload here reads as
    // "getting kicked back to a different page" even when it isn't,
    // since the browser visibly navigates. No reload means nothing that
    // can look like a redirect, full stop.
    var muruFpToken = <?= json_encode(\Joomla\CMS\Session\Session::getFormToken()) ?>;

    // Mirrors muru_section_open()'s PHP markup exactly (count>0 = red
    // pill with the number, count=0 = green checkmark) so a live
    // decrement looks identical to what a fresh page render would show.
    function muruDecrementBadge(el) {
        var current = parseInt(el.textContent, 10);
        var next = isNaN(current) ? 0 : Math.max(0, current - 1);
        if (next > 0) {
            el.textContent = String(next);
            el.classList.remove('bg-green-500');
            el.classList.add('bg-red-500');
        } else {
            el.textContent = '✓';
            el.classList.remove('bg-red-500');
            el.classList.add('bg-green-500');
        }
    }

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.muru-mark-safe-btn');
        if (!btn) return;
        // Stops this click from being interpreted by anything else this
        // event might otherwise bubble into (the tab's own bulk-select
        // <form> this button lives inside, a row-click handler, etc.) --
        // this button's own fetch is the only thing a click on it should
        // ever trigger.
        e.preventDefault();
        e.stopPropagation();
        if (btn.disabled) return;
        if (!confirm(<?= json_encode(Text::_('COM_MURUGUARD_FP_MARK_CONFIRM')) ?>)) return;

        btn.disabled = true;
        var row = btn.closest('tr');
        var panel = btn.closest('.muru-panel');
        var panelId = panel ? panel.getAttribute('data-panel') : null;

        var body = new URLSearchParams();
        body.set('fp_category', btn.getAttribute('data-fp-category'));
        body.set('fp_identifier', btn.getAttribute('data-fp-identifier'));
        body.set('fp_fingerprint', btn.getAttribute('data-fp-fingerprint'));
        body.set(muruFpToken, '1');

        fetch('index.php?option=com_muruguard&task=scanner.markfalsepositive', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
        }).then(function (res) {
            return res.json().catch(function () { return null; }).then(function (data) {
                return { ok: res.ok && !!data && data.ok === true, error: data && data.error };
            });
        }).then(function (result) {
            if (!result.ok) {
                btn.disabled = false;
                window.alert(result.error || <?= json_encode(Text::_('COM_MURUGUARD_FP_MARK_FAILED')) ?>);
                return;
            }

            if (row) {
                row.style.transition = 'opacity 180ms ease, transform 180ms ease';
                row.style.opacity = '0';
                row.style.transform = 'scale(0.99)';
                setTimeout(function () { row.remove(); }, 180);
            }
            if (panelId) {
                var tabBadge = document.querySelector('.muru-tab[data-tab="' + panelId + '"] .muru-tab-badge');
                if (tabBadge) muruDecrementBadge(tabBadge);
            }
            if (panel) {
                var sectionBadge = panel.querySelector('.muru-section-badge');
                if (sectionBadge) muruDecrementBadge(sectionBadge);
            }
        }).catch(function () {
            btn.disabled = false;
            window.alert(<?= json_encode(Text::_('COM_MURUGUARD_FP_MARK_FAILED')) ?>);
        });
    });

    // ── Bulk actions (multi-select "Mark Selected Safe" / "Check via AI") ──
    // Reuses whichever checkboxes in a panel already carry the shared
    // muru-bulk-chk class -- added alongside each tab's own existing
    // delete/clean checkbox class where one already existed, or newly
    // added for Super Users / SPPB Assets, which never had bulk-select
    // before -- so one shared set of listeners covers every tab instead
    // of per-tab wiring. Same fetch-only, JSON-in/JSON-out, no-reload
    // shape as the single-item "Mark as Safe" flow above; the form
    // token travels as a query param (same as the AI review calls
    // elsewhere on this page) since Session::checkToken('request')
    // accepts it via GET or POST, but a JSON request body never
    // populates PHP's $_POST for a non-form content type.
    var muruBulkToken = <?= json_encode(\Joomla\CMS\Session\Session::getFormToken()) ?>;

    // Data lives directly on the checkbox for rows with no <tr> to carry
    // a sibling button (the SPPB Assets accordion) -- everywhere else
    // it's read off the same "Mark as Safe" button the single-item flow
    // already uses, so there's exactly one place that data is defined
    // for a normal table row.
    function muruBulkFpData(chk) {
        if (chk.hasAttribute('data-fp-category')) {
            return {
                category: chk.getAttribute('data-fp-category'),
                identifier: chk.getAttribute('data-fp-identifier'),
                fingerprint: chk.getAttribute('data-fp-fingerprint'),
            };
        }
        var container = chk.closest('tr') || chk.closest('details');
        var btn = container ? container.querySelector('.muru-mark-safe-btn') : null;
        if (!btn) return null;
        return {
            category: btn.getAttribute('data-fp-category'),
            identifier: btn.getAttribute('data-fp-identifier'),
            fingerprint: btn.getAttribute('data-fp-fingerprint'),
        };
    }

    function muruBulkRemoveRow(chk) {
        var container = chk.closest('tr') || chk.closest('details');
        if (!container) return;
        container.style.transition = 'opacity 180ms ease, transform 180ms ease';
        container.style.opacity = '0';
        container.style.transform = 'scale(0.99)';
        setTimeout(function () { container.remove(); }, 180);
    }

    // Exposed on window, not a plain function declaration -- this whole
    // <script> block is wrapped in an IIFE (see the top of this block),
    // so a plain `function muruUpdatePanelToolbar(...)` is only visible
    // to code inside that same closure. Every "Select All" checkbox
    // across the scan-result panels calls this directly from an inline
    // onclick="" attribute (needed there specifically because it also
    // programmatically sets each child checkbox's .checked, which does
    // NOT fire a native change event for the delegated listener below to
    // catch) -- inline attribute handlers execute in the GLOBAL scope
    // regardless of where the function is defined in the page, so they
    // were throwing "muruUpdatePanelToolbar is not defined" on every
    // click. Real reported bug: the bulk toolbar always showed "0
    // selected" and Delete/Mark Safe stayed disabled no matter what was
    // checked.
    window.muruUpdatePanelToolbar = function (panel) {
        var checked = panel.querySelectorAll('.muru-bulk-chk:checked').length;
        var countEl = panel.querySelector('.muru-bulk-count');
        if (countEl) countEl.textContent = checked + ' ' + <?= json_encode(Text::_('COM_MURUGUARD_BULK_SELECTED')) ?>;
        var markBtn = panel.querySelector('.muru-bulk-mark-safe-btn');
        if (markBtn) markBtn.disabled = checked === 0;
        var aiBtn = panel.querySelector('.muru-bulk-ai-check-btn');
        if (aiBtn) aiBtn.disabled = checked === 0;
    };

    document.addEventListener('change', function (e) {
        if (!e.target.classList || !e.target.classList.contains('muru-bulk-chk')) return;
        var panel = e.target.closest('.muru-panel');
        if (panel) muruUpdatePanelToolbar(panel);
    });

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.muru-bulk-mark-safe-btn');
        if (!btn) return;
        e.preventDefault();
        e.stopPropagation();
        if (btn.disabled) return;

        var panel = btn.closest('.muru-panel');
        if (!panel) return;
        var panelId = panel.getAttribute('data-panel');
        var checkedBoxes = Array.prototype.slice.call(panel.querySelectorAll('.muru-bulk-chk:checked'));
        if (checkedBoxes.length === 0) return;

        var items = [];
        var itemChecks = [];
        checkedBoxes.forEach(function (chk) {
            var data = muruBulkFpData(chk);
            if (!data || !data.identifier) return;
            items.push(data);
            itemChecks.push(chk);
        });
        if (items.length === 0) return;

        if (!window.confirm(<?= json_encode(Text::_('COM_MURUGUARD_BULK_MARK_SAFE_CONFIRM')) ?>.replace('%s', items.length))) return;

        btn.disabled = true;
        var aiBtn = panel.querySelector('.muru-bulk-ai-check-btn');
        if (aiBtn) aiBtn.disabled = true;

        fetch('index.php?option=com_muruguard&task=scanner.bulkmarkfalsepositive&' + encodeURIComponent(muruBulkToken) + '=1', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ items: items }),
        }).then(function (res) {
            return res.json().catch(function () { return null; });
        }).then(function (data) {
            if (!data || !data.ok) {
                window.alert(<?= json_encode(Text::_('COM_MURUGUARD_BULK_MARK_SAFE_FAILED')) ?>);
                muruUpdatePanelToolbar(panel);
                return;
            }

            // Only remove rows that actually succeeded -- a partial
            // failure (data.failed) leaves the rest checked and in
            // place rather than silently disappearing them too.
            var failedSet = {};
            (data.failed || []).forEach(function (id) { failedSet[id] = true; });
            var removedCount = 0;
            itemChecks.forEach(function (chk, i) {
                if (failedSet[items[i].identifier]) return;
                muruBulkRemoveRow(chk);
                removedCount++;
            });

            if (removedCount > 0) {
                if (panelId) {
                    var tabBadge = document.querySelector('.muru-tab[data-tab="' + panelId + '"] .muru-tab-badge');
                    for (var i = 0; i < removedCount; i++) {
                        if (tabBadge) muruDecrementBadge(tabBadge);
                    }
                }
                var sectionBadge = panel.querySelector('.muru-section-badge');
                for (var j = 0; j < removedCount; j++) {
                    if (sectionBadge) muruDecrementBadge(sectionBadge);
                }
            }

            if (data.failed && data.failed.length > 0) {
                window.alert(
                    <?= json_encode(Text::_('COM_MURUGUARD_BULK_MARK_SAFE_PARTIAL')) ?>
                        .replace('%s', removedCount).replace('%s', items.length)
                );
            }
            setTimeout(function () { muruUpdatePanelToolbar(panel); }, 200);
        }).catch(function () {
            window.alert(<?= json_encode(Text::_('COM_MURUGUARD_BULK_MARK_SAFE_FAILED')) ?>);
            muruUpdatePanelToolbar(panel);
        });
    });

    // ── Bulk AI Check (multi-select toolbar, file-based tabs only) ──
    var muruBulkAiModal = document.getElementById('muru-bulk-ai-modal');
    var muruBulkAiStatus = document.getElementById('muru-bulk-ai-modal-status');
    var muruBulkAiBody = document.getElementById('muru-bulk-ai-modal-body');

    function muruBulkAiResultCard(item) {
        var card = document.createElement('div');
        card.className = 'border rounded-xl p-3 ' + (item.ok ? 'border-gray-200 bg-gray-50' : 'border-red-200 bg-red-50');
        var pathEl = document.createElement('code');
        pathEl.className = 'text-xs font-mono text-gray-700 break-all block mb-2';
        pathEl.textContent = item.path;
        card.appendChild(pathEl);
        var bodyEl = document.createElement('div');
        bodyEl.className = 'text-sm whitespace-pre-wrap ' + (item.ok ? 'text-gray-800' : 'text-red-700');
        bodyEl.textContent = item.ok ? item.review : <?= json_encode(Text::_('COM_MURUGUARD_BULK_AI_RESULT_ERROR')) ?>;
        card.appendChild(bodyEl);
        return card;
    }

    function muruCloseBulkAiModal() {
        if (muruBulkAiModal) muruBulkAiModal.classList.add('hidden');
    }
    var muruBulkAiCloseBtn = document.getElementById('muru-bulk-ai-modal-close');
    if (muruBulkAiCloseBtn) muruBulkAiCloseBtn.addEventListener('click', muruCloseBulkAiModal);
    if (muruBulkAiModal) {
        muruBulkAiModal.addEventListener('click', function (e) {
            if (e.target === muruBulkAiModal) muruCloseBulkAiModal();
        });
    }
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && muruBulkAiModal && !muruBulkAiModal.classList.contains('hidden')) {
            muruCloseBulkAiModal();
        }
    });

    // Runs bulkaicheck() one batch at a time (the endpoint itself caps
    // each call at 10 files -- a large selection is chunked client-side
    // into multiple calls of that size rather than the admin needing to
    // do that themselves), appending each batch's results to the modal
    // as they come back instead of waiting for the entire selection to
    // finish before showing anything.
    function muruRunBulkAiCheck(paths) {
        var BATCH_SIZE = 10;
        var total = paths.length;
        var done = 0;
        var allResults = [];

        function runBatch(start) {
            if (start >= paths.length) {
                muruBulkAiStatus.textContent = '';
                return;
            }
            var batch = paths.slice(start, start + BATCH_SIZE);
            muruBulkAiStatus.textContent = <?= json_encode(Text::_('COM_MURUGUARD_BULK_AI_CHECK_RUNNING')) ?>
                .replace('%s', done + 1).replace('%s', total);

            fetch('index.php?option=com_muruguard&task=scanner.bulkaicheck&' + encodeURIComponent(muruBulkToken) + '=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ paths: batch }),
            }).then(function (res) {
                return res.json().catch(function () { return null; });
            }).then(function (data) {
                var results = (data && data.ok && Array.isArray(data.results)) ? data.results : batch.map(function (p) {
                    return { path: p, ok: false };
                });
                results.forEach(function (item) {
                    allResults.push(item);
                    muruBulkAiBody.appendChild(muruBulkAiResultCard(item));
                });
                done += batch.length;
                runBatch(start + BATCH_SIZE);
            }).catch(function () {
                batch.forEach(function (p) {
                    var item = { path: p, ok: false };
                    allResults.push(item);
                    muruBulkAiBody.appendChild(muruBulkAiResultCard(item));
                });
                done += batch.length;
                runBatch(start + BATCH_SIZE);
            });
        }

        runBatch(0);
    }

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.muru-bulk-ai-check-btn');
        if (!btn) return;
        e.preventDefault();
        e.stopPropagation();
        if (btn.disabled) return;

        var panel = btn.closest('.muru-panel');
        if (!panel) return;
        var checkedBoxes = Array.prototype.slice.call(panel.querySelectorAll('.muru-bulk-chk:checked'));
        if (checkedBoxes.length === 0) return;

        // AI check only ever makes sense for file-based findings --
        // reviewOneFinding() reads real file content, which a
        // database-row finding has none of. This button is only ever
        // rendered on the file tabs to begin with, but filter here too
        // rather than trusting that alone.
        var paths = [];
        checkedBoxes.forEach(function (chk) {
            var data = muruBulkFpData(chk);
            if (data && data.category === 'file' && data.identifier) paths.push(data.identifier);
        });
        if (paths.length === 0) return;

        muruBulkAiBody.innerHTML = '';
        muruBulkAiModal.classList.remove('hidden');
        muruRunBulkAiCheck(paths);
    });

    // ── Tabbed results ──────────────────────────────────────────
    // Remembers the active tab across a reload (e.g. right after
    // dismissing a false positive above) via sessionStorage, instead of
    // always falling back to the server's "first tab with any findings"
    // default -- that default previously meant marking something safe on
    // a low-count tab (SPPB Assets, Super Users, ...) bounced the admin
    // back to Suspicious Files if it still had anything in it, even
    // though that's not the tab they were just working in.
    var tabs   = document.querySelectorAll('.muru-tab');
    var panels = document.querySelectorAll('.muru-panel');
    var MURU_ACTIVE_TAB_KEY = 'muru_active_tab';
    function activateTab(id) {
        tabs.forEach(function (t) { t.classList.toggle('active', t.getAttribute('data-tab') === id); });
        panels.forEach(function (p) {
            var on = p.getAttribute('data-panel') === id;
            p.classList.toggle('active', on);
            p.classList.toggle('hidden', !on);
        });
        try { sessionStorage.setItem(MURU_ACTIVE_TAB_KEY, id); } catch (err) { /* storage unavailable -- non-fatal, just no memory across reloads */ }
    }
    tabs.forEach(function (t) {
        t.addEventListener('click', function () { activateTab(t.getAttribute('data-tab')); });
    });
    if (tabs.length) {
        var storedTab = null;
        try { storedTab = sessionStorage.getItem(MURU_ACTIVE_TAB_KEY); } catch (err) { /* storage unavailable */ }
        var validStoredTab = storedTab && Array.prototype.some.call(tabs, function (t) { return t.getAttribute('data-tab') === storedTab; });
        activateTab(validStoredTab ? storedTab : <?= json_encode($activeTab ?? 'files') ?>);
    }

    // ── Pagination (Suspicious/Cleanable file tables) ────────────
    // Purely client-side -- every row (and its checkbox) stays in the
    // DOM regardless of which page is showing, only .muru-paginated-row
    // visibility toggles. This is deliberate: "Select All" / "Select
    // High Only" already work by querySelectorAll() over the whole
    // table (see their onclick handlers above), which doesn't care
    // about CSS visibility -- so pagination needed to not break that,
    // rather than requiring it to be specially taught about pages.
    var muruItemsPerPage = <?= (int) $this->itemsPerPage ?>;
    function muruPaginateTable(tbodyId) {
        var tbody = document.getElementById(tbodyId);
        var controls = document.querySelector('.muru-pagination[data-paginate-for="' + tbodyId + '"]');
        if (!tbody || !controls) return;

        var rows = Array.prototype.slice.call(tbody.querySelectorAll('.muru-paginated-row'));
        var total = rows.length;
        var totalPages = Math.max(1, Math.ceil(total / muruItemsPerPage));
        var currentPage = 1;

        var statusEl = controls.querySelector('.muru-pagination-status');
        var prevBtn   = controls.querySelector('.muru-pagination-prev');
        var nextBtn   = controls.querySelector('.muru-pagination-next');

        if (total <= muruItemsPerPage) {
            // Nothing to page -- hide the controls entirely rather than
            // showing a pointless "1 of 1" with disabled buttons.
            controls.style.display = 'none';
            return;
        }

        function render() {
            var start = (currentPage - 1) * muruItemsPerPage;
            var end = Math.min(start + muruItemsPerPage, total);
            rows.forEach(function (row, i) {
                row.classList.toggle('hidden', i < start || i >= end);
            });
            statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_PAGINATION_SHOWING')) ?>
                .replace('%s', start + 1).replace('%s', end).replace('%s', total);
            prevBtn.disabled = currentPage <= 1;
            nextBtn.disabled = currentPage >= totalPages;
        }

        prevBtn.addEventListener('click', function () { if (currentPage > 1) { currentPage--; render(); } });
        nextBtn.addEventListener('click', function () { if (currentPage < totalPages) { currentPage++; render(); } });
        render();
    }
    muruPaginateTable('muru-files-tbody');
    muruPaginateTable('muru-cleanable-tbody');
    muruPaginateTable('muru-attacklog-tbody');
    muruPaginateTable('muru-bruteforce-tbody');

    // ── Settings panel ───────────────────────────────────────────
    // Swaps #muru-main-content (whichever of scan-gate/results is
    // currently rendered) for #muru-settings-panel and back -- a plain
    // two-way toggle, independent of the results tab system above.
    var settingsBtn   = document.getElementById('muru-settings-btn');
    var settingsBack  = document.getElementById('muru-settings-back');
    var settingsPanel = document.getElementById('muru-settings-panel');
    var mainContent   = document.getElementById('muru-main-content');
    var aiBtn         = document.getElementById('muru-ai-btn');
    var aiBack        = document.getElementById('muru-ai-back');
    var aiPanel       = document.getElementById('muru-ai-panel');
    var helpBack      = document.getElementById('muru-help-back');
    var helpPanel     = document.getElementById('muru-help-panel');
    // Settings, the AI Assistant, and Help Center are all mutually
    // exclusive with each other AND with the dashboard content --
    // opening any one of them closes the others first, so at most one
    // of the four is ever visible.
    function hideAllPanels() {
        if (mainContent) mainContent.classList.add('hidden');
        if (settingsPanel) settingsPanel.classList.add('hidden');
        if (aiPanel) aiPanel.classList.add('hidden');
        if (helpPanel) helpPanel.classList.add('hidden');
        if (settingsBtn) { settingsBtn.classList.remove('muru-settings-open'); settingsBtn.setAttribute('aria-pressed', 'false'); }
        if (aiBtn) { aiBtn.classList.remove('muru-settings-open'); aiBtn.setAttribute('aria-pressed', 'false'); }
    }
    function openSettings() {
        if (!settingsPanel) return;
        hideAllPanels();
        settingsPanel.classList.remove('hidden');
        if (settingsBtn) { settingsBtn.classList.add('muru-settings-open'); settingsBtn.setAttribute('aria-pressed', 'true'); }
    }
    function closeSettings() {
        hideAllPanels();
        if (mainContent) mainContent.classList.remove('hidden');
    }
    function openAiAssistant() {
        if (!aiPanel) return;
        hideAllPanels();
        aiPanel.classList.remove('hidden');
        if (aiBtn) { aiBtn.classList.add('muru-settings-open'); aiBtn.setAttribute('aria-pressed', 'true'); }
    }
    function closeAiAssistant() {
        hideAllPanels();
        if (mainContent) mainContent.classList.remove('hidden');
    }
    function openHelpCenter() {
        if (!helpPanel) return;
        hideAllPanels();
        helpPanel.classList.remove('hidden');
    }
    function closeHelpCenter() {
        hideAllPanels();
        if (mainContent) mainContent.classList.remove('hidden');
    }
    if (settingsBtn) settingsBtn.addEventListener('click', openSettings);
    var cronBadge = document.getElementById('muru-cron-status-badge');
    if (cronBadge) cronBadge.addEventListener('click', openSettings);
    if (settingsBack) settingsBack.addEventListener('click', closeSettings);
    if (aiBtn) aiBtn.addEventListener('click', openAiAssistant);
    if (aiBack) aiBack.addEventListener('click', closeAiAssistant);
    if (helpBack) helpBack.addEventListener('click', closeHelpCenter);

    // ── Help Center: "Send system info too" preview ───────────────
    var sysInfoToggle = document.getElementById('muru-help-sysinfo-toggle');
    var sysInfoPreview = document.getElementById('muru-help-sysinfo-preview');
    if (sysInfoToggle && sysInfoPreview) {
        sysInfoToggle.addEventListener('change', function () {
            sysInfoPreview.classList.toggle('hidden', !sysInfoToggle.checked);
        });
    }

    // Land on the right panel when arriving from the left sidebar's
    // Dashboard/Settings/Smart AI Assistant/Help Center submenu (see
    // MuruguardViewScanner::addSubmenu()) -- server-rendered, so this
    // only ever matches what Joomla itself already decided the active
    // panel is.
    var initialPanel = <?= json_encode($this->activePanel) ?>;
    if (initialPanel === 'settings') { openSettings(); }
    else if (initialPanel === 'ai_assistant') { openAiAssistant(); }
    else if (initialPanel === 'help') { openHelpCenter(); }

    // ── Settings sub-tabs (Protection / Scheduled / License / AI / Guide) ─
    var settingsTabs   = document.querySelectorAll('.muru-settings-tab');
    var settingsPanels = document.querySelectorAll('.muru-settings-tabpanel');
    function activateSettingsTab(id) {
        settingsTabs.forEach(function (st) { st.classList.toggle('active', st.getAttribute('data-settings-tab') === id); });
        settingsPanels.forEach(function (p) {
            var on = p.getAttribute('data-settings-panel') === id;
            p.classList.toggle('active', on);
            p.classList.toggle('hidden', !on);
        });
    }
    settingsTabs.forEach(function (t) {
        t.addEventListener('click', function () { activateSettingsTab(t.getAttribute('data-settings-tab')); });
    });

    // Every Settings sub-tab's Save button is a real form POST + redirect
    // (not AJAX), which would otherwise always land back on whichever tab
    // is hardcoded "active" in the markup regardless of which one the
    // save actually came from. Each such form gets a hidden settings_tab
    // field, filled in right before it submits with whichever tab is
    // CURRENTLY active -- the corresponding controller action reads it
    // and carries it through the redirect (see savesettings()/
    // saveshieldsettings()/savelicense() in the controller), and the
    // initialSettingsTab restore below picks it back up on the reload.
    document.querySelectorAll('#muru-settings-panel form').forEach(function (form) {
        form.addEventListener('submit', function () {
            var activeTabBtn = document.querySelector('.muru-settings-tab.active');
            var activeId = activeTabBtn ? activeTabBtn.getAttribute('data-settings-tab') : 'general';
            var hidden = form.querySelector('input[name="settings_tab"]');
            if (!hidden) {
                hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = 'settings_tab';
                form.appendChild(hidden);
            }
            hidden.value = activeId;
        });
    });

    // Unconditional now (used to skip this when the default tab id
    // matched the server-rendered default's static "active"/"hidden"
    // classes, as a micro-optimization) -- since the settings-tab
    // consolidation, several tab ids (e.g. "site_protection") are split
    // across MULTIPLE separate panel divs (IP Access List's own div,
    // plus Site Protection/Hardening/Protection Log's own div), and
    // only one div per tab is marked active/not-hidden by default in
    // the static HTML, so skipping this call could leave some of a
    // tab's panels stuck hidden on a fresh page load even though they
    // belong to the currently-visible tab.
    var initialSettingsTab = <?= json_encode($this->activeSettingsTab) ?>;
    if (initialSettingsTab) {
        activateSettingsTab(initialSettingsTab);
    }

    // Live-updates the webcron URL preview as the token field changes,
    // and fills in a fresh random token on Generate -- purely client-side
    // convenience, nothing is saved until the Save Settings button posts.
    var tokenField = document.getElementById('muru-cron-token');
    var urlEl      = document.getElementById('muru-webcron-url');
    var urlCopyBtn = urlEl ? urlEl.closest('div').querySelector('.muru-copy-btn') : null;
    var webcronBase = <?= json_encode(Uri::root() . 'administrator/index.php?option=com_ajax&plugin=muruguardshield&group=system&format=raw&token=') ?>;
    function refreshWebcronUrl() {
        if (!tokenField || !urlEl) return;
        var url = webcronBase + encodeURIComponent(tokenField.value || '');
        urlEl.textContent = url;
        if (urlCopyBtn) urlCopyBtn.setAttribute('data-copy', url);
    }
    if (tokenField) tokenField.addEventListener('input', refreshWebcronUrl);
    var generateBtn = document.getElementById('muru-cron-generate');
    if (generateBtn && tokenField) {
        generateBtn.addEventListener('click', function () {
            var bytes = new Uint8Array(24);
            (window.crypto || window.msCrypto).getRandomValues(bytes);
            var token = Array.prototype.map.call(bytes, function (b) { return b.toString(16).padStart(2, '0'); }).join('');
            tokenField.value = token;
            refreshWebcronUrl();
        });
    }

    // ── MuRu Shield Hardening: "Generate securely" password ───────
    // Purely client-side -- fills both password fields with a strong
    // random value the admin can see right there in the (deliberately
    // text, not password-masked) field before submitting, since they
    // need to actually copy it down somewhere. The server never
    // generates or round-trips this value; see activatebackendauth()'s
    // docblock for why.
    var baGenerateBtn = document.getElementById('muru-ba-generate');
    if (baGenerateBtn) {
        baGenerateBtn.addEventListener('click', function () {
            var alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#%^&*-_=+';
            var bytes = new Uint8Array(20);
            (window.crypto || window.msCrypto).getRandomValues(bytes);
            var pw = Array.prototype.map.call(bytes, function (b) { return alphabet[b % alphabet.length]; }).join('');
            var pwField = document.getElementById('muru-ba-password');
            var pwRepeatField = document.getElementById('muru-ba-password-repeat');
            if (pwField) pwField.value = pw;
            if (pwRepeatField) pwRepeatField.value = pw;
        });
    }

    // ── Scan-area picker modal ───────────────────────────────────
    var scanModal   = document.getElementById('muru-scan-modal');
    var openScanBtn = document.getElementById('muru-open-scan-modal');
    function openScanModal() {
        if (scanModal) scanModal.classList.add('muru-show');
    }
    function closeScanModal() {
        if (scanModal) scanModal.classList.remove('muru-show');
    }
    if (openScanBtn) openScanBtn.addEventListener('click', openScanModal);
    document.addEventListener('click', function (e) {
        if (e.target.id === 'muru-scan-modal-close' || e.target.id === 'muru-scan-modal-backdrop') {
            closeScanModal();
        }
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeScanModal();
    });

    // ── .htaccess hardening modal ────────────────────────────────
    var htaccessModal   = document.getElementById('muru-htaccess-modal');
    var openHtaccessBtn = document.getElementById('muru-open-htaccess-modal');
    function openHtaccessModal() {
        if (htaccessModal) htaccessModal.classList.add('muru-show');
    }
    function closeHtaccessModal() {
        if (htaccessModal) htaccessModal.classList.remove('muru-show');
    }
    if (openHtaccessBtn) openHtaccessBtn.addEventListener('click', openHtaccessModal);
    document.addEventListener('click', function (e) {
        if (e.target.id === 'muru-htaccess-modal-close' || e.target.id === 'muru-htaccess-modal-backdrop') {
            closeHtaccessModal();
        }
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeHtaccessModal();
    });

    // "Apply" button per missing rule -- writes it into the real
    // .htaccess (see MuruguardHelper::applyHtaccessSuggestion()), then
    // flips this one <details> item to "present" in place, same
    // no-reload reasoning as markfalsepositive() elsewhere on this page.
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.muru-hc-apply-btn');
        if (!btn) return;

        var checkId  = btn.getAttribute('data-check-id');
        var resultEl = btn.parentElement.querySelector('.muru-hc-apply-result');
        btn.disabled = true;
        if (resultEl) { resultEl.textContent = ''; resultEl.className = 'muru-hc-apply-result'; }

        var body = new URLSearchParams();
        body.set(muruFpToken, '1');
        body.set('check_id', checkId);

        fetch('index.php?option=com_muruguard&task=scanner.applyhtaccesssuggestion', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
        }).then(function (res) {
            return res.json().catch(function () { return null; }).then(function (data) { return { ok: res.ok, data: data }; });
        }).then(function (r) {
            if (!r.data || !r.data.ok) {
                var err = (r.data && r.data.error) ? r.data.error : 'Could not apply this rule.';
                if (resultEl) { resultEl.textContent = err; resultEl.className = 'muru-hc-apply-result err'; }
                btn.disabled = false;
                return;
            }
            if (resultEl) {
                resultEl.textContent = r.data.alreadyPresent ? 'Already applied' : 'Applied — backed up your previous .htaccess first';
                resultEl.className = 'muru-hc-apply-result ok';
            }
            // Flip this item to "present" without a full reload -- the
            // rule really is in .htaccess now, no need to re-fetch the
            // whole advisory list to know that.
            var item = btn.closest('.muru-hc-item');
            if (item) {
                item.classList.remove('missing');
                item.classList.add('present');
                var summaryIcon = item.querySelector('summary span:first-child');
                if (summaryIcon) summaryIcon.textContent = summaryIcon.textContent.replace('⚠️', '✅');
                var statusEl = item.querySelector('[data-htaccess-status="' + checkId + '"]');
                if (statusEl) { statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_HTACCESS_PRESENT')) ?>; statusEl.className = 'muru-hc-status present'; }
            }
            btn.remove();
        }).catch(function () {
            if (resultEl) { resultEl.textContent = 'Could not reach the server.'; resultEl.className = 'muru-hc-apply-result err'; }
            btn.disabled = false;
        });
    });

    // ── Code-analysis modal ─────────────────────────────────────
    // Event delegation, not per-button listeners -- the button set lives
    // inside a results panel that can be re-rendered/hidden by the tab
    // switcher above, so this stays correct regardless of DOM churn.
    document.addEventListener('click', function (e) {
        var issuesBtn = e.target.closest('.muru-code-issues-btn');
        if (issuesBtn) { muruOpenCodeModal(issuesBtn); return; }

        var copyBtn = e.target.closest('.muru-copy-btn');
        if (copyBtn) { muruCopyPath(copyBtn); return; }

        if (e.target.id === 'muru-modal-close' || e.target.id === 'muru-modal-backdrop') {
            muruCloseCodeModal();
        }
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') muruCloseCodeModal();
    });

    // ── Smart AI Assistant chat ──────────────────────────────────
    // Browser-driven agent loop -- see MuruguardControllerScanner::
    // aichat()'s docblock for why the multi-step loop lives here
    // rather than in one long-running PHP request. Each call to
    // scanner.aichat is exactly ONE LLM turn; a read-only tool result
    // triggers this same function again automatically (status:
    // 'continue'), a mutating tool call (write/rename/delete) pauses
    // and waits for an explicit Approve/Reject click (status:
    // 'confirm_required') before continuing.
    (function () {
        var messagesEl = document.getElementById('muru-ai-messages');
        var formEl     = document.getElementById('muru-ai-form');
        var inputEl    = document.getElementById('muru-ai-input');
        var sendBtn    = document.getElementById('muru-ai-send');
        var confirmBox = document.getElementById('muru-ai-confirm-box');
        if (!formEl || !messagesEl) return;

        var aiFormToken  = <?= json_encode($this->aiFormToken) ?>;
        var conversation = [];
        var busy         = false;
        // One id per user turn, reused across every approved mutating
        // tool call within that turn -- how TimeMachine groups a single
        // AI request that touches several files into one rollback-able
        // transaction. Purely a UI-grouping label, not a security
        // boundary (the server sanitizes/defaults it regardless), so a
        // browser without crypto.randomUUID() just falls back to a
        // weaker-but-fine random string.
        var currentTransactionId = null;
        function newTransactionId() {
            if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
            return 'tm_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
        }

        function appendMessage(role, text) {
            var div = document.createElement('div');
            var isUser = role === 'user';
            div.className = 'text-sm rounded-xl p-3 whitespace-pre-wrap ' +
                (isUser ? 'bg-indigo-600 text-white ml-8' : 'bg-gray-50 border border-gray-200 text-gray-800 mr-8');
            div.textContent = text;
            messagesEl.appendChild(div);
            messagesEl.scrollTop = messagesEl.scrollHeight;
        }

        function appendStatus(text) {
            var div = document.createElement('div');
            div.className = 'text-xs text-gray-400 italic px-1';
            div.textContent = text;
            div.setAttribute('data-ai-status', '1');
            messagesEl.appendChild(div);
            messagesEl.scrollTop = messagesEl.scrollHeight;
            return div;
        }

        function clearStatuses() {
            messagesEl.querySelectorAll('[data-ai-status]').forEach(function (el) { el.remove(); });
        }

        function setBusy(b) {
            busy = b;
            sendBtn.disabled = b;
            inputEl.disabled = b;
        }

        // Resolves to a real {error} object on ANY failure (network drop,
        // a non-JSON response) instead of rejecting -- step()'s own
        // .catch() below still covers it (res.json() failing inside
        // THIS function would previously reject silently for callers
        // with no .catch() of their own, e.g. showConfirm()'s Approve/
        // Reject buttons, which would then just sit "busy" forever with
        // no visible feedback at all).
        function ajax(task, body) {
            return fetch('index.php?option=com_muruguard&task=scanner.' + task + '&' + encodeURIComponent(aiFormToken) + '=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            }).then(function (res) {
                return res.json().catch(function () {
                    return { error: 'Unexpected response from server (HTTP ' + res.status + ').' };
                });
            }).catch(function () {
                return { error: 'Network error -- please try again.' };
            });
        }

        function describeToolCall(toolCall) {
            var input = toolCall.input || {};
            if (toolCall.name === 'write_file') return 'Write to ' + (input.path || '?') + ' (' + ((input.content || '').length) + ' bytes)';
            if (toolCall.name === 'rename_file') return 'Rename ' + (input.from || '?') + ' → ' + (input.to || '?');
            if (toolCall.name === 'delete_file') return 'Delete ' + (input.path || '?');
            return toolCall.name;
        }

        function step() {
            var statusEl = appendStatus(<?= json_encode(Text::_('COM_MURUGUARD_AI_THINKING')) ?>);
            ajax('aichat', { conversation: conversation }).then(function (res) {
                statusEl.remove();
                if (res.error === 'license_required') {
                    appendMessage('assistant', <?= json_encode(Text::_('COM_MURUGUARD_AI_LICENSE_REQUIRED_MSG')) ?>);
                    setBusy(false);
                    return;
                }
                if (res.error === 'provider_error') {
                    appendMessage('assistant', (res.message || <?= json_encode(Text::_('COM_MURUGUARD_AI_ERROR_MSG')) ?>) + <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_ERROR_HINT')) ?>);
                    setBusy(false);
                    return;
                }
                if (res.error) {
                    appendMessage('assistant', <?= json_encode(Text::_('COM_MURUGUARD_AI_ERROR_MSG')) ?> + ' (' + res.error + ')');
                    setBusy(false);
                    return;
                }
                if (res.status === 'done') {
                    clearStatuses();
                    appendMessage('assistant', res.message || '');
                    setBusy(false);
                    return;
                }
                if (res.status === 'continue') {
                    conversation = res.conversation;
                    step();
                    return;
                }
                if (res.status === 'confirm_required') {
                    conversation = res.conversation;
                    showConfirm(res.toolCall, res.preview);
                    return;
                }
            }).catch(function () {
                statusEl.remove();
                appendMessage('assistant', <?= json_encode(Text::_('COM_MURUGUARD_AI_NETWORK_ERROR_MSG')) ?>);
                setBusy(false);
            });
        }

        /** Renders the TimeMachine repair preview (a real per-line diff for text, a hash/size comparison for binary, or nothing for a rename) into $target -- called from showConfirm() below. */
        function renderPreview(target, preview) {
            if (!preview || preview.mode === 'none') return;

            if (preview.mode === 'denied') {
                var deniedEl = document.createElement('div');
                deniedEl.className = 'muru-tm-binary';
                deniedEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_TM_PREVIEW_DENIED')) ?>;
                target.appendChild(deniedEl);
                return;
            }

            if (preview.mode === 'text' && Array.isArray(preview.ops)) {
                var diffEl = document.createElement('div');
                diffEl.className = 'muru-tm-diff';
                preview.ops.forEach(function (op) {
                    var line = document.createElement('div');
                    var cls = op.type === 'add' ? 'muru-tm-diff-add' : (op.type === 'remove' ? 'muru-tm-diff-remove' : 'muru-tm-diff-equal');
                    line.className = 'muru-tm-diff-line ' + cls;
                    var prefix = op.type === 'add' ? '+ ' : (op.type === 'remove' ? '- ' : '  ');
                    line.textContent = prefix + op.text;
                    diffEl.appendChild(line);
                });
                target.appendChild(diffEl);
                if (preview.reason === 'too_large') {
                    var hint = document.createElement('div');
                    hint.className = 'text-[10px] text-amber-700 mb-2';
                    hint.textContent = <?= json_encode(Text::_('COM_MURUGUARD_TM_PREVIEW_TOO_LARGE')) ?>;
                    target.appendChild(hint);
                }
                return;
            }

            if (preview.mode === 'binary' && preview.before && preview.after) {
                var binEl = document.createElement('div');
                binEl.className = 'muru-tm-binary';
                binEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_TM_PREVIEW_BINARY')) ?>
                    .replace('%s', formatBytes(preview.before.size)).replace('%s', preview.before.sha256.slice(0, 12) + '…')
                    .replace('%s', formatBytes(preview.after.size)).replace('%s', preview.after.sha256.slice(0, 12) + '…');
                target.appendChild(binEl);
            }
        }

        function formatBytes(n) {
            if (n < 1024) return n + ' B';
            if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
            return (n / 1048576).toFixed(1) + ' MB';
        }

        function showConfirm(toolCall, preview) {
            confirmBox.innerHTML = '';
            confirmBox.classList.remove('hidden');

            var label = document.createElement('div');
            label.className = 'text-sm font-semibold text-amber-800 mb-2';
            label.textContent = '⚠️ ' + describeToolCall(toolCall);
            confirmBox.appendChild(label);

            renderPreview(confirmBox, preview);

            var row = document.createElement('div');
            row.className = 'flex gap-2';

            var approveBtn = document.createElement('button');
            approveBtn.type = 'button';
            approveBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 shadow-sm';
            approveBtn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_APPROVE_BTN')) ?>;
            approveBtn.addEventListener('click', function () {
                confirmBox.classList.add('hidden');
                setBusy(true);
                ajax('aiexecutetool', { conversation: conversation, toolCall: toolCall, transactionId: currentTransactionId }).then(function (res) {
                    if (res.status === 'continue') { conversation = res.conversation; step(); }
                    else { appendMessage('assistant', <?= json_encode(Text::_('COM_MURUGUARD_AI_ERROR_MSG')) ?>); setBusy(false); }
                });
            });

            var rejectBtn = document.createElement('button');
            rejectBtn.type = 'button';
            rejectBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm';
            rejectBtn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_REJECT_BTN')) ?>;
            rejectBtn.addEventListener('click', function () {
                confirmBox.classList.add('hidden');
                setBusy(true);
                ajax('airejecttool', { conversation: conversation, toolCall: toolCall }).then(function (res) {
                    if (!res.conversation) { appendMessage('assistant', <?= json_encode(Text::_('COM_MURUGUARD_AI_ERROR_MSG')) ?>); setBusy(false); return; }
                    conversation = res.conversation;
                    step();
                });
            });

            row.appendChild(approveBtn);
            row.appendChild(rejectBtn);
            confirmBox.appendChild(row);
        }

        function sendMessage(text) {
            if (!text || busy) return;
            currentTransactionId = newTransactionId();
            appendMessage('user', text);
            conversation.push({ role: 'user', content: text });
            setBusy(true);
            step();
        }

        formEl.addEventListener('submit', function (e) {
            e.preventDefault();
            var text = inputEl.value.trim();
            if (!text) return;
            inputEl.value = '';
            sendMessage(text);
        });
        inputEl.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (formEl.requestSubmit) formEl.requestSubmit();
                else formEl.dispatchEvent(new Event('submit', { cancelable: true }));
            }
        });

        document.querySelectorAll('.muru-ai-quick-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                sendMessage(btn.getAttribute('data-prompt'));
            });
        });

        // TimeMachine -- Restore button on each "Protected Repairs" row.
        // Server-rendered once at page load (this list isn't re-rendered
        // client-side), so a plain per-button listener is enough -- no
        // delegation needed since new rows never appear without a full
        // page reload.
        document.querySelectorAll('.muru-tm-restore-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var row = btn.closest('[data-snapshot-id]');
                if (!row) return;
                var snapshotId = row.getAttribute('data-snapshot-id');
                muruTimeMachineRestore(snapshotId, btn, false);
            });
        });

        document.querySelectorAll('.muru-tm-pin-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var row = btn.closest('[data-snapshot-id]');
                if (!row) return;
                var snapshotId = row.getAttribute('data-snapshot-id');
                var nowKept = btn.getAttribute('data-keep') !== '1';
                btn.disabled = true;
                ajax('timemachinepin', { scope: 'snapshot', id: snapshotId, keep: nowKept }).then(function (res) {
                    btn.disabled = false;
                    if (!res || !res.ok) return;
                    btn.setAttribute('data-keep', nowKept ? '1' : '0');
                    btn.textContent = nowKept ? <?= json_encode(Text::_('COM_MURUGUARD_TM_UNPIN_BTN')) ?> : <?= json_encode(Text::_('COM_MURUGUARD_TM_PIN_BTN')) ?>;
                    btn.className = 'muru-tm-pin-btn text-[10px] font-medium ' + (nowKept ? 'text-amber-600' : 'text-gray-400 hover:text-gray-600');
                }).catch(function () { btn.disabled = false; });
            });
        });

        function muruTimeMachineRestore(snapshotId, btn, force) {
            btn.disabled = true;
            var originalText = btn.textContent;
            btn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_TM_RESTORING_MSG')) ?>;

            ajax('timemachinerollback', { scope: 'snapshot', id: snapshotId, force: !!force }).then(function (res) {
                var result = res && res.results && res.results[0];
                if (!result) {
                    btn.disabled = false;
                    btn.textContent = originalText;
                    appendStatus(<?= json_encode(Text::_('COM_MURUGUARD_TM_ROLLBACK_FAILED_MSG')) ?>);
                    return;
                }
                if (result.ok) {
                    btn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_TM_RESTORED_MSG')) ?>;
                    btn.className = 'shrink-0 text-[10px] font-medium text-gray-400';
                    btn.disabled = true;
                    return;
                }
                if (result.error === 'conflict' && !force) {
                    btn.disabled = false;
                    btn.textContent = originalText;
                    if (window.confirm(<?= json_encode(Text::_('COM_MURUGUARD_TM_CONFLICT_CONFIRM')) ?>)) {
                        muruTimeMachineRestore(snapshotId, btn, true);
                    }
                    return;
                }
                btn.disabled = false;
                btn.textContent = originalText;
                var msg = result.error === 'corrupted'
                    ? <?= json_encode(Text::_('COM_MURUGUARD_TM_ROLLBACK_CORRUPTED_MSG')) ?>
                    : <?= json_encode(Text::_('COM_MURUGUARD_TM_ROLLBACK_FAILED_MSG')) ?>;
                appendStatus(msg);
            }).catch(function () {
                btn.disabled = false;
                btn.textContent = originalText;
                appendStatus(<?= json_encode(Text::_('COM_MURUGUARD_TM_ROLLBACK_FAILED_MSG')) ?>);
            });
        }
    })();

    // ── Settings > AI Integrations ───────────────────────────────
    // Joomla never stores a provider API key itself -- every action
    // here (list/save/test/default) proxies straight through to the
    // dashboard via scanner.aiproviders (see MuruguardControllerScanner
    // ::aiproviders()). Loaded lazily the first time this settings
    // sub-tab is actually opened, not on every Settings page load.
    (function () {
        var listEl = document.getElementById('muru-ai-providers-list');
        var aiTabBtn = document.querySelector('.muru-settings-tab[data-settings-tab="automation"]');
        if (!listEl || !aiTabBtn) return;

        var aiFormToken = <?= json_encode($this->aiFormToken) ?>;
        var loaded = false;

        var PROVIDER_META = {
            CLAUDE:       { label: 'Claude',                       icon: '🟠' },
            OPENAI_CODEX: { label: 'OpenAI Codex',                 icon: '💻' },
            OPENAI_GPT:   { label: 'OpenAI GPT',                   icon: '🟢' },
            GEMINI:       { label: 'Gemini',                       icon: '✨' },
            OPENROUTER:   { label: 'OpenRouter',                   icon: '🔀' },
            CUSTOM:       { label: 'Custom OpenAI-Compatible API', icon: '🔧' }
        };

        // Every call site below does `.then(function (res) { if (res.error) ... })`
        // -- this NEVER rejects, so a failure of any kind (network drop, a
        // PHP fatal that outputs an HTML error page instead of JSON, a
        // timeout) always resolves to a real {error} object those call
        // sites can show, instead of silently swallowing the failure as
        // an unhandled promise rejection that leaves the button looking
        // like it did nothing at all.
        function ajax(action, body) {
            return fetch('index.php?option=com_muruguard&task=scanner.aiproviders&ai_action=' + encodeURIComponent(action) + '&' + encodeURIComponent(aiFormToken) + '=1', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body || {})
            }).then(function (res) {
                return res.json().catch(function () {
                    return { error: 'Unexpected response from server (HTTP ' + res.status + ').' };
                });
            }).catch(function () {
                return { error: 'Network error -- please try again.' };
            });
        }

        function renderRow(p) {
            var meta = PROVIDER_META[p.provider] || { label: p.provider, icon: '🤖' };

            var wrap = document.createElement('div');
            wrap.className = 'border rounded-xl overflow-hidden ' + (p.enabled ? 'border-indigo-200' : 'border-gray-200');
            wrap.setAttribute('data-provider', p.provider);

            // ── Header: icon, name, status badges, auto-saving Enabled switch ──
            var header = document.createElement('div');
            header.className = 'flex items-center justify-between gap-3 px-4 py-3 ' + (p.enabled ? 'bg-indigo-50/60' : 'bg-gray-50');

            var titleWrap = document.createElement('div');
            titleWrap.className = 'flex items-center gap-2 min-w-0';
            titleWrap.innerHTML =
                '<span class="text-lg flex-shrink-0">' + meta.icon + '</span>' +
                '<span class="text-sm font-bold text-gray-800 truncate">' + meta.label + '</span>' +
                (p.isDefault ? '<span class="flex-shrink-0 px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-bold">' + <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_DEFAULT_BADGE')) ?> + '</span>' : '') +
                (p.configured
                    ? '<span class="flex-shrink-0 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold">' + <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_CONFIGURED_BADGE')) ?> + '</span>'
                    : '<span class="flex-shrink-0 px-2 py-0.5 rounded-full bg-gray-200 text-gray-500 text-[10px] font-bold">' + <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_NOT_CONFIGURED_BADGE')) ?> + '</span>');
            header.appendChild(titleWrap);

            var switchLabel = document.createElement('label');
            switchLabel.className = 'muru-switch flex-shrink-0';
            switchLabel.title = p.configured ? <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_ENABLED')) ?> : <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_SAVE_KEY_FIRST')) ?>;
            var switchInput = document.createElement('input');
            switchInput.type = 'checkbox';
            switchInput.className = 'muru-ai-enabled';
            switchInput.checked = !!p.enabled;
            switchInput.disabled = !p.configured;
            switchLabel.appendChild(switchInput);
            switchLabel.insertAdjacentHTML('beforeend', '<span class="muru-switch-track"><span class="muru-switch-thumb"></span></span>');
            header.appendChild(switchLabel);
            wrap.appendChild(header);

            // ── Body: API key / base URL / model + actions ──
            var body = document.createElement('div');
            body.className = 'p-4';

            var grid = document.createElement('div');
            grid.className = 'grid sm:grid-cols-3 gap-3 mb-3';
            grid.innerHTML =
                '<div>' +
                    '<label class="block text-[11px] font-bold text-gray-500 mb-1">' + <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_API_KEY')) ?> + '</label>' +
                    (p.apiKeyMasked ? '<div class="text-xs font-mono text-gray-500 mb-1">' + p.apiKeyMasked + '</div>' : '') +
                    '<input type="text" class="muru-ai-apikey w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs font-mono" autocomplete="off" placeholder="' + (p.configured ? <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_API_KEY_PLACEHOLDER')) ?> : 'sk-...') + '">' +
                '</div>' +
                '<div>' +
                    '<label class="block text-[11px] font-bold text-gray-500 mb-1">' + <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_BASE_URL')) ?> + '</label>' +
                    '<input type="text" class="muru-ai-baseurl w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs" value="' + (p.baseUrl || '') + '">' +
                '</div>' +
                '<div>' +
                    '<label class="block text-[11px] font-bold text-gray-500 mb-1">' + <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_MODEL')) ?> + '</label>' +
                    '<input type="text" class="muru-ai-model w-full px-2.5 py-1.5 border border-gray-300 rounded-lg text-xs" value="' + (p.model || '') + '">' +
                '</div>';
            body.appendChild(grid);

            var actions = document.createElement('div');
            actions.className = 'flex items-center flex-wrap gap-2';

            var saveBtn = document.createElement('button');
            saveBtn.type = 'button';
            saveBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm';
            saveBtn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_SAVE_BTN')) ?>;

            var testBtn = document.createElement('button');
            testBtn.type = 'button';
            testBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm';
            testBtn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_TEST_BTN')) ?>;

            var defaultBtn = document.createElement('button');
            defaultBtn.type = 'button';
            defaultBtn.className = 'px-3 py-1.5 rounded-lg text-xs font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm disabled:opacity-40 disabled:cursor-not-allowed';
            defaultBtn.textContent = p.isDefault ? <?= json_encode('✓ ' . Text::_('COM_MURUGUARD_AI_PROVIDER_DEFAULT_BADGE')) ?> : <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_SET_DEFAULT_BTN')) ?>;
            defaultBtn.disabled = !p.configured || p.isDefault;

            var statusEl = document.createElement('span');
            statusEl.className = 'text-xs';

            actions.appendChild(saveBtn);
            actions.appendChild(testBtn);
            actions.appendChild(defaultBtn);
            actions.appendChild(statusEl);
            body.appendChild(actions);
            wrap.appendChild(body);

            function fieldValues() {
                return {
                    apiKey: wrap.querySelector('.muru-ai-apikey').value.trim(),
                    baseUrl: wrap.querySelector('.muru-ai-baseurl').value.trim(),
                    model: wrap.querySelector('.muru-ai-model').value.trim()
                };
            }

            // Enabled is its OWN instant-save action, same pattern as the
            // Protection Mode / Scheduled Scanning toggle switches
            // elsewhere in this component -- flipping it saves
            // immediately, it does NOT wait for the Save button below
            // (which only covers API key/base URL/model). This is the
            // direct fix for "I checked Enabled, reloaded, and it wasn't
            // enabled" -- there was no separate step to miss before.
            switchInput.addEventListener('change', function () {
                var wasChecked = switchInput.checked;
                switchInput.disabled = true;
                ajax('save', { provider: p.provider, enabled: wasChecked, model: wrap.querySelector('.muru-ai-model').value.trim() || undefined }).then(function (res) {
                    switchInput.disabled = !p.configured;
                    if (res.error) {
                        switchInput.checked = !wasChecked;
                        statusEl.textContent = res.error;
                        statusEl.className = 'text-xs text-red-600';
                        return;
                    }
                    wrap.classList.toggle('border-indigo-200', wasChecked);
                    wrap.classList.toggle('border-gray-200', !wasChecked);
                    header.classList.toggle('bg-indigo-50/60', wasChecked);
                    header.classList.toggle('bg-gray-50', !wasChecked);
                });
            });

            saveBtn.addEventListener('click', function () {
                statusEl.textContent = '';
                var v = fieldValues();
                ajax('save', { provider: p.provider, enabled: switchInput.checked, apiKey: v.apiKey || undefined, baseUrl: v.baseUrl, model: v.model }).then(function (res) {
                    if (res.error) { statusEl.textContent = res.error; statusEl.className = 'text-xs text-red-600'; return; }
                    statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_SAVED_MSG')) ?>;
                    statusEl.className = 'text-xs text-emerald-600';
                    loadProviders();
                });
            });

            testBtn.addEventListener('click', function () {
                statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_TESTING_MSG')) ?>;
                statusEl.className = 'text-xs text-gray-500';
                var v = fieldValues();
                ajax('test', { provider: p.provider, apiKey: v.apiKey || undefined, baseUrl: v.baseUrl, model: v.model }).then(function (res) {
                    statusEl.textContent = (res.ok ? '✅ ' : '❌ ') + (res.message || '');
                    statusEl.className = 'text-xs ' + (res.ok ? 'text-emerald-600' : 'text-red-600');
                });
            });

            defaultBtn.addEventListener('click', function () {
                ajax('default', { provider: p.provider }).then(function (res) {
                    if (res.error) { statusEl.textContent = res.error; statusEl.className = 'text-xs text-red-600'; return; }
                    loadProviders();
                });
            });

            return wrap;
        }

        // Maps the dashboard's raw license-check error codes to the same
        // human-readable labels Settings > License already uses (see
        // COM_MURUGUARD_LICENSE_STATUS_* below) -- this panel used to
        // just dump the raw code ("not_found") straight into the page.
        var LICENSE_ERROR_LABELS = {
            not_found:           <?= json_encode(Text::_('COM_MURUGUARD_LICENSE_STATUS_NOT_FOUND')) ?>,
            revoked:             <?= json_encode(Text::_('COM_MURUGUARD_LICENSE_STATUS_REVOKED')) ?>,
            expired:             <?= json_encode(Text::_('COM_MURUGUARD_LICENSE_STATUS_EXPIRED')) ?>,
            site_limit_reached:  <?= json_encode(Text::_('COM_MURUGUARD_LICENSE_STATUS_SITE_LIMIT_REACHED')) ?>
        };
        function friendlyLoadError(code) {
            return LICENSE_ERROR_LABELS[code] || code || 'Failed to load';
        }

        function loadProviders() {
            listEl.innerHTML = '<p class="text-xs text-gray-400">' + <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_TESTING_MSG')) ?> + '</p>';
            ajax('list', {}).then(function (res) {
                listEl.innerHTML = '';
                if (!res.providers) { listEl.innerHTML = '<p class="text-xs text-red-600">' + friendlyLoadError(res.error) + '</p>'; return; }
                res.providers.forEach(function (p) { listEl.appendChild(renderRow(p)); });
            });
        }

        aiTabBtn.addEventListener('click', function () {
            if (loaded) return;
            loaded = true;
            loadProviders();
        });

        // ── Custom Skill (project instructions the AI Assistant should
        // always follow) -- loaded/saved through the same license-key-
        // authenticated proxy as the providers above.
        var skillTextarea = document.getElementById('muru-ai-skill-content');
        var skillFileInput = document.getElementById('muru-ai-skill-file');
        var skillSaveBtn = document.getElementById('muru-ai-skill-save');
        var skillStatus = document.getElementById('muru-ai-skill-status');
        var skillLoaded = false;

        if (skillTextarea && skillSaveBtn) {
            function loadSkill() {
                ajax('getskill', {}).then(function (res) {
                    skillTextarea.value = res.content || '';
                });
            }
            aiTabBtn.addEventListener('click', function () {
                if (skillLoaded) return;
                skillLoaded = true;
                loadSkill();
            });
            skillFileInput.addEventListener('change', function () {
                var file = skillFileInput.files[0];
                if (!file) return;
                var reader = new FileReader();
                reader.onload = function () { skillTextarea.value = String(reader.result || ''); };
                reader.readAsText(file);
            });
            skillSaveBtn.addEventListener('click', function () {
                skillStatus.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_TESTING_MSG')) ?>;
                skillStatus.className = 'text-xs text-gray-500';
                ajax('saveskill', { content: skillTextarea.value }).then(function (res) {
                    if (res.error) { skillStatus.textContent = res.error; skillStatus.className = 'text-xs text-red-600'; return; }
                    skillStatus.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_PROVIDER_SAVED_MSG')) ?>;
                    skillStatus.className = 'text-xs text-emerald-600';
                });
            });
        }
    })();

    // ── Settings > Pro Features > Alert Channel "Test" buttons ────
    // Sends whatever is currently typed into that channel's fields (not
    // necessarily saved yet) through scanner.testalertchannel -- same
    // CSRF pattern as the AI provider test button above (form token as
    // a query param, since Session::checkToken('request') accepts it
    // via GET or POST).
    (function () {
        var testBtns = document.querySelectorAll('.muru-test-alert-btn');
        if (!testBtns.length) return;

        var proFormToken = <?= json_encode($this->aiFormToken) ?>;

        testBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var channel = btn.getAttribute('data-channel');
                var card = btn.closest('.border-gray-200');
                var statusEl = card ? card.querySelector('.muru-test-alert-status') : null;
                var payload = { channel: channel };
                if (channel === 'slack') {
                    payload.webhook = card.querySelector('#muru-alert-slack-webhook').value.trim();
                } else if (channel === 'discord') {
                    payload.webhook = card.querySelector('#muru-alert-discord-webhook').value.trim();
                } else if (channel === 'telegram') {
                    payload.botToken = card.querySelector('#muru-alert-telegram-token').value.trim();
                    payload.chatId = card.querySelector('#muru-alert-telegram-chatid').value.trim();
                }

                btn.disabled = true;
                if (statusEl) {
                    statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_ALERT_TESTING_MSG')) ?>;
                    statusEl.className = 'muru-test-alert-status text-xs text-gray-500';
                }

                fetch('index.php?option=com_muruguard&task=scanner.testalertchannel&' + encodeURIComponent(proFormToken) + '=1', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }).then(function (res) { return res.json(); }).then(function (res) {
                    btn.disabled = false;
                    if (!statusEl) return;
                    if (res.ok) {
                        statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_ALERT_TEST_SUCCESS_MSG')) ?>;
                        statusEl.className = 'muru-test-alert-status text-xs text-emerald-600';
                    } else {
                        statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_ALERT_TEST_FAILED_MSG')) ?>;
                        statusEl.className = 'muru-test-alert-status text-xs text-red-600';
                    }
                }).catch(function () {
                    btn.disabled = false;
                    if (statusEl) {
                        statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_ALERT_TEST_FAILED_MSG')) ?>;
                        statusEl.className = 'muru-test-alert-status text-xs text-red-600';
                    }
                });
            });
        });
    })();

    // ── Settings > Site Protection > "Test a request" ───────────────
    // Read-only preview: posts whatever's typed into the URL/IP/User-
    // Agent/Referer fields to scanner.testfirewallrequest, which runs it
    // through the same checks the live gate uses without ever writing
    // to the attack log or blocking anything, then renders one row per
    // check underneath the button.
    (function () {
        var btn = document.getElementById('muru-test-request-btn');
        var resultsEl = document.getElementById('muru-test-request-results');
        if (!btn || !resultsEl) return;

        var testToken = <?= json_encode(\Joomla\CMS\Session\Session::getFormToken()) ?>;
        var verdictStyles = {
            'block': 'bg-red-50 text-red-700 border-red-200',
            'flagged-not-blocking': 'bg-amber-50 text-amber-700 border-amber-200',
            'allow': 'bg-emerald-50 text-emerald-700 border-emerald-200',
            'allow-override': 'bg-emerald-50 text-emerald-700 border-emerald-200',
            'no-match': 'bg-gray-50 text-gray-600 border-gray-200',
            'not-tested': 'bg-gray-50 text-gray-400 border-gray-200',
        };
        var verdictLabels = {
            'block': <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_VERDICT_BLOCK')) ?>,
            'flagged-not-blocking': <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_VERDICT_FLAGGED')) ?>,
            'allow': <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_VERDICT_ALLOW')) ?>,
            'allow-override': <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_VERDICT_ALLOW')) ?>,
            'no-match': <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_VERDICT_ALLOW')) ?>,
            'not-tested': <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_VERDICT_SKIPPED')) ?>,
        };

        btn.addEventListener('click', function () {
            btn.disabled = true;
            resultsEl.innerHTML = '<p class="text-xs text-gray-400">' + <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_RUNNING')) ?> + '</p>';

            var body = new URLSearchParams();
            body.set('test_url', document.getElementById('muru-test-url').value);
            body.set('test_ip', document.getElementById('muru-test-ip').value);
            body.set('test_useragent', document.getElementById('muru-test-ua').value);
            body.set('test_referrer', document.getElementById('muru-test-referrer').value);
            body.set(testToken, '1');

            fetch('index.php?option=com_muruguard&task=scanner.testfirewallrequest', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body.toString(),
            }).then(function (res) { return res.json(); }).then(function (data) {
                btn.disabled = false;
                if (!data || !data.ok) {
                    resultsEl.innerHTML = '<p class="text-xs text-red-600">' + <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_FAILED')) ?> + '</p>';
                    return;
                }
                resultsEl.innerHTML = '';
                data.checks.forEach(function (c) {
                    var style = verdictStyles[c.verdict] || verdictStyles['no-match'];
                    var label = verdictLabels[c.verdict] || c.verdict;
                    // c.detail can echo back attacker-shaped text an admin
                    // typed into the test fields (e.g. the matched
                    // substring of a deliberately malicious test URL) --
                    // built with textContent, never innerHTML, so a test
                    // input crafted to include markup can't execute
                    // against the admin's own session viewing the result.
                    var row = document.createElement('div');
                    row.className = 'flex items-start gap-3 px-3 py-2 rounded-lg border text-xs ' + style;
                    var verdictSpan = document.createElement('span');
                    verdictSpan.className = 'font-bold uppercase tracking-wide shrink-0 mt-px';
                    verdictSpan.textContent = label;
                    var detailSpan = document.createElement('span');
                    var labelStrong = document.createElement('span');
                    labelStrong.className = 'font-semibold';
                    labelStrong.textContent = c.label + ':';
                    detailSpan.appendChild(labelStrong);
                    detailSpan.appendChild(document.createTextNode(' ' + c.detail));
                    row.appendChild(verdictSpan);
                    row.appendChild(detailSpan);
                    resultsEl.appendChild(row);
                });
            }).catch(function () {
                btn.disabled = false;
                resultsEl.innerHTML = '<p class="text-xs text-red-600">' + <?= json_encode(Text::_('COM_MURUGUARD_TEST_REQUEST_FAILED')) ?> + '</p>';
            });
        });
    })();

    // ── Settings > Pro Features > File Integrity Monitoring ────────
    // Both buttons drive the exact same chunked-AJAX-loop pattern as
    // muruRunChunkedScan() below, just against fimbuildchunk/
    // fimcheckchunk instead of scanchunk, and updating this card's own
    // inline status line instead of the full-screen scan overlay -- a
    // settings-panel action reads as calmer than the same big modal the
    // main "Run a Scan" flow uses.
    (function () {
        var buildBtn = document.getElementById('muru-fim-build-btn');
        var checkBtn = document.getElementById('muru-fim-check-btn');
        var statusEl = document.getElementById('muru-fim-status');
        if (!buildBtn && !checkBtn) return;

        var fimFormToken = <?= json_encode($this->aiFormToken) ?>;

        function runFimLoop(task, btn, otherBtn, onDone) {
            var isFirstCall = true;
            btn.disabled = true;
            if (otherBtn) otherBtn.disabled = true;

            function step() {
                var fd = new FormData();
                fd.append(fimFormToken, '1');
                fd.set('reset', isFirstCall ? '1' : '');
                isFirstCall = false;

                fetch('index.php?option=com_muruguard&task=scanner.' + task, {
                    method: 'POST',
                    body: fd,
                    credentials: 'same-origin',
                }).then(function (res) { return res.json(); }).then(function (data) {
                    if (data.error) {
                        statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_FIM_ERROR_MSG')) ?>;
                        statusEl.className = 'text-xs text-red-600 mt-1';
                        btn.disabled = false;
                        if (otherBtn) otherBtn.disabled = false;
                        return;
                    }

                    if (data.done) {
                        btn.disabled = false;
                        if (otherBtn) otherBtn.disabled = false;
                        onDone(data);
                        return;
                    }

                    statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_FIM_PROGRESS_PREFIX')) ?> +
                        ' ' + data.completedCount + ' / ' + data.totalCount +
                        (data.currentAreaLabel ? ' — ' + data.currentAreaLabel : '');
                    statusEl.className = 'text-xs text-gray-500 mt-1';

                    step();
                }).catch(function () {
                    statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_FIM_ERROR_MSG')) ?>;
                    statusEl.className = 'text-xs text-red-600 mt-1';
                    btn.disabled = false;
                    if (otherBtn) otherBtn.disabled = false;
                });
            }

            step();
        }

        if (buildBtn) {
            buildBtn.addEventListener('click', function () {
                if (!window.confirm(<?= json_encode(Text::_('COM_MURUGUARD_FIM_BUILD_CONFIRM')) ?>)) return;
                runFimLoop('fimbuildchunk', buildBtn, checkBtn, function () {
                    statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_FIM_BUILD_DONE_MSG')) ?>;
                    statusEl.className = 'text-xs text-emerald-600 mt-1';
                    // A bare reload() re-requests the CURRENT URL, which
                    // never carries view_panel/settings_tab (every panel/
                    // tab switch here is client-side-only, see
                    // activateSettingsTab() -- the address bar never
                    // changes) -- so a plain reload always lands back on
                    // Dashboard > General regardless of where this button
                    // actually was. Navigating explicitly back to this
                    // same tab is what actually shows the freshly-built
                    // baseline status where the admin is already looking.
                    window.location.href = 'index.php?option=com_muruguard&view_panel=settings&settings_tab=site_protection';
                });
            });
        }

        if (checkBtn) {
            checkBtn.addEventListener('click', function () {
                runFimLoop('fimcheckchunk', checkBtn, buildBtn, function (data) {
                    if (data.changedCount > 0) {
                        window.location.href = <?= json_encode(Route::_('index.php?option=com_muruguard', false)) ?>;
                        return;
                    }
                    statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_FIM_CHECK_CLEAN_MSG')) ?>;
                    statusEl.className = 'text-xs text-emerald-600 mt-1';
                });
            });
        }
    })();

    /**
     * Drives the chunked-scan AJAX loop: calls scanner.scanchunk repeatedly
     * (each call bounded to a fixed time budget server-side), showing REAL
     * progress -- how many of the site's scan areas are done so far --
     * rather than the rotating placeholder messages muruguardShowOverlay()
     * uses for the no-JS fallback path. Navigates to the results page once
     * done, same destination a normal form submit would have landed on.
     * Declared inside this IIFE (not at the top level, alongside
     * muruguardShowOverlay()) specifically so it can call closeScanModal(),
     * which is itself scoped in here -- calling it from an outer-scope
     * function throws "closeScanModal is not defined" regardless of call
     * order, since JS closures resolve by where a function is DEFINED, not
     * by where it's called from.
     */
    function muruRunChunkedScan(sourceForm) {
        closeScanModal();

        var overlay  = document.getElementById('muruguard-overlay');
        var statusEl = document.getElementById('muruguard-loading-status');
        overlay.classList.add('muruguard-show');
        statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_OVERLAY_STARTING')) ?>;

        var chunkUrl   = <?= json_encode(Route::_('index.php?option=com_muruguard&task=scanner.scanchunk', false)) ?>;
        var resultsUrl = <?= json_encode(Route::_('index.php?option=com_muruguard', false)) ?>;
        var isFirstCall = true;

        function step() {
            var fd = new FormData(sourceForm);
            if (isFirstCall) {
                fd.set('reset', '1');
            } else {
                // Only the very first call of a run should re-persist the
                // area picker / start a fresh queue -- every call after
                // that must continue the SAME in-progress queue, so it
                // deliberately leaves these out rather than resubmitting
                // them.
                fd.delete('areas_submitted');
                fd.delete('scan_areas[]');
                fd.set('reset', '');
            }
            isFirstCall = false;

            fetch(chunkUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data.error) { muruChunkScanFailed(data.error); return; }

                    if (data.done) {
                        if (data.truncatedLabels && data.truncatedLabels.length) {
                            window.alert(
                                <?= json_encode(Text::_('COM_MURUGUARD_CHUNK_TRUNCATED_ALERT')) ?> +
                                '\n\n' + data.truncatedLabels.join(', ')
                            );
                        }
                        window.location.href = resultsUrl;
                        return;
                    }

                    statusEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_CHUNK_PROGRESS_PREFIX')) ?> +
                        ' ' + data.completedCount + ' / ' + data.totalCount +
                        (data.currentAreaLabel ? ' — ' + data.currentAreaLabel : '');

                    step();
                })
                .catch(function () { muruChunkScanFailed(''); });
        }

        step();
    }

    function muruChunkScanFailed(detail) {
        var overlay = document.getElementById('muruguard-overlay');
        if (overlay) overlay.classList.remove('muruguard-show');
        window.alert(<?= json_encode(Text::_('COM_MURUGUARD_CHUNK_SCAN_ERROR')) ?> + (detail ? ' (' + detail + ')' : ''));
    }
})();

function muruOpenCodeModal(btn) {
    var modal   = document.getElementById('muru-modal');
    var badge   = document.getElementById('muru-modal-badge');
    var pathEl  = document.getElementById('muru-modal-path');
    var bodyEl  = document.getElementById('muru-modal-body');
    var conf    = btn.getAttribute('data-confidence') || 'medium';
    var blocks  = [];
    try { blocks = JSON.parse(btn.getAttribute('data-reasons') || '[]'); } catch (err) { blocks = []; }

    badge.textContent = conf === 'high' ? '🔴 High confidence' : '🟡 Needs manual review';
    badge.className = conf === 'high' ? 'high' : 'medium';
    pathEl.textContent = btn.getAttribute('data-path') || '';
    // blocks[] is pre-rendered, escaped HTML built server-side in
    // MuruguardHelper::formatReasonForDisplay() / formatCleanPreview() --
    // nothing user-controlled reaches innerHTML unescaped here.
    bodyEl.innerHTML = blocks.join('');

    // Reset any AI review left over from a previously-opened finding --
    // this modal is reused across rows, so a stale verdict must never
    // appear to belong to the file now showing.
    var aiSection = document.getElementById('muru-modal-ai-section');
    var aiBtn = document.getElementById('muru-modal-ai-btn');
    var aiResultWrap = document.getElementById('muru-modal-ai-result-wrap');
    var aiResult = document.getElementById('muru-modal-ai-result');
    if (aiBtn) { aiBtn.disabled = false; aiBtn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_REVIEW_BTN')) ?>; }
    if (aiResultWrap) aiResultWrap.classList.add('hidden');
    if (aiResult) { aiResult.textContent = ''; aiResult.classList.remove('muru-ai-error'); }
    // A directory finding has no file content for the AI to read --
    // hide the whole AI section rather than offering a button that can
    // only ever fail.
    if (aiSection) aiSection.classList.toggle('hidden', btn.getAttribute('data-type') === 'dir');

    modal.classList.add('muru-show');
    document.body.style.overflow = 'hidden';
}

// ── AI review of a single finding (Pro) -- purely advisory, see
// MuruguardControllerScanner::aireviewfinding()'s docblock. Never marks
// anything safe or deletes anything on its own. Callable both from the
// button inside the modal and from the 🤖 shortcut on each table row
// (which opens the modal via muruOpenCodeModal() first, then calls this
// immediately so both entry points land on the same result).
function muruRunAiReview() {
    var btn = document.getElementById('muru-modal-ai-btn');
    var pathEl = document.getElementById('muru-modal-path');
    var resultWrap = document.getElementById('muru-modal-ai-result-wrap');
    var resultEl = document.getElementById('muru-modal-ai-result');
    var path = pathEl ? pathEl.textContent : '';
    if (!btn || !path || btn.disabled) return;

    btn.disabled = true;
    btn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_REVIEW_LOADING')) ?>;
    resultWrap.classList.remove('hidden');
    resultEl.classList.remove('muru-ai-error');
    resultEl.textContent = '';

    var aiReviewToken = <?= json_encode($this->aiFormToken) ?>;
    fetch('index.php?option=com_muruguard&task=scanner.aireviewfinding&' + encodeURIComponent(aiReviewToken) + '=1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: path }),
    })
        .then(function (res) { return res.json().then(function (data) { return { ok: res.ok, data: data }; }); })
        .then(function (r) {
            if (!r.ok || !r.data || !r.data.ok) {
                resultEl.textContent = (r.data && r.data.error === 'ai_not_configured')
                    ? <?= json_encode(Text::_('COM_MURUGUARD_AI_NOT_CONFIGURED_MSG')) ?>
                    : <?= json_encode(Text::_('COM_MURUGUARD_AI_REVIEW_ERROR')) ?>;
                resultEl.classList.add('muru-ai-error');
                btn.disabled = false;
                btn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_REVIEW_BTN')) ?>;
                return;
            }
            resultEl.textContent = r.data.review;
            btn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_REVIEW_BTN')) ?>;
            btn.disabled = false;
        })
        .catch(function () {
            resultEl.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_REVIEW_ERROR')) ?>;
            resultEl.classList.add('muru-ai-error');
            btn.disabled = false;
            btn.textContent = <?= json_encode(Text::_('COM_MURUGUARD_AI_REVIEW_BTN')) ?>;
        });
}

document.addEventListener('click', function (e) {
    if (e.target.id === 'muru-modal-ai-btn') muruRunAiReview();
});

// Row-level 🤖 shortcut -- same data-path/data-confidence/data-reasons
// as the 🧬 Code Issues button, so it opens the same modal, then
// immediately runs the review instead of requiring a second click.
document.addEventListener('click', function (e) {
    var shortcutBtn = e.target.closest('.muru-ai-review-shortcut');
    if (!shortcutBtn) return;
    muruOpenCodeModal(shortcutBtn);
    muruRunAiReview();
});

// ♻️ Restore a core file from its official checksum baseline -- see
// MuruguardHelper::restoreCoreFileFromBaseline()'s own docblock for the
// fetch+verify+backup sequence. Own local token (same pattern as
// muruRunAiReview() above) rather than reusing a variable from a
// different closure's scope.
document.addEventListener('click', function (e) {
    var btn = e.target.closest('.muru-restore-core-btn');
    if (!btn) return;

    var relPath = btn.getAttribute('data-rel-path') || '';
    if (!relPath) return;
    if (!confirm(<?= json_encode(Text::_('COM_MURUGUARD_RESTORE_CORE_CONFIRM')) ?>)) return;

    var restoreToken = <?= json_encode($this->aiFormToken) ?>;
    btn.disabled = true;

    var body = new URLSearchParams();
    body.set(restoreToken, '1');
    body.set('rel_path', relPath);

    fetch('index.php?option=com_muruguard&task=scanner.restorecorefile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
    }).then(function (res) {
        return res.json().catch(function () { return null; }).then(function (data) { return { ok: res.ok, data: data }; });
    }).then(function (r) {
        if (!r.data || !r.data.ok) {
            alert((r.data && r.data.error) ? r.data.error : <?= json_encode(Text::_('COM_MURUGUARD_RESTORE_CORE_ERROR')) ?>);
            btn.disabled = false;
            return;
        }
        alert(<?= json_encode(Text::_('COM_MURUGUARD_RESTORE_CORE_OK')) ?>);
        window.location.reload();
    }).catch(function () {
        alert(<?= json_encode(Text::_('COM_MURUGUARD_RESTORE_CORE_ERROR')) ?>);
        btn.disabled = false;
    });
});

function muruCloseCodeModal() {
    var modal = document.getElementById('muru-modal');
    modal.classList.remove('muru-show');
    document.body.style.overflow = '';
}

function muruCopyPath(btn) {
    var text = btn.getAttribute('data-copy') || '';
    var icon = btn.querySelector('.muru-copy-icon');

    function showCopied() {
        if (!icon) return;
        icon.textContent = '✅';
        btn.classList.add('muru-copied');
        setTimeout(function () {
            icon.textContent = '📋';
            btn.classList.remove('muru-copied');
        }, 1200);
    }

    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(showCopied).catch(function () { muruCopyPathFallback(text, showCopied); });
    } else {
        muruCopyPathFallback(text, showCopied);
    }
}

function muruCopyPathFallback(text, onDone) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try { document.execCommand('copy'); onDone(); } catch (err) { /* clipboard unavailable -- no-op */ }
    document.body.removeChild(ta);
}

function muruUpdateAreaCount() {
    var boxes = document.querySelectorAll('.muru-area-chk');
    if (!boxes.length) return;
    var checked = 0;
    boxes.forEach(function (c) { if (c.checked) checked++; });

    var countEl = document.getElementById('muru-area-count');
    if (countEl) countEl.textContent = checked;

    var master = document.getElementById('muru-area-all');
    if (master) {
        master.checked = checked === boxes.length;
        master.indeterminate = checked > 0 && checked < boxes.length;
    }
}

function muruguardShowOverlay() {
    var overlay  = document.getElementById('muruguard-overlay');
    var statusEl = document.getElementById('muruguard-loading-status');

    overlay.classList.add('muruguard-show');

    var messages = <?= json_encode([
        Text::_('COM_MURUGUARD_OVERLAY_STARTING'),
        Text::_('COM_MURUGUARD_SCAN_MSG_2'),
        Text::_('COM_MURUGUARD_SCAN_MSG_3'),
        Text::_('COM_MURUGUARD_SCAN_MSG_4'),
        Text::_('COM_MURUGUARD_SCAN_MSG_5'),
        Text::_('COM_MURUGUARD_SCAN_MSG_6'),
    ]) ?>;
    var i = 0;
    statusEl.textContent = messages[0];
    // Cycles purely for perceived progress -- only reachable when fetch()
    // isn't available and the form falls back to one blocking submit (see
    // above), so there's no real per-chunk progress to show instead.
    setInterval(function () {
        i = (i + 1) % messages.length;
        statusEl.style.opacity = '0';
        setTimeout(function () {
            statusEl.textContent = messages[i];
            statusEl.style.opacity = '1';
        }, 200);
    }, 2200);
}
</script>