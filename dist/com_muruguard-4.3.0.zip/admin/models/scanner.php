<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;

require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/compat.php';
require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/muruguard.php';
require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/insights.php';
require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/extensions.php';

/**
 * Internal control-flow signal only -- thrown from inside scanFilesystem()'s
 * walkDir() callback when a chunked scan's wall-clock deadline is reached
 * mid-directory, caught one level up around that single area's walk so the
 * area is marked truncated and the next chunk request can move on to the
 * next area instead of the whole HTTP request running past a host's
 * execution-time limit. Never escapes scanFilesystem() itself.
 */
class MuruguardScanChunkTimeout extends \RuntimeException
{
}

// Base class from helpers/compat.php: the native BaseDatabaseModel on
// Joomla 4+, JModelLegacy plus a getDatabase() polyfill on Joomla 3.
class MuruguardModelScanner extends MuruguardCompatDatabaseModel
{
    protected string $root;
    protected array $fileFindings = [];
    protected array $dbFindings = [
        'superusers' => [], 'menu_xss' => [], 'sppb_assets' => [],
        'rogue_iconfont' => [], 'template_defacement' => [], 'vulnerable_extensions' => [], 'sppb_pages' => [],
    ];
    protected array $seenAbs = [];
    protected ?array $registeredTemplatesCache = null;
    protected ?array $registeredPluginsCache = null;
    protected ?array $registeredComponentsCache = null;
    // Areas whose walk was cut off by a chunk deadline mid-directory rather
    // than finishing naturally -- see MuruguardScanChunkTimeout. Surfaced by
    // runScanChunk() so a pathologically large single folder is reported
    // honestly as "scanned up to the time budget" instead of silently
    // passing as complete.
    protected array $truncatedAreas = [];
    /** Entries already walked per area in an earlier chunk, so a timed-out area continues where it stopped. */
    protected array $resumeSkips = [];
    /** Entries visited so far in the area being walked. */
    protected int $walkCounter = 0;

    public function __construct($config = [])
    {
        parent::__construct($config);
        $this->root = JPATH_ROOT;
    }

    /**
     * Joomla's own #__extensions table is the actual source of truth for
     * "is this template really installed" -- a real, in-the-wild attack
     * seen on a live site faked EVERY filesystem-level signal at once
     * (the template folder, a templateDetails.xml manifest inside it, and
     * a matching #__template_styles row), so a check based purely on
     * what's sitting on disk can be, and was, fully spoofed. It could not,
     * however, make its faked #__extensions rows enabled -- every one of
     * them was left at enabled=0, unlike every genuinely-installed
     * template. Returns ['<client_id>|<element lowercase>' => enabled
     * (bool)] for every row of type "template", built once per request
     * and shared by both scanFilesystem() and scanDatabase() so a single
     * DB scan (in runScheduledCheck()) only queries this once. Public so
     * the view layer can also cross-reference it when deciding which tab
     * (Suspicious vs Cleanable) a template-root index.php finding
     * belongs in -- see default.php's $notDeletable closure.
     */
    public function getRegisteredTemplates(): ?array
    {
        if ($this->registeredTemplatesCache !== null) {
            return $this->registeredTemplatesCache;
        }

        try {
            $registry = [];
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['element', 'client_id', 'enabled']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('template'));
            $db->setQuery($query);
            foreach ($db->loadAssocList() ?: [] as $row) {
                $key = ((int) $row['client_id']) . '|' . strtolower((string) $row['element']);
                $registry[$key] = (bool) $row['enabled'];
            }
        } catch (\Throwable $e) {
            // Query failed for some reason -- return null (not an empty
            // array) so callers fall back to weaker filesystem-only
            // signals instead of treating a failed query as "definitely no
            // templates are registered", which would flood false positives.
            return null;
        }

        return $this->registeredTemplatesCache = $registry;
    }

    /**
     * Same idea as getRegisteredTemplates(), for plugins -- a real, live
     * compromise dropped fake plugin folders (plugins/system/data,
     * plugins/system/loader, plugins/system/core, ...) each holding a
     * self-decoding backdoor, WITH matching #__extensions rows.
     *
     * IMPORTANT: unlike templates, "enabled=0" is NOT a reliable fake
     * signal for plugins on its own -- a stock Joomla install ships
     * several genuinely core plugins disabled by default (e.g.
     * plg_authentication_ldap, plg_api-authentication_basic), so a naive
     * "disabled = suspicious" check flags every real site running with
     * Joomla's own defaults. Only a completely MISSING #__extensions row
     * (checkJunkExtensionFolder() checks array_key_exists against this
     * map) is used as the structural signal; "enabled" is still returned
     * here for callers that want it, but is deliberately not treated as
     * suspicious by itself. Components were also faked in that attack but
     * with enabled=1 -- see getRegisteredComponents() for why that needs
     * yet another signal (manifest_cache, not enabled). Returns
     * ['<folder>|<element lowercase>' => enabled (bool)] for every row of
     * type "plugin" (folder = the plugin group, e.g. "system"; element =
     * the plugin name, e.g. "log" -- together they match a
     * plugins/<folder>/<element> path).
     */
    protected function getRegisteredPlugins(): ?array
    {
        if ($this->registeredPluginsCache !== null) {
            return $this->registeredPluginsCache;
        }

        try {
            $registry = [];
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['element', 'folder', 'enabled']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'));
            $db->setQuery($query);
            foreach ($db->loadAssocList() ?: [] as $row) {
                $key = strtolower((string) $row['folder']) . '|' . strtolower((string) $row['element']);
                $registry[$key] = (bool) $row['enabled'];
            }
        } catch (\Throwable $e) {
            return null;
        }

        return $this->registeredPluginsCache = $registry;
    }

    /**
     * Components equivalent of getRegisteredTemplates()/getRegisteredPlugins()
     * -- but keyed on a DIFFERENT signal. A real, live compromise faked
     * components/com_feed, com_stat, com_base, com_track, com_util with
     * matching #__extensions rows left ENABLED (unlike the disabled fake
     * template/plugin rows), so "enabled" doesn't discriminate here at
     * all. What a raw SQL-inserted fake row realistically won't have is a
     * populated manifest_cache -- Joomla's installer generates this JSON
     * blob (name, version, description, ...) from the extension's XML
     * manifest at install time for every genuinely-installed extension,
     * including every core component; an attacker forging a single
     * #__extensions row directly has no reason to also hand-craft a
     * matching manifest_cache blob. Returns ['<element lowercase>' =>
     * hasManifestCache (bool)] for every row of type "component".
     */
    protected function getRegisteredComponents(): ?array
    {
        if ($this->registeredComponentsCache !== null) {
            return $this->registeredComponentsCache;
        }

        try {
            $registry = [];
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['element', 'manifest_cache']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'));
            $db->setQuery($query);
            foreach ($db->loadAssocList() ?: [] as $row) {
                $key = strtolower((string) $row['element']);
                $cache = trim((string) $row['manifest_cache']);
                $registry[$key] = $cache !== '' && $cache !== '{}' && strtolower($cache) !== 'null';
            }
        } catch (\Throwable $e) {
            return null;
        }

        return $this->registeredComponentsCache = $registry;
    }

    /**
     * The scan areas the user ticked in the pre-scan directory picker.
     * Stored in the session so both the fresh scan and the cached-result
     * re-display honour the same selection. An empty selection means
     * "scan everything" (backwards-compatible default).
     */
    protected function selectedAreas(): array
    {
        return (array) MuruguardCompat::getSession()->get('muruguard.scan_areas', []);
    }

    /** True if $key was selected (or if nothing was explicitly selected). */
    protected function isAreaSelected(string $key): bool
    {
        $sel = $this->selectedAreas();
        return empty($sel) || in_array($key, $sel, true);
    }

    // ------------------------------------------------------------------
    // Public accessors used by the view
    // ------------------------------------------------------------------

    public function getFileFindings(): array
    {
        $session = MuruguardCompat::getSession();
        $forceRescan = Factory::getApplication()->input->getBool('rescan', false);

        if (!$forceRescan) {
            $cached = $session->get('muruguard.filefindings');
            $cachedAt = $session->get('muruguard.filefindings_time', 0);
            if (is_array($cached) && (time() - $cachedAt) < 300) {
                $this->fileFindings = $cached;
                return $this->fileFindings;
            }
        }

        $this->scanFilesystem();
        $session->set('muruguard.filefindings', $this->fileFindings);
        $session->set('muruguard.filefindings_time', time());
        return $this->fileFindings;
    }

    public function getDbFindings(): array
    {
        $this->scanDatabase();
        return $this->dbFindings;
    }

    /** True if a scan result is already sitting in the session cache. */
    public function hasCachedScan(): bool
    {
        $cached = MuruguardCompat::getSession()->get('muruguard.filefindings');
        return is_array($cached);
    }

    /**
     * Called by the controller's scan() task.
     * Forces a fresh filesystem walk, stores result in session, returns time.
     */
    public function runScan(): int
    {
        $session = MuruguardCompat::getSession();
        $this->scanFilesystem();
        $now = time();
        $session->set('muruguard.filefindings', $this->fileFindings);
        $session->set('muruguard.filefindings_time', $now);
        return $now;
    }

    /**
     * Full scan + diff-against-last-run, for the scheduled/webcron entry
     * point (see ScannerController::scheduledcheck()). There's no HTTP
     * session in a cron context, so the set of finding keys from the
     * PREVIOUS run is persisted in a small JSON file this component owns
     * (see loadLastScanKeys()/saveLastScanKeys() below) rather than the
     * session -- no new DB table, and deliberately NOT the component's
     * config params (see scanHistoryFilePath() for why).
     *
     * Deliberately never sends anything itself -- it only decides WHAT is
     * new, so the Joomla-Mailer-specific code stays in the controller.
     * On the very first run ever (no previous snapshot exists yet) this
     * only records a baseline and reports isFirstRun = true, so the
     * caller can skip alerting on a site's entire pre-existing finding
     * list the first time this ever runs.
     */
    // ------------------------------------------------------------------
    // Dashboard insights (see helpers/insights.php) -- read-only facts
    // that need no scan. Every piece is isolated: one failing source
    // leaves its own card empty, never the page.
    // ------------------------------------------------------------------

    /**
     * @param int $openFindings scan findings to include in the score, or -1 when no scan has run this session
     * @param array $htaccess MuruguardHelper::getHtaccessSuggestions() result
     */
    public function getInsights(int $openFindings, int $vulnerableExtensions, array $htaccess): array
    {
        $now = time();
        $cfgParams = ComponentHelper::getParams('com_muruguard');
        $out = [];

        $phpSupport = \MuruguardInsights::phpSupportStatus(PHP_VERSION, $now);
        $releases = [];
        if (preg_match('/^(\d+\.\d+)/', PHP_VERSION, $m)) {
            try { $releases = \MuruguardInsights::fetchPhpReleases($m[1]); } catch (\Throwable $e) { $releases = []; }
        }
        $out['php'] = ['version' => \MuruguardInsights::phpVersionTriple(PHP_VERSION), 'support' => $phpSupport,
                       'php2shell' => \MuruguardInsights::php2shellStatus(PHP_VERSION)];
        $out['phpBanner'] = \MuruguardInsights::phpBannerState(PHP_VERSION, $phpSupport, $releases);

        $out['joomla'] = \MuruguardInsights::joomlaStatus(defined('JVERSION') ? JVERSION : '', $this->getLatestCoreVersion());

        $isHttps = false;
        try { $isHttps = \Joomla\CMS\Uri\Uri::getInstance()->isSsl(); } catch (\Throwable $e) {}
        $out['https'] = $isHttps;
        $out['config'] = \MuruguardInsights::configChecks($this->getGlobalConfigValues(), $isHttps);
        try {
            $out['admins'] = \MuruguardInsights::adminChecks($this->getSuperUsers());
        } catch (\Throwable $e) {
            $out['admins'] = [];
        }
        $out['exposed'] = \MuruguardInsights::findExposedFiles($this->root);

        $log = MuruguardHelper::getAttackLog();
        $out['threats24h'] = \MuruguardInsights::summarizeThreats($log, $now - 86400);
        // The live log keeps the newest 500 entries; older ones are in the archive.
        $oldest = $log === [] ? $now : (int) (end($log)['time'] ?? $now);
        $weekLog = $oldest > $now - 7 * 86400 ? array_merge($log, MuruguardHelper::getAttackLogArchive()) : $log;
        $out['threats7d'] = \MuruguardInsights::summarizeThreats($weekLog, $now - 7 * 86400);

        try { $out['news'] = \MuruguardInsights::fetchSecurityNews(5); } catch (\Throwable $e) { $out['news'] = []; }

        try {
            $out['extensions'] = $this->getExtensionHealth($now);
        } catch (\Throwable $e) {
            $out['extensions'] = ['abandoned' => [], 'unused' => [], 'checked' => 0];
        }

        $htTotal = count($htaccess['checks'] ?? []);
        $htPresent = count(array_filter($htaccess['checks'] ?? [], fn($c) => !empty($c['present'])));
        $out['score'] = \MuruguardInsights::computeSecurityScore([
            'https'                   => $isHttps,
            'shield_enabled'          => (bool) $cfgParams->get('shield_enabled', 0) && $this->isShieldPluginActive(),
            'backend_auth_enabled'    => (bool) $cfgParams->get('backend_auth_enabled', 0),
            'htaccess_checks_present' => $htPresent,
            'htaccess_checks_total'   => $htTotal,
            'vulnerable_extensions'   => $vulnerableExtensions,
            'joomla_status'           => $out['joomla']['status'],
            'php_banner'              => $out['phpBanner'] !== null,
            'config_issues'           => count(array_filter($out['config'], fn($r) => !$r['ok'])),
            'admin_issues'            => count(array_filter($out['admins'], fn($r) => !$r['ok'])),
            'exposed_files'           => count($out['exposed']),
            'open_findings'           => max(0, $openFindings),
        ]);
        $out['scanned'] = $openFindings >= 0;
        return $out;
    }

    /**
     * Installed third-party extensions worth a second look (see MuruguardExtensionHealth): abandoned ones and unused
     * ones. Core extensions, MuRu Guard itself and the parts of an installed package (they cannot be removed on their
     * own) are left out. Plain queries only, so it runs on Joomla 3.10 and Joomla 4 to 6.
     */
    public function getExtensionHealth(int $now): array
    {
        $db = $this->getDatabase();
        $types = array_map([$db, 'quote'], ['component', 'module', 'plugin', 'template', 'library', 'package', 'file']);
        $all = (array) $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName(['extension_id', 'name', 'type', 'element', 'folder', 'client_id', 'enabled', 'manifest_cache', 'package_id']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' IN (' . implode(',', $types) . ')')
        )->loadAssocList('extension_id');

        $sites = array_flip(array_map('intval', (array) $db->setQuery(
            $db->getQuery(true)->select('DISTINCT ' . $db->quoteName('use.extension_id'))
                ->from($db->quoteName('#__update_sites_extensions', 'use'))
                ->join('INNER', $db->quoteName('#__update_sites', 'us') . ' ON ' . $db->quoteName('us.update_site_id') . ' = ' . $db->quoteName('use.update_site_id'))
                ->where($db->quoteName('us.enabled') . ' = 1')
        )->loadColumn()));
        $updates = array_flip(array_map('intval', (array) $db->setQuery(
            $db->getQuery(true)->select('DISTINCT ' . $db->quoteName('extension_id'))->from($db->quoteName('#__updates'))
                ->where($db->quoteName('extension_id') . ' > 0')
        )->loadColumn()));

        // Published module instances per module and client.
        $published = [];
        foreach ((array) $db->setQuery(
            $db->getQuery(true)->select([$db->quoteName('module'), $db->quoteName('client_id'), 'COUNT(*) AS n'])
                ->from($db->quoteName('#__modules'))->where($db->quoteName('published') . ' = 1')
                ->group([$db->quoteName('module'), $db->quoteName('client_id')])
        )->loadAssocList() as $m) {
            $published[$m['module'] . '|' . (int) $m['client_id']] = (int) $m['n'];
        }
        // Site templates in use: a default style (home is '1' or a language code) or a style a menu item uses.
        $styleTemplate = [];
        $templateInUse = [];
        foreach ((array) $db->setQuery(
            $db->getQuery(true)->select($db->quoteName(['id', 'template', 'home']))->from($db->quoteName('#__template_styles'))
                ->where($db->quoteName('client_id') . ' = 0')
        )->loadAssocList() as $st) {
            $styleTemplate[(int) $st['id']] = (string) $st['template'];
            if ((string) $st['home'] !== '0' && (string) $st['home'] !== '') $templateInUse[(string) $st['template']] = true;
        }
        foreach ((array) $db->setQuery(
            $db->getQuery(true)->select('DISTINCT ' . $db->quoteName('template_style_id'))->from($db->quoteName('#__menu'))
                ->where($db->quoteName('template_style_id') . ' > 0')->where($db->quoteName('client_id') . ' = 0')
        )->loadColumn() as $sid) {
            if (isset($styleTemplate[(int) $sid])) $templateInUse[$styleTemplate[(int) $sid]] = true;
        }

        $abandonedRows = [];
        $unusedRows = [];
        $owners = [];
        $checked = 0;
        foreach ($all as $id => $e) {
            $pkg = (int) ($e['package_id'] ?? 0);
            if ($pkg > 0 && isset($all[$pkg])) continue; // part of an installed package: judged as the package
            $core = false;
            try {
                $core = \Joomla\CMS\Extension\ExtensionHelper::checkIfCoreExtension((string) $e['type'], (string) $e['element'], (int) $e['client_id'], (string) $e['folder']);
            } catch (\Throwable $ex) {
                continue; // without the core list nothing can be told apart: never guess
            }
            if ($core) continue;
            $checked++;
            if ($e['type'] === 'component') $owners[] = preg_replace('/^com_/', '', (string) $e['element']);
            if ($e['type'] === 'template') $owners[] = (string) $e['element'];
            $mc = json_decode((string) $e['manifest_cache'], true) ?: [];
            $name = (string) ($mc['name'] ?? $e['name']);
            $installed = null;
            foreach (\MuruguardExtensionHealth::manifestCandidates((string) $e['type'], (string) $e['element'], (string) $e['folder'], (int) $e['client_id']) as $file) {
                if (is_file($file)) { $installed = (int) filemtime($file); break; }
            }
            $abandonedRows[] = [
                'id' => (int) $id, 'name' => $name, 'type' => (string) $e['type'], 'element' => (string) $e['element'],
                'created' => (string) ($mc['creationDate'] ?? ''), 'version' => (string) ($mc['version'] ?? ''), 'installed' => $installed,
                'hasUpdateSite' => isset($sites[(int) $id]), 'updateAvailable' => isset($updates[(int) $id]),
            ];
            if (in_array($e['type'], ['component', 'module', 'plugin', 'template'], true)) {
                $row = ['id' => (int) $id, 'name' => $name, 'type' => (string) $e['type'], 'element' => (string) $e['element'],
                        'folder' => (string) $e['folder'], 'enabled' => (int) $e['enabled'] === 1, 'clientId' => (int) $e['client_id']];
                if ($e['type'] === 'module') $row['publishedModules'] = $published[$e['element'] . '|' . (int) $e['client_id']] ?? 0;
                if ($e['type'] === 'template' && (int) $e['client_id'] === 0) $row['templateInUse'] = isset($templateInUse[(string) $e['element']]);
                $unusedRows[] = $row;
            }
        }
        $abandoned = \MuruguardExtensionHealth::abandoned($abandonedRows, $now);
        $unused = \MuruguardExtensionHealth::unused($unusedRows, $owners);
        // Names as the Extensions screen shows them: many manifests hold a language key, not the name.
        $byId = [];
        foreach ($all as $id => $e) $byId[(int) $id] = $e;
        foreach ([&$abandoned, &$unused] as &$list) {
            foreach ($list as &$item) {
                if (isset($byId[$item['id']])) $item['name'] = $this->translatedExtensionName($byId[$item['id']], $item['name']);
            }
            unset($item);
        }
        unset($list);
        return ['abandoned' => $abandoned, 'unused' => $unused, 'checked' => $checked];
    }

    /** Loads an extension's .sys.ini (like Joomla's Extensions screen) and returns its translated name. */
    private function translatedExtensionName(array $e, string $name): string
    {
        try {
            $lang = Factory::getLanguage();
            $element = (string) $e['element'];
            $type = (string) $e['type'];
            $client = (int) $e['client_id'] === 1 ? JPATH_ADMINISTRATOR : JPATH_SITE;
            switch ($type) {
                case 'component':
                    $lang->load($element . '.sys', JPATH_ADMINISTRATOR) || $lang->load($element . '.sys', JPATH_ADMINISTRATOR . '/components/' . $element);
                    break;
                case 'module':
                    $lang->load($element . '.sys', $client) || $lang->load($element . '.sys', $client . '/modules/' . $element);
                    break;
                case 'plugin':
                    $file = 'plg_' . $e['folder'] . '_' . $element . '.sys';
                    $lang->load($file, JPATH_ADMINISTRATOR) || $lang->load($file, JPATH_PLUGINS . '/' . $e['folder'] . '/' . $element);
                    break;
                case 'template':
                    $lang->load('tpl_' . $element . '.sys', $client) || $lang->load('tpl_' . $element . '.sys', $client . '/templates/' . $element);
                    break;
            }
            $t = Text::_($name);
            return $t !== '' ? $t : $name;
        } catch (\Throwable $ex) {
            return $name;
        }
    }

    /** Newest Joomla core version Joomla's own updater has found, or null when it has not checked. */
    private function getLatestCoreVersion(): ?string
    {
        try {
            $db = $this->getDatabase();
            $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('version'))
                    ->from($db->quoteName('#__updates'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('joomla'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('file'))
            );
            $latest = null;
            foreach ((array) $db->loadColumn() as $v) {
                $v = (string) $v;
                if (preg_match('/^\d+\.\d+\.\d+$/', $v) && ($latest === null || version_compare($v, $latest, '>'))) $latest = $v;
            }
            return $latest;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function getGlobalConfigValues(): array
    {
        $app = Factory::getApplication();
        $out = [];
        foreach (['debug', 'error_reporting', 'force_ssl', 'sef'] as $key) {
            $out[$key] = $app->get($key);
        }
        // Joomla 3 only: the setting does not exist on 4+.
        if ($app->get('ftp_enable', null) !== null) $out['ftp_enable'] = $app->get('ftp_enable');
        return $out;
    }

    /**
     * Every account that holds core.admin (Super User) through any of its
     * groups, including blocked ones (adminChecks() filters those).
     *
     * @return list<array{id:int,username:string,lastvisitDate:?string,block:int}>
     */
    private function getSuperUsers(): array
    {
        $db = $this->getDatabase();
        $db->setQuery($db->getQuery(true)->select($db->quoteName('id'))->from($db->quoteName('#__usergroups')));
        $superGroups = [];
        foreach ((array) $db->loadColumn() as $gid) {
            if (\Joomla\CMS\Access\Access::checkGroup((int) $gid, 'core.admin')) $superGroups[] = (int) $gid;
        }
        if ($superGroups === []) return [];

        $db->setQuery(
            $db->getQuery(true)
                ->select('DISTINCT ' . implode(', ', $db->quoteName(['u.id', 'u.username', 'u.lastvisitDate', 'u.block'])))
                ->from($db->quoteName('#__users', 'u'))
                ->join('INNER', $db->quoteName('#__user_usergroup_map', 'm') . ' ON ' . $db->quoteName('m.user_id') . ' = ' . $db->quoteName('u.id'))
                ->where($db->quoteName('m.group_id') . ' IN (' . implode(',', $superGroups) . ')')
        );
        $rows = [];
        foreach ((array) $db->loadAssocList() as $r) {
            $rows[] = ['id' => (int) $r['id'], 'username' => (string) $r['username'], 'lastvisitDate' => $r['lastvisitDate'], 'block' => (int) $r['block']];
        }
        return $rows;
    }

    // ------------------------------------------------------------------
    // Upload lockdown (see MuruguardHardeningHelper)
    // ------------------------------------------------------------------

    public function getUploadLockState(): ?array
    {
        require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/hardening.php';
        return \MuruguardHardeningHelper::maintainUploadLock($this->root);
    }

    public function activateUploadLock(int $hours, bool $includeAdmin): array
    {
        require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/hardening.php';
        return \MuruguardHardeningHelper::activateUploadLock($this->root, \Joomla\CMS\Uri\Uri::root(), $hours, $includeAdmin);
    }

    public function deactivateUploadLock(): void
    {
        require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/hardening.php';
        \MuruguardHardeningHelper::deactivateUploadLock($this->root);
    }

    /** Downloads or refreshes the local GeoIP database when country blocking is on or a copy already exists. Never throws. */
    public function refreshGeoIpIfInUse(bool $countryBlockingOn): ?array
    {
        try {
            require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/geoip.php';
            if (!$countryBlockingOn && !is_file(\MuruguardGeoIp::dbPath())) return null;
            return \MuruguardGeoIp::refreshIfStale();
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** For the Settings panel: whether the local country database is installed and how old it is. */
    public function getGeoIpStatus(): array
    {
        require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/geoip.php';
        return \MuruguardGeoIp::status();
    }

    /**
     * Content-only check for a file whose NAME is expected (a known webroot
     * file): content signatures plus the .htaccess / .user.ini / php.ini
     * directive checks, never the "unrecognized file" fallback.
     */
    private function scanKnownFileContent(string $path, array $sig, int $maxSize, array $falsePositives): void
    {
        if (isset($this->seenAbs[$path])) return;

        $reasons = [];
        $base = strtolower(basename($path));
        if (in_array($base, ['.htaccess', '.user.ini', 'php.ini'], true)) {
            $directives = @file_get_contents($path, false, null, 0, 8192);
            if ($directives !== false) {
                if ($base === '.htaccess') {
                    $hijack = MuruguardHelper::checkMaliciousHtaccessHandler($directives);
                    if ($hijack !== null) $reasons[] = $hijack;
                }
                $prepend = MuruguardHelper::checkPhpAutoPrependDirective($directives);
                if ($prepend !== null) $reasons[] = $prepend;
            }
        }

        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        MuruguardHelper::scanFileContent($path, $ext, $sig, $maxSize, $reasons);
        if (empty($reasons)) return;

        $this->seenAbs[$path] = true;
        $rel = ltrim(str_replace($this->root, '', $path), '/');
        if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $rel, MuruguardHelper::fingerprintReasons($reasons))) {
            MuruguardHelper::recordFinding($this->fileFindings, $path, $this->root, $reasons, false);
        }
    }

    public function runScheduledCheck(): array
    {
        $this->scanFilesystem();
        $this->scanDatabase();

        $currentKeys = array_keys($this->fileFindings);
        sort($currentKeys);

        $previousKeys = $this->loadLastScanKeys();
        $this->saveLastScanKeys($currentKeys);

        $newKeys = $previousKeys === null ? [] : array_values(array_diff($currentKeys, $previousKeys));
        $newFindings = [];
        foreach ($newKeys as $rel) {
            if (isset($this->fileFindings[$rel])) $newFindings[$rel] = $this->fileFindings[$rel];
        }

        return [
            'newFindings' => $newFindings,
            'newCount'    => count($newFindings),
            'totalCount'  => count($this->fileFindings),
            'isFirstRun'  => $previousKeys === null,
        ];
    }

    /**
     * Deliberately a plain JSON file under this component's own data/
     * folder, NOT a key inside #__extensions.params -- Joomla's own
     * Global Configuration save for this component replaces that whole
     * params blob with just the config.xml-declared fields, which would
     * silently wipe an internal bookkeeping key living there every time
     * an admin saves Options, with no error or warning. A dedicated file
     * is immune to that entirely and needs no schema/migration.
     */
    private function scanHistoryFilePath(): string
    {
        $new = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/scan-history.php';
        MuruguardHelper::migrateLegacyDataFile(JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/scan-history.json', $new);
        return $new;
    }

    /** Null means the scheduled check has never run on this site. For the Settings panel's "Last run" indicator. */
    public function getLastScheduledRunTime(): ?int
    {
        $path = $this->scanHistoryFilePath();
        if (!is_file($path)) return null;

        $contents = @file_get_contents($path);
        if ($contents === false) return null;

        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        return is_array($decoded) && isset($decoded['saved_at']) ? (int) $decoded['saved_at'] : null;
    }

    /** Null means "never run before" (as opposed to an empty array, which means the last run found nothing). */
    private function loadLastScanKeys(): ?array
    {
        $path = $this->scanHistoryFilePath();
        if (!is_file($path)) return null;

        $contents = @file_get_contents($path);
        if ($contents === false) return null;

        // A history file that exists but can't be read back means the
        // baseline was lost, not that this is the first run: report every
        // current finding as new (fail loud) instead of alerting on nothing.
        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        if (!is_array($decoded) || !isset($decoded['keys']) || !is_array($decoded['keys'])) return [];
        return $decoded['keys'];
    }

    private function saveLastScanKeys(array $keys): void
    {
        $path = $this->scanHistoryFilePath();
        MuruguardHelper::writeDataFile($path, ['keys' => $keys, 'saved_at' => time()]);
    }

    // ------------------------------------------------------------------
    // Chunked / resumable scanning
    //
    // A single "Run a Scan" click used to run the entire filesystem+DB
    // scan inside one HTTP request -- fine for a small site, but a large
    // one (many extensions, big vendor/media trees) could genuinely
    // outrun a host's max_execution_time before finishing, which surfaced
    // to the admin as a bare "500 - Whoops" with no results at all. Each
    // call to runScanChunk() below instead does AS MUCH work as fits in a
    // fixed wall-clock budget (one SCAN_CONFIG directory at a time, plus
    // the webroot/core-entry checks and the DB scan as their own single
    // items), persists progress to a small data file, and returns
    // immediately -- the scanner.php view's JS then calls it again, and
    // again, until it reports done. No single request can ever run longer
    // than the budget, regardless of how large the site is.
    // ------------------------------------------------------------------

    /** Wall-clock budget per HTTP request/chunk call -- comfortably inside even a conservative host's default execution-time limit. */
    private const CHUNK_TIME_BUDGET_SECONDS = 20;

    /**
     * A step ends early, after a finished area, once it has run this long, so the scan overlay can show progress
     * and new findings every few seconds instead of once per 20-second step. Large areas still use the full budget.
     */
    private const CHUNK_REPORT_AFTER_SECONDS = 2.0;
    public const CHUNK_WEBROOT_CORE_KEY = '__webroot_core__';
    public const CHUNK_DATABASE_KEY = '__database__';

    /** Ordered list of chunk-queue items, respecting the user's current area selection -- same selection getFileFindings()/runScan() already honour. */
    private function buildChunkQueue(): array
    {
        $sig = MuruguardHelper::getSignatures();
        $queue = [];
        foreach (array_keys($sig['SCAN_CONFIG']) as $relDir) {
            if ($this->isAreaSelected($relDir)) $queue[] = $relDir;
        }
        if ($this->isAreaSelected('webroot') || $this->isAreaSelected('core_entry')) {
            $queue[] = self::CHUNK_WEBROOT_CORE_KEY;
        }
        if ($this->isAreaSelected('database')) {
            $queue[] = self::CHUNK_DATABASE_KEY;
        }
        return $queue;
    }

    /**
     * Deliberately the same stub-protected data-file technique as
     * scanHistoryFilePath() (see that method's own comment for why this
     * is never session-only or component-params) -- a chunked scan of a
     * genuinely huge site can span several minutes across many chunk
     * calls, longer than it's safe to assume a session survives, and
     * Global Configuration saves would otherwise be able to wipe it.
     */
    private function scanProgressFilePath(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/scan-progress.php';
    }

    private function loadScanProgress(): ?array
    {
        $path = $this->scanProgressFilePath();
        if (!is_file($path)) return null;
        $contents = @file_get_contents($path);
        if ($contents === false) return null;
        $decoded = json_decode(MuruguardHelper::stripDataFileStub($contents), true);
        return is_array($decoded) ? $decoded : null;
    }

    private function saveScanProgress(array $progress): void
    {
        MuruguardHelper::writeDataFile($this->scanProgressFilePath(), $progress);
    }

    /**
     * Runs one chunk's worth of work (bounded by CHUNK_TIME_BUDGET_SECONDS)
     * and returns progress for the calling AJAX loop.
     *
     * @param bool $reset Start a brand-new scan, abandoning any in-progress
     *   chunked scan -- passed true only by the very first call of a fresh
     *   "Run a Scan" click; every follow-up call from the same run passes
     *   false so it continues the existing queue instead of restarting it.
     * @return array{done:bool,completedCount:int,totalCount:int,currentArea:?string,truncated:list<string>}
     */
    public function runScanChunk(bool $reset = false): array
    {
        // Serialised on the progress file: two admins (or two tabs)
        // scanning at once used to overwrite each other's queue and
        // findings. A step that finds another one running reports the
        // current progress with busy=true and changes nothing; the
        // progress bar simply asks again.
        $lock = @fopen($this->scanProgressFilePath(), 'c');
        if ($lock !== false && !@flock($lock, LOCK_EX | LOCK_NB)) {
            fclose($lock);
            $p = $this->loadScanProgress() ?? [];
            return [
                'done'           => false,
                'busy'           => true,
                'completedCount' => count((array) ($p['completed'] ?? [])),
                'totalCount'     => (int) ($p['totalItems'] ?? 0),
                'currentArea'    => $p['queue'][0] ?? null,
                'truncated'      => [],
            ];
        }
        try {
            return $this->runScanChunkLocked($reset);
        } finally {
            if ($lock !== false) {
                @flock($lock, LOCK_UN);
                fclose($lock);
            }
        }
    }

    private function runScanChunkLocked(bool $reset): array
    {
        $progress = $reset ? null : $this->loadScanProgress();

        if ($progress === null || !empty($progress['done'])) {
            $queue = $this->buildChunkQueue();
            $progress = [
                'queue'      => $queue,
                'completed'  => [],
                'findings'   => [],
                'dbFindings' => $this->dbFindings,
                'truncated'  => [],
                'totalItems' => count($queue),
                'startedAt'  => time(),
                'updatedAt'  => time(),
                'done'       => false,
            ];
        }

        $stepStart = microtime(true);
        $deadline = $stepStart + self::CHUNK_TIME_BUDGET_SECONDS;
        // Paths already found before this step, so the step can report only what it added (live list on the overlay).
        $knownBefore = array_flip(array_map('strval', array_keys((array) $progress['findings'])));

        while (!empty($progress['queue']) && microtime(true) < $deadline) {
            $item = array_shift($progress['queue']);

            if ($item === self::CHUNK_DATABASE_KEY) {
                $this->scanDatabase();
                foreach ($this->dbFindings as $category => $rows) {
                    $progress['dbFindings'][$category] = $rows;
                }
            } elseif ($item === self::CHUNK_WEBROOT_CORE_KEY) {
                $this->fileFindings = [];
                $this->truncatedAreas = [];
                $this->scanFilesystem([], true, $deadline);
                $progress['findings'] = array_merge($progress['findings'], $this->fileFindings);
                $progress['truncated'] = array_merge($progress['truncated'], array_keys($this->truncatedAreas));
            } else {
                $this->fileFindings = [];
                $this->truncatedAreas = [];
                $this->resumeSkips = isset($progress['resume'][$item]) ? [$item => (int) $progress['resume'][$item]] : [];
                $this->scanFilesystem([$item], false, $deadline);
                $this->resumeSkips = [];
                $progress['findings'] = array_merge($progress['findings'], $this->fileFindings);
                if (isset($this->truncatedAreas[$item])) {
                    // Out of time mid-area: continue this area in the next
                    // chunk from where it stopped (always at least one
                    // entry further, so one slow file can't loop forever).
                    $prevSkip = (int) ($progress['resume'][$item] ?? 0);
                    $walked = (int) $this->truncatedAreas[$item];
                    $progress['resume'][$item] = $walked < 0 ? $prevSkip : max($walked, $prevSkip + 1);
                    array_unshift($progress['queue'], $item);
                    continue;
                }
                unset($progress['resume'][$item]);
            }

            $progress['completed'][] = $item;
            if (microtime(true) - $stepStart >= self::CHUNK_REPORT_AFTER_SECONDS) break;
        }

        $progress['updatedAt'] = time();
        $progress['done'] = empty($progress['queue']);

        if ($progress['done']) {
            // Publish through the exact same session keys the unchunked
            // runScan()/getFileFindings() path already uses, so the results
            // view renders identically regardless of which path produced
            // them -- chunking only changes HOW the scan runs, never the
            // shape of its output.
            $session = MuruguardCompat::getSession();
            $session->set('muruguard.filefindings', $progress['findings']);
            $session->set('muruguard.filefindings_time', time());
            $this->fileFindings = $progress['findings'];
            $this->dbFindings   = $progress['dbFindings'];
        }

        $this->saveScanProgress($progress);

        return [
            'done'           => $progress['done'],
            'completedCount' => count($progress['completed']),
            'totalCount'     => $progress['totalItems'],
            'currentArea'    => $progress['done'] ? null : ($progress['queue'][0] ?? null),
            'truncated'      => array_values(array_unique($progress['truncated'])),
            // Live view on the scan overlay: running counts and what this step found.
            'findingsCount'  => count($progress['findings']),
            'highCount'      => count(array_filter($progress['findings'], fn($f) => ($f['confidence'] ?? '') === 'high')),
            'recentFindings' => MuruguardHelper::liveScanFindings((array) $progress['findings'], $knownBefore),
        ];
    }

    /**
     * Persists the 3 scheduled-scanning settings into this component's
     * own extension params -- the same storage Global Configuration reads
     * from, so the in-page Settings panel and System > Global
     * Configuration > MuRu Guard always agree with each other. Safe
     * from the wipe risk documented on scanHistoryFilePath() because it
     * ONLY ever touches these 3 known keys, never the internal scan
     * history (which deliberately never lives in this params blob at
     * all anymore).
     */
    public function saveScheduledSettings(bool $enabled, string $token, string $email): void
    {
        // Persistence -- including the Joomla 3 query path and the Joomla
        // 4+ '_system' cache invalidation -- lives in
        // saveHardeningParams(), so every settings save shares the one
        // version branch instead of each repeating it.
        $this->saveHardeningParams([
            'cron_enabled' => $enabled ? 1 : 0,
            'cron_token'   => $token,
            'alert_email'  => $email,
        ]);
    }

    /** Dismisses the "get security alerts & updates" dashboard banner without subscribing. */
    public function dismissNewsletterBanner(): void
    {
        \MuruguardHelper::markNewsletterBannerDone(false);
        $this->saveHardeningParams(['newsletter_banner_dismissed' => 1]);
    }

    /**
     * Submits the banner's name/email to the dashboard's public opt-in
     * endpoint (see MuruguardHelper::submitNewsletterOptIn()) and, only on
     * success, marks the banner as both subscribed and dismissed so it
     * never shows again -- a failed submission leaves it showing so the
     * admin can retry, rather than silently losing the lead.
     */
    public function subscribeToNewsletter(string $name, string $email): bool
    {
        $ok = \MuruguardHelper::submitNewsletterOptIn($name, $email);
        if ($ok) {
            \MuruguardHelper::markNewsletterBannerDone(true);
            $this->saveHardeningParams(['newsletter_subscribed' => 1, 'newsletter_banner_dismissed' => 1]);
        }
        return $ok;
    }

    /** How many rows the scan-result file lists (Suspicious/Cleanable) show per page before pagination kicks in -- purely a display preference, same storage/save pattern as the other settings above. */
    /**
     * Saves the three AI provider configs + which one is the default --
     * validation (both key and model present for whichever is picked as
     * default) already happened in the controller before this is
     * called. Thin public wrapper around the same private
     * saveHardeningParams() every other Settings save goes through, so
     * this gets its cache-invalidation handling for free.
     */
    public function saveAiSettings(array $settings): void
    {
        $this->saveHardeningParams($settings);
    }

    public function saveDisplaySettings(int $itemsPerPage): void
    {
        $allowed = [25, 50, 100, 250, 500];
        if (!in_array($itemsPerPage, $allowed, true)) $itemsPerPage = 50;

        // Same shared persistence as saveScheduledSettings() above.
        $this->saveHardeningParams(['items_per_page' => $itemsPerPage]);
    }

    /**
     * Same storage the plg_system_muruguardshield plugin reads from on
     * every request via ComponentHelper::getParams('com_muruguard') --
     * this is the only place that plugin's behaviour is actually
     * configured, there is no separate plugin-side settings screen.
     */
    public function saveShieldSettings(
        bool $enabled,
        bool $blockPatterns,
        bool $blockBruteForce,
        int $threshold,
        int $window,
        bool $blockUserAgents = false,
        bool $blockCountries = false,
        string $blockedCountries = '',
        bool $sppbEndpoints = true
    ): void {
        // Normalise to a clean, de-duplicated, comma-separated list of
        // 2-letter codes -- whatever stray formatting an admin pastes in
        // (extra spaces, lowercase, trailing commas) still works.
        $codes = array_unique(array_filter(array_map(
            fn($c) => strtoupper(trim($c)),
            explode(',', $blockedCountries)
        ), fn($c) => preg_match('/^[A-Z]{2}$/', $c)));
        // Same shared persistence as saveScheduledSettings() above.
        $this->saveHardeningParams([
            'shield_enabled'             => $enabled ? 1 : 0,
            'shield_block_patterns'      => $blockPatterns ? 1 : 0,
            'shield_block_bruteforce'    => $blockBruteForce ? 1 : 0,
            'shield_bruteforce_threshold' => max(2, min(50, $threshold)),
            'shield_bruteforce_window'   => max(1, min(1440, $window)),
            'shield_block_useragents'    => $blockUserAgents ? 1 : 0,
            'shield_block_countries'     => $blockCountries ? 1 : 0,
            'shield_blocked_countries'   => implode(',', $codes),
            'sppb_guard_endpoints'       => $sppbEndpoints ? 1 : 0,
        ]);
    }

    /**
     * Serialises every read-modify-write of the component's params: each
     * settings save loads the whole params blob, changes a few keys and
     * stores it back, so two saves at once used to lose one side's change.
     * The returned object holds an exclusive lock until the calling
     * function returns (it is released when the object goes out of
     * scope), so no early return can leave it held.
     */
    private function lockParams(): object
    {
        $path = JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/data/.muruguard-' . substr(md5('params-write'), 0, 16) . '.lock';
        $fh = @fopen($path, 'c');
        if ($fh !== false) @flock($fh, LOCK_EX);
        return new class($fh) {
            private $fh;
            public function __construct($fh) { $this->fh = $fh; }
            public function __destruct()
            {
                if (is_resource($this->fh)) {
                    @flock($this->fh, LOCK_UN);
                    fclose($this->fh);
                }
            }
        };
    }

    /** The stored params blob, read straight from #__extensions (plain queries, so Joomla 3 works too). */
    private function storedParams(): array
    {
        $db = $this->getDatabase();
        $db->setQuery(
            $db->getQuery(true)->select($db->quoteName('params'))->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_muruguard'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
        );
        $params = json_decode((string) $db->loadResult(), true);
        return is_array($params) ? $params : [];
    }

    /** Writes the whole params blob (used where keys must also be removed, which saveHardeningParams() cannot do). */
    private function replaceStoredParams(array $params): void
    {
        $db = $this->getDatabase();
        $db->setQuery(
            $db->getQuery(true)->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('params') . ' = ' . $db->quote(json_encode($params)))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_muruguard'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
        )->execute();
        if (MuruguardCompat::isJoomla4()) $this->cleanCache('_system');
    }

    /**
     * Security presets: what applying each level would change, for the confirmation list.
     *
     * @return array{active: string, stored: string, plans: array, undo: ?array}
     */
    public function getSecurityPresetState(): array
    {
        require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/presets.php';
        $params = $this->storedParams();
        $plans = [];
        foreach (\MuruguardPresets::LEVELS as $level) {
            $plans[$level] = ['changes' => \MuruguardPresets::plan($params, $level)];
        }
        $undo = json_decode((string) ($params[\MuruguardPresets::UNDO] ?? ''), true);
        return [
            'active' => \MuruguardPresets::active($params),
            'stored' => (string) ($params[\MuruguardPresets::STORED] ?? ''),
            'plans' => $plans,
            'undo' => is_array($undo) && !empty($undo['values']) ? $undo : null,
        ];
    }

    /**
     * Applies a protection level: only the settings the level sets are written (everything else is kept), the values
     * they replace are saved for Undo, and Protected Users goes through its own setter (it takes the first snapshot).
     *
     * @return int how many settings changed
     */
    public function applySecurityPreset(string $level): int
    {
        require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/presets.php';
        if (!\MuruguardPresets::isLevel($level)) return 0;
        $stored = $this->storedParams();
        $plan = \MuruguardPresets::plan($stored, $level);
        $targets = \MuruguardPresets::targets($level);

        $set = $targets;
        unset($set['protected_users_enabled']);
        $set[\MuruguardPresets::STORED] = $level;
        // Applying the same level again (nothing to change) keeps the Undo of the earlier apply.
        if ($plan !== []) $set[\MuruguardPresets::UNDO] = json_encode(\MuruguardPresets::undoSnapshot($stored, $level));
        $this->saveHardeningParams($set);
        if (isset($plan['protected_users_enabled'])) {
            $this->saveProtectedUsersSetting((bool) $targets['protected_users_enabled']);
        }
        return count($plan);
    }

    /** Puts back the settings the last preset replaced (and the preset shown before it). Returns false when there is nothing to undo. */
    public function undoSecurityPreset(): bool
    {
        require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/presets.php';
        $stored = $this->storedParams();
        $undo = json_decode((string) ($stored[\MuruguardPresets::UNDO] ?? ''), true);
        if (!is_array($undo) || empty($undo['values']) || !is_array($undo['values'])) return false;

        $allowed = array_flip(\MuruguardPresets::keys());
        $paramsLock = $this->lockParams();
        $params = $this->storedParams();
        foreach ($undo['values'] as $key => $value) {
            if (!isset($allowed[$key])) continue; // only keys a preset can write
            if ($value === null) unset($params[$key]); else $params[$key] = $value;
        }
        $prev = (string) ($undo['level'] ?? '');
        $params[\MuruguardPresets::STORED] = \MuruguardPresets::isLevel($prev) ? $prev : '';
        unset($params[\MuruguardPresets::UNDO]);
        $this->replaceStoredParams($params);
        unset($paramsLock);
        return true;
    }

    private function saveHardeningParams(array $set): void
    {
        $paramsLock = $this->lockParams();
        // Joomla\CMS\Table\Extension does not exist on Joomla 3 (and
        // Joomla 3 has no persistent component-registry cache needing a
        // cleanCache()), so that platform takes the plain-query path.
        if (!MuruguardCompat::isJoomla4()) {
            $this->saveHardeningParamsJoomla3($set);
            return;
        }

        $table = new \Joomla\CMS\Table\Extension($this->getDatabase());
        if (!$table->load(['element' => 'com_muruguard', 'type' => 'component'])) return;
        $params = json_decode((string) $table->params, true);
        if (!is_array($params)) $params = [];
        foreach ($set as $key => $value) {
            $params[$key] = $value;
        }
        $table->params = json_encode($params);
        $table->store();
        // ComponentHelper::getComponents() (what every ComponentHelper::
        // getParams('com_muruguard') call in this codebase reads through)
        // caches the ENTIRE component registry, params blob included, in
        // the '_system' cache group when Joomla's own system caching is
        // enabled. Writing straight to the #__extensions row via
        // Table::store() never invalidates that cache on its own -- so
        // the write itself succeeds, but the NEXT page load can still
        // read back the stale pre-write params, making the change look
        // like it silently reverted. Real reported bug: the newsletter
        // banner's dismissal (saved this same way) reappeared after
        // every reload despite dismissing it successfully each time.
        $this->cleanCache('_system');
    }

    /**
     * Joomla 3 path for saveHardeningParams(): the exact same
     * read-params-blob / merge-keys / write-params-blob cycle as the
     * Joomla 4+ Table::store() path above, expressed as plain
     * SELECT/UPDATE queries against #__extensions (same table, same
     * columns on both platforms). No cleanCache(): Joomla 3's
     * JComponentHelper keeps component params in a per-request static
     * only, so the next page load re-reads the row and the stale-cache
     * bug the Joomla 4+ path guards against cannot occur here.
     */
    private function saveHardeningParamsJoomla3(array $set): void
    {
        $db = $this->getDatabase();
        $where = [
            $db->quoteName('element') . ' = ' . $db->quote('com_muruguard'),
            $db->quoteName('type') . ' = ' . $db->quote('component'),
        ];
        $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('params'))
                ->from($db->quoteName('#__extensions'))
                ->where($where)
        );
        $params = json_decode((string) $db->loadResult(), true);
        if (!is_array($params)) $params = [];
        foreach ($set as $key => $value) {
            $params[$key] = $value;
        }
        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('params') . ' = ' . $db->quote(json_encode($params)))
                ->where($where)
        )->execute();
    }

    /** Toggles plg_system_muruguardshield's Admin Lockdown gate (see checkAdminLockdownGate() in that plugin -- blocks the extension installer and new-backend-user creation while on). */
    public function saveAdminLockdownSetting(bool $enabled): void
    {
        $this->saveHardeningParams(['harden_lock_admin_actions' => $enabled ? 1 : 0]);
    }

    /** Returns the ids of Joomla's own "Super Users"/"Super User" group(s). */
    private function getSuperUserGroupIds(): array
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select('id')
            ->from($db->quoteName('#__usergroups'))
            ->where($db->quoteName('title') . ' IN (' . $db->quote('Super Users') . ',' . $db->quote('Super User') . ')');
        $db->setQuery($query);
        return array_map('intval', $db->loadColumn() ?: []);
    }

    /**
     * Takes (or refreshes) the Protected User snapshot -- every current
     * Super User's sensitive fields, kept solely so
     * checkAndRevertProtectedUsers() has a known-good baseline to revert
     * to. Refreshing wipes the 'alerted' dedup map too -- an admin who
     * just reviewed and accepted the current state shouldn't immediately
     * get a fresh alert next check for a difference against the OLD
     * baseline that no longer exists.
     */
    public function snapshotProtectedUsers(): array
    {
        $db = $this->getDatabase();
        $groupIds = $this->getSuperUserGroupIds();
        $users = [];
        if (!empty($groupIds)) {
            $query = $db->getQuery(true)
                ->select('DISTINCT u.id, u.username, u.email, u.password, u.block')
                ->from($db->quoteName('#__users', 'u'))
                ->join('INNER', $db->quoteName('#__user_usergroup_map', 'm') . ' ON ' . $db->quoteName('m.user_id') . ' = ' . $db->quoteName('u.id'))
                ->where($db->quoteName('m.group_id') . ' IN (' . implode(',', $groupIds) . ')');
            $db->setQuery($query);
            foreach ($db->loadAssocList() ?: [] as $row) {
                $users[(string) $row['id']] = [
                    'username' => $row['username'],
                    'email'    => $row['email'],
                    'password' => $row['password'],
                    'block'    => (int) $row['block'],
                ];
            }
        }
        $state = ['takenAt' => time(), 'users' => $users, 'alerted' => []];
        MuruguardHelper::saveProtectedUsersState($state);
        return ['count' => count($users), 'takenAt' => $state['takenAt']];
    }

    /** For the Settings panel -- how many users are currently protected and when the snapshot was last taken/refreshed. */
    public function getProtectedUsersStatus(): array
    {
        $state = MuruguardHelper::loadProtectedUsersState();
        if ($state === null) return ['hasSnapshot' => false, 'count' => 0, 'takenAt' => null];
        return ['hasSnapshot' => true, 'count' => count($state['users'] ?? []), 'takenAt' => $state['takenAt'] ?? null];
    }

    /**
     * Compares every snapshotted Super User's CURRENT row against the
     * baseline and reacts. Blocked/demoted -- AUTO-REVERTED (neither is
     * something the legitimate owner of an ACTIVE account plausibly does
     * to themselves). Email/password changed, or the account deleted --
     * logged/alerted ONLY, never auto-reverted (all three are things a
     * real admin plausibly does through completely normal means, and
     * re-materializing a deleted row risks reusing an id Joomla has
     * since handed to someone else). Each unresolved issue is only ever
     * alerted on the FIRST check that observes it -- see the 'alerted'
     * dedup map -- so a scheduled-check cron doesn't re-email the same
     * still-open problem every single run.
     *
     * @return string[] Human-readable descriptions of every NEWLY-seen issue this run (empty if nothing new).
     */
    public function checkAndRevertProtectedUsers(): array
    {
        $state = MuruguardHelper::loadProtectedUsersState();
        if ($state === null || empty($state['users'])) return [];

        $db = $this->getDatabase();
        $superUserGroupIds = $this->getSuperUserGroupIds();
        $alerted = $state['alerted'] ?? [];
        $newIssues = [];
        $stateChanged = false;

        foreach ($state['users'] as $id => $baseline) {
            $id = (int) $id;

            $query = $db->getQuery(true)
                ->select('id, username, email, password, block')
                ->from($db->quoteName('#__users'))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($query);
            $current = $db->loadAssoc();

            $label = $baseline['username'] . ' (id ' . $id . ')';

            if ($current === null) {
                $key = "{$id}:deleted";
                if (($alerted[$key] ?? null) !== '1') {
                    $newIssues[] = "Protected Super User {$label} was DELETED. Not automatically restored -- review immediately.";
                    $alerted[$key] = '1';
                    $stateChanged = true;
                }
                continue;
            }

            if (isset($alerted["{$id}:deleted"])) {
                unset($alerted["{$id}:deleted"]);
                $stateChanged = true;
            }

            if ((int) $current['block'] !== (int) $baseline['block'] && (int) $current['block'] === 1) {
                $key = "{$id}:block";
                if (($alerted[$key] ?? null) !== '1') {
                    $newIssues[] = "Protected Super User {$label} was BLOCKED -- automatically unblocked.";
                    $alerted[$key] = '1';
                    $stateChanged = true;
                }
                try {
                    $upd = $db->getQuery(true)->update($db->quoteName('#__users'))
                        ->set($db->quoteName('block') . ' = 0')
                        ->where($db->quoteName('id') . ' = ' . $id);
                    $db->setQuery($upd)->execute();
                } catch (\Throwable $e) { /* non-fatal -- still alerted above */ }
            } elseif ((int) $current['block'] === (int) $baseline['block'] && isset($alerted["{$id}:block"])) {
                unset($alerted["{$id}:block"]);
                $stateChanged = true;
            }

            if (!empty($superUserGroupIds)) {
                $gq = $db->getQuery(true)
                    ->select('COUNT(*)')
                    ->from($db->quoteName('#__user_usergroup_map'))
                    ->where($db->quoteName('user_id') . ' = ' . $id)
                    ->where($db->quoteName('group_id') . ' IN (' . implode(',', $superUserGroupIds) . ')');
                $db->setQuery($gq);
                $stillSuperUser = ((int) $db->loadResult()) > 0;

                if (!$stillSuperUser) {
                    $key = "{$id}:demoted";
                    if (($alerted[$key] ?? null) !== '1') {
                        $newIssues[] = "Protected Super User {$label} was REMOVED from the Super Users group -- automatically restored.";
                        $alerted[$key] = '1';
                        $stateChanged = true;
                    }
                    try {
                        $insQuery = $db->getQuery(true)
                            ->insert($db->quoteName('#__user_usergroup_map'))
                            ->columns([$db->quoteName('user_id'), $db->quoteName('group_id')])
                            ->values($id . ', ' . (int) $superUserGroupIds[0]);
                        $db->setQuery($insQuery)->execute();
                    } catch (\Throwable $e) { /* non-fatal -- still alerted above, and a duplicate-key failure here means it's actually fine */ }
                } elseif (isset($alerted["{$id}:demoted"])) {
                    unset($alerted["{$id}:demoted"]);
                    $stateChanged = true;
                }
            }

            if ($current['email'] !== $baseline['email']) {
                $key = "{$id}:email";
                if (($alerted[$key] ?? null) !== $current['email']) {
                    $newIssues[] = "Protected Super User {$label} email changed from \"{$baseline['email']}\" to \"{$current['email']}\" -- NOT auto-reverted (could be a legitimate change), review immediately.";
                    $alerted[$key] = $current['email'];
                    $stateChanged = true;
                }
            } elseif (isset($alerted["{$id}:email"])) {
                unset($alerted["{$id}:email"]);
                $stateChanged = true;
            }

            if ($current['password'] !== $baseline['password']) {
                $key = "{$id}:password";
                if (($alerted[$key] ?? null) !== $current['password']) {
                    $newIssues[] = "Protected Super User {$label} password changed -- NOT auto-reverted (could be a legitimate reset), review immediately.";
                    $alerted[$key] = $current['password'];
                    $stateChanged = true;
                }
            } elseif (isset($alerted["{$id}:password"])) {
                unset($alerted["{$id}:password"]);
                $stateChanged = true;
            }
        }

        if ($stateChanged) {
            $state['alerted'] = $alerted;
            MuruguardHelper::saveProtectedUsersState($state);
        }

        return $newIssues;
    }

    /**
     * Toggles Protected User Snapshot & Auto-Revert. Turning it ON for
     * the first time (no snapshot exists yet) takes an initial snapshot
     * immediately.
     */
    public function saveProtectedUsersSetting(bool $enabled): void
    {
        $this->saveHardeningParams(['protected_users_enabled' => $enabled ? 1 : 0]);
        if ($enabled && !MuruguardHelper::loadProtectedUsersState()) {
            $this->snapshotProtectedUsers();
        }
    }

    /**
     * MuRu Shield Hardening: activates the /administrator HTTP Basic
     * Auth gate. Only ever persists username + a bcrypt hash + an
     * activation timestamp -- never the plaintext password, which is
     * returned to the caller exactly once so it can be shown to the
     * admin, and is not retrievable again afterward (matching every
     * other secret in this codebase -- see maskLicenseKey()'s docblock
     * for the same "never echo a secret back" discipline).
     */
    public function activateBackendAuth(string $username, string $password): array
    {
        $testUrl = \Joomla\CMS\Uri\Uri::root() . 'administrator/index.php';
        $result = \MuruguardHardeningHelper::activateBackendAuth(JPATH_ADMINISTRATOR, $testUrl, $username, $password);
        if ($result['ok']) {
            $this->saveHardeningParams([
                'backend_auth_enabled'    => 1,
                'backend_auth_username'   => $username,
                'backend_auth_activated'  => time(),
            ]);
        } elseif (!$this->isShieldPluginActive()) {
            // The single most common reason the self-test fails on a non-
            // Apache host: plg_system_muruguardshield is what actually
            // enforces this at the PHP layer there (see its
            // checkBasicAuthGate()) -- .htaccess-only enforcement only
            // ever works on Apache. If it's not installed/enabled, no
            // amount of retrying will help, so say so explicitly instead
            // of leaving the admin to guess between three generic causes.
            $result['reason'] = 'The MuRu Guard Shield plugin (System > Plugins > "System - MuRu Guard Shield") is not installed or enabled. '
                . 'On any server other than Apache, this plugin is what actually enforces Backend Access -- install/enable it, then try again. '
                . 'Original error: ' . $result['reason'];
        }
        return $result;
    }

    public function deactivateBackendAuth(): void
    {
        \MuruguardHardeningHelper::deactivateBackendAuth(JPATH_ADMINISTRATOR);
        // Emergency Mode reuses backend auth's .htpasswd -- it cannot be
        // left active pointing at a file that just got deleted.
        \MuruguardHardeningHelper::deactivateEmergencyMode($this->root);
        $this->saveHardeningParams([
            'backend_auth_enabled'   => 0,
            'backend_auth_username'  => '',
            'backend_auth_activated' => 0,
            'emergency_mode_enabled' => 0,
        ]);
    }

    public function activateEmergencyMode(string $username, string $password): array
    {
        // The plaintext password is never persisted once backend auth is
        // active (see activateBackendAuth()'s docblock) -- Emergency Mode
        // reuses those same credentials rather than minting new ones, so
        // the admin re-supplies the password here and it's checked
        // against the already-active .htpasswd BEFORE anything is
        // written, refusing outright rather than writing an Emergency
        // Mode block self-tested with a password that turns out wrong.
        if (!\MuruguardHardeningHelper::verifyBackendPassword(JPATH_ADMINISTRATOR, $username, $password)) {
            return ['ok' => false, 'reason' => 'That username/password doesn\'t match your currently-active backend access credentials.'];
        }

        $testUrl = \Joomla\CMS\Uri\Uri::root();
        $result = \MuruguardHardeningHelper::activateEmergencyMode($this->root, JPATH_ADMINISTRATOR, $testUrl, $username, $password);
        if ($result['ok']) {
            $this->saveHardeningParams(['emergency_mode_enabled' => 1, 'emergency_mode_activated' => time()]);
        } elseif (!$this->isShieldPluginActive()) {
            // Same reasoning as activateBackendAuth() above -- on any
            // non-Apache host, plg_system_muruguardshield's
            // checkBasicAuthGate() is what actually enforces this.
            $result['reason'] = 'The MuRu Guard Shield plugin (System > Plugins > "System - MuRu Guard Shield") is not installed or enabled. '
                . 'On any server other than Apache, this plugin is what actually enforces this. '
                . 'Original error: ' . $result['reason'];
        }
        return $result;
    }

    public function deactivateEmergencyMode(): void
    {
        \MuruguardHardeningHelper::deactivateEmergencyMode($this->root);
        $this->saveHardeningParams(['emergency_mode_enabled' => 0, 'emergency_mode_activated' => 0]);
    }

    /**
     * True only if plg_system_muruguardshield is both installed AND
     * enabled -- the Settings panel uses this to warn when the shield
     * toggles are turned on but have no extension actually reading them,
     * since that combination looks configured but silently does nothing.
     */
    public function isShieldPluginActive(): bool
    {
        $db    = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select($db->quoteName('enabled'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('muruguardshield'));

        $db->setQuery($query);
        return (bool) $db->loadResult();
    }

    // ------------------------------------------------------------------
    // Filesystem scan
    // ------------------------------------------------------------------

    /**
     * SP Page Builder content (pages, unsaved 7.x drafts, saved versions, collection values, saved sections and saved
     * addons) checked for stored cross-site scripting -- see MuruguardHelper::sppbContentThreats(). Report-only: the
     * finding links to the page in SP Page Builder. Tables or columns a version does not have are skipped, so 3.x to
     * 7.x all work. The database pre-filters rows on cheap words so only candidate rows reach PHP.
     */
    private function scanSppbPages(array $falsePositives): void
    {
        $this->dbFindings['sppb_pages'] = [];
        $db = $this->getDatabase();
        try {
            $prefix = $db->getPrefix();
            $tables = array_flip(array_map('strtolower', $db->getTableList()));
        } catch (\Throwable $e) {
            return;
        }
        if (!isset($tables[strtolower($prefix . 'sppagebuilder')])) return;

        // source => [table, id column, page id column (or ''), title column (or ''), content columns]
        $sources = [
            'page'       => ['#__sppagebuilder', 'id', 'id', 'title', ['text', 'content', 'css']],
            'draft'      => ['#__sppagebuilder_drafts', 'page_id', 'page_id', '', ['content', 'css']],
            'version'    => ['#__sppagebuilder_versions', 'id', 'page_id', '', ['content', 'css']],
            'collection' => ['#__sppagebuilder_collection_item_values', 'item_id', '', '', ['value']],
            'section'    => ['#__sppagebuilder_sections', 'id', '', 'title', ['section', 'content']],
            'addon'      => ['#__sppagebuilder_addons', 'id', '', 'title', ['code']],
        ];
        $words = ['script', 'onerror', 'onload', 'srcdoc', 'cookie', 'Storage', 'eval', 'atob', 'fromCharCode', 'unescape', 'Function', 'xss.report'];
        $pageTitles = [];
        foreach ($sources as $source => [$table, $idCol, $pageCol, $titleCol, $wanted]) {
            if (count($this->dbFindings['sppb_pages']) >= 200) break;
            $real = strtolower(str_replace('#__', $prefix, $table));
            if (!isset($tables[$real])) continue;
            try {
                $have = array_map('strtolower', array_keys($db->getTableColumns($table)));
                $cols = array_values(array_intersect($wanted, $have));
                if (!$cols || !in_array($idCol, $have, true)) continue;
                $select = array_unique(array_filter(array_merge([$idCol, $pageCol, in_array($titleCol, $have, true) ? $titleCol : ''], $cols)));
                if ($source === 'collection' && in_array('field_id', $have, true)) $select[] = 'field_id';
                $or = [];
                foreach ($cols as $c) {
                    foreach ($words as $w) $or[] = $db->quoteName($c) . ' LIKE ' . $db->quote('%' . $w . '%');
                }
                $offset = 0;
                do {
                    $query = $db->getQuery(true)->select($db->quoteName(array_values($select)))->from($db->quoteName($table))
                        ->where('(' . implode(' OR ', $or) . ')')->order($db->quoteName($idCol));
                    $db->setQuery($query, $offset, 100);
                    $offset += 100;
                    $rows = $db->loadAssocList() ?: [];
                    foreach ($rows as $row) {
                        $text = '';
                        foreach ($cols as $c) $text .= "\n" . (string) ($row[$c] ?? '');
                        $threat = MuruguardHelper::sppbContentThreats($text);
                        if (!$threat['reasons']) continue;
                        $id = (string) $row[$idCol];
                        if ($source === 'collection') $id .= ':' . (string) ($row['field_id'] ?? '');
                        $identifier = $source . ':' . $id;
                        if (MuruguardHelper::isFalsePositive($falsePositives, 'sppb_pages', $identifier, MuruguardHelper::fingerprintReasons($threat['reasons']))) continue;
                        $pageId = $pageCol !== '' ? (int) ($row[$pageCol] ?? 0) : 0;
                        $title = (string) ($row[$titleCol] ?? '');
                        if ($title === '' && $pageId > 0) {
                            if (!array_key_exists($pageId, $pageTitles)) {
                                $q = $db->getQuery(true)->select($db->quoteName('title'))->from($db->quoteName('#__sppagebuilder'))->where($db->quoteName('id') . ' = ' . $pageId);
                                $db->setQuery($q);
                                $pageTitles[$pageId] = (string) $db->loadResult();
                            }
                            $title = $pageTitles[$pageId];
                        }
                        $this->dbFindings['sppb_pages'][] = [
                            'source' => $source, 'id' => $id, 'identifier' => $identifier, 'page_id' => $pageId, 'title' => $title,
                            'matches' => $threat['reasons'], 'snippet' => $threat['snippet'],
                        ];
                        if (count($this->dbFindings['sppb_pages']) >= 200) break 2;
                    }
                } while (count($rows) === 100);
            } catch (\Throwable $e) {
                // A table that cannot be read is skipped; the other sources still run.
            }
        }
    }

    /**
     * @param ?array $onlyDirs Restricts the SCAN_CONFIG directory walk to
     *   just these relative-dir keys (e.g. ['media']) -- null (default)
     *   walks every selected SCAN_CONFIG dir, same as before this param
     *   existed. Pass [] to skip the directory walk entirely while still
     *   running the webroot/core-entry checks below, if $includeWebrootCore.
     * @param bool $includeWebrootCore Whether to run the shallow webroot
     *   scan and core-entry-point checks in this call. Defaults true (full
     *   scan, unchanged behaviour); a per-directory chunk call passes false
     *   so those cheap-but-redundant checks only run once per chunked scan,
     *   not once per chunk.
     * @param ?float $deadline Wall-clock microtime(true) cutoff. When set,
     *   a directory walk that's still running past it is cut short (see
     *   MuruguardScanChunkTimeout) instead of letting one huge folder blow
     *   through an entire chunked-scan HTTP request's time budget.
     */
    public function scanFilesystem(?array $onlyDirs = null, bool $includeWebrootCore = true, ?float $deadline = null): void
    {
        $sig = MuruguardHelper::getSignatures();
        $params = ComponentHelper::getParams('com_muruguard');
        $maxSize = (int) ($params->get('max_file_scan_size', 2 * 1024 * 1024));

        $extraRootDirs = array_filter(array_map('trim', explode(',', (string) $params->get('extra_root_dirs', ''))));
        $sig['KNOWN_ROOT_DIRS'] = array_merge($sig['KNOWN_ROOT_DIRS'], $extraRootDirs);

        $ignoredPaths = array_filter(array_map('trim', explode("\n", (string) $params->get('ignored_paths', ''))));
        $isIgnored = function (string $relPath) use ($ignoredPaths): bool {
            foreach ($ignoredPaths as $pattern) {
                if ($pattern === '') continue;
                if (fnmatch($pattern, $relPath, FNM_PATHNAME)) return true;

                // A trailing "/*" is documented (COM_MURUGUARD_CONFIG_IGNORED_
                // PATHS_DESC) as ignoring an entire extension, e.g.
                // "plugins/mcp/*" -- but FNM_PATHNAME makes "*" stop at the
                // first "/", so that pattern only ever matched files placed
                // directly inside plugins/mcp/, never anything one level
                // deeper like plugins/mcp/mcpadminlogin/foo.php. Treat a
                // trailing "/*" as "this whole subtree" via a plain prefix
                // check instead, without loosening any other pattern shape
                // (a bare "*.php" still only matches within one directory,
                // as documented/expected).
                if (substr($pattern, -2) === '/*') {
                    $prefix = substr($pattern, 0, -1); // keep the trailing slash
                    if ($prefix !== '/' && strncmp($relPath, $prefix, strlen($prefix)) === 0) {
                        return true;
                    }
                }
            }
            return false;
        };

        $selfLogPattern  = '/^\.muruguard-[a-f0-9]{16}\.(log|lock)$/i';
        $googleVerifyPattern = '/^google[a-f0-9]{16,}\.html$/i';
        // Safety-backup copies this scanner's own "Clean code" action
        // writes before overwriting an infected file -- deliberately kept
        // on disk for manual review/rollback, so they shouldn't re-appear
        // as a "new" finding on the next scan (they still contain the
        // original malicious content by design, that's the whole point).
        $selfBackupPattern = '/\.muruguard-\d{8}-\d{6}\.bak$/i';
        $registeredTemplates = $this->getRegisteredTemplates();
        $registeredPlugins = $this->getRegisteredPlugins();
        $registeredComponents = $this->getRegisteredComponents();
        $falsePositives = MuruguardHelper::getFalsePositiveLookup();

        foreach ($sig['SCAN_CONFIG'] as $relDir => $mode) {
            if ($onlyDirs !== null && !in_array($relDir, $onlyDirs, true)) continue;
            if (!$this->isAreaSelected($relDir)) continue;
            if ($deadline !== null && microtime(true) > $deadline) {
                // Budget already spent before even starting this area (only
                // reachable when $onlyDirs covers more than one area) --
                // leave it for the next chunk rather than starting it.
                $this->truncatedAreas[$relDir] = -1; // not started: resume from the same place
                break;
            }
            $dir = $this->root . '/' . $relDir;
            if (!is_dir($dir)) continue;

            try {
                $this->walkCounter = 0;
                MuruguardHelper::walkDir($dir, function (string $path, bool $isDir) use ($sig, $mode, $maxSize, $isIgnored, $selfBackupPattern, $registeredTemplates, $registeredPlugins, $registeredComponents, $falsePositives, $deadline, $relDir) {
                if ($deadline !== null && microtime(true) > $deadline) {
                    throw new MuruguardScanChunkTimeout();
                }
                $this->walkCounter++;
                if ($this->walkCounter <= ($this->resumeSkips[$relDir] ?? 0)) return;
                // Trusted security extensions are skipped only at their real
                // folder and only while installed, so a copy of that folder
                // path under images/ (or anywhere else) is still scanned.
                if (MuruguardHelper::isSafeComponentPath($path, $this->root, $sig['SAFE_COMPONENT_PATHS'])
                    && MuruguardHelper::isSafeComponentInstalled($path, $this->root, $registeredComponents)) return;
                if (preg_match('#/tmp/install_[a-z0-9]+(/|$)#i', $path)) {
                    return; // Joomla's own installer extraction folder — transient, not user-uploadable
                }
                if (!$isDir && preg_match($selfBackupPattern, basename($path))) return;
                if (isset($this->seenAbs[$path])) return;

                $basename = basename($path);
                $relCheck = ltrim(str_replace($this->root, '', $path), '/');
                if ($isIgnored($relCheck)) return;
                $isKnownSafeEntry = !$isDir && in_array($relCheck, $sig['KNOWN_SAFE_RELATIVE_FILES'], true);
                $flagged = false;
                $reasons = [];

                // iconfont strict allow-list -- file TYPE is checked at
                // ANY depth inside an iconfont/ tree (icomoon/, css/,
                // fonts/, or any other allowed subfolder), not just its
                // immediate children. A subfolder name being on the
                // allow-list (e.g. "icomoon", IcoMoon's own export/build
                // tool name -- a legitimate, common icon-font vendor
                // folder) only means the FOLDER itself isn't flagged as
                // unrecognized; it is never a free pass for what's placed
                // inside it -- every file there still has its own
                // extension checked against the allow-list below, on top
                // of the depth-independent executable check and the
                // ordinary content-signature scan every file gets
                // regardless of location.
                if (stripos($path, '/iconfont/') !== false) {
                    $parentBase = strtolower(basename(dirname($path)));
                    if ($isDir) {
                        if ($parentBase === 'iconfont' && !in_array(strtolower($basename), $sig['ICONFONT_ALLOWED_DIRNAMES'], true)) {
                            $flagged = true;
                            $reasons[] = 'Unrecognized folder inside icon-font asset directory.';
                        }
                    } else {
                        $extL = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                        if (in_array($extL, $sig['EXEC_EXTS'], true)) {
                            $flagged = true;
                            $reasons[] = 'Executable file inside icon-font asset folder.';
                        } elseif ($basename === '.htaccess') {
                            // Icon-font export tools (IcoMoon, Fontello, ...)
                            // commonly ship a minimal .htaccess here purely
                            // to set the correct MIME type for .woff/.ttf/
                            // .eot -- checked by CONTENT, not trusted by
                            // location alone: only a genuinely permissive
                            // .htaccess is flagged, same criteria the
                            // 'upload' mode structural check below already
                            // uses for every other .htaccess it finds.
                            $htContents = @file_get_contents($path, false, null, 0, 4096);
                            if ($htContents !== false
                                && preg_match('/Allow\s+from\s+all|Require\s+all\s+granted|RewriteEngine\s+Off/i', $htContents)
                                && !preg_match('/FilesMatch.*php/i', $htContents)) {
                                $flagged = true;
                                $reasons[] = 'Suspicious .htaccess inside icon-font asset directory: permissively allows access.';
                            }
                        } else {
                            $baseNoExt = strtolower(pathinfo($basename, PATHINFO_FILENAME));
                            if (!in_array($extL, $sig['ICONFONT_ALLOWED_EXTENSIONS'], true)
                                && !($extL === '' && in_array($baseNoExt, $sig['ICONFONT_ALLOWED_BARE_NAMES'], true))) {
                                $flagged = true;
                                $reasons[] = 'Unrecognized file type inside icon-font asset directory.';
                            }
                        }
                    }
                }

                // JCE upload strict allow-list
                if (!$isDir && !$flagged) {
                    foreach ($sig['JCE_UPLOAD_PATH_FRAGMENTS'] as $frag) {
                        if (stripos($path, $frag) === false) continue;
                        $extL = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                        if (in_array($extL, $sig['EXEC_EXTS'], true)) {
                            $flagged = true;
                            $reasons[] = 'Executable file inside JCE file-browser upload path.';
                        } elseif ($extL !== '' && !in_array($extL, $sig['JCE_UPLOAD_ALLOWED_EXTENSIONS'], true)) {
                            $flagged = true;
                            $reasons[] = 'Unrecognized file type inside JCE file-browser upload path.';
                        }
                        break;
                    }
                }

                // 'upload' mode strict structural checks
                if ($mode === 'upload') {
                    if ($isDir) {
                        if (preg_match('/^\d+$/', $basename) && !MuruguardHelper::isDateLikeNumericFolderName($basename)) {
                            $flagged = true;
                            $reasons[] = "Folder name is purely numeric (\"{$basename}\") and isn't a normal date/ID component — a common automated-malware-drop pattern.";
                        }
                    } else {
                        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                        $isBlankStub = false;
                        if ($ext === 'php' && strcasecmp($basename, 'index.php') === 0) {
                            $stubContents = @file_get_contents($path, false, null, 0, 4096);
                            if ($stubContents !== false && MuruguardHelper::isStandardJoomlaStub($stubContents)) {
                                $isBlankStub = true;
                            }
                        }
                        $isJoomlaCacheFile = $ext === 'php'
                            && strpos($relCheck, 'cache/') === 0
                            && (bool) preg_match($sig['JOOMLA_CACHE_FILE_RE'], $basename);
                        $isRegisteredExtensionSnapshot = $ext === 'php'
                            && strpos($relCheck, 'tmp/joomtower_snapshots/') === 0
                            && MuruguardHelper::isRegisteredExtensionSnapshotPath($relCheck, $registeredPlugins, $registeredComponents, $registeredTemplates);
                        $isJedCheckerOwnZipSnapshot = $ext === 'php'
                            && strpos($relCheck, 'tmp/jed_checker/unzipped/') === 0
                            && MuruguardHelper::isJedCheckerOwnZipSnapshotPath($relCheck);
                        $isHikashopMailTemplate = $ext === 'php'
                            && strpos($relCheck, 'media/com_hikashop/mail/') === 0
                            && MuruguardHelper::isHikashopMailTemplatePath($relCheck, $registeredComponents);
                        if (!$isKnownSafeEntry && !$isBlankStub && !$isJoomlaCacheFile && !$isRegisteredExtensionSnapshot && !$isJedCheckerOwnZipSnapshot && !$isHikashopMailTemplate && in_array($ext, $sig['EXEC_EXTS'], true)) {
                            $flagged = true;
                            $reasons[] = "Executable file (.$ext) inside an upload directory — these should never contain runnable code.";
                        }
                        if ($basename === '.htaccess') {
                            $contents = @file_get_contents($path, false, null, 0, 4096);
                            if ($contents !== false
                                && preg_match('/Allow\s+from\s+all|Require\s+all\s+granted|RewriteEngine\s+Off/i', $contents)
                                && !preg_match('/FilesMatch.*php/i', $contents)) {
                                $flagged = true;
                                $reasons[] = 'Suspicious .htaccess: permissively allows access in an upload folder.';
                            }
                        }
                    }
                }

                // content signature scan runs in both modes, files only
                if (!$isDir) {
                    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                    if (MuruguardHelper::scanFileContent($path, $ext, $sig, $maxSize, $reasons)) {
                        // Strip only this scanner's own narrow, known,
                        // per-file self-matches (see
                        // SELF_CONTENT_SIGNATURE_EXEMPTIONS) -- never a
                        // blanket skip, so an actually-injected backdoor
                        // in this scanner's own files is still caught.
                        $reasons = MuruguardHelper::filterSelfSignatureExemptions($relCheck, $sig, $reasons);
                        // Narrow, per-file, per-signature exemption for
                        // known-legitimate third-party libraries (see
                        // KNOWN_LIBRARY_SIGNATURE_EXEMPTIONS) -- same
                        // "never blanket-skip a path" reasoning as above.
                        $reasons = MuruguardHelper::filterKnownLibrarySignatureExemptions($relCheck, $sig, $reasons);
                        // Full content-signature exemption for exactly
                        // one file (scan-progress.php) -- see
                        // filterStubProtectedDataCacheExemptions()'s own
                        // docblock for why this one is structurally
                        // different from the two narrower filters above.
                        $reasons = MuruguardHelper::filterStubProtectedDataCacheExemptions($relCheck, $reasons, $path);
                        if (!empty($reasons)) {
                            $flagged = true;
                        }
                    }
                }

                // known-malicious filename pattern (location-independent, runs both modes --
                // malware doesn't respect the upload-vs-code folder distinction)
                // Known Joomla 3 core files (com_privacy's request.xml.php
                // controller, ...) skip the filename IOCs -- their exact
                // names are legitimate there; content signatures below
                // still run on them.
                if (!$isDir && !$isKnownSafeEntry && !MuruguardHelper::isJoomla3CoreExactPath($relCheck, $sig)) {
                    // Joomla's own legacy MVC convention names a view's
                    // per-format render file view.<format>.php --
                    // view.html.php, view.xml.php, view.json.php,
                    // view.rss.php, view.atom.php, ... -- ubiquitous
                    // across virtually every real component that outputs
                    // more than plain HTML (sitemaps, feeds, JSON APIs),
                    // this scanner's own admin/views/scanner/view.html.php
                    // included. The .xml.php entry in
                    // SUSPICIOUS_FILENAME_REGEXES exists for a webshell/
                    // dropper disguised as an XML file, not this
                    // well-known naming convention -- confirmed false
                    // positive on com_osmap's views/xml/view.xml.php.
                    $isStandardMvcFormatView = (bool) preg_match('/^view\.[a-z0-9]+\.php$/i', $basename);
                    foreach ($sig['SUSPICIOUS_FILENAME_REGEXES'] as $re) {
                        if ($re === '/\.xml\.php$/i' && $isStandardMvcFormatView) continue;
                        if (preg_match($re, $basename)) { $flagged = true; $reasons[] = 'Filename matches known malicious pattern.'; break; }
                    }
                }

                // .htaccess rewriting a non-PHP extension to execute as PHP
                // (location-independent, runs both modes) -- confirmed real
                // backdoor technique: pairs with a *.php.json-style dropped
                // file (see SUSPICIOUS_FILENAME_REGEXES above) to defeat any
                // filter that only blocks the .php extension itself.
                if (!$isDir && !$isKnownSafeEntry && in_array(strtolower($basename), ['.htaccess', '.user.ini', 'php.ini'], true)) {
                    $htaccessContents = @file_get_contents($path, false, null, 0, 8192);
                    if ($htaccessContents !== false) {
                        if (strtolower($basename) === '.htaccess') {
                            $handlerHijack = MuruguardHelper::checkMaliciousHtaccessHandler($htaccessContents);
                            if ($handlerHijack !== null) { $flagged = true; $reasons[] = $handlerHijack; }
                            // A .htaccess in a sub-folder that sends visitors
                            // to another site (search-engine spam redirects).
                            $foreignRedirect = MuruguardHelper::checkHtaccessForeignRedirect($htaccessContents, MuruguardHelper::currentSiteHost());
                            if ($foreignRedirect !== null) { $flagged = true; $reasons[] = $foreignRedirect; }
                        }
                        $autoPrepend = MuruguardHelper::checkPhpAutoPrependDirective($htaccessContents);
                        if ($autoPrepend !== null) { $flagged = true; $reasons[] = $autoPrepend; }
                    }
                }

                // core-path masquerade check (location-based, runs both modes)
                $masq = MuruguardHelper::checkCoreMasquerade($relCheck, $isDir, $sig, $path);
                if ($masq !== null) { $flagged = true; $reasons[] = $masq; }

                // junk auto-generated template folder check (location-based, runs both modes)
                $junkTpl = MuruguardHelper::checkJunkTemplateFolder($relCheck, $sig, $path, $registeredTemplates);
                if ($junkTpl !== null) { $flagged = true; $reasons[] = $junkTpl; }

                // junk module/plugin/component folder check (location-based, runs both modes)
                $junkExt = MuruguardHelper::checkJunkExtensionFolder($relCheck, $sig, $registeredPlugins, $registeredComponents, $path);
                if ($junkExt !== null) { $flagged = true; $reasons[] = $junkExt; }

                // stray index.php structural check (location-based, runs both modes)
                if (!$isDir && !$isKnownSafeEntry) {
                    $strayIdx = MuruguardHelper::checkStrayIndexPhp($relCheck, $path, $sig);
                    if ($strayIdx !== null) { $flagged = true; $reasons[] = $strayIdx; }
                }

                if ($flagged) {
                    $this->seenAbs[$path] = true;
                    // Admin-dismissed false positives (see the "Mark as
                    // Safe" button on each finding row) are keyed on the
                    // exact reasons text, not just the path -- if this
                    // exact same file later matches something DIFFERENT
                    // (e.g. an attacker overwrites a previously-dismissed
                    // path with a real backdoor, which trips a different/
                    // additional signature), the fingerprint no longer
                    // matches and it reappears as a fresh finding rather
                    // than staying silently suppressed forever.
                    $fingerprint = MuruguardHelper::fingerprintReasons($reasons);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $relCheck, $fingerprint)) {
                        MuruguardHelper::recordFinding($this->fileFindings, $path, $this->root, $reasons, $isDir);
                    }
                }
                });
            } catch (MuruguardScanChunkTimeout $e) {
                // Whatever this area's walk found before hitting the
                // deadline is already recorded in $this->fileFindings above
                // -- kept as a partial result rather than discarded, with
                // the area marked truncated so runScanChunk() can report it
                // honestly instead of implying a complete scan. The count
                // of entries walked lets the next chunk continue from here.
                $this->truncatedAreas[$relDir] = $this->walkCounter;
                break;
            }
        }

        // Shallow webroot scan
        $rootItems = ($includeWebrootCore && $this->isAreaSelected('webroot')) ? (@scandir($this->root) ?: []) : [];
        foreach ($rootItems as $it) {
            if ($it === '.' || $it === '..') continue;
            $p = $this->root . '/' . $it;
            if (isset($this->seenAbs[$p])) continue;
            if (preg_match($selfLogPattern, $it)) continue;
            if (preg_match($selfBackupPattern, $it)) continue;
            if (preg_match($googleVerifyPattern, $it)) continue;
            if ($isIgnored($it)) continue;

            if (is_dir($p)) {
                if (in_array(strtolower($it), array_map('strtolower', $sig['KNOWN_ROOT_DIRS']), true)) {
                    continue;
                }

                if (MuruguardHelper::isKnownExtensionDataFolder($it, $sig, $registeredComponents)
                    || MuruguardHelper::isComposerVendorFolder($it, $this->root)) {
                    // Recognized companion data folder of an installed
                    // extension (e.g. ConvertForms' own convertforms_<alias>
                    // custom-code folders) or Composer's own vendor/
                    // dependency tree -- not itself suspicious, but still
                    // content-scanned file by file so malware planted here
                    // later doesn't get a free pass just because the
                    // folder name matches a known convention.
                    $this->seenAbs[$p] = true;
                    MuruguardHelper::walkDir($p, function (string $innerPath, bool $innerIsDir) use ($sig, $maxSize, $falsePositives) {
                        if ($innerIsDir || isset($this->seenAbs[$innerPath])) return;
                        $this->seenAbs[$innerPath] = true;
                        $innerExt = strtolower(pathinfo($innerPath, PATHINFO_EXTENSION));
                        $innerReasons = [];
                        MuruguardHelper::scanFileContent($innerPath, $innerExt, $sig, $maxSize, $innerReasons);
                        if (!empty($innerReasons)) {
                            $innerRel = ltrim(str_replace($this->root, '', $innerPath), '/');
                            $innerFp = MuruguardHelper::fingerprintReasons($innerReasons);
                            if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $innerRel, $innerFp)) {
                                MuruguardHelper::recordFinding($this->fileFindings, $innerPath, $this->root, $innerReasons, false);
                            }
                        }
                    });
                    continue;
                }

                // Unrecognized directory -- flagged ONCE, at the folder
                // itself, unless it's made up ENTIRELY of static assets
                // (fonts/images/css/...), a common, legitimate custom
                // template/page-builder asset folder, not a malware
                // staging area (no directory-level flag at all in that
                // case). Confirmed real false positive, twice: first a
                // top-level /fonts folder was flagged High identically to
                // a dropped-shell folder purely because the reason text
                // contained the word "unrecognized"; downgrading it to
                // Medium instead of removing the flag entirely was STILL
                // reported back as a false positive needing individual
                // per-file dismissal.
                //
                // Files inside are never ALSO individually flagged with a
                // blanket "inside an unrecognized folder" structural
                // reason, regardless of which case above applies -- only
                // content-signature scanning decides whether an inner file
                // gets its own finding, same as a known extension's data
                // folder just above. Confirmed real case: a legitimate
                // ~200MB unrelated application (a separate forum/hotspot
                // tool, nothing to do with Joomla) installed in its own
                // top-level folder produced 16,000+ duplicate High-
                // confidence findings, one per file, every single one
                // just repeating the same fact the ONE folder-level
                // finding already states. An actual payload hiding
                // anywhere in the tree is still caught on its own merits
                // by the unconditional content scan below.
                $this->seenAbs[$p] = true;
                $innerFiles = [];
                $hasNonAssetContent = false;
                MuruguardHelper::walkDir($p, function (string $innerPath, bool $innerIsDir) use (&$innerFiles, &$hasNonAssetContent, $sig) {
                    if ($innerIsDir) return;
                    $innerFiles[] = $innerPath;
                    $innerExt = strtolower(pathinfo($innerPath, PATHINFO_EXTENSION));
                    if (!in_array($innerExt, $sig['ICONFONT_ALLOWED_EXTENSIONS'], true)) $hasNonAssetContent = true;
                });

                if ($hasNonAssetContent) {
                    $dirReason = 'Unrecognized directory directly in the Joomla webroot — not part of a standard install.';
                    $dirFp = MuruguardHelper::fingerprintReasons([$dirReason]);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $it, $dirFp)) {
                        MuruguardHelper::recordFinding($this->fileFindings, $p, $this->root, $dirReason, true);
                    }
                }

                foreach ($innerFiles as $innerPath) {
                    if (isset($this->seenAbs[$innerPath])) continue;
                    $this->seenAbs[$innerPath] = true;
                    $innerExt = strtolower(pathinfo($innerPath, PATHINFO_EXTENSION));
                    $innerReasons = [];
                    MuruguardHelper::scanFileContent($innerPath, $innerExt, $sig, $maxSize, $innerReasons);
                    if (!empty($innerReasons)) {
                        $innerRel = ltrim(str_replace($this->root, '', $innerPath), '/');
                        $innerFp = MuruguardHelper::fingerprintReasons($innerReasons);
                        if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $innerRel, $innerFp)) {
                            MuruguardHelper::recordFinding($this->fileFindings, $innerPath, $this->root, $innerReasons, false);
                        }
                    }
                }
                continue;
            }

            if (!is_file($p)) continue;
            if (in_array(strtolower($it), array_map('strtolower', $sig['KNOWN_ROOT_FILES']), true)) {
                // Known by name, so never "unrecognized" -- but still read:
                // configuration.php, .htaccess and .user.ini used to be
                // skipped outright, so a payload in them was never seen.
                if (!in_array($it, $sig['CORE_ENTRY_POINTS'], true)) {
                    $this->scanKnownFileContent($p, $sig, $maxSize, $falsePositives);
                }
                continue;
            }
            if (preg_match($sig['MYJOOMLA_CHECKSUM_FILE_RE'], $it)) continue;
            $relCheck = ltrim(str_replace($this->root, '', $p), '/');
            if (in_array($relCheck, $sig['KNOWN_SAFE_RELATIVE_FILES'], true)) continue;

            $flaggedRoot = false;
            $reasonsRoot = [];
            foreach ($sig['SUSPICIOUS_FILENAME_REGEXES'] as $re) {
                if (preg_match($re, $it)) { $flaggedRoot = true; $reasonsRoot[] = 'Filename matches known malicious pattern.'; break; }
            }
            foreach ($sig['ROOT_SUSPICIOUS_FILENAME_REGEXES'] as $re) {
                if (preg_match($re, $it)) { $flaggedRoot = true; $reasonsRoot[] = 'Filename resembles a known dropped-shell naming pattern.'; break; }
            }
            foreach ($sig['CONFIG_BACKUP_PATTERNS'] as $re) {
                if (preg_match($re, $it)) { $flaggedRoot = true; $reasonsRoot[] = 'Backup/duplicate configuration file — leaks the same credentials as configuration.php.'; break; }
            }

            $masqRoot = MuruguardHelper::checkCoreMasquerade($relCheck, false, $sig, $p);
            if ($masqRoot !== null) { $flaggedRoot = true; $reasonsRoot[] = $masqRoot; }

            $dotfileRoot = MuruguardHelper::checkRootLevelDotfile($it);
            if ($dotfileRoot !== null) { $flaggedRoot = true; $reasonsRoot[] = $dotfileRoot; }

            $extR = strtolower(pathinfo($p, PATHINFO_EXTENSION));
            MuruguardHelper::scanFileContent($p, $extR, $sig, $maxSize, $reasonsRoot);
            if (count($reasonsRoot) > ($flaggedRoot ? 1 : 0)) $flaggedRoot = true;

            $benignStaticExts = ['css', 'jpg', 'jpeg', 'png', 'gif', 'svg', 'ico', 'webp', 'woff', 'woff2', 'ttf', 'eot', 'map'];
            if (!$flaggedRoot && !in_array($extR, $benignStaticExts, true)) {
                $flaggedRoot = true;
                $reasonsRoot[] = 'Unrecognized file directly in the Joomla webroot — not part of a standard install.';
            }

            if ($flaggedRoot) {
                $this->seenAbs[$p] = true;
                $rootFp = MuruguardHelper::fingerprintReasons($reasonsRoot);
                if (!MuruguardHelper::isFalsePositive($falsePositives, 'file', $relCheck, $rootFp)) {
                    MuruguardHelper::recordFinding($this->fileFindings, $p, $this->root, $reasonsRoot, false);
                }
            }
        }

        // Core entry-point integrity + content-signature scan, plus (when
        // the site's exact Joomla version is covered by the bundled
        // manifest) a byte-for-byte checksum comparison against the
        // official release -- unambiguous proof of tampering, independent
        // of and stronger than every heuristic check here.
        $joomlaVersion = MuruguardHelper::getInstalledJoomlaVersion($this->root);
        $checksumManifest = MuruguardHelper::getCoreChecksumManifest();

        // The checksum check is chosen by the version in joomla.xml, so
        // editing that one number switched it off. Joomla's own Version
        // class must agree; if not, say so.
        $classVersion = MuruguardHelper::getJoomlaVersionFromVersionClass($this->root);
        if ($includeWebrootCore && $this->isAreaSelected('core_entry') && $joomlaVersion !== null && $classVersion !== null && $joomlaVersion !== $classVersion) {
            $manifestAbs = $this->root . '/administrator/manifests/files/joomla.xml';
            MuruguardHelper::recordFinding($this->fileFindings, $manifestAbs, $this->root, [
                "The Joomla version in joomla.xml ({$joomlaVersion}) does not match the version in libraries/src/Version.php ({$classVersion}). One of them was edited -- core file checksums are chosen by this version, so check both files.",
            ], false);
        }

        $coreEntries = ($includeWebrootCore && $this->isAreaSelected('core_entry')) ? $sig['CORE_ENTRY_POINTS'] : [];
        foreach ($coreEntries as $relEntry) {
            $absEntry = $this->root . '/' . $relEntry;
            if (!is_file($absEntry)) continue;
            $size = @filesize($absEntry);
            if ($size === false || $size > $maxSize) continue;
            $contents = @file_get_contents($absEntry);
            if ($contents === false) continue;

            $reasonsEntry = [];
            $issue = MuruguardHelper::checkCoreIndexIntegrity($contents);
            if ($issue !== null) $reasonsEntry[] = $issue;

            $ext = strtolower(pathinfo($absEntry, PATHINFO_EXTENSION));
            MuruguardHelper::scanFileContent($absEntry, $ext, $sig, $maxSize, $reasonsEntry);

            $checksumIssue = MuruguardHelper::checkCoreFileChecksum($relEntry, $absEntry, $joomlaVersion, $checksumManifest);
            if ($checksumIssue !== null) $reasonsEntry[] = $checksumIssue;

            if (!empty($reasonsEntry)) {
                $this->seenAbs[$absEntry] = true;
                MuruguardHelper::recordFinding($this->fileFindings, $absEntry, $this->root, $reasonsEntry, false);
            }
        }

        // Checksum-only pass for the remaining manifest-covered static
        // files (includes/framework.php, robots.txt.dist, htaccess.txt,
        // web.config.txt) -- none of these paths are reached by any other
        // scan pass above, so there's no risk of a second recordFinding()
        // call on the same file silently overwriting an earlier finding.
        if ($includeWebrootCore && $this->isAreaSelected('core_entry') && $joomlaVersion !== null && isset($checksumManifest[$joomlaVersion])) {
            $staticCoreFiles = ['includes/framework.php', 'robots.txt.dist', 'htaccess.txt', 'web.config.txt'];
            foreach ($staticCoreFiles as $relEntry) {
                $absEntry = $this->root . '/' . $relEntry;
                if (isset($this->seenAbs[$absEntry]) || !is_file($absEntry)) continue;

                $checksumIssue = MuruguardHelper::checkCoreFileChecksum($relEntry, $absEntry, $joomlaVersion, $checksumManifest);
                if ($checksumIssue !== null) {
                    $this->seenAbs[$absEntry] = true;
                    MuruguardHelper::recordFinding($this->fileFindings, $absEntry, $this->root, [$checksumIssue], false);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Database scan
    // ------------------------------------------------------------------

    public function scanDatabase(): void
    {
        if (!$this->isAreaSelected('database')) return;

        $db  = $this->getDatabase();
        $sig = MuruguardHelper::getSignatures();
        $falsePositives = MuruguardHelper::getFalsePositiveLookup();

        try {
            $query = $db->getQuery(true)
                ->select('u.id, u.name, u.username, u.email, u.registerDate, u.lastvisitDate')
                ->from($db->quoteName('#__users', 'u'))
                ->join('INNER', $db->quoteName('#__user_usergroup_map', 'm') . ' ON ' . $db->quoteName('m.user_id') . ' = ' . $db->quoteName('u.id'))
                ->where($db->quoteName('m.group_id') . ' IN (SELECT id FROM ' . $db->quoteName('#__usergroups') . ' WHERE title IN (' . $db->quote('Super Users') . ',' . $db->quote('Super User') . '))')
                ->order($db->quoteName('u.registerDate') . ' DESC');
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
            foreach ($rows as $row) {
                $suspicious = false;
                $why = [];
                if (stripos($row['email'], 'secure.local') !== false) { $suspicious = true; $why[] = 'email domain: secure.local (known attacker marker)'; }
                if (preg_match('/webmanager\d+|codex|sppb/i', $row['username'])) { $suspicious = true; $why[] = 'username matches known attacker pattern'; }
                // A widespread automated attack wave injects a rogue Super
                // User account using exactly this email address on hijacked
                // sites (regardless of username/display name, which vary).
                // Exact match only -- this is a known literal marker, not a
                // pattern, so no false positives on legitimate similar-looking
                // addresses.
                if (strcasecmp(trim((string) $row['email']), 'joomla@test.com') === 0) { $suspicious = true; $why[] = 'known mass-attack marker: injected admin account using joomla@test.com'; }
                // Only a "suspicious" row is ever a candidate for dismissal
                // -- an already-normal row has nothing to suppress.
                if ($suspicious) {
                    $fingerprint = MuruguardHelper::fingerprintReasons($why);
                    if (MuruguardHelper::isFalsePositive($falsePositives, 'superusers', (string) $row['id'], $fingerprint)) {
                        $suspicious = false;
                        $why = [];
                    }
                }
                $this->dbFindings['superusers'][] = [
                    'id' => $row['id'], 'name' => $row['name'], 'username' => $row['username'],
                    'email' => $row['email'], 'registered' => $row['registerDate'], 'lastvisit' => $row['lastvisitDate'],
                    'suspicious' => $suspicious, 'why' => implode('; ', $why), 'why_list' => $why,
                ];
            }
        } catch (\Throwable $e) { /* table missing or query failed -- non-fatal */ }

        try {
            $query = $db->getQuery(true)->select('id, title, link, params')->from($db->quoteName('#__menu'));
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
            foreach ($rows as $row) {
                $params = (string) ($row['params'] ?? '');
                $matches = [];
                foreach ($sig['MENU_XSS_PATTERNS'] as $label => $re) {
                    if (preg_match($re, $params)) $matches[] = $label;
                }
                if (!empty($matches)) {
                    $fingerprint = MuruguardHelper::fingerprintReasons($matches);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'menu_xss', (string) $row['id'], $fingerprint)) {
                        $this->dbFindings['menu_xss'][] = [
                            'id' => $row['id'], 'title' => $row['title'], 'link' => $row['link'], 'matches' => $matches,
                        ];
                    }
                }
            }
        } catch (\Throwable $e) { /* non-fatal */ }

       try {

    $this->dbFindings['sppb_assets'] = [];
    $this->dbFindings['rogue_iconfont'] = [];

    // Load all SP Page Builder assets
    $query = $db->getQuery(true)
        ->select('*')
        ->from($db->quoteName('#__sppagebuilder_assets'))
        ->order($db->quoteName('id') . ' DESC');

    $db->setQuery($query);
    $rows = $db->loadAssocList() ?: [];


    foreach ($rows as $row) {

        $reasons = [];

        // The real #__sppagebuilder_assets column is "assets" (a JSON/text
        // blob of the actual icon-font/asset definition) -- NOT
        // "asset_value", which doesn't exist in this table at all and was
        // silently always empty, meaning every payload check below matched
        // against '' on every real install regardless of what this row
        // actually contained. css_path is checked too: it's the other
        // attacker-controllable text field here, and should only ever
        // reference a real .css file -- never inline code, never a PHP path.
        $assetValue = (string) ($row['assets'] ?? '');
        $cssPath    = (string) ($row['css_path'] ?? '');
        $type       = strtolower((string) ($row['type'] ?? ''));
        $name       = strtolower((string) ($row['name'] ?? ''));
        $createdBy  = (int) ($row['created_by'] ?? 0);


        /*
         * Payload detection -- runs against every row regardless of type or
         * name. A "known good" iconfont name (icofont, icomoon, ...) is
         * only ever a name -- it is never a substitute for actually
         * checking what this row's content contains, since nothing stops
         * an attacker from naming a malicious row "icofont" too.
         */
        foreach ([$assetValue, $cssPath] as $content) {
            if (stripos($content, 'xss.report') !== false) {
                $reasons[] = 'Contains xss.report';
            }

            if (stripos($content, 'base64_decode') !== false) {
                $reasons[] = 'Contains base64_decode()';
            }

            if (stripos($content, 'eval(') !== false) {
                $reasons[] = 'Contains eval()';
            }

            if (stripos($content, '<script') !== false) {
                $reasons[] = 'Contains script tag';
            }

            if (preg_match('/on(load|error|click|mouseover)\s*=/i', $content)) {
                $reasons[] = 'Contains JavaScript event handler';
            }

            if (preg_match('/<\?php|<\?=\s*[\$A-Za-z_(]/i', $content)) {
                $reasons[] = 'Contains a PHP open tag';
            }
        }

        // css_path should only ever point at a real stylesheet -- a path
        // ending in .php/.phtml/etc. (or any other executable extension)
        // is a direct way to smuggle a runnable file reference through a
        // field nobody expects to hold one.
        if ($cssPath !== '') {
            $cssExt = strtolower(pathinfo(parse_url($cssPath, PHP_URL_PATH) ?: $cssPath, PATHINFO_EXTENSION));
            if (in_array($cssExt, $sig['EXEC_EXTS'], true)) {
                $reasons[] = "css_path references an executable file (.{$cssExt}), not a stylesheet";
            }
        }


        /*
         * Iconfont detection -- a secondary, name-based signal ON TOP OF
         * the content checks above, not a replacement for them. A row
         * named exactly "icofont" (SP Page Builder's own bundled default)
         * still goes through every content check above; this block only
         * adds an extra reason when the name itself doesn't match that
         * one known-legitimate default.
         */
        if ($type === 'iconfont') {

            // Ignore known-legitimate iconfont names (see
            // KNOWN_GOOD_ICONFONT_NAMES's docblock for why this is only
            // a secondary signal, not a substitute for the content checks
            // above).
            if (!in_array($name, $sig['KNOWN_GOOD_ICONFONT_NAMES'], true)) {

                $iconfontReasons = ['Non-default iconfont'];
                if ($createdBy === 0) {
                    $iconfontReasons[] = 'Created by Guest/System';
                }
                $reasons = array_merge($reasons, $iconfontReasons);

                $rogueFingerprint = MuruguardHelper::fingerprintReasons($iconfontReasons);
                if (!MuruguardHelper::isFalsePositive($falsePositives, 'rogue_iconfont', (string) $row['id'], $rogueFingerprint)) {
                    $rogueRow = $row;
                    $rogueRow['scan_reasons'] = $iconfontReasons;
                    $this->dbFindings['rogue_iconfont'][] = $rogueRow;
                }
            }
        }


        /*
         * Only store suspicious rows
         */
        if (!empty($reasons)) {

            $row['scan_reasons'] = array_values(array_unique($reasons));

            $sppbFingerprint = MuruguardHelper::fingerprintReasons($row['scan_reasons']);
            if (!MuruguardHelper::isFalsePositive($falsePositives, 'sppb_assets', (string) $row['id'], $sppbFingerprint)) {
                $this->dbFindings['sppb_assets'][] = $row;
            }
        }
    }


} catch (\Throwable $e) {

    // table missing or query failed
    $this->dbFindings['sppb_assets'] = [];
    $this->dbFindings['rogue_iconfont'] = [];

}

        $this->scanSppbPages($falsePositives);

        try {
            $query = $db->getQuery(true)->select('id, template, title, params, client_id')->from($db->quoteName('#__template_styles'));
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
            $registeredTemplates = $this->getRegisteredTemplates();
            foreach ($rows as $row) {
                $matches = [];
                foreach ($sig['DEFACEMENT_PATTERNS'] as $pattern) {
                    if (preg_match($pattern, (string) $row['params'], $m)) $matches[] = $m[0];
                }

                $templateName = (string) $row['template'];
                $clientId     = (int) $row['client_id'];
                $isSystemTemplate = in_array(strtolower($templateName), $sig['TEMPLATE_SYSTEM_FOLDER_NAMES'], true);

                if ($templateName !== '' && !$isSystemTemplate) {
                    // Strongest, hardest-to-fake signal first: cross-reference
                    // Joomla's own #__extensions registry -- see
                    // getRegisteredTemplates()/checkJunkTemplateFolder() for
                    // why this is checked ahead of the on-disk manifest
                    // check below. A real attack faked the folder AND its
                    // templateDetails.xml AND even a matching #__extensions
                    // row, but every faked #__extensions row was left
                    // disabled -- unlike every genuinely-installed template.
                    if ($registeredTemplates !== null) {
                        $key = $clientId . '|' . strtolower($templateName);
                        if (!array_key_exists($key, $registeredTemplates)) {
                            $matches[] = "No matching #__extensions row of type \"template\" exists for \"{$templateName}\" -- Joomla never actually installed this as a real template";
                        } elseif (!$registeredTemplates[$key]) {
                            $matches[] = "Matching #__extensions row for \"{$templateName}\" exists but is disabled (enabled = 0) -- a strong sign of an injected row rather than a real, active template";
                        }
                    }

                    // Independent, on-disk corroborating signals -- still
                    // checked even when the registry already flagged the
                    // row above, and still useful on their own when the
                    // registry itself is unavailable (see getRegisteredTemplates()).
                    $templateDir = $clientId === 1
                        ? JPATH_ADMINISTRATOR . '/templates/' . $templateName
                        : $this->root . '/templates/' . $templateName;
                    $noManifest = !is_file($templateDir . '/templateDetails.xml');
                    $junkName   = (bool) preg_match($sig['TEMPLATE_STYLE_JUNK_NAME_RE'], $templateName);

                    if ($noManifest) {
                        $matches[] = is_dir($templateDir)
                            ? "Template folder \"{$templateName}\" exists but has no templateDetails.xml manifest -- was never actually installed as a real template, orphaned or injected row"
                            : "Template folder not found on disk ({$templateName}) -- orphaned or injected row";
                    }
                    if ($junkName) {
                        $matches[] = 'Auto-generated junk name pattern (tmpl_xxxxxx)';
                    }
                }

                if (!empty($matches)) {
                    $fingerprint = MuruguardHelper::fingerprintReasons($matches);
                    if (!MuruguardHelper::isFalsePositive($falsePositives, 'template_defacement', (string) $row['id'], $fingerprint)) {
                        $this->dbFindings['template_defacement'][] = [
                            'id' => $row['id'], 'template' => $row['template'], 'title' => $row['title'], 'matches' => $matches,
                        ];
                    }
                }
            }
        } catch (\Throwable $e) { /* non-fatal */ }

        // Known-vulnerability cross-check -- cheap (one #__extensions
        // query + comparing against the already-cached feed, no file I/O),
        // so it runs as part of every scan alongside everything else here.
        $this->dbFindings['vulnerable_extensions'] = $this->getVulnerableExtensions();
    }

    // ------------------------------------------------------------------
    // Actions
    // ------------------------------------------------------------------

    public function deleteTargets(array $targets): array
    {
        $this->fileFindings = $this->getFileFindings();
        $sig = MuruguardHelper::getSignatures();
        $rootReal = realpath($this->root);
        $protectedAbs = array_map(fn($d) => $rootReal . DIRECTORY_SEPARATOR . $d, $sig['PROTECTED_TOP_DIRS']);
        $registeredTemplates = $this->getRegisteredTemplates();
        $flash = [];

        foreach ($targets as $relPath) {
            $relPath = (string) $relPath;
            if (!isset($this->fileFindings[$relPath])) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NOT_FLAGGED', $relPath); continue; }
            $abs = realpath($this->root . '/' . $relPath);
            if ($abs === false) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_VANISHED', $relPath); continue; }
            // Never act on a symlink's target: a flagged link pointing at index.php
            // or a core folder would otherwise delete or rewrite the real thing.
            if (is_link($this->root . '/' . $relPath) || str_replace('\\', '/', $abs) !== str_replace('\\', '/', $rootReal) . '/' . $relPath) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_SYMLINK', $relPath); continue; }
            if (strpos($abs, $rootReal . DIRECTORY_SEPARATOR) !== 0) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_OUTSIDE_ROOT', $relPath); continue; }
            if (basename($abs) === 'configuration.php') { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_PROTECTED', $relPath); continue; }
            if (in_array($abs, $protectedAbs, true) || $abs === $rootReal) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_PROTECTED_DIR', $relPath); continue; }

            if (MuruguardHelper::isProtectedEntryPath($relPath, $sig, $abs, $registeredTemplates)) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_REQUIRED_ENTRY', $relPath);
                continue;
            }

            if (is_dir($abs)) {
                $flash[] = MuruguardHelper::deleteRecursive($abs) ? Text::sprintf('COM_MURUGUARD_FLASH_DELETED_FOLDER', $relPath) : Text::sprintf('COM_MURUGUARD_FLASH_FAILED_PERMISSIONS', $relPath);
            } elseif (is_file($abs)) {
                $flash[] = @unlink($abs) ? Text::sprintf('COM_MURUGUARD_FLASH_DELETED', $relPath) : Text::sprintf('COM_MURUGUARD_FLASH_FAILED_PERMISSIONS', $relPath);
            }
        }

        MuruguardCompat::getSession()->set('muruguard.filefindings', null);
        return $flash;
    }

    /**
     * Surgically repairs selected files instead of deleting them -- for
     * the well-bounded injection patterns this scanner can safely fix
     * (a payload prepended before Joomla's bootstrap/access guard, or a
     * <script> block injected right after <head>) the exact malicious
     * region is known, so it can be stripped while leaving the rest of
     * the file -- a genuinely legitimate Joomla core/template file --
     * completely untouched. A timestamped backup of the original is
     * always written first so the change can be reviewed or reverted.
     */
    public function cleanCodeFiles(array $targets): array
    {
        $this->fileFindings = $this->getFileFindings();
        $rootReal = realpath($this->root);
        $cleanableExts = ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'pht', 'html', 'htm'];
        $flash = [];

        foreach ($targets as $relPath) {
            $relPath = (string) $relPath;
            if (!isset($this->fileFindings[$relPath])) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NOT_FLAGGED', $relPath); continue; }

            $abs = realpath($this->root . '/' . $relPath);
            if ($abs === false || !is_file($abs)) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_VANISHED', $relPath); continue; }
            // Never act on a symlink's target: a flagged link pointing at index.php
            // or a core folder would otherwise delete or rewrite the real thing.
            if (is_link($this->root . '/' . $relPath) || str_replace('\\', '/', $abs) !== str_replace('\\', '/', $rootReal) . '/' . $relPath) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_SYMLINK', $relPath); continue; }
            if (strpos($abs, $rootReal . DIRECTORY_SEPARATOR) !== 0) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_OUTSIDE_ROOT', $relPath); continue; }

            $ext = strtolower(pathinfo($abs, PATHINFO_EXTENSION));
            if (!in_array($ext, $cleanableExts, true)) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NOT_CLEANABLE_TYPE', $relPath);
                continue;
            }

            // Checked explicitly (rather than only relying on
            // file_put_contents()'s return value) so a permissions
            // problem -- the single most common real-world reason a
            // "successful" clean silently doesn't stick on shared
            // hosting -- gets its own clear, actionable message.
            if (!is_writable($abs)) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NOT_WRITABLE', $relPath);
                continue;
            }

            $contents = @file_get_contents($abs);
            if ($contents === false) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_UNREADABLE', $relPath); continue; }

            $result = MuruguardHelper::cleanPrependedPayload($contents);
            if (!$result['changed']) {
                $result = MuruguardHelper::cleanHeadTagInjection($contents);
            }
            if (!$result['changed']) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NO_PATTERN', $relPath);
                continue;
            }

            $backup = $abs . '.muruguard-' . date('Ymd-His') . '.bak';
            if (@copy($abs, $backup) === false) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_NO_BACKUP', $relPath);
                continue;
            }
            if (@file_put_contents($abs, $result['cleaned']) === false) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_FAILED_WRITE', basename($backup), $relPath);
                continue;
            }

            // Verify the write actually stuck by re-reading the file from
            // disk and confirming the same issue no longer matches --
            // catches caching layers, race conditions, or any other way a
            // "successful" write could fail to actually take effect,
            // instead of just trusting file_put_contents()'s return value.
            clearstatcache(true, $abs);
            $verifyContents = @file_get_contents($abs);
            $stillInfected = $verifyContents !== false && (
                MuruguardHelper::cleanPrependedPayload($verifyContents)['changed']
                || MuruguardHelper::cleanHeadTagInjection($verifyContents)['changed']
            );
            if ($stillInfected) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_WARNING_REVERTED', basename($backup), $relPath);
                continue;
            }

            $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_CLEANED', $result['removed_preview'], basename($backup), $relPath);
        }

        MuruguardCompat::getSession()->set('muruguard.filefindings', null);
        return $flash;
    }

    public function cleanMenuXss(array $ids): array
    {
        $db = $this->getDatabase();
        $sig = MuruguardHelper::getSignatures();
        $flash = [];

        foreach ($ids as $id) {
            $id = (int) $id;
            $query = $db->getQuery(true)->select('params')->from($db->quoteName('#__menu'))->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($query);
            $paramsJson = $db->loadResult();
            if ($paramsJson === null) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_ROW_NOT_FOUND', $id); continue; }

            $result = MuruguardHelper::cleanMenuParamsXss((string) $paramsJson, array_values($sig['MENU_XSS_PATTERNS']));
            if (!$result['changed']) { $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_UNPARSEABLE', $id); continue; }

            $update = $db->getQuery(true)->update($db->quoteName('#__menu'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($result['cleaned']))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($update);
            $db->execute();
            $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_CLEANED_MENU', $id);
        }
        return $flash;
    }

    /** Deletes selected rogue SP Page Builder asset rows. */
    public function deleteRogueAssets(array $ids): void
    {
        if (empty($ids)) return;
        $db = $this->getDatabase();
        $ids = array_map('intval', $ids);
        $query = $db->getQuery(true)->delete($db->quoteName('#__sppagebuilder_assets'))
            ->where($db->quoteName('id') . ' IN (' . implode(',', $ids) . ')');
        $db->setQuery($query);
        $db->execute();
    }

    /**
     * Deletes selected #__template_styles rows, but only the ones
     * independently confirmed as junk/injected -- an orphaned template
     * reference (folder not found on disk) or an auto-generated
     * tmpl_xxxxxx name. Rows flagged only for classic defacement TEXT are
     * left alone and reported as skipped: a text match alone isn't a
     * reliable enough signal to safely auto-delete a row that might
     * otherwise be a legitimate style (false positives are more likely
     * there than for the junk-name/orphaned-folder checks). Re-derives
     * each row's flags fresh from the DB rather than trusting the cached
     * scan result, same as cleanMenuXss() above.
     */
    public function cleanTemplateDefacement(array $ids): array
    {
        $db  = $this->getDatabase();
        $sig = MuruguardHelper::getSignatures();
        $flash = [];

        // Same registry cross-reference scanDatabase() already reports
        // against (see getRegisteredTemplates()) -- without this, a row
        // flagged ONLY because its #__extensions record is missing/
        // disabled (manifest present, name not junk-patterned) would show
        // up as a template_defacement finding but then get skipped here
        // every time, since neither $noManifest nor $junkName alone would
        // be true for it.
        $registeredTemplates = $this->getRegisteredTemplates();

        foreach ($ids as $id) {
            $id = (int) $id;
            $query = $db->getQuery(true)->select('id, template, client_id')
                ->from($db->quoteName('#__template_styles'))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($query);
            $row = $db->loadAssoc();
            if ($row === null) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_ROW_NOT_FOUND', $id);
                continue;
            }

            $templateDir = ((int) $row['client_id']) === 1
                ? JPATH_ADMINISTRATOR . '/templates/' . $row['template']
                : $this->root . '/templates/' . $row['template'];
            $isSystemTemplate = in_array(strtolower((string) $row['template']), $sig['TEMPLATE_SYSTEM_FOLDER_NAMES'], true);
            $noManifest = !$isSystemTemplate && $row['template'] !== '' && !is_file($templateDir . '/templateDetails.xml');
            $junkName   = (bool) preg_match($sig['TEMPLATE_STYLE_JUNK_NAME_RE'], (string) $row['template']);

            $registryProblem = false;
            if (!$isSystemTemplate && $row['template'] !== '' && $registeredTemplates !== null) {
                $key = ((int) $row['client_id']) . '|' . strtolower((string) $row['template']);
                $registryProblem = !array_key_exists($key, $registeredTemplates) || !$registeredTemplates[$key];
            }

            if (!$noManifest && !$junkName && !$registryProblem) {
                $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_SKIPPED_REVIEW_DEFACEMENT', $id);
                continue;
            }

            $delete = $db->getQuery(true)->delete($db->quoteName('#__template_styles'))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($delete);
            $db->execute();
            $flash[] = Text::sprintf('COM_MURUGUARD_FLASH_DELETED_DEFACEMENT', $id);
        }

        return $flash;
    }

    /**
     * Checks the installed SP Page Builder version from #__extensions and
     * returns a warning array if it is a vulnerable build.
     */
    public function getSppbVersionWarning(): ?array
    {
        try {
            $db    = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['manifest_cache', 'enabled']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_sppagebuilder'))
                ->where($db->quoteName('type')    . ' = ' . $db->quote('component'));
            $db->setQuery($query);
            $row = $db->loadAssoc();
        } catch (\Throwable $e) {
            return null;
        }

        if (empty($row)) return null;

        $manifest = json_decode($row['manifest_cache'] ?? '{}', true);
        $version  = trim($manifest['version'] ?? '');

        if ($version === '') {
            return ['safe' => null, 'version' => 'unknown', 'major' => 0, 'enabled' => (bool) $row['enabled']];
        }

        $parts = array_map('intval', explode('.', $version));
        $major = $parts[0] ?? 0;
        $minor = $parts[1] ?? 0;
        $patch = $parts[2] ?? 0;

        $isSafe = ($major > 6)
            || ($major === 6 && $minor > 6)
            || ($major === 6 && $minor === 6 && $patch >= 2);

        return [
            'safe'    => $isSafe,
            'version' => $version,
            'major'   => $major,
            'enabled' => (bool) $row['enabled'],
        ];
    }

    /**
     * Checks whether Joomla's own update-checking mechanism is actually
     * working -- not whether an update exists, but whether Joomla is even
     * capable of finding out. A real, reported failure mode: a site gets
     * compromised through an unpatched extension because Joomla's "Check
     * for Updates" screen never showed an update was available, not
     * because none existed, but because the plumbing that tells Joomla
     * WHERE to look was broken -- #__update_sites.enabled = 0 (Joomla
     * itself calls this out with a one-line warning on the Find Updates
     * screen, see com_installer's UpdateController::find(), but that's
     * easy to never see -- most admins only ever look at the Update list
     * itself, which just silently omits anything whose update site is
     * broken instead of explaining why), or no #__update_sites_extensions
     * link row at all.
     *
     * Deliberately narrow: only the extensions this scanner already has
     * dedicated, name-specific knowledge of elsewhere (SPPB's own version
     * check above, JCE's upload-path signature in getSignatures()) are
     * checked for a totally MISSING update site, since third-party
     * extensions vary too much in normal update-server behaviour to flag
     * that reliably without noise. A DISABLED update site, in contrast,
     * is checked for every installed extension -- Joomla having once
     * registered one and then stopped checking it is unambiguous
     * regardless of which extension it is.
     *
     * Returns null when nothing is wrong -- this is an "only show if
     * there's a real problem" banner, not a status line.
     */
    public function getUpdateSiteHealthWarning(): ?array
    {
        try {
            $db    = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['e.extension_id', 'e.name', 'e.element', 'e.package_id', 'us.update_site_id', 'us.enabled']))
                ->from($db->quoteName('#__extensions', 'e'))
                ->join('LEFT', $db->quoteName('#__update_sites_extensions', 'use') . ' ON ' . $db->quoteName('use.extension_id') . ' = ' . $db->quoteName('e.extension_id'))
                ->join('LEFT', $db->quoteName('#__update_sites', 'us') . ' ON ' . $db->quoteName('us.update_site_id') . ' = ' . $db->quoteName('use.update_site_id'))
                ->where($db->quoteName('e.state') . ' = 0')
                ->where($db->quoteName('e.enabled') . ' = 1');
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
        } catch (\Throwable $e) {
            return null;
        }

        return MuruguardHelper::updateSiteHealth($rows, [
            'com_sppagebuilder' => 'SP Page Builder',
            'com_jce'           => 'JCE Editor',
        ]);
    }

    /**
     * Whether an #__extensions row ships with Joomla itself. Joomla's own list is asked first: core extensions added
     * by a later Joomla update get ids above 10000, so the id alone misses them. The id rule (Joomla gives the
     * extensions of a fresh install ids below 10000) is the fallback when that list is not available.
     */
    protected static function isCoreExtensionRow(array $row): bool
    {
        $id = (int) ($row['extension_id'] ?? 0);
        if ($id > 0 && $id < 10000) return true;
        try {
            if (class_exists('\\Joomla\\CMS\\Extension\\ExtensionHelper') && method_exists('\\Joomla\\CMS\\Extension\\ExtensionHelper', 'checkIfCoreExtension')) {
                return (bool) \Joomla\CMS\Extension\ExtensionHelper::checkIfCoreExtension(
                    (string) ($row['type'] ?? ''),
                    (string) ($row['element'] ?? ''),
                    (int) ($row['client_id'] ?? 0),
                    (string) ($row['folder'] ?? '')
                );
            }
        } catch (\Throwable $e) {
            // fall through: treated as third-party
        }
        return false;
    }

    /**
     * Every installed extension with a parsed version number, keyed by
     * lowercase element -- ['element' => ..., 'type' => ..., 'name' =>
     * ..., 'version' => ...]. Version comes out of manifest_cache the
     * same way getSppbVersionWarning() already parses it for SPPB
     * specifically; here it's done generically for every row so it can
     * be cross-referenced against the known-vulnerability feed. A row
     * with no parseable version is skipped -- nothing to compare it
     * against anyway.
     */
    protected function getInstalledExtensionsWithVersions(): array
    {
        try {
            $db = $this->getDatabase();
            $query = $db->getQuery(true)
                ->select($db->quoteName(['extension_id', 'element', 'type', 'folder', 'client_id', 'name', 'manifest_cache']))
                ->from($db->quoteName('#__extensions'));
            $db->setQuery($query);
            $rows = $db->loadAssocList() ?: [];
        } catch (\Throwable $e) {
            return [];
        }

        $extensions = [];
        foreach ($rows as $row) {
            $element = strtolower(trim((string) $row['element']));
            if ($element === '') continue;

            $manifest = json_decode((string) ($row['manifest_cache'] ?? ''), true);
            $version = is_array($manifest) ? trim((string) ($manifest['version'] ?? '')) : '';
            if ($version === '' || !preg_match('/^\d+(\.\d+)*/', $version)) continue;

            $extensions[] = [
                'element' => $element,
                'type'    => (string) $row['type'],
                'name'    => (string) $row['name'],
                'version' => $version,
                'core'    => self::isCoreExtensionRow($row),
            ];
        }

        return $extensions;
    }

    /**
     * Cross-references installed extensions (see
     * getInstalledExtensionsWithVersions()) against the cached
     * known-vulnerability feed (MuruguardHelper::fetchVulnerabilityFeed(),
     * admin-curated on the dashboard -- see that method's docblock), using
     * plain version_compare() against each advisory's affectedFrom/
     * affectedTo. Both bounds are inclusive; a blank bound means
     * "unbounded on that side" (e.g. no affectedTo -- still unpatched as
     * of publish). Returns one row per match: the advisory plus the
     * actually-installed version, so the UI can show "you have 4.1.0,
     * this affects up to 4.2.1, update to 4.2.3". Independent of whether
     * a full scan has been run -- safe to call any time (e.g. for the
     * top-of-report banner), same as getUpdateSiteHealthWarning().
     */
    public function getVulnerableExtensions(): array
    {
        $advisories = MuruguardHelper::fetchVulnerabilityFeed();
        if (empty($advisories)) return [];

        $installed = $this->getInstalledExtensionsWithVersions();
        if (empty($installed)) return [];

        return MuruguardHelper::matchVulnerabilityAdvisories($advisories, $installed);
    }
}