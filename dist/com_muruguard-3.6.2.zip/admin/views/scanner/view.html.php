<?php
/**
 * @package     com_muruguard
 * @author      ZKRANA <zkranao@gmail.com>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Component\ComponentHelper;

require_once JPATH_ADMINISTRATOR . '/components/com_muruguard/helpers/muruguard.php';

class MuruguardViewScanner extends HtmlView
{
    public $fileFindings = [];
    public $dbFindings = [];
    public $highCount = 0;
    public $medCount = 0;
    public $scanned = false;
    public $scanStartedAt = 0;
    public $sppbWarning = null;
    public $updateSiteHealthWarning = null;
    public $vulnerableExtensions = [];
    public $scanAreas = [];
    public $selectedAreas = [];
    public $cronEnabled = false;
    public $cronToken = '';
    public $alertEmail = '';
    public $lastScheduledRun = null;
    public int $itemsPerPage = 50;
    public $canDelete = false;
    public $canEdit = false;
    public $canAdmin = false;
    public $shieldEnabled = false;
    public $shieldBlockPatterns = false;
    public $shieldBlockBruteForce = false;
    public $shieldThreshold = 5;
    public $shieldWindow = 15;
    public $shieldPluginActive = false;
    public $attackLog = [];
    public ?array $registeredTemplates = null;
    public array $htaccess = [];
    public array $serverLimits = [];
    public $shieldBlockUserAgents = false;
    public $shieldBlockCountries = false;
    public $shieldBlockedCountries = '';
    public bool $hardenLockAdminActions = false;
    public bool $protectedUsersEnabled = false;
    public array $protectedUsersStatus = ['hasSnapshot' => false, 'count' => 0, 'takenAt' => null];
    public array $ipList = [];
    public array $falsePositives = [];
    public int $attackLogArchiveCount = 0;
    public bool $backendAuthEnabled = false;
    public string $backendAuthUsername = '';
    public int $backendAuthActivated = 0;
    public bool $emergencyModeEnabled = false;
    public int $emergencyModeActivated = 0;
    public string $componentVersion = '';
    public string $activePanel = 'dashboard';
    public string $activeSettingsTab = 'general';
    public bool $newsletterBannerDismissed = false;

    // AI Integration -- an admin-supplied API key + model name for each of
    // three providers, one picked as the default. Used only for the
    // per-row "Ask AI" action on a scan finding (see
    // MuruguardHelper::askAi()). Displayed the same way cron_token
    // already is elsewhere on this same Settings panel -- a plain input
    // pre-filled with the real value, same admin-only trust boundary as
    // the rest of this page -- rather than inventing a separate masked-
    // secret system this codebase doesn't otherwise have.
    public string $aiGeminiKey = '';
    public string $aiGeminiModel = '';
    public string $aiDefaultProvider = '';
    // True only when the CHOSEN default provider actually has both an
    // API key and a model name set -- gates whether the "Ask AI" button
    // shows on scan result rows at all, rather than showing a button
    // that would just error every time.
    public bool $aiConfigured = false;

    public function display($tpl = null)
    {
        MuruguardHelper::requireManageAccess();

        // Read straight from the manifest on disk rather than the DB's
        // manifest_cache -- accurate even if files were ever overwritten
        // outside Joomla's own installer/updater flow (manifest_cache
        // only refreshes on an actual install/update through Joomla).
        $manifestPath = JPATH_ADMINISTRATOR . '/components/com_muruguard/muruguard.xml';
        if (is_file($manifestPath)) {
            $manifestXml = @simplexml_load_file($manifestPath);
            if ($manifestXml !== false) {
                $this->componentVersion = (string) $manifestXml->version;
            }
        }

        $app     = Factory::getApplication();
        $session = $app->getSession();

        // What this specific user is authorised to DO, not just view -- the
        // template uses these to hide/disable Delete, Clean, and Settings
        // actions a user's ACL group doesn't grant, rather than showing a
        // button that would just 403 on click.
        $this->canDelete = MuruguardHelper::canDelete();
        $this->canEdit   = MuruguardHelper::canEdit();
        $this->canAdmin  = MuruguardHelper::canAdmin();

        /** @var MuruguardModelScanner $model */
        $model = $this->getModel('Scanner');

        // Show SPPB version warning
        $this->sppbWarning = $model->getSppbVersionWarning();

        // Is Joomla's own update-checking mechanism actually working?
        // Only ever set to a non-null value when there's a real problem --
        // see getUpdateSiteHealthWarning()'s docblock.
        $this->updateSiteHealthWarning = $model->getUpdateSiteHealthWarning();

        // Known-vulnerability cross-check against installed extension
        // versions -- independent of whether a scan has run, same as the
        // update-site-health check above, so the banner shows immediately.
        $this->vulnerableExtensions = $model->getVulnerableExtensions();

        // .htaccess hardening advisor -- read-only, cheap (one file read +
        // a handful of regexes), so it's always available regardless of
        // whether a scan has been run yet.
        $this->htaccess = MuruguardHelper::getHtaccessSuggestions(JPATH_ROOT);
        // Cheap (a couple ini_get/ini_set calls, no I/O) -- always computed
        // rather than gated on scan state, so it's available regardless.
        $this->serverLimits = MuruguardHelper::getServerLimitsInfo();

        // Directory-picker definitions + the user's last selection.
        $this->scanAreas     = MuruguardHelper::getScanAreas();
        $this->selectedAreas = (array) $session->get('muruguard.scan_areas', []);

        // Scheduled-scanning settings, for the in-page Settings panel --
        // the exact same storage System > Global Configuration reads/
        // writes, so both stay in sync with each other automatically.
        $cfgParams = ComponentHelper::getParams('com_muruguard');
        $this->cronEnabled = (bool) $cfgParams->get('cron_enabled', 0);
        $this->cronToken   = (string) $cfgParams->get('cron_token', '');
        $this->itemsPerPage = (int) $cfgParams->get('items_per_page', 50);
        if (!in_array($this->itemsPerPage, [25, 50, 100, 250, 500], true)) {
            $this->itemsPerPage = 50;
        }
        $this->alertEmail  = (string) $cfgParams->get('alert_email', '');
        $this->lastScheduledRun = $model->getLastScheduledRunTime();

        // Protection Mode settings + audit log, for the in-page Settings
        // panel and the new Protection Log tab -- same params blob the
        // plg_system_muruguardshield plugin reads on every request.
        $this->shieldEnabled         = (bool) $cfgParams->get('shield_enabled', 0);
        $this->shieldBlockPatterns   = (bool) $cfgParams->get('shield_block_patterns', 0);
        $this->shieldBlockBruteForce = (bool) $cfgParams->get('shield_block_bruteforce', 0);
        $this->shieldThreshold       = (int) $cfgParams->get('shield_bruteforce_threshold', 5);
        $this->shieldWindow          = (int) $cfgParams->get('shield_bruteforce_window', 15);
        $this->shieldPluginActive    = $model->isShieldPluginActive();
        $this->attackLog             = MuruguardHelper::getAttackLog();
        $this->attackLogArchiveCount = MuruguardHelper::getAttackLogArchiveCount();
        $this->shieldBlockUserAgents = (bool) $cfgParams->get('shield_block_useragents', 0);
        $this->shieldBlockCountries  = (bool) $cfgParams->get('shield_block_countries', 0);
        $this->shieldBlockedCountries = (string) $cfgParams->get('shield_blocked_countries', '');
        $this->hardenLockAdminActions = (bool) $cfgParams->get('harden_lock_admin_actions', 0);
        $this->protectedUsersEnabled  = (bool) $cfgParams->get('protected_users_enabled', 0);
        $protectedUsersState         = MuruguardHelper::loadProtectedUsersState();
        $this->protectedUsersStatus   = $protectedUsersState !== null
            ? ['hasSnapshot' => true, 'count' => count($protectedUsersState['users'] ?? []), 'takenAt' => $protectedUsersState['takenAt'] ?? null]
            : ['hasSnapshot' => false, 'count' => 0, 'takenAt' => null];
        $this->ipList                = MuruguardHelper::getIpList();
        $this->falsePositives        = MuruguardHelper::getFalsePositives();
        // Covers both an explicit dismissal and a successful subscription
        // (subscribeToNewsletter() sets this same flag on success) --
        // either way, the banner has nothing left to ask this site for.
        $this->newsletterBannerDismissed = (bool) $cfgParams->get('newsletter_banner_dismissed', 0);

        // AI Integration -- see MuruguardHelper::askAi() for how these are
        // actually used (only ever server-side, on the per-row "Ask AI"
        // action).
        $this->aiGeminiKey      = (string) $cfgParams->get('ai_gemini_key', '');
        $this->aiGeminiModel    = (string) $cfgParams->get('ai_gemini_model', '');
        // Gemini is the only provider this edition offers, so
        // ai_default_provider is only ever 'gemini' or '' (see
        // MuruguardControllerScanner::saveaisettings()) -- kept as a
        // stored param rather than derived here purely so askai()'s
        // check stays a simple, cheap param read on every "Ask AI" click.
        $this->aiDefaultProvider = (string) $cfgParams->get('ai_default_provider', '');
        $this->aiConfigured = $this->aiDefaultProvider === 'gemini' && $this->aiGeminiKey !== '' && $this->aiGeminiModel !== '';

        $this->backendAuthEnabled     = (bool) $cfgParams->get('backend_auth_enabled', 0);
        $this->backendAuthUsername    = (string) $cfgParams->get('backend_auth_username', '');
        $this->backendAuthActivated   = (int) $cfgParams->get('backend_auth_activated', 0);
        $this->emergencyModeEnabled   = (bool) $cfgParams->get('emergency_mode_enabled', 0);
        $this->emergencyModeActivated = (int) $cfgParams->get('emergency_mode_activated', 0);

        // Restore cached scan results. Deliberately NOT gated on the same
        // 300-second freshness window getFileFindings() uses internally
        // to decide "reuse the cache vs. do a fresh rescan" -- that's a
        // read-time optimisation concern, not a "should results even be
        // shown at all" concern. This used to conflate the two: any bulk
        // action (delete, mark safe, clean code, any DB-row action --
        // Super Users/Menu XSS/SPPB Assets/Defacement included, since ALL
        // of them are gated behind this same file-findings check) taken
        // more than 5 minutes after the original scan -- entirely
        // plausible while reviewing dozens of flagged items one at a
        // time -- redirected back to the "no scan yet, run one" landing
        // screen instead of showing the just-updated results, even
        // though the action itself succeeded. Now "has a scan ever
        // completed this session" (any real timestamp) is enough to show
        // results; getFileFindings() below still transparently re-scans
        // on its own if the underlying cache actually is stale.
        $cachedAt = (int) $session->get('muruguard.filefindings_time', 0);
        $hasCache = $cachedAt > 0;

        if ($hasCache) {
            $this->fileFindings = $model->getFileFindings();
            $this->dbFindings   = $model->getDbFindings();

            // Same #__extensions registry cross-check scanFilesystem()/
            // deleteTargets() already use server-side (see
            // getRegisteredTemplates()) -- the template needs it too so
            // the Suspicious-vs-Cleanable tab routing for a template-root
            // index.php finding uses the strongest available signal, not
            // just the weaker on-disk manifest check.
            $this->registeredTemplates = $model->getRegisteredTemplates();

            $this->highCount = count(array_filter(
                $this->fileFindings,
                function ($f) {
                    return isset($f['confidence']) && $f['confidence'] === 'high';
                }
            ));

            $this->medCount      = count($this->fileFindings) - $this->highCount;
            $this->scanned       = true;
            $this->scanStartedAt = $cachedAt;
        }

        // Which panel the left sidebar submenu (see addSubmenu()) should
        // land on -- a plain custom query param rather than Joomla's
        // reserved &layout=, since there's deliberately no separate
        // tmpl/settings.php file: this component is still one page with
        // everything on it, the submenu just jumps straight to the right
        // part of it (auto-opening the existing Settings panel client-
        // side) rather than a full page reload into an isolated view,
        // which would mean duplicating the scan-results header/stats
        // across separate templates for no real benefit.
        $requestedPanel = $app->input->getCmd('view_panel', 'dashboard');
        $this->activePanel = in_array($requestedPanel, ['dashboard', 'settings'], true) ? $requestedPanel : 'dashboard';

        $requestedSettingsTab = $app->input->getCmd('settings_tab', '');
        // 'protection'/'iplist' merged into 'site_protection' and
        // 'scheduled' merged into 'general' in 3.1.0 -- map any stale
        // redirect/bookmark carrying the old id onto its replacement
        // instead of silently falling back to the default tab.
        $legacySettingsTabMap = ['protection' => 'site_protection', 'iplist' => 'site_protection', 'scheduled' => 'general'];
        if (isset($legacySettingsTabMap[$requestedSettingsTab])) {
            $requestedSettingsTab = $legacySettingsTabMap[$requestedSettingsTab];
        }
        $this->activeSettingsTab = in_array($requestedSettingsTab, ['general', 'site_protection', 'ai', 'guide'], true)
            ? $requestedSettingsTab
            : 'general';

        $this->addToolbar();
        $this->addSubmenu();

        parent::display($tpl);
    }

    protected function addToolbar()
    {
        ToolbarHelper::title(Text::_('COM_MURUGUARD_TITLE'), 'shield');

        // Show Preferences only if the helper supports it
        if (method_exists('ToolbarHelper', 'preferences')) {
            ToolbarHelper::preferences('com_muruguard');
        }

        // Help button intentionally omitted for Joomla 3/4/5/6 compatibility.
    }

    /**
     * Left-sidebar submenu (Dashboard / Settings), the same mechanism
     * com_content/com_banners/... and third-party components like SP
     * Page Builder use for their own multi-page navigation.
     */
    protected function addSubmenu(): void
    {
        \Joomla\CMS\HTML\HTMLHelper::_(
            'sidebar.addEntry',
            Text::_('COM_MURUGUARD_SUBMENU_DASHBOARD'),
            'index.php?option=com_muruguard&view_panel=dashboard',
            $this->activePanel === 'dashboard'
        );
        \Joomla\CMS\HTML\HTMLHelper::_(
            'sidebar.addEntry',
            Text::_('COM_MURUGUARD_SUBMENU_SETTINGS'),
            'index.php?option=com_muruguard&view_panel=settings',
            $this->activePanel === 'settings'
        );
    }
}